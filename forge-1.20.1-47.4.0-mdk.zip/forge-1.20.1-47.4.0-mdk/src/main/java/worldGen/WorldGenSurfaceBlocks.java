/*     */ package com.tmtravlr.lootplusplus.worldGen;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemDye;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.biome.BiomeGenBase;
/*     */ import net.minecraft.world.chunk.IChunkProvider;
/*     */ import net.minecraftforge.common.BiomeDictionary;
/*     */ import net.minecraftforge.fml.common.IWorldGenerator;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WorldGenSurfaceBlocks
/*     */   implements IWorldGenerator
/*     */ {
/*     */   public static class SurfaceGenInfo
/*     */   {
/*     */     public IBlockState toGenerate;
/*     */     public NBTTagCompound blockTag;
/*     */     public boolean bonemeal;
/*     */     public float chancePerChunk;
/*     */     public int triesPerChunk;
/*     */     public int groupSize;
/*     */     public int triesPerGroup;
/*     */     public int heightMin;
/*     */     public int heightMax;
/*  37 */     public HashSet<Block> blocksBl = new HashSet<Block>();
/*  38 */     public HashSet<Block> blocksWl = new HashSet<Block>();
/*  39 */     public HashSet<Material> materialsBl = new HashSet<Material>();
/*  40 */     public HashSet<Material> materialsWl = new HashSet<Material>();
/*  41 */     public HashSet<String> biomeBl = new HashSet<String>();
/*  42 */     public HashSet<String> biomeWl = new HashSet<String>();
/*  43 */     public HashSet<BiomeDictionary.Type> biomeTypeBl = new HashSet<BiomeDictionary.Type>();
/*  44 */     public HashSet<BiomeDictionary.Type> biomeTypeWl = new HashSet<BiomeDictionary.Type>();
/*  45 */     public HashSet<Integer> dimensionBl = new HashSet<Integer>();
/*  46 */     public HashSet<Integer> dimensionWl = new HashSet<Integer>();
/*     */     
/*     */     public SurfaceGenInfo(IBlockState state, NBTTagCompound tag, boolean grow, float chance, int triesChunk, int group, int triesGroup, int heightMin, int heightMax) {
/*  49 */       this.toGenerate = state;
/*  50 */       this.blockTag = tag;
/*  51 */       this.chancePerChunk = chance;
/*  52 */       this.triesPerChunk = triesChunk;
/*  53 */       this.groupSize = group;
/*  54 */       this.triesPerGroup = triesGroup;
/*  55 */       this.bonemeal = grow;
/*  56 */       this.heightMin = heightMin;
/*  57 */       this.heightMax = heightMax;
/*     */     }
/*     */   }
/*     */   
/*  61 */   public static ArrayList<SurfaceGenInfo> surfaceGens = new ArrayList<SurfaceGenInfo>();
/*     */ 
/*     */   
/*     */   public void generate(Random random, int chunkX, int chunkZ, World world, IChunkProvider chunkGenerator, IChunkProvider chunkProvider) {
/*  65 */     int xPos = chunkX * 16;
/*  66 */     int zPos = chunkZ * 16;
/*     */     
/*  68 */     for (SurfaceGenInfo info : surfaceGens) {
/*     */       
/*  70 */       if (info.dimensionBl.contains(Integer.valueOf(world.field_73011_w.func_177502_q())) || (!info.dimensionWl.isEmpty() && !info.dimensionWl.contains(Integer.valueOf(world.field_73011_w.func_177502_q())))) {
/*     */         continue;
/*     */       }
/*     */       
/*  74 */       if (info.chancePerChunk >= random.nextFloat())
/*     */       {
/*  76 */         for (int i = 0; i < info.triesPerChunk; i++) {
/*  77 */           BlockPos tryPos = new BlockPos(xPos + random.nextInt(16), random.nextInt(info.heightMax - info.heightMin) + info.heightMin, zPos + random.nextInt(16));
/*     */           
/*  79 */           BiomeGenBase biome = world.func_180494_b(tryPos);
/*     */           
/*  81 */           if (!info.biomeBl.contains(biome.field_76791_y.toLowerCase()) && (info.biomeWl.isEmpty() || info.biomeWl.contains(biome.field_76791_y.toLowerCase()))) {
/*     */ 
/*     */ 
/*     */             
/*  85 */             boolean shouldGenerate = false;
/*     */             
/*  87 */             for (BiomeDictionary.Type biomeType : BiomeDictionary.getTypesForBiome(biome)) {
/*  88 */               if (info.biomeTypeBl.contains(biomeType)) {
/*     */                 break;
/*     */               }
/*     */               
/*  92 */               if (info.biomeTypeWl.isEmpty() || info.biomeTypeWl.contains(biomeType)) {
/*  93 */                 shouldGenerate = true;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/*  98 */             if (shouldGenerate)
/*     */             {
/*     */ 
/*     */               
/* 102 */               if (canGenerateOnBlock(world, tryPos) && !world.func_175623_d(tryPos.func_177977_b()))
/*     */               {
/*     */ 
/*     */                 
/* 106 */                 if (info.groupSize > 1) {
/* 107 */                   generateBlocks(world, random, tryPos, info);
/*     */                 } else {
/*     */                   
/* 110 */                   generateBlock(world, random, tryPos, info);
/*     */                 }  } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void generateBlocks(World world, Random random, BlockPos pos, SurfaceGenInfo info) {
/* 120 */     for (int tries = 0; tries < info.triesPerGroup; tries++) {
/*     */       
/* 122 */       BlockPos tryPos = pos.func_177982_a(random.nextInt((info.groupSize - 1) * 2) - info.groupSize, random.nextInt((info.groupSize - 1) * 2) - info.groupSize, random.nextInt((info.groupSize - 1) * 2) - info.groupSize);
/*     */       
/* 124 */       if (canGenerateOnBlock(world, tryPos) && !world.func_175623_d(tryPos.func_177977_b()))
/*     */       {
/* 126 */         generateBlock(world, random, tryPos, info);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateBlock(World world, Random random, BlockPos pos, SurfaceGenInfo info) {
/* 134 */     if (pos.func_177956_o() < 0 || pos.func_177956_o() > 255) {
/*     */       return;
/*     */     }
/*     */     
/* 138 */     if (!canGenerateOnBlock(world, pos) || world.func_175623_d(pos.func_177977_b())) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 144 */     Block beneath = world.func_180495_p(pos.func_177977_b()).func_177230_c();
/* 145 */     Material beneathMaterial = beneath.func_149688_o();
/*     */     
/* 147 */     if (info.blocksBl.contains(beneath) || (!info.blocksWl.isEmpty() && !info.blocksWl.contains(beneath))) {
/*     */       return;
/*     */     }
/*     */     
/* 151 */     if (info.materialsBl.contains(beneathMaterial) || (!info.materialsWl.isEmpty() && !info.materialsWl.contains(beneathMaterial))) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 157 */     world.func_175656_a(pos, info.toGenerate);
/*     */     
/* 159 */     if (info.blockTag != null) {
/* 160 */       TileEntity te = world.func_175625_s(pos);
/*     */       
/* 162 */       if (te != null) {
/* 163 */         NBTTagCompound tagToGenerate = (NBTTagCompound)info.blockTag.func_74737_b();
/*     */         
/* 165 */         tagToGenerate.func_74768_a("x", pos.func_177958_n());
/* 166 */         tagToGenerate.func_74768_a("y", pos.func_177956_o());
/* 167 */         tagToGenerate.func_74768_a("z", pos.func_177952_p());
/* 168 */         te.func_145839_a(tagToGenerate);
/*     */       } 
/*     */     } 
/*     */     
/* 172 */     if (info.bonemeal) {
/* 173 */       ItemDye.func_179234_a(new ItemStack(Items.field_151100_aR, 1, 15), world, pos);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean canGenerateOnBlock(World world, BlockPos pos) {
/* 178 */     Block block = world.func_180495_p(pos).func_177230_c();
/*     */     
/* 180 */     return (!(block instanceof net.minecraft.block.BlockLiquid) && !(block instanceof net.minecraftforge.fluids.BlockFluidBase) && block.func_176200_f(world, pos));
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\worldGen\WorldGenSurfaceBlocks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */