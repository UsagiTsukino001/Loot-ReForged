/*     */ package com.tmtravlr.lootplusplus.worldGen;
/*     */ 
/*     */ import com.google.common.base.Predicate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.block.state.pattern.BlockHelper;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.Vec3i;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.biome.BiomeGenBase;
/*     */ import net.minecraft.world.chunk.IChunkProvider;
/*     */ import net.minecraftforge.common.BiomeDictionary;
/*     */ import net.minecraftforge.fml.common.IWorldGenerator;
/*     */ 
/*     */ public class WorldGenUndergroundBlocks
/*     */   implements IWorldGenerator
/*     */ {
/*     */   public static class UndergroundGenInfo {
/*     */     public IBlockState toGenerate;
/*     */     public NBTTagCompound blockTag;
/*     */     public float chancePerChunk;
/*     */     public int triesPerChunk;
/*     */     public int veinLengthMin;
/*     */     public int veinLengthMax;
/*     */     public int veinThicknessMin;
/*     */     public int veinThicknessMax;
/*     */     public int heightMin;
/*     */     public int heightMax;
/*  37 */     public HashSet<Block> blocksBl = new HashSet<Block>();
/*  38 */     public HashSet<Block> blocksWl = new HashSet<Block>();
/*  39 */     public HashSet<Material> materialsBl = new HashSet<Material>();
/*  40 */     public HashSet<Material> materialsWl = new HashSet<Material>();
/*  41 */     public HashSet<String> biomeBl = new HashSet<String>();
/*  42 */     public HashSet<String> biomeWl = new HashSet<String>();
/*  43 */     public HashSet<BiomeDictionary.Type> biomeTypeBl = new HashSet<BiomeDictionary.Type>();
/*  44 */     public HashSet<BiomeDictionary.Type> biomeTypeWl = new HashSet<BiomeDictionary.Type>();
/*  45 */     public HashSet<Integer> dimensionBl = new HashSet<Integer>();
/*  46 */     public HashSet<Integer> dimensionWl = new HashSet<Integer>();
/*     */     
/*     */     public UndergroundGenInfo(IBlockState state, NBTTagCompound tag, float chance, int triesChunk, int lengthMin, int lengthMax, int thicknessMin, int thicknessMax, int heightMin, int heightMax) {
/*  49 */       this.toGenerate = state;
/*  50 */       this.blockTag = tag;
/*  51 */       this.chancePerChunk = chance;
/*  52 */       this.triesPerChunk = triesChunk;
/*  53 */       this.veinLengthMin = lengthMin;
/*  54 */       this.veinLengthMax = lengthMax;
/*  55 */       this.veinThicknessMin = thicknessMin;
/*  56 */       this.veinThicknessMax = thicknessMax;
/*  57 */       this.heightMin = heightMin;
/*  58 */       this.heightMax = heightMax;
/*     */     }
/*     */   }
/*     */   
/*  62 */   public static ArrayList<UndergroundGenInfo> undergroundGens = new ArrayList<UndergroundGenInfo>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generate(Random random, int chunkX, int chunkZ, World world, IChunkProvider chunkGenerator, IChunkProvider chunkProvider) {
/*  69 */     int xPos = chunkX * 16;
/*  70 */     int zPos = chunkZ * 16;
/*     */     
/*  72 */     for (UndergroundGenInfo info : undergroundGens) {
/*     */       
/*  74 */       if (info.dimensionBl.contains(Integer.valueOf(world.field_73011_w.func_177502_q())) || (!info.dimensionWl.isEmpty() && !info.dimensionWl.contains(Integer.valueOf(world.field_73011_w.func_177502_q())))) {
/*     */         continue;
/*     */       }
/*     */       
/*  78 */       if (info.chancePerChunk >= random.nextFloat())
/*     */       {
/*  80 */         for (int i = 0; i < info.triesPerChunk; i++) {
/*  81 */           BlockPos tryPos = new BlockPos(xPos + random.nextInt(16), random.nextInt(info.heightMax - info.heightMin) + info.heightMin, zPos + random.nextInt(16));
/*     */           
/*  83 */           BiomeGenBase biome = world.func_180494_b(tryPos);
/*     */           
/*  85 */           if (!info.biomeBl.contains(biome.field_76791_y.toLowerCase()) && (info.biomeWl.isEmpty() || !info.biomeWl.contains(biome.field_76791_y.toLowerCase()))) {
/*     */ 
/*     */ 
/*     */             
/*  89 */             boolean shouldGenerate = false;
/*     */             
/*  91 */             for (BiomeDictionary.Type biomeType : BiomeDictionary.getTypesForBiome(biome)) {
/*  92 */               if (info.biomeTypeBl.contains(biomeType)) {
/*     */                 break;
/*     */               }
/*     */               
/*  96 */               if (info.biomeTypeWl.isEmpty() || info.biomeTypeWl.contains(biomeType)) {
/*  97 */                 shouldGenerate = true;
/*     */                 
/*     */                 break;
/*     */               } 
/*     */             } 
/* 102 */             if (shouldGenerate)
/*     */             {
/*     */ 
/*     */               
/* 106 */               if (canGenerateInBlock(world, tryPos, info))
/*     */               {
/*     */ 
/*     */                 
/* 110 */                 generateVein(world, random, tryPos, info);
/*     */               }
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void generateVein(World world, Random random, BlockPos pos, UndergroundGenInfo info) {
/* 121 */     BlockPos veinPos = pos;
/* 122 */     Vec3i direction = new Vec3i(random.nextInt(3) - 1, random.nextInt(3) - 1, random.nextInt(3) - 1);
/*     */     
/* 124 */     int length = random.nextInt(info.veinLengthMax - info.veinLengthMin + 1) + info.veinLengthMin;
/* 125 */     int thickness = random.nextInt(info.veinThicknessMax - info.veinThicknessMin + 1) + info.veinThicknessMin;
/*     */     
/* 127 */     for (int tries = 1; tries <= length; tries++) {
/*     */       
/* 129 */       if (canGenerateInBlock(world, veinPos, info)) {
/*     */ 
/*     */         
/* 132 */         double distFromMiddle = Math.abs((Math.ceil(length / 2.0D) - tries) / length);
/*     */ 
/*     */         
/* 135 */         int thisThickness = MathHelper.func_76143_f(thickness * (1.0D - distFromMiddle * 0.5D));
/*     */ 
/*     */         
/* 138 */         generateSphere(world, random, veinPos, thisThickness, info);
/*     */       } 
/*     */       
/* 141 */       veinPos = veinPos.func_177971_a(direction);
/* 142 */       direction = newDirection(random, direction);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Vec3i newDirection(Random random, Vec3i direction) {
/* 147 */     if (random.nextBoolean()) {
/* 148 */       return direction;
/*     */     }
/*     */     
/* 151 */     return new Vec3i(MathHelper.func_76125_a(direction.func_177958_n() + (random.nextBoolean() ? 1 : -1), -1, 1), MathHelper.func_76125_a(direction.func_177956_o() + (random.nextBoolean() ? 1 : -1), -1, 1), MathHelper.func_76125_a(direction.func_177952_p() + (random.nextBoolean() ? 1 : -1), -1, 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateSphere(World world, Random random, BlockPos pos, int thickness, UndergroundGenInfo info) {
/* 159 */     double radius = thickness / 2.0D;
/*     */     
/* 161 */     for (int dispX = pos.func_177958_n() - MathHelper.func_76128_c(radius); dispX <= pos.func_177958_n() + MathHelper.func_76143_f(radius); dispX++) {
/* 162 */       for (int dispY = pos.func_177956_o() - MathHelper.func_76128_c(radius); dispY <= pos.func_177956_o() + MathHelper.func_76143_f(radius); dispY++) {
/* 163 */         for (int dispZ = pos.func_177952_p() - MathHelper.func_76128_c(radius); dispZ <= pos.func_177952_p() + MathHelper.func_76143_f(radius); dispZ++) {
/*     */           
/* 165 */           BlockPos genPos = new BlockPos(dispX, dispY, dispZ);
/*     */           
/* 167 */           if (Math.sqrt(genPos.func_177954_c(0.25D + pos.func_177958_n(), 0.25D + pos.func_177956_o(), 0.25D + pos.func_177952_p())) <= radius)
/*     */           {
/*     */ 
/*     */             
/* 171 */             generateBlock(world, random, genPos, info);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void generateBlock(World world, Random random, BlockPos pos, UndergroundGenInfo info) {
/* 182 */     if (!canGenerateInBlock(world, pos, info)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 188 */     world.func_175656_a(pos, info.toGenerate);
/*     */     
/* 190 */     if (info.blockTag != null) {
/* 191 */       TileEntity te = world.func_175625_s(pos);
/*     */       
/* 193 */       if (te != null) {
/* 194 */         NBTTagCompound tagToGenerate = (NBTTagCompound)info.blockTag.func_74737_b();
/*     */         
/* 196 */         tagToGenerate.func_74768_a("x", pos.func_177958_n());
/* 197 */         tagToGenerate.func_74768_a("y", pos.func_177956_o());
/* 198 */         tagToGenerate.func_74768_a("z", pos.func_177952_p());
/* 199 */         te.func_145839_a(tagToGenerate);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean canGenerateInBlock(World world, BlockPos pos, UndergroundGenInfo info) {
/* 206 */     if (pos.func_177956_o() < 0 || pos.func_177956_o() > 255) {
/* 207 */       return false;
/*     */     }
/*     */     
/* 210 */     IBlockState state = world.func_180495_p(pos);
/* 211 */     Block block = state.func_177230_c();
/*     */     
/* 213 */     if (block == info.toGenerate.func_177230_c() && block.func_176201_c(state) == info.toGenerate.func_177230_c().func_176201_c(info.toGenerate)) {
/* 214 */       return false;
/*     */     }
/*     */     
/* 217 */     if (info.blocksBl.contains(block) || info.materialsBl.contains(block.func_149688_o()) || (!info.materialsWl.isEmpty() && !info.materialsWl.contains(block.func_149688_o()))) {
/* 218 */       return false;
/*     */     }
/*     */     
/* 221 */     for (Block replace : info.blocksWl) {
/* 222 */       if (block.isReplaceableOreGen(world, pos, (Predicate)BlockHelper.func_177642_a(replace))) {
/* 223 */         return true;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 228 */     return block.isReplaceableOreGen(world, pos, (Predicate)BlockHelper.func_177642_a(Blocks.field_150348_b));
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\worldGen\WorldGenUndergroundBlocks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */