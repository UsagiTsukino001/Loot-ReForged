/*     */ package com.tmtravlr.lootplusplus;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemFood;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraft.world.biome.BiomeGenBase;
/*     */ import net.minecraftforge.common.BiomeDictionary;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LootPPIDFileGenerator
/*     */ {
/*     */   public static void generateDimensionIDFile() {
/*  39 */     File dimensionIds = new File(LootPPHelper.idFolder, "Dimension IDs.txt");
/*     */     try {
/*  41 */       PrintStream writeStream = new PrintStream(dimensionIds);
/*     */       
/*  43 */       writeStream.println("## Dimension IDs                                                      ##");
/*  44 */       writeStream.println("########################################################################");
/*  45 */       writeStream.println("## In the form:                                                       ##");
/*  46 */       writeStream.println("## <dimension id>                                                     ##");
/*  47 */       writeStream.println("##    - Name: <dimension name>                                        ##");
/*  48 */       writeStream.println("##    - Height: <dimension height>                                    ##");
/*  49 */       writeStream.println("##    - Has Sky? <true if dimension has a sky>                        ##");
/*  50 */       writeStream.println("##    - Cloud Height: <height of dimension's clouds (only on client)> ##");
/*  51 */       writeStream.println("##    - Can Respawn Here? <true if players can respawn here>          ##");
/*  52 */       writeStream.println("##    - Terrain Scale: <distance travelled per block (nether is 8)>   ##");
/*  53 */       writeStream.println("########################################################################");
/*  54 */       if ((MinecraftServer.func_71276_C()).field_71305_c.length != 0) {
/*  55 */         for (WorldServer world : (MinecraftServer.func_71276_C()).field_71305_c) {
/*  56 */           writeStream.println(world.field_73011_w.func_177502_q());
/*  57 */           writeStream.println("\t- Name: " + world.field_73011_w.func_80007_l());
/*  58 */           writeStream.println("\t- Height: " + world.field_73011_w.getActualHeight());
/*  59 */           writeStream.println("\t- Has Sky? " + (!world.field_73011_w.func_177495_o() ? 1 : 0));
/*  60 */           if (MinecraftServer.func_71276_C() != null && MinecraftServer.func_71276_C().func_71264_H()) {
/*  61 */             writeStream.println("\t- Cloud Height: " + world.field_73011_w.func_76571_f());
/*     */           }
/*  63 */           writeStream.println("\t- Can Respawn Here? " + world.field_73011_w.func_76567_e());
/*  64 */           writeStream.println("\t- Terrain Scale: " + world.field_73011_w.getMovementFactor());
/*  65 */           writeStream.println();
/*  66 */           writeStream.println();
/*     */         } 
/*     */       }
/*     */       
/*  70 */       writeStream.close();
/*     */     
/*     */     }
/*  73 */     catch (IOException x) {
/*  74 */       System.err.format("IOException: %s%n", new Object[] { x });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void generateIDFiles() {
/*  80 */     boolean singleplayer = (MinecraftServer.func_71276_C() != null && MinecraftServer.func_71276_C().func_71264_H());
/*  81 */     File blockItemIds = new File(LootPPHelper.idFolder, "Block and Item IDs.txt");
/*  82 */     File biomeIds = new File(LootPPHelper.idFolder, "Biome IDs.txt");
/*  83 */     File entityIds = new File(LootPPHelper.idFolder, "Entity IDs.txt");
/*  84 */     File effectIds = new File(LootPPHelper.idFolder, "Effect IDs.txt");
/*  85 */     File enchantIds = new File(LootPPHelper.idFolder, "Enchantment IDs.txt");
/*  86 */     File foods = new File(LootPPHelper.idFolder, "Food and Drink Info.txt");
/*  87 */     File oreDictionary = new File(LootPPHelper.idFolder, "Ore Dictionary Info.txt");
/*     */ 
/*     */     
/*     */     try {
/*  91 */       PrintStream writeStream = new PrintStream(blockItemIds);
/*     */       
/*  93 */       writeStream.println("## Item and Block IDs: in the form <string id> - <number id> ##");
/*  94 */       ArrayList<ResourceLocation> itemResources = new ArrayList<ResourceLocation>(Item.field_150901_e.func_148742_b());
/*  95 */       ArrayList<String> itemNames = new ArrayList<String>();
/*  96 */       for (ResourceLocation location : itemResources) {
/*  97 */         itemNames.add(location.toString());
/*     */       }
/*  99 */       Collections.sort(itemNames);
/* 100 */       for (String key : itemNames) {
/* 101 */         if (Item.field_150901_e.func_82594_a(key) instanceof Item) {
/* 102 */           writeStream.println(key + " - " + Item.func_150891_b((Item)Item.field_150901_e.func_82594_a(key)));
/*     */         }
/*     */       } 
/*     */       
/* 106 */       writeStream.close();
/*     */       
/* 108 */       writeStream = new PrintStream(entityIds);
/*     */       
/* 110 */       writeStream.println("## Entity IDs ##");
/* 111 */       ArrayList<String> entityStrings = new ArrayList<String>(EntityList.field_75625_b.keySet());
/* 112 */       Collections.sort(entityStrings);
/* 113 */       for (String key : entityStrings) {
/* 114 */         writeStream.println(key);
/*     */       }
/*     */       
/* 117 */       writeStream.println("## Spawn Egg IDs: in the form <number id> - <entity string id (which it spawns)> ##");
/* 118 */       ArrayList<Integer> eggIds = new ArrayList<Integer>(EntityList.field_75627_a.keySet());
/* 119 */       Collections.sort(eggIds);
/* 120 */       for (Iterator<Integer> iterator = eggIds.iterator(); iterator.hasNext(); ) { int key = ((Integer)iterator.next()).intValue();
/* 121 */         EntityList.EntityEggInfo info = (EntityList.EntityEggInfo)EntityList.field_75627_a.get(Integer.valueOf(key));
/* 122 */         writeStream.println("" + key + " - " + EntityList.field_75626_c.get(EntityList.field_75623_d.get(Integer.valueOf(key)))); }
/*     */ 
/*     */       
/* 125 */       writeStream.close();
/*     */       
/* 127 */       writeStream = new PrintStream(biomeIds);
/*     */       
/* 129 */       writeStream.println("## Biome IDs                                           ##");
/* 130 */       writeStream.println("#########################################################");
/* 131 */       writeStream.println("## In the form:                                        ##");
/* 132 */       writeStream.println("## <biome id>                                          ##");
/* 133 */       writeStream.println("##    - Name: <biome name>                             ##");
/* 134 */       writeStream.println("##    - Forge Biome Types: <list of forge biome types> ##");
/* 135 */       writeStream.println("#########################################################");
/* 136 */       for (BiomeGenBase biome : BiomeGenBase.func_150565_n()) {
/* 137 */         if (biome != null) {
/* 138 */           writeStream.println(biome.field_76756_M);
/* 139 */           writeStream.println("\t- Name: " + biome.field_76791_y);
/* 140 */           writeStream.print("\t- Forge Biome Types: ");
/* 141 */           for (BiomeDictionary.Type type : BiomeDictionary.getTypesForBiome(biome)) {
/* 142 */             writeStream.print(type.name() + " ");
/*     */           }
/* 144 */           writeStream.println();
/* 145 */           writeStream.println();
/*     */         } 
/*     */       } 
/*     */       
/* 149 */       writeStream.close();
/*     */       
/* 151 */       writeStream = new PrintStream(effectIds);
/*     */       
/* 153 */       writeStream.println("## Effect IDs                                                        ##");
/* 154 */       writeStream.println("#######################################################################");
/* 155 */       writeStream.println("## In the form:                                                      ##");
/* 156 */       writeStream.println("## <effect id>                                                       ##");
/* 157 */       writeStream.println("##    - Name: <effect name>                                          ##");
/* 158 */       writeStream.println("##    - Color: <effect color>                                        ##");
/* 159 */       writeStream.println("##    - Is Instant? <true if an instant effect (like health)>        ##");
/* 160 */       writeStream.println("##    - Is Bad? <true if considered a 'bad' effect (only on client)> ##");
/* 161 */       writeStream.println("#######################################################################");
/* 162 */       for (Potion effect : Potion.field_76425_a) {
/* 163 */         if (effect != null) {
/* 164 */           writeStream.println(effect.field_76415_H);
/* 165 */           writeStream.println("\t- Name: " + effect.func_76393_a());
/* 166 */           writeStream.println("\t- Color: " + effect.func_76401_j());
/* 167 */           writeStream.println("\t- Is Instant? " + effect.func_76403_b());
/* 168 */           if (singleplayer) {
/* 169 */             writeStream.println("\t- Is Bad? " + effect.func_76398_f());
/*     */           }
/* 171 */           writeStream.println();
/* 172 */           writeStream.println();
/*     */         } 
/*     */       } 
/*     */       
/* 176 */       writeStream.close();
/*     */       
/* 178 */       writeStream = new PrintStream(enchantIds);
/*     */       
/* 180 */       writeStream.println("## Enchantment IDs                                ##");
/* 181 */       writeStream.println("####################################################");
/* 182 */       writeStream.println("## In the form:                                   ##");
/* 183 */       writeStream.println("## <enchantment id>                               ##");
/* 184 */       writeStream.println("##    - Name: <enchantment name>                  ##");
/* 185 */       writeStream.println("##    - Weight: <enchantment weight (rarity)>     ##");
/* 186 */       writeStream.println("##    - Min Level: <min xp level for enchantment> ##");
/* 187 */       writeStream.println("##    - Max Level: <max xp level for enchantment> ##");
/* 188 */       writeStream.println("####################################################");
/* 189 */       for (int i = 0; i < 256; i++) {
/* 190 */         Enchantment enchant = Enchantment.func_180306_c(i);
/* 191 */         if (enchant != null) {
/* 192 */           writeStream.println(enchant.field_77352_x);
/* 193 */           writeStream.println("\t- Name: " + enchant.func_77320_a());
/* 194 */           writeStream.println("\t- Weight: " + enchant.func_77324_c());
/* 195 */           writeStream.println("\t- Min Level: " + enchant.func_77319_d());
/* 196 */           writeStream.println("\t- Max Level: " + enchant.func_77325_b());
/* 197 */           writeStream.println();
/* 198 */           writeStream.println();
/*     */         } 
/*     */       } 
/*     */       
/* 202 */       writeStream.close();
/*     */       
/* 204 */       writeStream = new PrintStream(foods);
/*     */       
/* 206 */       writeStream.println("## Foods and Drinks (Note it's still a bit WIP)                ##");
/* 207 */       writeStream.println("#################################################################");
/* 208 */       writeStream.println("## In the form:                                                ##");
/* 209 */       writeStream.println("## <effect id>                                                 ##");
/* 210 */       writeStream.println("##    - Metadata: <item metadata>                              ##");
/* 211 */       writeStream.println("##    - Food or Drink? <Food or Drink (or Unknown)>            ##");
/* 212 */       writeStream.println("##    - Food Amount: <Number of food points restored>          ##");
/* 213 */       writeStream.println("##    - Saturation Amount: <Number of saturation points given> ##");
/* 214 */       writeStream.println("################################################################");
/* 215 */       for (String key : itemNames) {
/* 216 */         if (Item.field_150901_e.func_82594_a(key) != null && Item.field_150901_e.func_82594_a(key) instanceof Item) {
/* 217 */           Item possibleItem = (Item)Item.field_150901_e.func_82594_a(key);
/*     */           
/*     */           try {
/* 220 */             possibleItem.func_77614_k();
/*     */             
/* 222 */             List<ItemStack> subItems = new ArrayList<ItemStack>();
/* 223 */             if (singleplayer) {
/* 224 */               possibleItem.func_150895_a(possibleItem, CreativeTabs.field_78027_g, subItems);
/*     */             }
/* 226 */             if (subItems.isEmpty()) {
/* 227 */               subItems.add(new ItemStack(possibleItem));
/*     */             }
/*     */             
/* 230 */             for (ItemStack itemStack : subItems) {
/* 231 */               EnumAction action = itemStack.func_77975_n();
/*     */               
/* 233 */               if (itemStack.func_77973_b() instanceof ItemFood) {
/* 234 */                 ItemFood itemFood = (ItemFood)itemStack.func_77973_b();
/* 235 */                 writeStream.println(key);
/* 236 */                 writeStream.println("\t- Megadata: " + itemStack.func_77952_i());
/* 237 */                 writeStream.println("\t- Food or Drink? " + ((action == EnumAction.EAT) ? "Food" : ((action == EnumAction.DRINK) ? "Drink" : "Unknown")));
/* 238 */                 writeStream.println("\t- Food Amount: " + itemFood.func_150905_g(new ItemStack((Item)itemFood)));
/* 239 */                 writeStream.println("\t- Saturation Amount: " + itemFood.func_150906_h(new ItemStack((Item)itemFood)));
/* 240 */                 writeStream.println();
/* 241 */                 writeStream.println(); continue;
/*     */               } 
/* 243 */               if (action == EnumAction.EAT || action == EnumAction.DRINK) {
/* 244 */                 writeStream.println(key);
/* 245 */                 writeStream.println("\t- Megadata: " + itemStack.func_77952_i());
/* 246 */                 writeStream.println("\t- Food or Drink? " + ((action == EnumAction.EAT) ? "Food" : ((action == EnumAction.DRINK) ? "Drink" : "Unknown")));
/* 247 */                 writeStream.println("\t- Food Info Unknown!");
/* 248 */                 writeStream.println();
/* 249 */                 writeStream.println();
/*     */               }
/*     */             
/*     */             } 
/* 253 */           } catch (Exception e) {
/* 254 */             System.out.println("[Loot++] Caught Exception while writing food and drink info file.");
/* 255 */             e.printStackTrace();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 260 */       writeStream.close();
/*     */       
/* 262 */       writeStream = new PrintStream(oreDictionary);
/*     */       
/* 264 */       writeStream.println("## Ore Dictionary Info                      ##");
/* 265 */       writeStream.println("##############################################");
/* 266 */       writeStream.println("## In the form:                             ##");
/* 267 */       writeStream.println("## <ore dictionary entry>                   ##");
/* 268 */       writeStream.println("##     <item id registered> - <item damage> ##");
/* 269 */       writeStream.println("##     etc...                               ##");
/* 270 */       writeStream.println("##############################################");
/*     */       
/* 272 */       List<String> registeredEntries = Arrays.asList(OreDictionary.getOreNames());
/* 273 */       Collections.sort(registeredEntries);
/*     */       
/* 275 */       for (String entry : registeredEntries) {
/* 276 */         writeStream.println(entry);
/* 277 */         for (ItemStack stack : OreDictionary.getOres(entry)) {
/* 278 */           writeStream.println(Item.field_150901_e.func_177774_c(stack.func_77973_b()) + " - " + ((stack.func_77952_i() == 32767) ? "any" : (String)Integer.valueOf(stack.func_77952_i())));
/*     */         }
/* 280 */         writeStream.println();
/* 281 */         writeStream.println();
/*     */       } 
/*     */       
/* 284 */       writeStream.close();
/*     */     
/*     */     }
/* 287 */     catch (IOException x) {
/* 288 */       System.err.format("IOException: %s%n", new Object[] { x });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPIDFileGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */