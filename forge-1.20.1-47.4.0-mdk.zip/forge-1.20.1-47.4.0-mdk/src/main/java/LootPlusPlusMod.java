/*     */ package com.tmtravlr.lootplusplus;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.additions.EntityAddedThrownItem;
/*     */ import com.tmtravlr.lootplusplus.additions.TileEntityAddedFurnace;
/*     */ import com.tmtravlr.lootplusplus.commands.BlockCommandBlockTrigger;
/*     */ import com.tmtravlr.lootplusplus.commands.BlockCommandTrigger;
/*     */ import com.tmtravlr.lootplusplus.commands.ItemCommandTrigger;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandCondition;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandDamage;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandDamageItem;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandEffect;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandEntityData;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandExplode;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandGenLoot;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandLock;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandMount;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandNBTDump;
/*     */ import com.tmtravlr.lootplusplus.commands.LPPCommandTeleport;
/*     */ import com.tmtravlr.lootplusplus.commands.TileEntityCommandTrigger;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigExtrasLoader;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderBlockDrops;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderBlocks;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderChestLoot;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderEffects;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderEntityDrops;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderFishingLoot;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderFurnaceRecipes;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderGeneral;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderItems;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderOreDict;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderRecipes;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderRecords;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderStackSize;
/*     */ import com.tmtravlr.lootplusplus.config.ConfigLoaderWorldGen;
/*     */ import com.tmtravlr.lootplusplus.loot.BlockLootChest;
/*     */ import com.tmtravlr.lootplusplus.loot.ItemBlockLootChest;
/*     */ import com.tmtravlr.lootplusplus.loot.ItemLootItem;
/*     */ import com.tmtravlr.lootplusplus.loot.TileEntityLootChest;
/*     */ import com.tmtravlr.lootplusplus.network.CToSMessage;
/*     */ import com.tmtravlr.lootplusplus.network.PacketHandlerClient;
/*     */ import com.tmtravlr.lootplusplus.network.PacketHandlerServer;
/*     */ import com.tmtravlr.lootplusplus.network.SToCMessage;
/*     */ import com.tmtravlr.lootplusplus.testing.BlockTestingEntitySpawner;
/*     */ import com.tmtravlr.lootplusplus.testing.ItemTestingEntitySpawner;
/*     */ import com.tmtravlr.lootplusplus.testing.TileEntityTestingEntitySpawner;
/*     */ import com.tmtravlr.lootplusplus.worldGen.WorldGenSurfaceBlocks;
/*     */ import com.tmtravlr.lootplusplus.worldGen.WorldGenUndergroundBlocks;
/*     */ import java.io.File;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockDispenser;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
/*     */ import net.minecraft.dispenser.IBlockSource;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemRecord;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.IFuelHandler;
/*     */ import net.minecraftforge.fml.common.IWorldGenerator;
/*     */ import net.minecraftforge.fml.common.Mod;
/*     */ import net.minecraftforge.fml.common.Mod.EventHandler;
/*     */ import net.minecraftforge.fml.common.Mod.Instance;
/*     */ import net.minecraftforge.fml.common.SidedProxy;
/*     */ import net.minecraftforge.fml.common.event.FMLInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLInterModComms;
/*     */ import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLServerAboutToStartEvent;
/*     */ import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
/*     */ import net.minecraftforge.fml.common.network.NetworkRegistry;
/*     */ import net.minecraftforge.fml.common.registry.EntityRegistry;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mod(modid = "lootplusplus", name = "Loot++", version = "1.7.1_for_1.8", acceptedMinecraftVersions = "[1.8]")
/*     */ public class LootPlusPlusMod
/*     */ {
/*     */   public static final String MOD_ID = "lootplusplus";
/*     */   public static final String MOD_NAME = "Loot++";
/*     */   public static final String MOD_VERSION = "1.7.1_for_1.8";
/*     */   @Instance("lootplusplus")
/*     */   public static LootPlusPlusMod instance;
/*     */   @SidedProxy(clientSide = "com.tmtravlr.lootplusplus.LootPPClientProxy", serverSide = "com.tmtravlr.lootplusplus.LootPPCommonProxy")
/*     */   public static LootPPCommonProxy proxy;
/*     */   public static boolean debug = false;
/*     */   
/*     */   static {
/*  97 */     new LootPPHelper();
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void preInit(FMLPreInitializationEvent event) {
/* 103 */     instance = this;
/*     */ 
/*     */     
/* 106 */     byte serverMessageID = 1;
/* 107 */     byte clientMessageID = 2;
/*     */ 
/*     */     
/* 110 */     LootPPHelper.lppNetworkWrapper = NetworkRegistry.INSTANCE.newSimpleChannel("lootplusplus");
/* 111 */     LootPPHelper.lppNetworkWrapper.registerMessage(PacketHandlerServer.class, CToSMessage.class, serverMessageID, Side.SERVER);
/* 112 */     LootPPHelper.lppNetworkWrapper.registerMessage(PacketHandlerClient.class, SToCMessage.class, clientMessageID, Side.CLIENT);
/*     */     
/* 114 */     LootPPHelper.configFolder = new File(event.getSuggestedConfigurationFile().getParentFile(), "Loot++");
/*     */     
/* 116 */     if (!LootPPHelper.configFolder.exists()) {
/* 117 */       LootPPHelper.configFolder.mkdir();
/*     */     }
/* 119 */     LootPPHelper.idFolder = new File(LootPPHelper.configFolder, "IDs");
/*     */     
/* 121 */     if (!LootPPHelper.idFolder.exists()) {
/* 122 */       LootPPHelper.idFolder.mkdir();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 127 */     ConfigLoaderGeneral.instance.loadGeneral();
/*     */     
/* 129 */     LootPPBlocks.blockLootChest = (new BlockLootChest(99)).func_149711_c(2.5F).func_149672_a(Block.field_149766_f).func_149663_c("loot_chest");
/* 130 */     LootPPItems.itemLootItem = (new ItemLootItem()).func_77655_b("loot_item");
/*     */     
/* 132 */     LootPPBlocks.blockCommandBlockTrigger = (new BlockCommandBlockTrigger()).func_149663_c("command_block_trigger");
/* 133 */     LootPPBlocks.blockCommandTrigger = (new BlockCommandTrigger()).func_149663_c("command_trigger_block").func_149711_c(-1.0F).func_149752_b(6000000.0F);
/* 134 */     LootPPItems.itemCommandTrigger = (new ItemCommandTrigger()).func_77655_b("command_trigger_item").func_77625_d(1);
/*     */     
/* 136 */     LootPPBlocks.blockTestingSpawner = (new BlockTestingEntitySpawner()).func_149663_c("single_entity_spawner");
/* 137 */     LootPPItems.itemTestingSpawner = (new ItemTestingEntitySpawner()).func_77655_b("custom_spawn_egg");
/*     */ 
/*     */     
/* 140 */     GameRegistry.registerItem(LootPPItems.generalDummyIcon, "dummy_tab_icon_present");
/* 141 */     GameRegistry.registerItem(LootPPItems.additionsDummyIcon, "dummy_tab_icon_record");
/*     */ 
/*     */     
/* 144 */     GameRegistry.registerBlock(LootPPBlocks.blockLootChest, ItemBlockLootChest.class, "loot_chest");
/* 145 */     GameRegistry.registerItem(LootPPItems.itemLootItem, "loot_item");
/*     */ 
/*     */     
/* 148 */     GameRegistry.registerBlock(LootPPBlocks.blockTestingSpawner, "single_entity_spawner");
/* 149 */     GameRegistry.registerItem(LootPPItems.itemTestingSpawner, "custom_spawn_egg");
/*     */ 
/*     */     
/* 152 */     GameRegistry.registerBlock(LootPPBlocks.blockCommandBlockTrigger, "command_block_trigger");
/* 153 */     GameRegistry.registerBlock(LootPPBlocks.blockCommandTrigger, "command_trigger_block");
/* 154 */     GameRegistry.registerItem(LootPPItems.itemCommandTrigger, "command_trigger_item");
/*     */ 
/*     */     
/* 157 */     GameRegistry.registerItem(LootPPItems.itemNBTChecker, "nbt_checker");
/*     */ 
/*     */     
/* 160 */     GameRegistry.registerTileEntity(TileEntityTestingEntitySpawner.class, "tile_single_entity_spawner");
/* 161 */     GameRegistry.registerTileEntity(TileEntityCommandTrigger.class, "tile_command_trigger");
/* 162 */     GameRegistry.registerTileEntity(TileEntityAddedFurnace.class, "tile_entity_added_furnace");
/* 163 */     GameRegistry.registerTileEntity(TileEntityLootChest.class, "tile_entity_loot_chest");
/*     */ 
/*     */ 
/*     */     
/* 167 */     BlockDispenser.field_149943_a.func_82595_a(LootPPItems.itemTestingSpawner, new BehaviorDefaultDispenseItem()
/*     */         {
/*     */ 
/*     */ 
/*     */           
/*     */           public ItemStack func_82487_b(IBlockSource source, ItemStack stack)
/*     */           {
/* 174 */             EnumFacing enumfacing = BlockDispenser.func_149937_b(source.func_82620_h());
/* 175 */             double d0 = source.func_82615_a() + enumfacing.func_82601_c();
/* 176 */             double d1 = (source.func_180699_d().func_177956_o() + 0.2F);
/* 177 */             double d2 = source.func_82616_c() + enumfacing.func_82599_e();
/* 178 */             Entity entity = ItemTestingEntitySpawner.spawnEntity(source.func_82618_k(), stack, d0, d1, d2);
/*     */             
/* 180 */             if (entity instanceof net.minecraft.entity.EntityLivingBase && stack.func_82837_s())
/*     */             {
/* 182 */               ((EntityLiving)entity).func_96094_a(stack.func_82833_r());
/*     */             }
/*     */             
/* 185 */             stack.func_77979_a(1);
/* 186 */             return stack;
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */     
/* 192 */     proxy.registerEventHandlers();
/* 193 */     proxy.registerTickHandlers();
/*     */ 
/*     */     
/* 196 */     GameRegistry.registerFuelHandler((IFuelHandler)LootPPHelper.fuelHandler);
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void init(FMLInitializationEvent event) {
/* 202 */     GameRegistry.registerWorldGenerator((IWorldGenerator)new WorldGenSurfaceBlocks(), 2147483647);
/* 203 */     GameRegistry.registerWorldGenerator((IWorldGenerator)new WorldGenUndergroundBlocks(), 2147483647);
/*     */     
/* 205 */     proxy.registerRenderers();
/* 206 */     EntityRegistry.registerModEntity(EntityAddedThrownItem.class, "ThrownItem", 0, this, 80, 1, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void afterInit(FMLInterModComms.IMCEvent event) {
/* 214 */     ConfigExtrasLoader.loadAllExtras();
/*     */ 
/*     */     
/* 217 */     ConfigLoaderRecords.instance.loadRecordConfig();
/* 218 */     ConfigLoaderBlocks.instance.loadBlockAdditions();
/* 219 */     ConfigLoaderItems.instance.loadItemAdditions();
/* 220 */     ConfigLoaderBlocks.instance.loadCropAdditions();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void postInit(FMLPostInitializationEvent event) {
/* 227 */     ConfigLoaderGeneral.instance.loadCreativeAdditions();
/*     */     
/* 229 */     ConfigLoaderStackSize.instance.loadStackSizes();
/* 230 */     ConfigLoaderWorldGen.instance.loadWorldGen();
/*     */ 
/*     */     
/* 233 */     if (LootPPHelper.creepersDropAllRecords) {
/* 234 */       for (Object key : Item.field_150901_e.func_148742_b()) {
/* 235 */         if (Item.field_150901_e.func_82594_a(key) instanceof ItemRecord) {
/* 236 */           ItemRecord record = (ItemRecord)Item.field_150901_e.func_82594_a(key);
/* 237 */           LootPPItems.allRecords.add(record);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void serverAboutToStart(FMLServerAboutToStartEvent event) {
/* 247 */     if (!LootPPHelper.loadedDropsAndChestLoot) {
/* 248 */       ConfigLoaderChestLoot.instance.loadChestContent();
/* 249 */       ConfigLoaderFishingLoot.instance.loadFishingLoot();
/* 250 */       ConfigLoaderEntityDrops.instance.loadEntityDrops();
/* 251 */       ConfigLoaderBlockDrops.instance.loadBlockDrops();
/*     */       
/* 253 */       LootPPHelper.loadedDropsAndChestLoot = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void serverStart(FMLServerStartingEvent event) {
/* 263 */     if (debug) System.out.println("[Loot++] Registering commands"); 
/* 264 */     event.registerServerCommand((ICommand)new LPPCommandNBTDump());
/* 265 */     event.registerServerCommand((ICommand)new LPPCommandTeleport());
/* 266 */     event.registerServerCommand((ICommand)new LPPCommandMount());
/* 267 */     event.registerServerCommand((ICommand)new LPPCommandCondition());
/* 268 */     event.registerServerCommand((ICommand)new LPPCommandEffect());
/* 269 */     event.registerServerCommand((ICommand)new LPPCommandEntityData());
/* 270 */     event.registerServerCommand((ICommand)new LPPCommandGenLoot());
/* 271 */     event.registerServerCommand((ICommand)new LPPCommandLock());
/* 272 */     event.registerServerCommand((ICommand)new LPPCommandDamage());
/* 273 */     event.registerServerCommand((ICommand)new LPPCommandDamageItem());
/* 274 */     event.registerServerCommand((ICommand)new LPPCommandExplode());
/*     */ 
/*     */ 
/*     */     
/* 278 */     if (!LootPPHelper.loadedRecipes && MinecraftServer.func_71276_C().func_130014_f_() != null) {
/* 279 */       loadRecipesAndSuch(MinecraftServer.func_71276_C().func_130014_f_());
/* 280 */       LootPPHelper.loadedRecipes = true;
/*     */     } 
/*     */     
/* 283 */     if (LootPPHelper.generateFiles) {
/* 284 */       LootPPIDFileGenerator.generateDimensionIDFile();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void loadRecipesAndSuch(World world) {
/* 290 */     if (LootPPHelper.generateFiles) {
/* 291 */       LootPPIDFileGenerator.generateIDFiles();
/*     */     }
/* 293 */     ConfigLoaderOreDict.instance.loadOreDict();
/* 294 */     ConfigLoaderRecipes.instance.loadRecipes(world);
/* 295 */     ConfigLoaderFurnaceRecipes.instance.loadFurnaceRecipes();
/* 296 */     ConfigLoaderEffects.instance.loadItemEffects();
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPlusPlusMod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */