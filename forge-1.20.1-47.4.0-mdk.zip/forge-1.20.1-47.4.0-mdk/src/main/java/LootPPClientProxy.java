/*     */ package com.tmtravlr.lootplusplus;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.additions.EntityAddedThrownItem;
/*     */ import com.tmtravlr.lootplusplus.additions.RenderAddedThrownItem;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.ItemMeshDefinition;
/*     */ import net.minecraft.client.renderer.entity.RenderItem;
/*     */ import net.minecraft.client.resources.FileResourcePack;
/*     */ import net.minecraft.client.resources.FolderResourcePack;
/*     */ import net.minecraft.client.resources.model.ModelBakery;
/*     */ import net.minecraft.client.resources.model.ModelResourceLocation;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.client.FMLClientHandler;
/*     */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*     */ import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
/*     */ 
/*     */ 
/*     */ public class LootPPClientProxy
/*     */   extends LootPPCommonProxy
/*     */ {
/*  27 */   private List defaultResourcePacks = null;
/*     */ 
/*     */   
/*     */   public void registerTickHandlers() {
/*  31 */     super.registerTickHandlers();
/*  32 */     FMLCommonHandler.instance().bus().register(new LootPPTickHandlerClient());
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerEventHandlers() {
/*  37 */     super.registerEventHandlers();
/*  38 */     MinecraftForge.EVENT_BUS.register(new LootPPEventHandlerClient());
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerRenderers() {
/*  43 */     RenderItem renderer = Minecraft.func_71410_x().func_175599_af();
/*     */     
/*  45 */     registerItemRender(renderer, LootPPItems.generalDummyIcon);
/*  46 */     registerItemRender(renderer, LootPPItems.additionsDummyIcon);
/*     */     
/*  48 */     registerItemRenderDefinition(renderer, LootPPItems.itemLootItem);
/*  49 */     registerBlockRender(renderer, LootPPBlocks.blockLootChest);
/*     */     
/*  51 */     registerItemRenderDefinition(renderer, LootPPItems.itemNBTChecker);
/*     */     
/*  53 */     renderer.func_175037_a().func_178080_a(LootPPItems.itemCommandTrigger, new ItemMeshDefinition()
/*     */         {
/*     */           public ModelResourceLocation func_178113_a(ItemStack stack)
/*     */           {
/*  57 */             return new ModelResourceLocation("lootplusplus:" + LootPPItems.itemLootItem.func_77658_a().substring(LootPPItems.itemLootItem.func_77658_a().indexOf(".") + 1), "inventory");
/*     */           }
/*     */         });
/*  60 */     renderer.func_175037_a().func_178086_a(Item.func_150898_a(LootPPBlocks.blockCommandBlockTrigger), 0, new ModelResourceLocation("command_block"));
/*  61 */     renderer.func_175037_a().func_178086_a(Item.func_150898_a(LootPPBlocks.blockCommandTrigger), 0, new ModelResourceLocation("command_block"));
/*     */     
/*  63 */     renderer.func_175037_a().func_178080_a(LootPPItems.itemTestingSpawner, new ItemMeshDefinition()
/*     */         {
/*     */           public ModelResourceLocation func_178113_a(ItemStack stack)
/*     */           {
/*  67 */             return new ModelResourceLocation("spawn_egg", "inventory");
/*     */           }
/*     */         });
/*  70 */     renderer.func_175037_a().func_178086_a(Item.func_150898_a(LootPPBlocks.blockTestingSpawner), 0, new ModelResourceLocation("mob_spawner", "inventory"));
/*     */     
/*  72 */     (Minecraft.func_71410_x().func_175598_ae()).field_78729_o.put(EntityAddedThrownItem.class, new RenderAddedThrownItem(Minecraft.func_71410_x().func_175598_ae(), Minecraft.func_71410_x().func_175599_af()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerBlockRender(Block block) {
/*  77 */     registerBlockRender(Minecraft.func_71410_x().func_175599_af(), block);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerItemRender(Item item) {
/*  82 */     registerItemRender(Minecraft.func_71410_x().func_175599_af(), item);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerItemRenderDefinition(Item item) {
/*  87 */     registerItemRenderDefinition(Minecraft.func_71410_x().func_175599_af(), item);
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerItemRenderWithDamage(Item item, int damage, String name) {
/*  92 */     Minecraft.func_71410_x().func_175599_af().func_175037_a().func_178086_a(item, damage, new ModelResourceLocation("lootplusplus:" + name, "inventory"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerBlockRenderWithDamage(Block block, int damage, String name) {
/*  97 */     Item item = Item.func_150898_a(block);
/*  98 */     if (item != null) {
/*  99 */       registerItemRenderWithDamage(item, damage, name);
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerBlockRender(RenderItem renderer, Block block) {
/* 104 */     Item item = Item.func_150898_a(block);
/* 105 */     if (item != null) {
/* 106 */       registerItemRender(renderer, Item.func_150898_a(block));
/*     */     }
/*     */   }
/*     */   
/*     */   private void registerItemRender(RenderItem renderer, Item item) {
/* 111 */     renderer.func_175037_a().func_178086_a(item, 0, new ModelResourceLocation("lootplusplus:" + item.func_77658_a().substring(item.func_77658_a().indexOf(".") + 1), "inventory"));
/*     */   }
/*     */   
/*     */   private void registerItemRenderDefinition(RenderItem renderer, Item item) {
/* 115 */     renderer.func_175037_a().func_178080_a(item, new ItemMeshDefinition()
/*     */         {
/*     */           public ModelResourceLocation func_178113_a(ItemStack stack) {
/* 118 */             return new ModelResourceLocation("lootplusplus:" + stack.func_77973_b().func_77658_a().substring(stack.func_77973_b().func_77658_a().indexOf(".") + 1), "inventory");
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void registerVariants(Item item, String... args) {
/* 125 */     ModelBakery.addVariantName(item, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void registerAsResourcePack(File addon) {
/* 132 */     if (this.defaultResourcePacks == null) {
/* 133 */       getDefaultResourcePacks();
/*     */     }
/*     */     
/* 136 */     this.defaultResourcePacks.add(addon.isDirectory() ? new FolderResourcePack(addon) : new FileResourcePack(addon));
/*     */   }
/*     */   
/*     */   private void getDefaultResourcePacks() {
/*     */     try {
/* 141 */       this.defaultResourcePacks = (List)ObfuscationReflectionHelper.getPrivateValue(FMLClientHandler.class, FMLClientHandler.instance(), new String[] { "resourcePackList" });
/*     */     }
/* 143 */     catch (Exception e) {
/* 144 */       System.err.println("[Loot++] Caught exception while trying to load resource pack list. =( The addon resource packs aren't going to load!");
/* 145 */       this.defaultResourcePacks = new ArrayList();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPClientProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */