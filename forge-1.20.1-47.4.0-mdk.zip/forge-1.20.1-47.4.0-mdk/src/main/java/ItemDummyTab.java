/*    */ package com.tmtravlr.lootplusplus;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class ItemDummyTab
/*    */   extends Item
/*    */ {
/* 12 */   public String tabName = "";
/*    */   
/*    */   public ItemDummyTab(String name) {
/* 15 */     this.tabName = name;
/* 16 */     func_77637_a(LootPPHelper.addedTabs.get(name));
/* 17 */     func_77655_b("dummy_tab_icon_record");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void func_150895_a(Item item, CreativeTabs tab, List list) {
/* 26 */     List additions = LootPPHelper.additionsToDisplay.get(this.tabName);
/* 27 */     if (additions != null && !additions.isEmpty())
/* 28 */       list.addAll(additions); 
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\ItemDummyTab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */