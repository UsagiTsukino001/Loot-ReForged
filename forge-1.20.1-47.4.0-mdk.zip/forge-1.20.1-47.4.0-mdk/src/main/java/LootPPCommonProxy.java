/*    */ package com.tmtravlr.lootplusplus;
/*    */ 
/*    */ import java.io.File;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*    */ 
/*    */ 
/*    */ public class LootPPCommonProxy
/*    */ {
/*    */   public void registerTickHandlers() {
/* 14 */     FMLCommonHandler.instance().bus().register(new LootPPTickHandlerServer());
/*    */   }
/*    */   
/*    */   public void registerEventHandlers() {
/* 18 */     MinecraftForge.EVENT_BUS.register(new LootPPEventHandler());
/* 19 */     FMLCommonHandler.instance().bus().register(new LootPPEventHandler());
/*    */   }
/*    */   
/*    */   public void registerBlockRender(Block block) {}
/*    */   
/*    */   public void registerRenderers() {}
/*    */   
/*    */   public void registerItemRender(Item item) {}
/*    */   
/*    */   public void registerItemRenderWithDamage(Item item, int damage, String name) {}
/*    */   
/*    */   public void registerBlockRenderWithDamage(Block block, int damage, String name) {}
/*    */   
/*    */   public void registerItemRenderDefinition(Item item) {}
/*    */   
/*    */   public void registerVariants(Item item, String... args) {}
/*    */   
/*    */   public void registerAsResourcePack(File addon) {}
/*    */   
/*    */   public void registerThrownEntityRender(Entity entity, Item item) {}
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPCommonProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */