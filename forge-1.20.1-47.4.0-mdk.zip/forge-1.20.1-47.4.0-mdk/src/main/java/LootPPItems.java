/*    */ package com.tmtravlr.lootplusplus;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.testing.ItemNBTChecker;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LootPPItems
/*    */ {
/* 19 */   public static ArrayList<Item> addedItems = new ArrayList<Item>();
/* 20 */   public static ArrayList<ItemRecord> allRecords = new ArrayList<ItemRecord>();
/*    */ 
/*    */   
/* 23 */   public static Item generalDummyIcon = (new Item()).func_77655_b("dummy_tab_icon_present");
/* 24 */   public static Item additionsDummyIcon = (new Item()).func_77655_b("dummy_tab_icon_record");
/*    */   
/*    */   public static Item itemLootItem;
/*    */   public static Item itemCommandTrigger;
/*    */   public static Item itemTestingSpawner;
/* 29 */   public static Item itemNBTChecker = (new ItemNBTChecker()).func_77625_d(1).func_77655_b("nbt_checker").func_77637_a(LootPPHelper.tabLootPP);
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPItems.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */