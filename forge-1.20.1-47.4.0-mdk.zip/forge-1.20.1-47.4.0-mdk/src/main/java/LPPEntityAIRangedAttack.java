/*     */ package com.tmtravlr.lootplusplus;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.additions.EntityAddedThrownItem;
/*     */ import com.tmtravlr.lootplusplus.additions.ItemAddedBow;
/*     */ import com.tmtravlr.lootplusplus.additions.ItemAddedGun;
/*     */ import com.tmtravlr.lootplusplus.additions.ItemAddedThrowable;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.IRangedAttackMob;
/*     */ import net.minecraft.entity.ai.EntityAIBase;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LPPEntityAIRangedAttack
/*     */   extends EntityAIBase
/*     */ {
/*     */   public final EntityLiving entityHost;
/*     */   public final IRangedAttackMob rangedAttackEntityHost;
/*     */   public EntityLivingBase attackTarget;
/*     */   
/*     */   public LPPEntityAIRangedAttack(IRangedAttackMob attackMob, double moveSpeedToSet, int attackTimeToSet, float maxDistanceToSet) {
/*  41 */     this(attackMob, moveSpeedToSet, attackTimeToSet, attackTimeToSet, maxDistanceToSet);
/*     */   }
/*     */ 
/*     */   
/*     */   public double entityMoveSpeed;
/*  46 */   public int rangedAttackTime = -1;
/*     */   public LPPEntityAIRangedAttack(IRangedAttackMob attackMob, double moveSpeedToSet, int baseAttackTimeToSet, int maxAttackTimeToSet, float maxDistanceToSet) {
/*  48 */     if (!(attackMob instanceof EntityLivingBase))
/*     */     {
/*  50 */       throw new IllegalArgumentException("ArrowAttackGoal requires Mob implements RangedAttackMob");
/*     */     }
/*     */ 
/*     */     
/*  54 */     this.rangedAttackEntityHost = attackMob;
/*  55 */     this.entityHost = (EntityLiving)attackMob;
/*  56 */     this.entityMoveSpeed = moveSpeedToSet;
/*  57 */     this.baseRangedAttackTime = baseAttackTimeToSet;
/*  58 */     this.maxRangedAttackTime = maxAttackTimeToSet;
/*  59 */     this.maxAttackDistance = maxDistanceToSet;
/*  60 */     this.maxAttackDistanceSquared = maxDistanceToSet * maxDistanceToSet;
/*  61 */     func_75248_a(3);
/*     */   }
/*     */   public int timeSeen;
/*     */   public int baseRangedAttackTime;
/*     */   public int maxRangedAttackTime;
/*     */   public float maxAttackDistance;
/*     */   public float maxAttackDistanceSquared;
/*     */   
/*     */   public boolean func_75250_a() {
/*  70 */     EntityLivingBase entitylivingbase = this.entityHost.func_70638_az();
/*     */     
/*  72 */     if (entitylivingbase == null)
/*     */     {
/*  74 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  78 */     this.attackTarget = entitylivingbase;
/*  79 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_75253_b() {
/*  88 */     return (func_75250_a() || !this.entityHost.func_70661_as().func_75500_f());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75251_c() {
/*  96 */     this.attackTarget = null;
/*  97 */     this.timeSeen = 0;
/*  98 */     this.rangedAttackTime = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_75246_d() {
/* 106 */     double d0 = this.entityHost.func_70092_e(this.attackTarget.field_70165_t, (this.attackTarget.func_174813_aQ()).field_72338_b, this.attackTarget.field_70161_v);
/* 107 */     boolean flag = this.entityHost.func_70635_at().func_75522_a((Entity)this.attackTarget);
/*     */     
/* 109 */     if (flag) {
/*     */       
/* 111 */       this.timeSeen++;
/*     */     }
/*     */     else {
/*     */       
/* 115 */       this.timeSeen = 0;
/*     */     } 
/*     */     
/* 118 */     if (d0 <= this.maxAttackDistanceSquared && this.timeSeen >= 20) {
/*     */       
/* 120 */       this.entityHost.func_70661_as().func_75499_g();
/*     */     }
/*     */     else {
/*     */       
/* 124 */       this.entityHost.func_70661_as().func_75497_a((Entity)this.attackTarget, this.entityMoveSpeed);
/*     */     } 
/*     */     
/* 127 */     this.entityHost.func_70671_ap().func_75651_a((Entity)this.attackTarget, 30.0F, 30.0F);
/*     */ 
/*     */     
/* 130 */     ItemAddedBow bow = null;
/* 131 */     ItemAddedThrowable throwable = null;
/* 132 */     ItemAddedGun gun = null;
/*     */     
/* 134 */     if (this.rangedAttackEntityHost instanceof EntityLivingBase) {
/* 135 */       ItemStack heldStack = ((EntityLivingBase)this.rangedAttackEntityHost).func_70694_bm();
/* 136 */       if (heldStack != null && heldStack.func_77973_b() != null) {
/* 137 */         if (heldStack.func_77973_b() instanceof ItemAddedBow) {
/* 138 */           bow = (ItemAddedBow)heldStack.func_77973_b();
/* 139 */           if (bow.ammoItem instanceof ItemAddedThrowable) {
/* 140 */             throwable = (ItemAddedThrowable)bow.ammoItem;
/*     */           }
/*     */         }
/* 143 */         else if (heldStack.func_77973_b() instanceof ItemAddedThrowable) {
/* 144 */           throwable = (ItemAddedThrowable)heldStack.func_77973_b();
/*     */         }
/* 146 */         else if (heldStack.func_77973_b() instanceof ItemAddedGun) {
/* 147 */           gun = (ItemAddedGun)heldStack.func_77973_b();
/* 148 */           throwable = gun.shotItem;
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 153 */     float speedMultiplier = 1.0F;
/*     */     
/* 155 */     if (bow != null) {
/* 156 */       speedMultiplier = bow.drawTime / 20.0F;
/*     */     }
/*     */     
/* 159 */     if (gun != null) {
/* 160 */       speedMultiplier = (gun.getWaitTime(((EntityLivingBase)this.rangedAttackEntityHost).func_70694_bm()) / 20);
/*     */     }
/*     */     
/* 163 */     if (--this.rangedAttackTime <= 0) {
/*     */       
/* 165 */       if (d0 > this.maxAttackDistanceSquared || !flag) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 170 */       int arrowCount = 1;
/* 171 */       float baseDamage = 0.0F;
/* 172 */       String customSound = "random.bow";
/*     */       
/* 174 */       if (bow != null) {
/* 175 */         arrowCount = bow.arrowCount;
/* 176 */         if (arrowCount < 1) arrowCount = 1; 
/* 177 */         baseDamage = bow.baseDamage;
/* 178 */         customSound = bow.shootingSound;
/*     */       } 
/*     */       
/* 181 */       if (gun != null) {
/* 182 */         arrowCount = gun.bulletCount;
/* 183 */         if (arrowCount < 1) arrowCount = 1; 
/* 184 */         baseDamage = gun.baseDamage;
/* 185 */         customSound = gun.shootingSound;
/*     */       } 
/*     */       
/* 188 */       float f = MathHelper.func_76133_a(d0) / this.maxAttackDistance;
/* 189 */       float f1 = MathHelper.func_76131_a(f, 0.1F, 1.0F);
/* 190 */       for (int i = 0; i < arrowCount; i++) {
/* 191 */         if (bow != null && bow.ammoItem == Items.field_151032_g) {
/* 192 */           this.rangedAttackEntityHost.func_82196_d(this.attackTarget, f1 + baseDamage / 2.0F);
/*     */         }
/* 194 */         else if (throwable != null) {
/* 195 */           int power = EnchantmentHelper.func_77506_a(Enchantment.field_77345_t.field_77352_x, this.entityHost.func_70694_bm());
/* 196 */           int punch = EnchantmentHelper.func_77506_a(Enchantment.field_77344_u.field_77352_x, this.entityHost.func_70694_bm());
/*     */           
/* 198 */           if (baseDamage > 0.0F && throwable.damage > 0.0F) {
/* 199 */             if (bow != null) {
/* 200 */               baseDamage += power * 0.5F + 0.5F;
/*     */             }
/* 202 */             else if (gun != null) {
/* 203 */               baseDamage += power * 1.25F;
/*     */             } 
/*     */           }
/*     */           
/* 207 */           attackEntityWithThrown(throwable, baseDamage, punch, customSound);
/*     */         } 
/*     */       } 
/* 210 */       setRangedAttackTime(speedMultiplier, f, gun);
/*     */     }
/* 212 */     else if (this.rangedAttackTime < 0) {
/*     */ 
/*     */       
/* 215 */       float f = MathHelper.func_76133_a(d0) / this.maxAttackDistance;
/* 216 */       setRangedAttackTime(speedMultiplier, f, gun);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setRangedAttackTime(float speedMultiplier, float distance, ItemAddedGun gun) {
/* 221 */     if (gun != null) {
/* 222 */       this.rangedAttackTime = gun.waitTime;
/*     */     } else {
/*     */       
/* 225 */       this.rangedAttackTime = MathHelper.func_76141_d(speedMultiplier * (distance * (this.maxRangedAttackTime - this.baseRangedAttackTime) + this.baseRangedAttackTime));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void attackEntityWithThrown(ItemAddedThrowable throwable, float extraDamage, int punch, String customSound) {
/* 234 */     EntityAddedThrownItem.nextVelocity = throwable.velocity;
/* 235 */     EntityAddedThrownItem thrown = new EntityAddedThrownItem(this.entityHost.field_70170_p, (EntityLivingBase)this.entityHost, throwable);
/*     */     
/* 237 */     thrown.damage += extraDamage;
/* 238 */     thrown.punch += punch;
/*     */     
/* 240 */     double d0 = this.attackTarget.field_70165_t - this.entityHost.field_70165_t;
/* 241 */     double d1 = this.attackTarget.field_70163_u + this.attackTarget.func_70047_e() - 1.100000023841858D - thrown.field_70163_u;
/* 242 */     double d2 = this.attackTarget.field_70161_v - this.entityHost.field_70161_v;
/* 243 */     float f1 = MathHelper.func_76133_a(d0 * d0 + d2 * d2) * 0.2F;
/* 244 */     thrown.func_70186_c(d0, d1 + f1, d2, 1.6F, 12.0F);
/*     */     
/* 246 */     this.entityHost.func_85030_a(customSound, 1.0F, 1.0F / (this.entityHost.func_70681_au().nextFloat() * 0.4F + 0.8F));
/* 247 */     this.entityHost.field_70170_p.func_72838_d((Entity)thrown);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LPPEntityAIRangedAttack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */