/*    */ package com.tmtravlr.lootplusplus;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLiving;
/*    */ import net.minecraft.entity.item.EntityItem;
/*    */ import net.minecraft.entity.monster.EntityCreeper;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LootPPTickHandlerServer
/*    */ {
/* 21 */   public static ArrayList<EntityCreeper> creepersToDropRecordsFrom = new ArrayList<EntityCreeper>();
/* 22 */   public static HashMap<Entity, Entity> entitiesToStack = new HashMap<Entity, Entity>();
/*    */   
/* 24 */   Random rand = new Random();
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onTick(TickEvent.ServerTickEvent event) {
/* 29 */     if (event.phase == TickEvent.Phase.START) {
/*    */ 
/*    */ 
/*    */       
/* 33 */       for (Entity bottom : entitiesToStack.keySet()) {
/* 34 */         Entity top = entitiesToStack.get(bottom);
/*    */         
/* 36 */         if (top != null) {
/* 37 */           top.func_70078_a(bottom);
/*    */         }
/*    */       } 
/*    */       
/* 41 */       entitiesToStack.clear();
/*    */     } 
/*    */     
/* 44 */     if (event.phase == TickEvent.Phase.END) {
/*    */ 
/*    */ 
/*    */       
/* 48 */       for (EntityCreeper creeper : creepersToDropRecordsFrom) {
/* 49 */         creeper.captureDrops = false;
/*    */         
/* 51 */         for (EntityItem item : creeper.capturedDrops) {
/*    */           
/* 53 */           if (item.func_92059_d().func_77973_b() instanceof net.minecraft.item.ItemRecord) {
/*    */             
/* 55 */             if (LootPPHelper.creepersDropRecords) {
/*    */               
/* 57 */               if (LootPPHelper.creepersDropAllRecords) {
/* 58 */                 if (LootPlusPlusMod.debug) System.out.println("Randomizing record drop from creeper."); 
/* 59 */                 Random rand = new Random();
/* 60 */                 item.func_92058_a(new ItemStack((Item)LootPPItems.allRecords.get(rand.nextInt(LootPPItems.allRecords.size()))));
/*    */               } 
/*    */               
/* 63 */               creeper.field_70170_p.func_72838_d((Entity)item);
/*    */               continue;
/*    */             } 
/* 66 */             if (LootPlusPlusMod.debug) System.out.println("Cancelling record drop from creeper.");
/*    */           
/*    */           } 
/*    */         } 
/*    */       } 
/*    */ 
/*    */       
/* 73 */       creepersToDropRecordsFrom.clear();
/*    */       
/* 75 */       for (EntityLiving living : LootPPHelper.delayedAIs) {
/* 76 */         if (living != null && !living.field_70128_L) {
/* 77 */           LootPPHelper.addAddedBowAIToMob(living);
/*    */         }
/*    */       } 
/*    */       
/* 81 */       LootPPHelper.delayedAIs.clear();
/*    */       
/* 83 */       if (this.rand.nextInt(100) == 0 && !LootPPHelper.rangedAIs.isEmpty()) {
/* 84 */         Iterator<Map.Entry<EntityLiving, LPPEntityAIRangedAttack>> it = LootPPHelper.rangedAIs.entrySet().iterator();
/* 85 */         while (it.hasNext()) {
/* 86 */           Map.Entry<EntityLiving, LPPEntityAIRangedAttack> entry = it.next();
/* 87 */           if (entry.getKey() == null || ((EntityLiving)entry.getKey()).field_70128_L) {
/* 88 */             it.remove();
/* 89 */             LootPPHelper.originalRangedAIs.remove(entry.getKey());
/* 90 */             LootPPHelper.originalMeleeAIs.remove(entry.getKey());
/* 91 */             LootPPHelper.meleeAIs.remove(entry.getKey());
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPTickHandlerServer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */