/*    */ package com.tmtravlr.lootplusplus;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class LootPPNotifier
/*    */ {
/*  8 */   public static List<String> notificationList = new ArrayList<String>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void notify(boolean comment, String notification) {
/* 14 */     if (!comment) notificationList.add(notification);
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void notify(boolean comment, String prefix, String notification) {
/* 21 */     if (!comment) notificationList.add(prefix + ": " + notification);
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void notifyNonexistant(boolean comment, String prefix, String nonexistant) {
/* 28 */     if (!comment) notificationList.add(prefix + ": The following block or item doesn't seem to exist: '" + nonexistant + "'.");
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void notifyNumber(boolean comment, String prefix, String... numbers) {
/* 35 */     String numberString = "";
/*    */     
/* 37 */     for (int i = 0; i < numbers.length; i++) {
/* 38 */       numberString = numberString + numbers[i] + ((i == numbers.length - 1) ? "" : ", ");
/*    */     }
/*    */     
/* 41 */     notifyNumber(comment, prefix, numberString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void notifyNumber(boolean comment, String prefix, String numbers) {
/* 48 */     if (!comment) notificationList.add(prefix + ": Problem while loading one of these numbers: " + numbers);
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void notifyNBT(boolean comment, String prefix, String nbt, String message) {
/* 55 */     if (!comment) notificationList.add(prefix + ": Problem while loading NBT: '" + message + "' for '" + nbt + "'."); 
/*    */   }
/*    */   
/*    */   public static void notifyWrongNumberOfParts(boolean comment, String prefix, String entry) {
/* 59 */     if (!comment) notificationList.add(prefix + ": Entry had wrong number of parts" + (underscoreProblem(entry) ? " (better check those underscores)" : "") + ": '" + entry + "'.");
/*    */   
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean underscoreProblem(String entry) {
/* 65 */     if (!entry.contains("____"))
/*    */     {
/* 67 */       return false;
/*    */     }
/*    */     
/* 70 */     if (entry.contains("______"))
/*    */     {
/* 72 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 76 */     int fourCount = 0;
/* 77 */     for (int index = 0; index < entry.length() && entry.indexOf("____", index) > 0; index = entry.indexOf("____", index) + 1) {
/* 78 */       fourCount++;
/*    */     }
/*    */ 
/*    */     
/* 82 */     int fiveCount = 0;
/* 83 */     for (int i = 0; i < entry.length() && entry.indexOf("_____", i) > 0; i = entry.indexOf("_____", i) + 1) {
/* 84 */       fiveCount++;
/*    */     }
/*    */ 
/*    */     
/* 88 */     if (fourCount != fiveCount * 2) {
/* 89 */       return true;
/*    */     }
/*    */     
/* 92 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPNotifier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */