/*    */ package com.tmtravlr.lootplusplus;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LootPPTickHandlerClient
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onTick(TickEvent.ClientTickEvent event) {
/* 14 */     if (event.phase == TickEvent.Phase.END)
/*    */     {
/*    */ 
/*    */       
/* 18 */       if (!LootPPHelper.loadedRecipes && (Minecraft.func_71410_x()).field_71441_e != null && (Minecraft.func_71410_x()).field_71441_e.func_72912_H().func_76065_j() != null && !(Minecraft.func_71410_x()).field_71441_e.func_72912_H().func_76065_j().equals("")) {
/* 19 */         LootPlusPlusMod.loadRecipesAndSuch((World)(Minecraft.func_71410_x()).field_71441_e);
/* 20 */         LootPPHelper.loadedRecipes = true;
/*    */       } 
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPTickHandlerClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */