/*    */ package com.tmtravlr.lootplusplus;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.block.Block;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LootPPBlocks
/*    */ {
/* 16 */   public static ArrayList<Block> addedBlocks = new ArrayList<Block>();
/*    */   public static Block blockLootChest;
/*    */   public static Block blockCommandBlockTrigger;
/*    */   public static Block blockCommandTrigger;
/*    */   public static Block blockTestingSpawner;
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPBlocks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */