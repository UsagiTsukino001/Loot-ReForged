/*    */ package com.tmtravlr.lootplusplus.commands;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.command.WrongUsageException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LPPCommandGenLoot
/*    */   extends CommandBase
/*    */ {
/*    */   public String func_71517_b() {
/* 27 */     return "lppgenloot";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_82362_a() {
/* 36 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public String func_71518_a(ICommandSender sender) {
/* 41 */     return "commands.lppgenloot.usage";
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/* 46 */     if (args.length != 2 && args.length != 4) {
/* 47 */       throw new WrongUsageException("commands.lppgenloot.usage", new Object[0]);
/*    */     }
/*    */     
/* 50 */     String type = args[0];
/*    */     
/* 52 */     if (!LootPPHelper.chestTypes.contains(type)) {
/* 53 */       throw new CommandException("commands.lppgenloot.lootNotRecognized", new Object[] { type });
/*    */     }
/*    */     
/* 56 */     if (args.length == 2) {
/* 57 */       Entity inventoryEntity = func_175768_b(sender, args[1]);
/*    */       
/* 59 */       if (inventoryEntity instanceof IInventory) {
/* 60 */         if (!(sender.func_130014_f_()).field_72995_K) {
/* 61 */           LootPPHelper.generateLoot(type, (IInventory)inventoryEntity);
/*    */         }
/*    */         
/* 64 */         func_152373_a(sender, (ICommand)this, "commands.lppgenloot.success", new Object[] { type, inventoryEntity.func_70005_c_() });
/*    */       } else {
/*    */         
/* 67 */         throw new CommandException("commands.lppgenloot.notInventory", new Object[] { inventoryEntity.func_70005_c_() });
/*    */       } 
/*    */     } else {
/*    */       
/* 71 */       BlockPos pos = func_175757_a(sender, args, 1, false);
/*    */       
/* 73 */       TileEntity te = sender.func_130014_f_().func_175625_s(pos);
/*    */       
/* 75 */       if (te instanceof IInventory) {
/* 76 */         if (!(sender.func_130014_f_()).field_72995_K) {
/* 77 */           LootPPHelper.generateLoot(type, (IInventory)te);
/*    */         }
/*    */         
/* 80 */         func_152373_a(sender, (ICommand)this, "commands.lppgenloot.success", new Object[] { type, pos });
/*    */       } else {
/*    */         
/* 83 */         throw new CommandException("commands.lppgenloot.notInventory", new Object[] { pos });
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/* 91 */     ArrayList<String> chestTypes = new ArrayList<String>();
/* 92 */     chestTypes.addAll(LootPPHelper.chestTypes);
/* 93 */     return (args.length == 1) ? chestTypes : ((args.length > 1 && args.length <= 4) ? func_175771_a(args, 1, pos) : null);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandGenLoot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */