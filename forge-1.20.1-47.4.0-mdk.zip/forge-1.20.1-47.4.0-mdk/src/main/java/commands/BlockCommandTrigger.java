/*    */ package com.tmtravlr.lootplusplus.commands;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.ITileEntityProvider;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.AxisAlignedBB;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockCommandTrigger
/*    */   extends Block
/*    */   implements ITileEntityProvider
/*    */ {
/*    */   public BlockCommandTrigger() {
/* 24 */     super(Material.field_151576_e);
/* 25 */     this.field_149785_s = true;
/* 26 */     func_149713_g(0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int func_149745_a(Random rand) {
/* 31 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AxisAlignedBB func_180640_a(World p_149668_1_, BlockPos pos, IBlockState state) {
/* 41 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int func_149645_b() {
/* 46 */     return -1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_149662_c() {
/* 52 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public float func_149685_I() {
/* 61 */     return 1.0F;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_180653_a(World worldIn, BlockPos pos, IBlockState state, float chance, int fortune) {}
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TileEntity func_149915_a(World world, int p_149915_2_) {
/* 78 */     TileEntityCommandTrigger tileEntity = new TileEntityCommandTrigger();
/* 79 */     return tileEntity;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_180663_b(World world, BlockPos pos, IBlockState state) {
/* 85 */     world.func_175713_t(pos);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\BlockCommandTrigger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */