/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.command.NumberInvalidException;
/*     */ import net.minecraft.command.WrongUsageException;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LPPCommandEffect
/*     */   extends CommandBase
/*     */ {
/*     */   public String func_71517_b() {
/*  24 */     return "lppeffect";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_82362_a() {
/*  32 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/*  37 */     return "commands.lppeffect.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/*  45 */     if (args.length < 2)
/*     */     {
/*  47 */       throw new WrongUsageException("commands.lppeffect.usage", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*  51 */     EntityLivingBase entitylivingbase = (EntityLivingBase)func_175759_a(sender, args[0], EntityLivingBase.class);
/*     */     
/*  53 */     if (args[1].equalsIgnoreCase("clear")) {
/*     */       
/*  55 */       if (entitylivingbase.func_70651_bq().isEmpty())
/*     */       {
/*  57 */         throw new CommandException("commands.effect.failure.notActive.all", new Object[] { entitylivingbase.func_70005_c_() });
/*     */       }
/*     */ 
/*     */       
/*  61 */       entitylivingbase.func_70674_bp();
/*  62 */       func_152373_a(sender, (ICommand)this, "commands.effect.success.removed.all", new Object[] { entitylivingbase.func_70005_c_() });
/*     */     } else {
/*     */       int i;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  71 */         i = func_180528_a(args[1], 1);
/*     */       }
/*  73 */       catch (NumberInvalidException numberinvalidexception) {
/*     */         
/*  75 */         Potion potion = Potion.func_180142_b(args[1]);
/*     */         
/*  77 */         if (potion == null)
/*     */         {
/*  79 */           throw numberinvalidexception;
/*     */         }
/*     */         
/*  82 */         i = potion.field_76415_H;
/*     */       } 
/*     */       
/*  85 */       int j = 600;
/*  86 */       int k = 0;
/*     */       
/*  88 */       if (i >= 0 && i < Potion.field_76425_a.length && Potion.field_76425_a[i] != null) {
/*     */         
/*  90 */         Potion potion1 = Potion.field_76425_a[i];
/*     */         
/*  92 */         if (args.length >= 3) {
/*     */           
/*  94 */           j = func_180528_a(args[2], 0);
/*     */         }
/*  96 */         else if (potion1.func_76403_b()) {
/*     */           
/*  98 */           j = 1;
/*     */         } 
/*     */         
/* 101 */         if (args.length >= 4)
/*     */         {
/* 103 */           k = func_175764_a(args[3], -256, 255);
/*     */         }
/*     */         
/* 106 */         boolean showParticles = true;
/*     */         
/* 108 */         if (args.length >= 5 && "true".equalsIgnoreCase(args[4]))
/*     */         {
/* 110 */           showParticles = false;
/*     */         }
/*     */         
/* 113 */         if (j > 0)
/*     */         {
/* 115 */           PotionEffect potioneffect = new PotionEffect(i, j, k, false, showParticles);
/* 116 */           entitylivingbase.func_70690_d(potioneffect);
/* 117 */           func_152373_a(sender, (ICommand)this, "commands.lppeffect.success", new Object[] { new ChatComponentTranslation(potioneffect.func_76453_d(), new Object[0]), Integer.valueOf(i), Integer.valueOf(k), entitylivingbase.func_70005_c_(), Integer.valueOf(j), Double.valueOf(j / 20.0D) });
/*     */         }
/* 119 */         else if (entitylivingbase.func_82165_m(i))
/*     */         {
/* 121 */           entitylivingbase.func_82170_o(i);
/* 122 */           func_152373_a(sender, (ICommand)this, "commands.effect.success.removed", new Object[] { new ChatComponentTranslation(potion1.func_76393_a(), new Object[0]), entitylivingbase.func_70005_c_() });
/*     */         }
/*     */         else
/*     */         {
/* 126 */           throw new CommandException("commands.effect.failure.notActive", new Object[] { new ChatComponentTranslation(potion1.func_76393_a(), new Object[0]), entitylivingbase.func_70005_c_() });
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 131 */         throw new NumberInvalidException("commands.effect.notFound", new Object[] { Integer.valueOf(i) });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/* 139 */     return (args.length == 1) ? func_71530_a(args, getAllUsernames()) : ((args.length == 2) ? func_71530_a(args, Potion.func_180141_c()) : ((args.length == 5) ? func_71530_a(args, new String[] { "true", "false" }) : null));
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] getAllUsernames() {
/* 144 */     return MinecraftServer.func_71276_C().func_71213_z();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82358_a(String[] args, int index) {
/* 152 */     return (index == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandEffect.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */