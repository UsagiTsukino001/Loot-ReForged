/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPItems;
/*     */ import java.util.Random;
/*     */ import net.minecraft.command.ICommandManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ public class ItemCommandTrigger
/*     */   extends Item
/*     */ {
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int func_82790_a(ItemStack stack, int layer) {
/*  26 */     NBTTagCompound tag = stack.func_77978_p();
/*     */     
/*  28 */     if (tag != null) {
/*     */ 
/*     */       
/*  31 */       if (tag.func_74764_b("Icon")) {
/*  32 */         return 16777215;
/*     */       }
/*     */       
/*  35 */       if ((layer == 0 && tag.func_74764_b("PrimaryColor")) || (layer != 0 && tag.func_74764_b("SecondaryColor"))) {
/*  36 */         return (layer == 0) ? tag.func_74762_e("PrimaryColor") : tag.func_74762_e("SecondaryColor");
/*     */       }
/*     */       
/*  39 */       int color = 16777215;
/*     */       
/*  41 */       if (stack.func_77978_p().func_150299_b("CommandList") == 9) {
/*  42 */         NBTTagList tagList = stack.func_77978_p().func_150295_c("CommandList", 8);
/*  43 */         if (tagList.func_74745_c() > 0) {
/*  44 */           String type = tagList.func_150307_f(0);
/*  45 */           Random rand = new Random((type + ((layer == 0) ? "p" : "s")).hashCode());
/*  46 */           color = rand.nextInt(16777215);
/*  47 */           tag.func_74768_a((layer == 0) ? "PrimaryColor" : "SecondaryColor", color);
/*     */         } 
/*     */       } 
/*     */       
/*  51 */       return color;
/*     */     } 
/*     */     
/*  54 */     EntityList.EntityEggInfo entityegginfo = (EntityList.EntityEggInfo)EntityList.field_75627_a.get(Integer.valueOf(stack.func_77952_i()));
/*  55 */     return (entityegginfo != null) ? ((layer == 0) ? entityegginfo.field_75611_b : entityegginfo.field_75612_c) : 16777215;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_77663_a(ItemStack stack, World world, Entity entity, int slot, boolean isHeld) {
/*  60 */     if (entity != null && entity instanceof EntityPlayer && stack.func_77973_b() == LootPPItems.itemCommandTrigger) {
/*  61 */       NBTTagCompound tag = stack.func_77978_p();
/*  62 */       if (tag != null && !tag.func_74767_n("Unwrap")) {
/*     */         
/*  64 */         if (tag.func_74762_e("Delay") > 0) {
/*  65 */           tag.func_74768_a("Delay", tag.func_74762_e("Delay") - 1);
/*     */           
/*     */           return;
/*     */         } 
/*  69 */         EntityPlayer player = (EntityPlayer)entity;
/*  70 */         stack.field_77994_a--;
/*     */         
/*  72 */         if (!world.field_72995_K) {
/*  73 */           runCommands(stack, player);
/*     */         }
/*     */         
/*  76 */         if (stack.field_77994_a <= 0) {
/*  77 */           player.field_71071_by.field_70462_a[slot] = null;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77659_a(ItemStack stack, World world, EntityPlayer player) {
/*  88 */     if (!world.field_72995_K) {
/*  89 */       runCommands(stack, player);
/*     */     }
/*     */     
/*  92 */     if (stack.field_77994_a <= 0) {
/*  93 */       player.field_71071_by.field_70462_a[player.field_71071_by.field_70461_c] = null;
/*     */     }
/*     */     
/*  96 */     return stack;
/*     */   }
/*     */   
/*     */   public void runCommands(ItemStack stack, EntityPlayer player) {
/*     */     try {
/* 101 */       NBTTagCompound tag = stack.func_77978_p();
/* 102 */       if (tag != null) {
/* 103 */         CommandSenderGeneric sender = new CommandSenderGeneric(stack.func_82833_r(), player.field_70170_p, new Vec3(player.field_70165_t, player.field_70163_u, player.field_70161_v));
/*     */         
/* 105 */         ICommandManager manager = MinecraftServer.func_71276_C().func_71187_D();
/*     */         
/* 107 */         if (tag.func_150297_b("CommandList", 9)) {
/* 108 */           NBTTagList tagList = tag.func_150295_c("CommandList", 8);
/* 109 */           for (int i = 0; i < tagList.func_74745_c(); i++) {
/* 110 */             String command = tagList.func_150307_f(i);
/* 111 */             manager.func_71556_a(sender, command);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 116 */         if (tag.func_150297_b("Next", 10) && !tag.func_74767_n("Stop")) {
/*     */ 
/*     */           
/* 119 */           NBTTagCompound thisItem = (NBTTagCompound)tag.func_74737_b();
/* 120 */           thisItem.func_82580_o("Next");
/* 121 */           tag = tag.func_74775_l("Next");
/*     */           
/* 123 */           if (tag.func_150297_b("DelayMax", 3)) {
/* 124 */             tag.func_74768_a("Delay", tag.func_74762_e("DelayMax"));
/*     */           }
/*     */           
/* 127 */           NBTTagCompound lastTag = tag;
/*     */ 
/*     */           
/* 130 */           while (lastTag.func_150297_b("Next", 10)) {
/* 131 */             lastTag = lastTag.func_74775_l("Next");
/*     */           }
/*     */ 
/*     */           
/* 135 */           lastTag.func_74782_a("Next", (NBTBase)thisItem);
/* 136 */           stack.func_77982_d(tag);
/*     */         } else {
/*     */           
/* 139 */           stack.field_77994_a--;
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 144 */     } catch (Exception e) {
/* 145 */       System.err.println("[Loot++] Problem while running command from item!");
/* 146 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\ItemCommandTrigger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */