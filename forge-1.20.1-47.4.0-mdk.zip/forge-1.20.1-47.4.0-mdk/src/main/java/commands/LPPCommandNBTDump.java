/*    */ package com.tmtravlr.lootplusplus.commands;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.PrintStream;
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.command.WrongUsageException;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ 
/*    */ public class LPPCommandNBTDump
/*    */   extends CommandBase
/*    */ {
/*    */   public String func_71517_b() {
/* 20 */     return "lppnbtdump";
/*    */   }
/*    */ 
/*    */   
/*    */   public String func_71518_a(ICommandSender sender) {
/* 25 */     return "commands.lppnbtdump.usage";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/* 31 */     if (args.length != 1) {
/* 32 */       throw new WrongUsageException("commands.lppnbtdump.usage", new Object[0]);
/*    */     }
/*    */     
/* 35 */     if (sender instanceof EntityPlayer) {
/* 36 */       EntityPlayer player = (EntityPlayer)sender;
/*    */       
/* 38 */       File nbtOutput = new File(LootPPHelper.idFolder, "NBTOutput.txt");
/*    */       
/*    */       try {
/* 41 */         PrintStream writeStream = new PrintStream(nbtOutput);
/*    */ 
/*    */         
/* 44 */         for (ItemStack stack : player.field_71071_by.field_70462_a) {
/* 45 */           if (stack != null && stack.func_77978_p() != null) {
/* 46 */             writeStream.println(stack.func_77978_p().toString());
/*    */           }
/*    */         } 
/* 49 */         writeStream.close();
/*    */         
/* 51 */         func_152373_a(sender, (ICommand)this, "commands.lppnbtdump.success", new Object[0]);
/*    */       }
/* 53 */       catch (FileNotFoundException e) {
/* 54 */         e.printStackTrace();
/* 55 */         throw new CommandException("commands.lppnbtdump.failed", new Object[0]);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandNBTDump.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */