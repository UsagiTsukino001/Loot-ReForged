/*    */ package com.tmtravlr.lootplusplus.commands;
/*    */ 
/*    */ import net.minecraft.command.CommandResultStats;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.ChatComponentText;
/*    */ import net.minecraft.util.IChatComponent;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.util.Vec3;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class CommandSenderGeneric
/*    */   implements ICommandSender {
/*    */   private String name;
/*    */   private World worldObj;
/*    */   private BlockPos position;
/*    */   private Vec3 vecPosition;
/*    */   
/*    */   public CommandSenderGeneric(String senderName, World world, BlockPos pos) {
/* 21 */     this.name = senderName;
/* 22 */     this.worldObj = world;
/* 23 */     this.position = pos;
/* 24 */     this.vecPosition = new Vec3(this.position.func_177958_n(), this.position.func_177956_o(), this.position.func_177952_p());
/*    */   }
/*    */   
/*    */   public CommandSenderGeneric(String senderName, World world, Vec3 pos) {
/* 28 */     this.name = senderName;
/* 29 */     this.worldObj = world;
/* 30 */     this.position = new BlockPos(MathHelper.func_76128_c(pos.field_72450_a), MathHelper.func_76128_c(pos.field_72448_b), MathHelper.func_76128_c(pos.field_72449_c));
/* 31 */     this.vecPosition = pos;
/*    */   }
/*    */ 
/*    */   
/*    */   public String func_70005_c_() {
/* 36 */     return this.name;
/*    */   }
/*    */ 
/*    */   
/*    */   public IChatComponent func_145748_c_() {
/* 41 */     return (IChatComponent)new ChatComponentText(func_70005_c_());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_70003_b(int permissionLevel, String command) {
/* 46 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public World func_130014_f_() {
/* 51 */     return this.worldObj;
/*    */   }
/*    */ 
/*    */   
/*    */   public BlockPos func_180425_c() {
/* 56 */     return this.position;
/*    */   }
/*    */ 
/*    */   
/*    */   public Vec3 func_174791_d() {
/* 61 */     return this.vecPosition;
/*    */   }
/*    */ 
/*    */   
/*    */   public Entity func_174793_f() {
/* 66 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_174792_t_() {
/* 71 */     return false;
/*    */   }
/*    */   
/*    */   public void func_174794_a(CommandResultStats.Type type, int amount) {}
/*    */   
/*    */   public void func_145747_a(IChatComponent message) {}
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\CommandSenderGeneric.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */