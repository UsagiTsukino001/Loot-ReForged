/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.command.WrongUsageException;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LPPCommandDamageItem
/*     */   extends CommandBase
/*     */ {
/*     */   public String func_71517_b() {
/*  24 */     return "lppdamageitem";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_82362_a() {
/*  32 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/*  37 */     return "commands.lppdamageitem.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/*  45 */     if (args.length < 3)
/*     */     {
/*  47 */       throw new WrongUsageException("commands.lppdamageitem.usage", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*  51 */     this; EntityLivingBase entity = (EntityLivingBase)func_175759_a(sender, args[0], EntityLivingBase.class);
/*     */     
/*  53 */     int amount = func_180528_a(args[2], 0);
/*  54 */     ItemStack stack = null;
/*     */     
/*  56 */     if (args[1].equals("held")) {
/*  57 */       stack = entity.func_70694_bm();
/*     */     }
/*  59 */     else if (args[1].equals("head")) {
/*  60 */       stack = entity.func_82169_q(3);
/*     */     }
/*  62 */     else if (args[1].equals("chest")) {
/*  63 */       stack = entity.func_82169_q(2);
/*     */     }
/*  65 */     else if (args[1].equals("legs")) {
/*  66 */       stack = entity.func_82169_q(1);
/*     */     }
/*  68 */     else if (args[1].equals("feet")) {
/*  69 */       stack = entity.func_82169_q(0);
/*     */     } else {
/*     */       
/*  72 */       throw new CommandException("commands.lppdamageitem.notvaliditem", new Object[] { args[1] });
/*     */     } 
/*     */     
/*  75 */     if (stack != null) {
/*  76 */       if (!(sender.func_130014_f_()).field_72995_K) {
/*  77 */         stack.func_96631_a(amount, new Random());
/*     */       }
/*  79 */       func_152373_a(sender, (ICommand)this, "commands.lppdamageitem.success", new Object[] { stack.func_82833_r() });
/*     */     } else {
/*     */       
/*  82 */       throw new CommandException("commands.lppdamageitem.noitem", new Object[] { args[1] });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/*  89 */     return (args.length == 1) ? func_71530_a(args, getAllUsernames()) : ((args.length == 2) ? func_71530_a(args, new String[] { "held", "head", "chest", "legs", "feet" }) : null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] getAllUsernames() {
/*  94 */     return MinecraftServer.func_71276_C().func_71213_z();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82358_a(String[] args, int index) {
/* 102 */     return (index == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandDamageItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */