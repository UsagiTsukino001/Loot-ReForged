/*    */ package com.tmtravlr.lootplusplus.commands;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPBlocks;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockCommandBlockTrigger
/*    */   extends Block
/*    */ {
/*    */   public BlockCommandBlockTrigger() {
/* 25 */     super(Material.field_151573_f);
/* 26 */     this.field_149785_s = true;
/* 27 */     func_149713_g(0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_176213_c(World world, BlockPos pos, IBlockState state) {
/* 35 */     world.func_175684_a(pos, this, 2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_180650_b(World world, BlockPos pos, IBlockState state, Random rand) {
/* 43 */     for (int ix = -5; ix < 6; ix++) {
/* 44 */       for (int iy = -5; iy < 6; iy++) {
/* 45 */         for (int iz = -5; iz < 6; iz++) {
/* 46 */           BlockPos iPos = pos.func_177982_a(ix, iy, iz);
/* 47 */           if (world.func_175667_e(iPos) && world.func_180495_p(iPos).func_177230_c() == Blocks.field_150483_bI) {
/* 48 */             Blocks.field_150483_bI.func_180650_b(world, iPos, world.func_180495_p(iPos), rand);
/*    */             
/* 50 */             if (world.func_180495_p(iPos).func_177230_c() == Blocks.field_150483_bI) {
/* 51 */               world.func_175698_g(iPos);
/*    */             }
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 58 */     if (world.func_180495_p(pos).func_177230_c() == LootPPBlocks.blockCommandBlockTrigger) {
/* 59 */       world.func_175698_g(pos);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_149662_c() {
/* 70 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int func_149645_b() {
/* 75 */     return -1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public float func_149685_I() {
/* 84 */     return 1.0F;
/*    */   }
/*    */   
/*    */   public void func_180653_a(World worldIn, BlockPos pos, IBlockState state, float chance, int fortune) {}
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\BlockCommandBlockTrigger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */