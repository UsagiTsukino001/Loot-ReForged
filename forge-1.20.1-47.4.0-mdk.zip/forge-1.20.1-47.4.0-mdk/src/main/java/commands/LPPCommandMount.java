/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPTeleporter;
/*     */ import com.tmtravlr.lootplusplus.LootPPTickHandlerServer;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.command.WrongUsageException;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LPPCommandMount
/*     */   extends CommandBase
/*     */ {
/*     */   public String func_71517_b() {
/*  32 */     return "lppmount";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_82362_a() {
/*  40 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/*  45 */     return "commands.lppmount.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/*  52 */     if (args.length < 1)
/*     */     {
/*  54 */       throw new WrongUsageException("commands.lppmount.usage", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*  58 */     boolean dismount = false;
/*  59 */     Entity mount = null;
/*  60 */     Entity rider = null;
/*     */ 
/*     */ 
/*     */     
/*  64 */     if (args[0].equalsIgnoreCase("none") || args[0].equalsIgnoreCase("null") || args[0].equalsIgnoreCase("clear")) {
/*  65 */       mount = null;
/*  66 */       dismount = true;
/*     */     } else {
/*     */       
/*  69 */       mount = func_175768_b(sender, args[0]);
/*     */     } 
/*     */     
/*  72 */     if (args.length == 1) {
/*  73 */       EntityPlayerMP entityPlayerMP = func_71521_c(sender);
/*     */     
/*     */     }
/*  76 */     else if (args[1].equalsIgnoreCase("none") || args[1].equalsIgnoreCase("null") || args[1].equalsIgnoreCase("clear")) {
/*  77 */       rider = null;
/*  78 */       dismount = true;
/*     */     } else {
/*     */       
/*  81 */       rider = func_175768_b(sender, args[1]);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     if (dismount) {
/*  88 */       if (rider != null) {
/*  89 */         rider.func_70078_a((Entity)null);
/*  90 */         func_152373_a(sender, (ICommand)this, "commands.lppmount.success.dismount", new Object[] { rider.func_70005_c_() });
/*     */       }
/*  92 */       else if (mount != null && mount.field_70153_n != null) {
/*  93 */         mount.field_70153_n.func_70078_a((Entity)null);
/*  94 */         func_152373_a(sender, (ICommand)this, "commands.lppmount.success.dismount", new Object[] { mount.field_70153_n.func_70005_c_() });
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 101 */       if (rider == mount) {
/* 102 */         throw new CommandException("commands.lppmount.failure.self", new Object[0]);
/*     */       }
/*     */       
/* 105 */       World newWorld = mount.field_70170_p;
/*     */       
/* 107 */       double x = mount.field_70165_t;
/* 108 */       double y = mount.field_70163_u;
/* 109 */       double z = mount.field_70161_v;
/*     */       
/* 111 */       float pitch = mount.field_70125_A;
/* 112 */       float yaw = mount.field_70177_z;
/*     */       
/* 114 */       double motionX = mount.field_70159_w;
/* 115 */       double motionY = mount.field_70181_x;
/* 116 */       double motionZ = mount.field_70179_y;
/*     */ 
/*     */ 
/*     */       
/* 120 */       rider.func_70078_a((Entity)null);
/*     */       
/* 122 */       if (rider instanceof EntityPlayerMP) {
/* 123 */         LootPPTeleporter.teleportPlayer((EntityPlayerMP)rider, null, newWorld, x, y, z, pitch, yaw, motionX, motionY, motionZ);
/*     */       } else {
/*     */         
/* 126 */         rider = LootPPTeleporter.teleportEntity(rider, newWorld, x, y, z, pitch, yaw, motionX, motionY, motionZ);
/*     */       } 
/*     */       
/* 129 */       if (mount.field_70153_n != null) {
/* 130 */         mount.field_70153_n.func_70078_a((Entity)null);
/*     */         
/* 132 */         LootPPTickHandlerServer.entitiesToStack.put(mount, rider);
/*     */       } else {
/*     */         
/* 135 */         rider.func_70078_a(mount);
/*     */       } 
/*     */       
/* 138 */       func_152373_a(sender, (ICommand)this, "commands.lppmount.success", new Object[] { rider.func_70005_c_(), mount.func_70005_c_() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/* 145 */     return (args.length != 1 && args.length != 2) ? null : func_71530_a(args, MinecraftServer.func_71276_C().func_71213_z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82358_a(String[] args, int index) {
/* 153 */     return (index == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandMount.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */