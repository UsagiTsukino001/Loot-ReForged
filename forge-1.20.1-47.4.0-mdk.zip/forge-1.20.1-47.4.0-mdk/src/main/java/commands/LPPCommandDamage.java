/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.command.WrongUsageException;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.DamageSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LPPCommandDamage
/*     */   extends CommandBase
/*     */ {
/*     */   public String func_71517_b() {
/*  26 */     return "lppdamage";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_82362_a() {
/*  34 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/*  39 */     return "commands.lppdamage.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/*  47 */     if (args.length < 3)
/*     */     {
/*  49 */       throw new WrongUsageException("commands.lppdamage.usage", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*  53 */     this; Entity entity = func_175759_a(sender, args[0], Entity.class);
/*     */     
/*  55 */     float amount = (float)func_180526_a(args[2], 0.0D);
/*     */     
/*  57 */     if (args[1].equals("anvil")) {
/*  58 */       entity.func_70097_a(DamageSource.field_82728_o, amount);
/*     */     }
/*  60 */     else if (args[1].equals("cactus")) {
/*  61 */       entity.func_70097_a(DamageSource.field_76367_g, amount);
/*     */     }
/*  63 */     else if (args[1].equals("drown")) {
/*  64 */       entity.func_70097_a(DamageSource.field_76369_e, amount);
/*     */     }
/*  66 */     else if (args[1].equals("fall")) {
/*  67 */       entity.func_70097_a(DamageSource.field_76379_h, amount);
/*     */     }
/*  69 */     else if (args[1].equals("fallingBlock")) {
/*  70 */       entity.func_70097_a(DamageSource.field_82729_p, amount);
/*     */     }
/*  72 */     else if (args[1].equals("generic")) {
/*  73 */       entity.func_70097_a(DamageSource.field_76377_j, amount);
/*     */     }
/*  75 */     else if (args[1].equals("inFire")) {
/*  76 */       entity.func_70097_a(DamageSource.field_76372_a, amount);
/*     */     }
/*  78 */     else if (args[1].equals("inWall")) {
/*  79 */       entity.func_70097_a(DamageSource.field_76368_d, amount);
/*     */     }
/*  81 */     else if (args[1].equals("lava")) {
/*  82 */       entity.func_70097_a(DamageSource.field_76371_c, amount);
/*     */     }
/*  84 */     else if (args[1].equals("lightningBolt")) {
/*  85 */       entity.func_70097_a(DamageSource.field_180137_b, amount);
/*     */     }
/*  87 */     else if (args[1].equals("magic")) {
/*  88 */       entity.func_70097_a(DamageSource.field_76376_m, amount);
/*     */     }
/*  90 */     else if (args[1].equals("onFire")) {
/*  91 */       entity.func_70097_a(DamageSource.field_76370_b, amount);
/*     */     }
/*  93 */     else if (args[1].equals("outOfWorld")) {
/*  94 */       entity.func_70097_a(DamageSource.field_76380_i, amount);
/*     */     }
/*  96 */     else if (args[1].equals("starve")) {
/*  97 */       entity.func_70097_a(DamageSource.field_76366_f, amount);
/*     */     }
/*  99 */     else if (args[1].equals("wither")) {
/* 100 */       entity.func_70097_a(DamageSource.field_82727_n, amount);
/*     */     } else {
/*     */       
/* 103 */       throw new CommandException("commands.lppdamage.notvaliddamage", new Object[] { args[1] });
/*     */     } 
/*     */     
/* 106 */     func_152373_a(sender, (ICommand)this, "commands.lppdamage.success", new Object[] { entity.func_70005_c_() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/* 113 */     return (args.length == 1) ? func_71530_a(args, getAllUsernames()) : ((args.length == 2) ? func_71530_a(args, new String[] { "anvil", "cactus", "drown", "fall", "fallingBlock", "generic", "inFire", "inWall", "lava", "lightningBolt", "magic", "onFire", "outOfWorld", "starve", "wither" }) : null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] getAllUsernames() {
/* 118 */     return MinecraftServer.func_71276_C().func_71213_z();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82358_a(String[] args, int index) {
/* 126 */     return (index == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandDamage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */