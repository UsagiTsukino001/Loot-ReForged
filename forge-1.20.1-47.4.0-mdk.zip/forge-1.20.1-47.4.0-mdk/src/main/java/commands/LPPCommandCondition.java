/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.command.WrongUsageException;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LPPCommandCondition
/*     */   extends CommandBase
/*     */ {
/*     */   public String func_71517_b() {
/*  27 */     return "lppcondition";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_82362_a() {
/*  35 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/*  40 */     return "commands.lppcondition.usage";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/*  47 */     if (sender.func_130014_f_() != null && !(sender.func_130014_f_()).field_72995_K) {
/*     */       
/*  49 */       if (args.length < 1) {
/*  50 */         throw new WrongUsageException("commands.lppcondition.usage", new Object[0]);
/*     */       }
/*     */       
/*  53 */       String conditionCommand = "";
/*  54 */       String trueCommand = "";
/*  55 */       String falseCommand = "";
/*     */       
/*  57 */       int trueIndex = -1;
/*  58 */       int falseIndex = -1;
/*     */       
/*     */       int i;
/*  61 */       for (i = 0; i < args.length; i++) {
/*  62 */         if (args[i].equals("_if_true_")) {
/*  63 */           trueIndex = i + 1;
/*     */           
/*     */           break;
/*     */         } 
/*  67 */         if (args[i].equals("_if_false_")) {
/*  68 */           falseIndex = i + 1;
/*     */           
/*     */           break;
/*     */         } 
/*  72 */         conditionCommand = conditionCommand + ((i == 0) ? "" : " ") + args[i];
/*     */       } 
/*     */ 
/*     */       
/*  76 */       if (trueIndex > 0) {
/*  77 */         for (i = trueIndex; i < args.length; i++) {
/*  78 */           if (args[i].equals("_if_false_")) {
/*  79 */             falseIndex = i + 1;
/*     */             
/*     */             break;
/*     */           } 
/*  83 */           trueCommand = trueCommand + ((i == 0) ? "" : " ") + args[i];
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*  88 */       if (falseIndex > 0) {
/*  89 */         for (i = falseIndex; i < args.length; i++) {
/*  90 */           falseCommand = falseCommand + ((i == 0) ? "" : " ") + args[i];
/*     */         }
/*     */       }
/*     */       
/*  94 */       int success = 0;
/*     */       
/*     */       try {
/*  97 */         success = MinecraftServer.func_71276_C().func_71187_D().func_71556_a(sender, conditionCommand);
/*     */       }
/*  99 */       catch (Exception e) {
/* 100 */         success = 0;
/*     */       } 
/*     */       
/* 103 */       if (success > 0) {
/* 104 */         if (!trueCommand.isEmpty()) {
/* 105 */           MinecraftServer.func_71276_C().func_71187_D().func_71556_a(sender, trueCommand);
/* 106 */           func_152373_a(sender, (ICommand)this, "commands.lppcondition.success.true", new Object[0]);
/*     */         }
/*     */       
/*     */       }
/* 110 */       else if (!falseCommand.isEmpty()) {
/* 111 */         MinecraftServer.func_71276_C().func_71187_D().func_71556_a(sender, falseCommand);
/* 112 */         func_152373_a(sender, (ICommand)this, "commands.lppcondition.success.false", new Object[0]);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandCondition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */