/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPTeleporter;
/*     */ import java.util.EnumSet;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.EntityNotFoundException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.command.WrongUsageException;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.network.play.server.S08PacketPlayerPosLook;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LPPCommandTeleport
/*     */   extends CommandBase
/*     */ {
/*     */   public String func_71517_b() {
/*  30 */     return "lpptp";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_82362_a() {
/*  38 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/*  43 */     return "commands.lpptp.usage";
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/*     */     EntityPlayerMP entityPlayerMP;
/*  49 */     if (args.length < 1)
/*     */     {
/*  51 */       throw new WrongUsageException("commands.lpptp.usage", new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*  55 */     byte startIndex = 0;
/*     */     
/*  57 */     Entity toTeleportTo = null;
/*     */     
/*  59 */     if (args.length > 1) {
/*     */       try {
/*  61 */         Entity toTeleport = func_175768_b(sender, args[0]);
/*  62 */         startIndex = 1;
/*     */       }
/*  64 */       catch (EntityNotFoundException e) {
/*  65 */         entityPlayerMP = func_71521_c(sender);
/*     */       } 
/*     */     } else {
/*     */       
/*  69 */       entityPlayerMP = func_71521_c(sender);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  74 */     double x = ((Entity)entityPlayerMP).field_70165_t;
/*  75 */     double y = ((Entity)entityPlayerMP).field_70163_u;
/*  76 */     double z = ((Entity)entityPlayerMP).field_70161_v;
/*  77 */     float pitch = ((Entity)entityPlayerMP).field_70125_A;
/*  78 */     float yaw = ((Entity)entityPlayerMP).field_70177_z;
/*  79 */     double motionX = 0.0D;
/*  80 */     double motionY = 0.0D;
/*  81 */     double motionZ = 0.0D;
/*  82 */     World newWorld = ((Entity)entityPlayerMP).field_70170_p;
/*     */     
/*  84 */     EnumSet<S08PacketPlayerPosLook.EnumFlags> packetSet = null;
/*     */     
/*  86 */     if (args.length > 2) {
/*     */       
/*  88 */       if (args.length < startIndex + 3)
/*     */       {
/*  90 */         throw new WrongUsageException("commands.lpptp.usage", new Object[0]);
/*     */       }
/*  92 */       if (((Entity)entityPlayerMP).field_70170_p != null)
/*     */       {
/*  94 */         int i = startIndex + 1;
/*  95 */         CommandBase.CoordinateArg argX = func_175770_a(((Entity)entityPlayerMP).field_70165_t, args[startIndex], true);
/*  96 */         CommandBase.CoordinateArg argY = func_175767_a(((Entity)entityPlayerMP).field_70163_u, args[i++], 0, 0, false);
/*  97 */         CommandBase.CoordinateArg argZ = func_175770_a(((Entity)entityPlayerMP).field_70161_v, args[i++], true);
/*  98 */         CommandBase.CoordinateArg argYaw = func_175770_a(((Entity)entityPlayerMP).field_70177_z, (args.length > i) ? args[i++] : "~", false);
/*  99 */         CommandBase.CoordinateArg argPitch = func_175770_a(((Entity)entityPlayerMP).field_70125_A, (args.length > i) ? args[i++] : "~", false);
/* 100 */         CommandBase.CoordinateArg argMotX = func_175770_a(((Entity)entityPlayerMP).field_70159_w, (args.length > i) ? args[i++] : "~", false);
/* 101 */         CommandBase.CoordinateArg argMotY = func_175770_a(((Entity)entityPlayerMP).field_70181_x, (args.length > i) ? args[i++] : "~", false);
/* 102 */         CommandBase.CoordinateArg argMotZ = func_175770_a(((Entity)entityPlayerMP).field_70179_y, (args.length > i) ? args[i++] : "~", false);
/* 103 */         String dimensionString = (args.length > i) ? args[i] : String.valueOf(((Entity)entityPlayerMP).field_71093_bK);
/*     */ 
/*     */ 
/*     */         
/* 107 */         int dimension = ((Entity)entityPlayerMP).field_71093_bK;
/*     */         
/*     */         try {
/* 110 */           dimension = Integer.valueOf(dimensionString).intValue();
/*     */         }
/* 112 */         catch (NumberFormatException e) {
/* 113 */           e.printStackTrace();
/* 114 */           throw new CommandException("commands.lpptp.notValidDimension", new Object[] { dimensionString });
/*     */         } 
/*     */         
/* 117 */         WorldServer worldServer = MinecraftServer.func_71276_C().func_71218_a(dimension);
/*     */         
/* 119 */         if (worldServer == null) {
/* 120 */           throw new CommandException("commands.lpptp.notValidDimension", new Object[] { dimensionString });
/*     */         }
/*     */         
/* 123 */         motionX = argMotX.func_179629_b();
/* 124 */         motionY = argMotY.func_179629_b();
/* 125 */         motionZ = argMotZ.func_179629_b();
/*     */         
/* 127 */         if (entityPlayerMP instanceof EntityPlayerMP)
/*     */         {
/* 129 */           EnumSet<S08PacketPlayerPosLook.EnumFlags> enumset = EnumSet.noneOf(S08PacketPlayerPosLook.EnumFlags.class);
/*     */           
/* 131 */           if (argX.func_179630_c())
/*     */           {
/* 133 */             enumset.add(S08PacketPlayerPosLook.EnumFlags.X);
/*     */           }
/*     */           
/* 136 */           if (argY.func_179630_c())
/*     */           {
/* 138 */             enumset.add(S08PacketPlayerPosLook.EnumFlags.Y);
/*     */           }
/*     */           
/* 141 */           if (argZ.func_179630_c())
/*     */           {
/* 143 */             enumset.add(S08PacketPlayerPosLook.EnumFlags.Z);
/*     */           }
/*     */           
/* 146 */           if (argPitch.func_179630_c())
/*     */           {
/* 148 */             enumset.add(S08PacketPlayerPosLook.EnumFlags.X_ROT);
/*     */           }
/*     */           
/* 151 */           if (argYaw.func_179630_c())
/*     */           {
/* 153 */             enumset.add(S08PacketPlayerPosLook.EnumFlags.Y_ROT);
/*     */           }
/*     */           
/* 156 */           yaw = (float)argYaw.func_179629_b();
/*     */           
/* 158 */           if (!argYaw.func_179630_c())
/*     */           {
/* 160 */             yaw = MathHelper.func_76142_g(yaw);
/*     */           }
/*     */           
/* 163 */           pitch = (float)argPitch.func_179629_b();
/*     */           
/* 165 */           if (!argPitch.func_179630_c())
/*     */           {
/* 167 */             pitch = MathHelper.func_76142_g(pitch);
/*     */           }
/*     */           
/* 170 */           if (pitch > 90.0F || pitch < -90.0F) {
/*     */             
/* 172 */             pitch = MathHelper.func_76142_g(180.0F - pitch);
/* 173 */             yaw = MathHelper.func_76142_g(yaw + 180.0F);
/*     */           } 
/*     */           
/* 176 */           if (dimension == ((Entity)entityPlayerMP).field_71093_bK) {
/* 177 */             x = argX.func_179629_b();
/* 178 */             y = argY.func_179629_b();
/* 179 */             z = argZ.func_179629_b();
/*     */           } else {
/*     */             
/* 182 */             x = argX.func_179628_a();
/* 183 */             y = argY.func_179628_a();
/* 184 */             z = argZ.func_179628_a();
/*     */           } 
/*     */           
/* 187 */           packetSet = enumset;
/*     */         }
/*     */         else
/*     */         {
/* 191 */           yaw = (float)MathHelper.func_76138_g(argYaw.func_179628_a());
/* 192 */           pitch = (float)MathHelper.func_76138_g(argPitch.func_179628_a());
/*     */           
/* 194 */           if (yaw > 90.0F || yaw < -90.0F) {
/*     */             
/* 196 */             pitch = MathHelper.func_76142_g(180.0F - pitch);
/* 197 */             yaw = MathHelper.func_76142_g(yaw + 180.0F);
/*     */           } 
/*     */           
/* 200 */           x = argX.func_179628_a();
/* 201 */           y = argY.func_179628_a();
/* 202 */           z = argZ.func_179628_a();
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 210 */       toTeleportTo = func_175768_b(sender, args[args.length - 1]);
/*     */       
/* 212 */       newWorld = toTeleportTo.field_70170_p;
/*     */       
/* 214 */       x = toTeleportTo.field_70165_t;
/* 215 */       y = toTeleportTo.field_70163_u;
/* 216 */       z = toTeleportTo.field_70161_v;
/*     */       
/* 218 */       pitch = toTeleportTo.field_70125_A;
/* 219 */       yaw = toTeleportTo.field_70177_z;
/*     */       
/* 221 */       motionX = toTeleportTo.field_70159_w;
/* 222 */       motionY = toTeleportTo.field_70181_x;
/* 223 */       motionZ = toTeleportTo.field_70179_y;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 231 */     entityPlayerMP.func_70078_a((Entity)null);
/*     */     
/* 233 */     if (entityPlayerMP instanceof EntityPlayerMP) {
/* 234 */       LootPPTeleporter.teleportPlayer(entityPlayerMP, packetSet, newWorld, x, y, z, pitch, yaw, motionX, motionY, motionZ);
/*     */     } else {
/*     */       
/* 237 */       LootPPTeleporter.teleportEntity((Entity)entityPlayerMP, newWorld, x, y, z, pitch, yaw, motionX, motionY, motionZ);
/*     */     } 
/*     */     
/* 240 */     if (toTeleportTo == null) {
/* 241 */       func_152373_a(sender, (ICommand)this, "commands.lpptp.success.coordinates", new Object[] { entityPlayerMP.func_70005_c_(), Double.valueOf(x), Double.valueOf(y), Double.valueOf(z), Integer.valueOf(newWorld.field_73011_w.func_177502_q()) });
/*     */     } else {
/*     */       
/* 244 */       func_152373_a(sender, (ICommand)this, "commands.tp.success", new Object[] { entityPlayerMP.func_70005_c_(), toTeleportTo.func_70005_c_() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/* 251 */     return (args.length != 1 && args.length != 2) ? null : func_71530_a(args, MinecraftServer.func_71276_C().func_71213_z());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82358_a(String[] args, int index) {
/* 259 */     return (index == 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandTeleport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */