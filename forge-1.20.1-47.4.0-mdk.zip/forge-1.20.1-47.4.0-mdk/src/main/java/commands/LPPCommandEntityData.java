/*    */ package com.tmtravlr.lootplusplus.commands;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.command.WrongUsageException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.nbt.JsonToNBT;
/*    */ import net.minecraft.nbt.NBTException;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ import net.minecraft.util.BlockPos;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LPPCommandEntityData
/*    */   extends CommandBase
/*    */ {
/*    */   public String func_71517_b() {
/* 24 */     return "lppentitydata";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_82362_a() {
/* 32 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public String func_71518_a(ICommandSender sender) {
/* 37 */     return "commands.lppentitydata.usage";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/*    */     NBTTagCompound nbttagcompound2;
/* 45 */     if (args.length < 2)
/*    */     {
/* 47 */       throw new WrongUsageException("commands.lppentitydata.usage", new Object[0]);
/*    */     }
/*    */ 
/*    */     
/* 51 */     Entity entity = func_175768_b(sender, args[0]);
/*    */ 
/*    */     
/* 54 */     NBTTagCompound nbttagcompound = new NBTTagCompound();
/* 55 */     entity.func_70109_d(nbttagcompound);
/* 56 */     NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttagcompound.func_74737_b();
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 61 */       nbttagcompound2 = JsonToNBT.func_180713_a(func_147178_a(sender, args, 1).func_150260_c());
/*    */     }
/* 63 */     catch (NBTException nbtexception) {
/*    */       
/* 65 */       throw new CommandException("commands.entitydata.tagError", new Object[] { nbtexception.getMessage() });
/*    */     } 
/*    */     
/* 68 */     nbttagcompound2.func_82580_o("UUIDMost");
/* 69 */     nbttagcompound2.func_82580_o("UUIDLeast");
/* 70 */     nbttagcompound.func_179237_a(nbttagcompound2);
/*    */     
/* 72 */     if (nbttagcompound.equals(nbttagcompound1))
/*    */     {
/* 74 */       throw new CommandException("commands.entitydata.failed", new Object[] { nbttagcompound.toString() });
/*    */     }
/*    */ 
/*    */     
/* 78 */     entity.func_70020_e(nbttagcompound);
/* 79 */     func_152373_a(sender, (ICommand)this, "commands.entitydata.success", new Object[] { nbttagcompound.toString() });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/* 87 */     return (args.length == 1) ? func_71530_a(args, MinecraftServer.func_71276_C().func_71213_z()) : null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_82358_a(String[] args, int index) {
/* 95 */     return (index == 0);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandEntityData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */