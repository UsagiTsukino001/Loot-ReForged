/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.command.CommandBase;
/*     */ import net.minecraft.command.CommandException;
/*     */ import net.minecraft.command.ICommand;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.command.WrongUsageException;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.world.ILockableContainer;
/*     */ import net.minecraft.world.LockCode;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LPPCommandLock
/*     */   extends CommandBase
/*     */ {
/*     */   public String func_71517_b() {
/*  23 */     return "lpplock";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_82362_a() {
/*  32 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_71518_a(ICommandSender sender) {
/*  37 */     return "commands.lpplock.usage";
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/*  42 */     if (args.length < 1 || args.length > 4) {
/*  43 */       throw new WrongUsageException("commands.lpplock.usage", new Object[0]);
/*     */     }
/*     */     
/*  46 */     if (args.length == 1) {
/*  47 */       Entity inventoryEntity = func_175768_b(sender, args[0]);
/*     */       
/*  49 */       if (inventoryEntity instanceof ILockableContainer) {
/*  50 */         if (!(sender.func_130014_f_()).field_72995_K) {
/*  51 */           ((ILockableContainer)inventoryEntity).func_174892_a(LockCode.field_180162_a);
/*     */         }
/*     */         
/*  54 */         func_152373_a(sender, (ICommand)this, "commands.lpplock.unlock.success", new Object[] { inventoryEntity.func_70005_c_() });
/*     */       } else {
/*     */         
/*  57 */         throw new CommandException("commands.lpplock.notLockable", new Object[] { inventoryEntity.func_70005_c_() });
/*     */       }
/*     */     
/*  60 */     } else if (args.length == 2) {
/*  61 */       String lock = args[1];
/*     */       
/*  63 */       Entity inventoryEntity = func_175768_b(sender, args[0]);
/*     */       
/*  65 */       if (inventoryEntity instanceof ILockableContainer) {
/*  66 */         if (!(sender.func_130014_f_()).field_72995_K) {
/*  67 */           ((ILockableContainer)inventoryEntity).func_174892_a(new LockCode(lock));
/*     */         }
/*     */         
/*  70 */         func_152373_a(sender, (ICommand)this, "commands.lpplock.success", new Object[] { lock, inventoryEntity.func_70005_c_() });
/*     */       } else {
/*     */         
/*  73 */         throw new CommandException("commands.lpplock.notLockable", new Object[] { inventoryEntity.func_70005_c_() });
/*     */       }
/*     */     
/*  76 */     } else if (args.length == 3) {
/*  77 */       BlockPos pos = func_175757_a(sender, args, 0, false);
/*     */       
/*  79 */       TileEntity te = sender.func_130014_f_().func_175625_s(pos);
/*     */       
/*  81 */       if (te instanceof net.minecraft.inventory.IInventory) {
/*  82 */         if (!(sender.func_130014_f_()).field_72995_K) {
/*  83 */           ((ILockableContainer)te).func_174892_a(LockCode.field_180162_a);
/*     */         }
/*     */         
/*  86 */         func_152373_a(sender, (ICommand)this, "commands.lpplock.unlock.success", new Object[] { pos });
/*     */       } else {
/*     */         
/*  89 */         throw new CommandException("commands.lpplock.notLockable", new Object[] { pos });
/*     */       } 
/*     */     } else {
/*     */       
/*  93 */       String lock = args[3];
/*     */       
/*  95 */       BlockPos pos = func_175757_a(sender, args, 0, false);
/*     */       
/*  97 */       TileEntity te = sender.func_130014_f_().func_175625_s(pos);
/*     */       
/*  99 */       if (te instanceof net.minecraft.inventory.IInventory) {
/* 100 */         if (!(sender.func_130014_f_()).field_72995_K) {
/* 101 */           ((ILockableContainer)te).func_174892_a(new LockCode(lock));
/*     */         }
/*     */         
/* 104 */         func_152373_a(sender, (ICommand)this, "commands.lpplock.success", new Object[] { lock, pos });
/*     */       } else {
/*     */         
/* 107 */         throw new CommandException("commands.lpplock.notLockable", new Object[] { pos });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/* 115 */     ArrayList<String> chestTypes = new ArrayList<String>();
/* 116 */     chestTypes.addAll(LootPPHelper.chestTypes);
/* 117 */     return (args.length > 0 && args.length <= 3) ? func_175771_a(args, 0, pos) : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandLock.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */