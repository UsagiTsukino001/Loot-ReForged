/*    */ package com.tmtravlr.lootplusplus.commands;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.command.CommandBase;
/*    */ import net.minecraft.command.CommandException;
/*    */ import net.minecraft.command.ICommand;
/*    */ import net.minecraft.command.ICommandSender;
/*    */ import net.minecraft.command.WrongUsageException;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import scala.actors.threadpool.Arrays;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LPPCommandExplode
/*    */   extends CommandBase
/*    */ {
/*    */   public String func_71517_b() {
/* 23 */     return "lppexplode";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_82362_a() {
/* 32 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public String func_71518_a(ICommandSender sender) {
/* 37 */     return "commands.lppexplode.usage";
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
/* 42 */     if (args.length < 4 || args.length > 7) {
/* 43 */       throw new WrongUsageException("commands.lppexplode.usage", new Object[0]);
/*    */     }
/*    */     
/* 46 */     float strength = 0.0F;
/* 47 */     boolean destroy = true;
/* 48 */     boolean fire = false;
/* 49 */     BlockPos pos = sender.func_180425_c();
/* 50 */     World world = sender.func_130014_f_();
/* 51 */     Entity cause = null;
/*    */     
/* 53 */     if (args.length < 6) {
/* 54 */       Entity entity = func_175768_b(sender, args[0]);
/* 55 */       pos = entity.func_180425_c();
/* 56 */       world = entity.func_130014_f_();
/* 57 */       strength = (float)CommandBase.func_175765_c(args[1]);
/* 58 */       destroy = CommandBase.func_180527_d(args[2]);
/* 59 */       fire = CommandBase.func_180527_d(args[3]);
/* 60 */       if (args.length == 5) {
/* 61 */         cause = func_175768_b(sender, args[4]);
/*    */       }
/*    */     } else {
/*    */       
/* 65 */       pos = func_175757_a(sender, args, 0, false);
/* 66 */       strength = (float)CommandBase.func_175765_c(args[3]);
/* 67 */       destroy = CommandBase.func_180527_d(args[4]);
/* 68 */       fire = CommandBase.func_180527_d(args[5]);
/* 69 */       if (args.length == 7) {
/* 70 */         cause = func_175768_b(sender, args[6]);
/*    */       }
/*    */     } 
/*    */     
/* 74 */     if (!world.field_72995_K) {
/* 75 */       world.func_72885_a(cause, pos.func_177958_n() + 0.5D, pos.func_177956_o() + 0.5D, pos.func_177952_p() + 0.5D, strength, fire, destroy);
/*    */     }
/*    */     
/* 78 */     func_152373_a(sender, (ICommand)this, "commands.lppexplode.success", new Object[] { pos });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List func_180525_a(ICommandSender sender, String[] args, BlockPos pos) {
/* 85 */     ArrayList<String> chestTypes = new ArrayList<String>();
/* 86 */     chestTypes.addAll(LootPPHelper.chestTypes);
/* 87 */     return (args.length <= 3) ? func_175771_a(args, 0, pos) : ((args.length == 4 || args.length == 5) ? Arrays.asList((Object[])new String[] { "true", "false" }) : null);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\LPPCommandExplode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */