/*     */ package com.tmtravlr.lootplusplus.commands;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPBlocks;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.command.CommandResultStats;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.nbt.NBTTagString;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.server.gui.IUpdatePlayerListBox;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.ChatComponentText;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class TileEntityCommandTrigger
/*     */   extends TileEntity
/*     */   implements IUpdatePlayerListBox, ICommandSender {
/*  27 */   public String defaultName = "@";
/*  28 */   public String customName = "";
/*  29 */   public ArrayList<String> commandList = new ArrayList<String>();
/*  30 */   public int[] delays = new int[0];
/*     */   public boolean repeat = false;
/*  32 */   public int time = 0;
/*     */ 
/*     */   
/*     */   public void func_145839_a(NBTTagCompound tag) {
/*  36 */     this.customName = tag.func_74779_i("CustomName");
/*     */     
/*  38 */     if (tag.func_150297_b("CommandList", 9)) {
/*  39 */       NBTTagList tagList = tag.func_150295_c("CommandList", 8);
/*  40 */       for (int i = 0; i < tagList.func_74745_c(); i++) {
/*  41 */         this.commandList.add(tagList.func_150307_f(i));
/*     */       }
/*     */     } 
/*     */     
/*  45 */     this.time = tag.func_74762_e("Time");
/*  46 */     this.repeat = tag.func_74767_n("Repeat");
/*  47 */     this.delays = tag.func_74759_k("Delays");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145841_b(NBTTagCompound tag) {
/*  53 */     tag.func_74778_a("CustomName", this.customName);
/*     */     
/*  55 */     NBTTagList tagList = new NBTTagList();
/*     */     
/*  57 */     for (int i = 0; i < this.commandList.size(); i++) {
/*  58 */       tagList.func_74742_a((NBTBase)new NBTTagString(this.commandList.get(i)));
/*     */     }
/*     */     
/*  61 */     tag.func_74782_a("CommandList", (NBTBase)tagList);
/*     */     
/*  63 */     tag.func_74768_a("Time", this.time);
/*  64 */     tag.func_74757_a("Repeat", this.repeat);
/*  65 */     tag.func_74783_a("Delays", this.delays);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_73660_a() {
/*  70 */     boolean done = true;
/*     */     
/*  72 */     if (!this.commandList.isEmpty()) {
/*  73 */       for (int i = 0; i < this.commandList.size(); i++) {
/*  74 */         int delay = 0;
/*     */         
/*  76 */         if (this.delays == null) {
/*  77 */           this.delays = new int[0];
/*     */         }
/*     */         
/*  80 */         if (i < this.delays.length) {
/*  81 */           delay = this.delays[i];
/*     */           
/*  83 */           if (delay > this.time) {
/*  84 */             done = false;
/*     */           }
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/*  90 */         if (delay == this.time) {
/*  91 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Running command " + (String)this.commandList.get(i)); 
/*  92 */           MinecraftServer.func_71276_C().func_71187_D().func_71556_a(this, this.commandList.get(i));
/*     */         } 
/*     */       } 
/*     */       
/*  96 */       if (done) {
/*  97 */         this.time = 0;
/*     */       } else {
/*     */         
/* 100 */         this.time++;
/*     */       } 
/*     */     } 
/*     */     
/* 104 */     if (done && !this.repeat) {
/* 105 */       if (LootPlusPlusMod.debug) System.out.println("[Loot++] Done running commands!"); 
/* 106 */       if (this.field_145850_b.func_180495_p(this.field_174879_c).func_177230_c() == LootPPBlocks.blockCommandTrigger) {
/* 107 */         this.field_145850_b.func_175698_g(this.field_174879_c);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Packet func_145844_m() {
/* 117 */     NBTTagCompound nbttagcompound = new NBTTagCompound();
/* 118 */     func_145841_b(nbttagcompound);
/* 119 */     return (Packet)new S35PacketUpdateTileEntity(this.field_174879_c, 2, nbttagcompound);
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_70005_c_() {
/* 124 */     return this.customName.equals("") ? this.defaultName : this.customName;
/*     */   }
/*     */ 
/*     */   
/*     */   public IChatComponent func_145748_c_() {
/* 129 */     return (IChatComponent)new ChatComponentText(func_70005_c_());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145747_a(IChatComponent chat) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public World func_130014_f_() {
/* 139 */     return this.field_145850_b;
/*     */   }
/*     */ 
/*     */   
/*     */   public BlockPos func_180425_c() {
/* 144 */     return this.field_174879_c;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_70003_b(int permLevel, String commandName) {
/* 149 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public Vec3 func_174791_d() {
/* 154 */     return new Vec3(this.field_174879_c.func_177958_n(), this.field_174879_c.func_177956_o(), this.field_174879_c.func_177952_p());
/*     */   }
/*     */ 
/*     */   
/*     */   public Entity func_174793_f() {
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_174792_t_() {
/* 164 */     return false;
/*     */   }
/*     */   
/*     */   public void func_174794_a(CommandResultStats.Type type, int amount) {}
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\commands\TileEntityCommandTrigger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */