/*    */ package com.tmtravlr.lootplusplus.network;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import net.minecraft.entity.player.EntityPlayerMP;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ 
/*    */ 
/*    */ public class PacketHelper
/*    */ {
/*    */   public static void addChestType(String name, EntityPlayerMP player) {
/* 13 */     LootPPHelper.chestTypes.add(name);
/*    */     
/* 15 */     PacketBuffer out = new PacketBuffer(Unpooled.buffer());
/*    */     
/* 17 */     out.writeInt(1);
/* 18 */     out.writeInt(name.length());
/*    */     
/* 20 */     for (int i = 0; i < name.length(); i++) {
/* 21 */       out.writeChar(name.charAt(i));
/*    */     }
/*    */     
/* 24 */     SToCMessage packet = new SToCMessage((ByteBuf)out);
/*    */     
/* 26 */     if (player == null) {
/* 27 */       LootPPHelper.lppNetworkWrapper.sendToAll(packet);
/*    */     } else {
/*    */       
/* 30 */       LootPPHelper.lppNetworkWrapper.sendTo(packet, player);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\network\PacketHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */