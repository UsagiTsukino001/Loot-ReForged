/*    */ package com.tmtravlr.lootplusplus.network;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SToCMessage
/*    */   implements IMessage
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */   public SToCMessage() {
/* 19 */     this(new byte[] { 0 });
/*    */   }
/*    */ 
/*    */   
/*    */   public SToCMessage(ByteBuf dataToSet) {
/* 24 */     this(dataToSet.array());
/*    */   }
/*    */ 
/*    */   
/*    */   public SToCMessage(byte[] dataToSet) {
/* 29 */     if (dataToSet.length > 2097136)
/*    */     {
/* 31 */       throw new IllegalArgumentException("Payload may not be larger than 2097136 (0x1ffff0) bytes");
/*    */     }
/*    */     
/* 34 */     this.data = dataToSet;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buffer) {
/* 46 */     if (this.data.length > 2097136)
/*    */     {
/* 48 */       throw new IllegalArgumentException("Payload may not be larger than 2097136 (0x1ffff0) bytes");
/*    */     }
/*    */     
/* 51 */     buffer.writeShort(this.data.length);
/* 52 */     buffer.writeBytes(this.data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buffer) {
/* 63 */     this.data = new byte[buffer.readShort()];
/* 64 */     buffer.readBytes(this.data);
/*    */   }
/*    */   
/*    */   public byte[] getData() {
/* 68 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\network\SToCMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */