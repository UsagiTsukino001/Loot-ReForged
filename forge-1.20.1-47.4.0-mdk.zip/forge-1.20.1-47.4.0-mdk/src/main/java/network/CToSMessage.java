/*    */ package com.tmtravlr.lootplusplus.network;
/*    */ 
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CToSMessage
/*    */   implements IMessage
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */   public CToSMessage() {
/* 20 */     this(new byte[] { 0 });
/*    */   }
/*    */ 
/*    */   
/*    */   public CToSMessage(ByteBuf dataToSet) {
/* 25 */     this(dataToSet.array());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public CToSMessage(byte[] dataToSet) {
/* 31 */     if (dataToSet.length > 2097136)
/*    */     {
/* 33 */       throw new IllegalArgumentException("Payload may not be larger than 2097136 (0x1ffff0) bytes");
/*    */     }
/*    */     
/* 36 */     this.data = dataToSet;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void toBytes(ByteBuf buffer) {
/* 47 */     if (this.data.length > 2097136)
/*    */     {
/* 49 */       throw new IllegalArgumentException("Payload may not be larger than 2097136 (0x1ffff0) bytes");
/*    */     }
/*    */     
/* 52 */     buffer.writeShort(this.data.length);
/* 53 */     buffer.writeBytes(this.data);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void fromBytes(ByteBuf buffer) {
/* 64 */     this.data = new byte[buffer.readShort()];
/* 65 */     buffer.readBytes(this.data);
/*    */   }
/*    */   
/*    */   public byte[] getData() {
/* 69 */     return this.data;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\network\CToSMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */