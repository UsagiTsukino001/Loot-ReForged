/*    */ package com.tmtravlr.lootplusplus.network;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import io.netty.buffer.ByteBuf;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
/*    */ import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PacketHandlerClient
/*    */   implements IMessageHandler<SToCMessage, IMessage>
/*    */ {
/*    */   public static final int CHEST_TYPE = 1;
/*    */   
/*    */   public IMessage onMessage(SToCMessage packet, MessageContext context) {
/*    */     int stringLength;
/*    */     char[] stringArray;
/*    */     int i;
/*    */     String chestType;
/* 23 */     ByteBuf buff = Unpooled.wrappedBuffer(packet.getData());
/*    */     
/* 25 */     int type = buff.readInt();
/*    */ 
/*    */ 
/*    */     
/* 29 */     switch (type) {
/*    */       case 1:
/* 31 */         stringLength = buff.readInt();
/*    */         
/* 33 */         if (stringLength <= 0) {
/* 34 */           return null;
/*    */         }
/*    */         
/* 37 */         stringArray = new char[stringLength];
/*    */         
/* 39 */         for (i = 0; i < stringLength; i++) {
/* 40 */           stringArray[i] = buff.readChar();
/*    */         }
/*    */         
/* 43 */         chestType = String.valueOf(stringArray);
/*    */         
/* 45 */         LootPPHelper.chestTypes.add(chestType);
/*    */         break;
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\network\PacketHandlerClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */