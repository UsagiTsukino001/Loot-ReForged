/*     */ package com.tmtravlr.lootplusplus;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.additions.BlockAddedCrops;
/*     */ import com.tmtravlr.lootplusplus.commands.CommandSenderGeneric;
/*     */ import com.tmtravlr.lootplusplus.effects.GiveEffects;
/*     */ import com.tmtravlr.lootplusplus.network.PacketHelper;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.monster.EntityCreeper;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.stats.AchievementList;
/*     */ import net.minecraft.stats.StatBase;
/*     */ import net.minecraft.util.ChatComponentText;
/*     */ import net.minecraft.util.EntityDamageSource;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.Vec3;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraftforge.common.IPlantable;
/*     */ import net.minecraftforge.event.entity.living.LivingAttackEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingDropsEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.event.entity.living.LivingHurtEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerEvent;
/*     */ import net.minecraftforge.event.entity.player.PlayerInteractEvent;
/*     */ import net.minecraftforge.event.world.BlockEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.PlayerEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LootPPEventHandler
/*     */ {
/*  64 */   private Random rand = new Random();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*     */   public void onLivingDrops(LivingDropsEvent event) {
/*  71 */     if (!event.entityLiving.field_70170_p.field_72995_K) {
/*     */       
/*  73 */       if ((!LootPPHelper.creepersDropRecords || LootPPHelper.creepersDropAllRecords) && event.entityLiving instanceof EntityCreeper)
/*     */       {
/*  75 */         if (event.source.func_76346_g() instanceof net.minecraft.entity.monster.EntitySkeleton) {
/*     */           
/*  77 */           event.entityLiving.captureDrops = true;
/*     */           
/*  79 */           LootPPTickHandlerServer.creepersToDropRecordsFrom.add((EntityCreeper)event.entityLiving);
/*     */         } 
/*     */       }
/*     */       
/*  83 */       String entityName = (String)EntityList.field_75626_c.get(event.entity.getClass());
/*     */       
/*  85 */       if (event.entity instanceof net.minecraft.entity.player.EntityPlayer) {
/*  86 */         entityName = "Player";
/*     */       }
/*     */       
/*  89 */       NBTTagCompound entityTag = new NBTTagCompound();
/*  90 */       event.entity.func_70109_d(entityTag);
/*     */       
/*  92 */       if (entityName != null && !entityName.equals("")) {
/*  93 */         entityTag.func_74778_a("id", entityName);
/*     */       }
/*     */       
/*  96 */       for (NBTTagCompound entryTag : LootPPHelper.entityDropRemovals.keySet()) {
/*     */         
/*  98 */         if ((!entryTag.func_74764_b("id") || entryTag.func_74779_i("id").equals(entityName)) && 
/*  99 */           LootPPHelper.hasAllTags((NBTBase)entryTag, (NBTBase)entityTag, true)) {
/* 100 */           Set<ItemStack> itemsToRemove = LootPPHelper.entityDropRemovals.get(entryTag);
/*     */           
/* 102 */           if (itemsToRemove != null && !itemsToRemove.isEmpty()) {
/* 103 */             boolean removeAll = false;
/* 104 */             Iterator<EntityItem> it = event.drops.iterator();
/*     */             
/* 106 */             while (it.hasNext() && !removeAll) {
/* 107 */               EntityItem current = it.next();
/*     */               
/* 109 */               for (ItemStack stack : itemsToRemove) {
/*     */                 
/* 111 */                 if (stack.func_77973_b() == LootPPItems.generalDummyIcon) {
/* 112 */                   removeAll = true;
/*     */                   break;
/*     */                 } 
/* 115 */                 if (current.func_92059_d() != null && stack.func_77973_b() == current.func_92059_d().func_77973_b() && (
/* 116 */                   stack.func_77952_i() == 32767 || stack.func_77952_i() == current.func_92059_d().func_77952_i()) && (
/* 117 */                   stack.func_77978_p() == null || stack.func_77978_p().func_82582_d() || stack.func_77978_p().equals(current.func_92059_d().func_77978_p()))) {
/* 118 */                   if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removed Drop '" + Item.field_150901_e.func_177774_c(current.func_92059_d().func_77973_b()) + "' from entity " + EntityList.func_75621_b(event.entity)); 
/* 119 */                   it.remove();
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 126 */             if (removeAll) {
/* 127 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removed all drops from entity " + EntityList.func_75621_b(event.entity)); 
/* 128 */               event.drops.clear();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 135 */       if (event.entity.field_70170_p.func_82736_K().func_82766_b("doMobLoot")) {
/* 136 */         for (NBTTagCompound entryTag : LootPPHelper.entityDropAdditions.keySet()) {
/* 137 */           if ((!entryTag.func_74764_b("id") || entryTag.func_74779_i("id").equals(entityName)) && 
/* 138 */             LootPPHelper.hasAllTags((NBTBase)entryTag, (NBTBase)entityTag, true)) {
/* 139 */             for (LootPPHelper.EntityDropInfo drop : LootPPHelper.entityDropAdditions.get(entryTag)) {
/* 140 */               LootPPHelper.dropEntityDropAdditions(event, drop, this.rand);
/*     */             }
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*     */   public void onBlockDrop(BlockEvent.HarvestDropsEvent event) {
/* 152 */     if (!event.world.field_72995_K && event.state != null) {
/* 153 */       LootPPHelper.BlockMeta blockMeta = new LootPPHelper.BlockMeta(event.state);
/* 154 */       LootPPHelper.BlockMeta blockMetaWild = new LootPPHelper.BlockMeta(event.state.func_177230_c(), 32767);
/*     */       
/* 156 */       if (LootPPHelper.blockDropRemovals.containsKey(blockMeta) || LootPPHelper.blockDropRemovals.containsKey(blockMetaWild)) {
/*     */         
/* 158 */         boolean removeAll = false;
/* 159 */         Iterator<ItemStack> it = event.drops.iterator();
/*     */         
/* 161 */         while (it.hasNext() && !removeAll) {
/* 162 */           ItemStack current = it.next();
/*     */           
/* 164 */           Set<ItemStack> stackSet = LootPPHelper.blockDropRemovals.get(blockMeta);
/* 165 */           if (stackSet != null && !stackSet.isEmpty()) {
/* 166 */             for (ItemStack stack : stackSet) {
/* 167 */               if (stack.func_77973_b() == LootPPItems.generalDummyIcon) {
/* 168 */                 removeAll = true;
/*     */                 break;
/*     */               } 
/* 171 */               LootPPHelper.removeBlockDrop(event, it, stack, current);
/*     */             } 
/*     */           }
/*     */           
/* 175 */           stackSet = LootPPHelper.blockDropRemovals.get(blockMetaWild);
/* 176 */           if (stackSet != null && !stackSet.isEmpty()) {
/* 177 */             for (ItemStack stack : LootPPHelper.blockDropRemovals.get(blockMetaWild)) {
/* 178 */               if (stack.func_77973_b() == LootPPItems.generalDummyIcon) {
/* 179 */                 removeAll = true;
/*     */                 break;
/*     */               } 
/* 182 */               LootPPHelper.removeBlockDrop(event, it, stack, current);
/*     */             } 
/*     */           }
/*     */         } 
/*     */         
/* 187 */         if (removeAll) {
/* 188 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removed all drops from block " + event.state); 
/* 189 */           event.drops.clear();
/*     */         } 
/*     */       } 
/*     */       
/* 193 */       if (event.world.func_82736_K().func_82766_b("doTileDrops"))
/*     */       {
/* 195 */         if (LootPPHelper.blockDropAdditions.containsKey(blockMeta) || LootPPHelper.blockDropAdditions.containsKey(blockMetaWild)) {
/*     */           
/* 197 */           ArrayList<LootPPHelper.BlockDropInfo> additionsList = LootPPHelper.blockDropAdditions.get(blockMeta);
/*     */           
/* 199 */           if (additionsList != null && !additionsList.isEmpty()) {
/* 200 */             for (LootPPHelper.BlockDropInfo drop : LootPPHelper.blockDropAdditions.get(blockMeta)) {
/* 201 */               LootPPHelper.dropBlockDropAdditions(event, drop, this.rand);
/*     */             }
/*     */           }
/*     */           
/* 205 */           additionsList = LootPPHelper.blockDropAdditions.get(blockMetaWild);
/*     */           
/* 207 */           if (additionsList != null && !additionsList.isEmpty()) {
/* 208 */             for (LootPPHelper.BlockDropInfo drop : LootPPHelper.blockDropAdditions.get(blockMetaWild)) {
/* 209 */               LootPPHelper.dropBlockDropAdditions(event, drop, this.rand);
/*     */             }
/*     */           }
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 216 */       if (event.state.func_177230_c() instanceof BlockAddedCrops && BlockAddedCrops.rightClickHarvesting) {
/*     */         
/* 218 */         Iterator<ItemStack> it = event.drops.iterator();
/*     */         
/* 220 */         while (it.hasNext()) {
/* 221 */           ItemStack drop = it.next();
/*     */           
/* 223 */           if (drop != null && drop.func_77973_b() != null && drop.func_77973_b() == ((BlockAddedCrops)event.state.func_177230_c()).func_149866_i()) {
/* 224 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removed extra seed while right click harvesting block " + Block.field_149771_c.func_177774_c(event.state.func_177230_c())); 
/* 225 */             if (drop.field_77994_a > 1) {
/* 226 */               drop.field_77994_a--;
/*     */               break;
/*     */             } 
/* 229 */             it.remove();
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onLivingHitWithArrow(LivingAttackEvent event) {
/* 244 */     if (event.source.field_76373_n.equals("arrow") && event.entityLiving != null && event.entity == event.source.func_76346_g() && event.entityLiving.func_70694_bm() != null && 
/* 245 */       event.entityLiving.func_70694_bm().func_77973_b() instanceof net.minecraft.item.ItemBow && event.source instanceof EntityDamageSource && 
/* 246 */       (((EntityDamageSource)event.source).func_76364_f()).field_70173_aa < 100) {
/* 247 */       event.setCanceled(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onDigBlock(PlayerEvent.BreakSpeed event) {
/* 256 */     if (!event.entityLiving.field_70170_p.field_72995_K && (
/* 257 */       !GiveEffects.onItemBlockDigMap.isEmpty() || !GiveEffects.onBlockBlockDigMap.isEmpty())) {
/* 258 */       GiveEffects.giveDigEffects(event.entityLiving, event.state);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onBlockBreak(BlockEvent.BreakEvent event) {
/* 265 */     if (!(event.getPlayer()).field_70170_p.field_72995_K && (
/* 266 */       !GiveEffects.onItemBlockBrokeMap.isEmpty() || !GiveEffects.onBlockBlockBrokeMap.isEmpty())) {
/* 267 */       GiveEffects.giveBreakEffects((EntityLivingBase)event.getPlayer(), event.state);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onItemRightClick(PlayerInteractEvent event) {
/* 274 */     if (!event.entityPlayer.field_70170_p.field_72995_K)
/*     */     {
/* 276 */       if (event.action == PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK || event.action == PlayerInteractEvent.Action.RIGHT_CLICK_AIR)
/*     */       {
/* 278 */         if (event.entityPlayer.func_70694_bm() != null && !GiveEffects.onRightClickMap.isEmpty()) {
/* 279 */           GiveEffects.giveRightClickEffects((EntityLivingBase)event.entityPlayer);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingHurt(LivingHurtEvent event) {
/* 290 */     if (!event.entityLiving.field_70170_p.field_72995_K && 
/* 291 */       event.source.func_76346_g() instanceof EntityLivingBase) {
/* 292 */       EntityLivingBase entityHitting = (EntityLivingBase)event.source.func_76346_g();
/*     */       
/* 294 */       if (entityHitting.func_70694_bm() != null && (
/* 295 */         !GiveEffects.entityOnHitEntityMap.isEmpty() || !GiveEffects.youOnHitEntityMap.isEmpty())) {
/* 296 */         GiveEffects.giveEntityHitEffects(entityHitting, event.entityLiving);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     if (event.entity.getEntityData().func_150297_b("LootPPCommands", 10)) {
/* 304 */       NBTTagCompound tag = event.entity.getEntityData().func_74775_l("LootPPCommands");
/*     */       
/* 306 */       NBTTagList commandList = tag.func_150295_c("CommandListOnHurt", 8);
/*     */       
/* 308 */       if (commandList != null && !commandList.func_82582_d()) {
/* 309 */         for (int i = 0; i < commandList.func_74745_c(); i++) {
/*     */           
/* 311 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Running command on hurt " + commandList.func_150307_f(i)); 
/* 312 */           MinecraftServer.func_71276_C().func_71187_D().func_71556_a((ICommandSender)new CommandSenderGeneric(event.entity.func_70005_c_(), event.entity.field_70170_p, new Vec3(event.entity.field_70165_t, event.entity.field_70163_u, event.entity.field_70161_v)), commandList.func_150307_f(i));
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.LOWEST)
/*     */   public void onRangedUpdate(LivingEvent.LivingUpdateEvent event) {
/* 321 */     if (!event.entity.field_70170_p.field_72995_K && event.entity.field_70173_aa % 11 == 0 && event.entityLiving instanceof net.minecraft.entity.IRangedAttackMob && event.entityLiving instanceof EntityLiving && !event.entityLiving.field_70128_L) {
/* 322 */       EntityLiving ranged = (EntityLiving)event.entityLiving;
/*     */       
/* 324 */       if (!event.entityLiving.field_70128_L && ranged.func_70694_bm() != null && ranged
/* 325 */         .func_70694_bm().func_77973_b() != null && (ranged.func_70694_bm().func_77973_b() instanceof com.tmtravlr.lootplusplus.additions.ItemAddedBow || ranged
/* 326 */         .func_70694_bm().func_77973_b() instanceof com.tmtravlr.lootplusplus.additions.ItemAddedGun || ranged.func_70694_bm().func_77973_b() instanceof com.tmtravlr.lootplusplus.additions.ItemAddedThrowable)) {
/* 327 */         if (!LootPPHelper.rangedAIs.containsKey(ranged) && !LootPPHelper.delayedAIs.contains(ranged)) {
/* 328 */           LootPPHelper.delayedAIs.add(ranged);
/*     */         
/*     */         }
/*     */       }
/* 332 */       else if (LootPPHelper.rangedAIs.containsKey(ranged)) {
/* 333 */         LootPPHelper.removeAddedBowAIFromMob(ranged);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
/* 341 */     if (!event.entityLiving.field_70170_p.field_72995_K && (
/* 342 */       !GiveEffects.onHeldMap.isEmpty() || !GiveEffects.onPassiveMap.isEmpty() || !GiveEffects.onWornMap.isEmpty())) {
/* 343 */       GiveEffects.givePassiveEffects(event.entityLiving);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 348 */     if (event.entity.getEntityData().func_150297_b("LootPPCommands", 10)) {
/* 349 */       NBTTagCompound tag = event.entity.getEntityData().func_74775_l("LootPPCommands");
/*     */       
/* 351 */       if (!tag.func_74767_n("Done") && tag.func_150297_b("CommandList", 9)) {
/* 352 */         NBTTagList commandList = tag.func_150295_c("CommandList", 8);
/* 353 */         int[] delays = tag.func_74759_k("Delays");
/* 354 */         int time = tag.func_74762_e("Time");
/* 355 */         boolean repeat = tag.func_74767_n("Repeat");
/*     */         
/* 357 */         boolean done = true;
/*     */         
/* 359 */         if (commandList != null && !commandList.func_82582_d()) {
/* 360 */           for (int i = 0; i < commandList.func_74745_c(); i++) {
/* 361 */             int delay = 0;
/*     */             
/* 363 */             if (delays == null) {
/* 364 */               delays = new int[0];
/*     */             }
/*     */             
/* 367 */             if (i < delays.length) {
/* 368 */               delay = delays[i];
/*     */               
/* 370 */               if (delay > time) {
/* 371 */                 done = false;
/*     */               }
/*     */             } 
/*     */             
/* 375 */             if (delay == time) {
/* 376 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Running command " + commandList.func_150307_f(i)); 
/* 377 */               MinecraftServer.func_71276_C().func_71187_D().func_71556_a((ICommandSender)new CommandSenderGeneric(event.entity.func_70005_c_(), event.entity.field_70170_p, new Vec3(event.entity.field_70165_t, event.entity.field_70163_u, event.entity.field_70161_v)), commandList.func_150307_f(i));
/*     */             } 
/*     */           } 
/*     */           
/* 381 */           if (done) {
/* 382 */             tag.func_74768_a("Time", 0);
/*     */           } else {
/*     */             
/* 385 */             tag.func_74768_a("Time", time + 1);
/*     */           } 
/*     */         } 
/*     */         
/* 389 */         if (done && !repeat) {
/* 390 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Done running commands!"); 
/* 391 */           tag.func_74757_a("Done", true);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLivingDeath(LivingDeathEvent event) {
/* 401 */     if (event.entity.getEntityData().func_150297_b("LootPPCommands", 10)) {
/* 402 */       NBTTagCompound tag = event.entity.getEntityData().func_74775_l("LootPPCommands");
/*     */       
/* 404 */       NBTTagList commandList = tag.func_150295_c("CommandListOnDeath", 8);
/*     */       
/* 406 */       if (commandList != null && !commandList.func_82582_d()) {
/* 407 */         for (int i = 0; i < commandList.func_74745_c(); i++) {
/*     */           
/* 409 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Running command on death " + commandList.func_150307_f(i)); 
/* 410 */           MinecraftServer.func_71276_C().func_71187_D().func_71556_a((ICommandSender)new CommandSenderGeneric(event.entity.func_70005_c_(), event.entity.field_70170_p, new Vec3(event.entity.field_70165_t, event.entity.field_70163_u, event.entity.field_70161_v)), commandList.func_150307_f(i));
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerInteract(PlayerInteractEvent event) {
/* 421 */     if (!event.world.field_72995_K && event.action == PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK && event.entityPlayer != null && event.entityPlayer.func_70694_bm() != null && BlockAddedCrops.itemToCrop.keySet().contains(event.entityPlayer.func_70694_bm())) {
/*     */       
/* 423 */       BlockAddedCrops cropBlock = (BlockAddedCrops)BlockAddedCrops.itemToCrop.get(event.entityPlayer.func_70694_bm());
/*     */       
/* 425 */       if (cropBlock == null || event.face != EnumFacing.UP || !event.entityPlayer.func_175151_a(event.pos.func_177972_a(event.face), event.face, event.entityPlayer.func_70694_bm())) {
/*     */         return;
/*     */       }
/*     */       
/* 429 */       if (event.world.func_180495_p(event.pos).func_177230_c().canSustainPlant((IBlockAccess)event.world, event.pos, EnumFacing.UP, (IPlantable)cropBlock) && event.world.func_175623_d(event.pos.func_177984_a())) {
/*     */         
/* 431 */         event.world.func_175656_a(event.pos.func_177984_a(), cropBlock.func_176223_P());
/* 432 */         if (!event.entityPlayer.field_71075_bZ.field_75098_d) {
/* 433 */           (event.entityPlayer.func_70694_bm()).field_77994_a--;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onCrafted(PlayerEvent.ItemCraftedEvent event) {
/* 444 */     if (Block.func_149634_a(event.crafting.func_77973_b()) instanceof net.minecraft.block.BlockWorkbench) {
/* 445 */       event.player.func_71064_a((StatBase)AchievementList.field_76017_h, 1);
/*     */     }
/*     */     
/* 448 */     if (Block.func_149634_a(event.crafting.func_77973_b()) instanceof net.minecraft.block.BlockFurnace) {
/* 449 */       event.player.func_71064_a((StatBase)AchievementList.field_76015_j, 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
/* 456 */     if (!event.player.field_70170_p.field_72995_K) {
/* 457 */       EntityPlayerMP player = LootPPHelper.getPlayerByUsername(event.player.func_70005_c_());
/*     */       
/* 459 */       for (String type : LootPPHelper.chestTypes) {
/* 460 */         PacketHelper.addChestType(type, player);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 465 */     if (!LootPPNotifier.notificationList.isEmpty()) {
/* 466 */       File problemFile = new File(LootPPHelper.configFolder, "Problems.txt");
/* 467 */       PrintStream writeStream = null;
/*     */       try {
/* 469 */         writeStream = new PrintStream(problemFile);
/*     */         
/* 471 */         event.player.func_145747_a((IChatComponent)new ChatComponentText(EnumChatFormatting.RED + "[Loot++] Encountered problems loading the config files! =("));
/* 472 */         writeStream.println("The following problems were encountered while loading the config files:");
/*     */         
/* 474 */         for (String notification : LootPPNotifier.notificationList) {
/* 475 */           event.player.func_145747_a((IChatComponent)new ChatComponentText(EnumChatFormatting.RED + "[Loot++]" + EnumChatFormatting.RESET + " - " + notification));
/* 476 */           event.player.func_145747_a((IChatComponent)new ChatComponentText(""));
/* 477 */           writeStream.println(notification);
/* 478 */           writeStream.println();
/*     */         } 
/*     */         
/* 481 */         event.player.func_145747_a((IChatComponent)new ChatComponentText(EnumChatFormatting.RED + "[Loot++] The problem messages were saved to file 'config/Loot++/Problems.txt'."));
/*     */       }
/* 483 */       catch (IOException x) {
/* 484 */         System.err.format("IOException: %s%n", new Object[] { x });
/*     */       } finally {
/*     */         
/* 487 */         if (writeStream != null) {
/* 488 */           writeStream.close();
/*     */         }
/*     */       } 
/*     */       
/* 492 */       LootPPNotifier.notificationList.clear();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPEventHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */