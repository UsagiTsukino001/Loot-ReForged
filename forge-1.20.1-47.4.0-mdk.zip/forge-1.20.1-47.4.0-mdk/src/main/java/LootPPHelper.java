/*      */ package com.tmtravlr.lootplusplus;
/*      */ 
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedThrowable;
/*      */ import com.tmtravlr.lootplusplus.commands.CommandSenderGeneric;
/*      */ import com.tmtravlr.lootplusplus.recipes.LootPPFuelHandler;
/*      */ import java.io.File;
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.block.state.IBlockState;
/*      */ import net.minecraft.command.ICommandManager;
/*      */ import net.minecraft.command.ICommandSender;
/*      */ import net.minecraft.creativetab.CreativeTabs;
/*      */ import net.minecraft.enchantment.Enchantment;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.EntityList;
/*      */ import net.minecraft.entity.EntityLiving;
/*      */ import net.minecraft.entity.IRangedAttackMob;
/*      */ import net.minecraft.entity.ai.EntityAIArrowAttack;
/*      */ import net.minecraft.entity.ai.EntityAIBase;
/*      */ import net.minecraft.entity.ai.EntityAITasks;
/*      */ import net.minecraft.entity.item.EntityItem;
/*      */ import net.minecraft.entity.player.EntityPlayerMP;
/*      */ import net.minecraft.init.Blocks;
/*      */ import net.minecraft.init.Items;
/*      */ import net.minecraft.inventory.IInventory;
/*      */ import net.minecraft.item.Item;
/*      */ import net.minecraft.item.ItemArmor;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.item.crafting.FurnaceRecipes;
/*      */ import net.minecraft.nbt.JsonToNBT;
/*      */ import net.minecraft.nbt.NBTBase;
/*      */ import net.minecraft.nbt.NBTException;
/*      */ import net.minecraft.nbt.NBTTagCompound;
/*      */ import net.minecraft.nbt.NBTTagList;
/*      */ import net.minecraft.server.MinecraftServer;
/*      */ import net.minecraft.util.StatCollector;
/*      */ import net.minecraft.util.Vec3;
/*      */ import net.minecraft.util.WeightedRandomChestContent;
/*      */ import net.minecraftforge.common.ChestGenHooks;
/*      */ import net.minecraftforge.common.util.EnumHelper;
/*      */ import net.minecraftforge.event.entity.living.LivingDropsEvent;
/*      */ import net.minecraftforge.event.world.BlockEvent;
/*      */ import net.minecraftforge.fml.common.FMLLog;
/*      */ import net.minecraftforge.fml.common.IWorldGenerator;
/*      */ import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
/*      */ import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LootPPHelper
/*      */ {
/*      */   public static SimpleNetworkWrapper lppNetworkWrapper;
/*      */   public static boolean generateFiles = true;
/*      */   public static Random rand = new Random();
/*      */   
/*      */   public static Comparator<ItemStack> stackComparatorWild = new Comparator<ItemStack>()
/*      */     {
/*      */       public int compare(ItemStack stack1, ItemStack stack2) {
/*      */         if (stack1 == null && stack2 == null)
/*      */           return 0; 
/*      */         if (stack1 == null && stack2 != null)
/*      */           return 1; 
/*      */         if (stack1 != null && stack2 == null)
/*      */           return -1; 
/*      */         if (stack1.func_77973_b() == null && stack2.func_77973_b() == null)
/*      */           return 0; 
/*      */         if (stack1.func_77973_b() == null && stack2.func_77973_b() != null)
/*      */           return 1; 
/*      */         if (stack1.func_77973_b() != null && stack2.func_77973_b() == null)
/*      */           return -1; 
/*      */         if (stack2.func_77973_b() != stack1.func_77973_b())
/*      */           return Item.func_150891_b(stack2.func_77973_b()) - Item.func_150891_b(stack1.func_77973_b()); 
/*      */         if (stack1.func_77952_i() == 32767 || stack2.func_77952_i() == 32767)
/*      */           return 0; 
/*      */         return stack2.func_77952_i() - stack1.func_77952_i();
/*      */       }
/*      */     };
/*      */   
/*      */   public static Comparator<ItemStack> stackComparator = new Comparator<ItemStack>()
/*      */     {
/*      */       public int compare(ItemStack stack1, ItemStack stack2) {
/*      */         if (stack1 == null && stack2 == null)
/*      */           return 0; 
/*      */         if (stack1 == null && stack2 != null)
/*      */           return 1; 
/*      */         if (stack1 != null && stack2 == null)
/*      */           return -1; 
/*      */         if (stack1.func_77973_b() == null && stack2.func_77973_b() == null)
/*      */           return 0; 
/*      */         if (stack1.func_77973_b() == null && stack2.func_77973_b() != null)
/*      */           return 1; 
/*      */         if (stack1.func_77973_b() != null && stack2.func_77973_b() == null)
/*      */           return -1; 
/*      */         if (stack2.func_77973_b() != stack1.func_77973_b())
/*      */           return Item.func_150891_b(stack2.func_77973_b()) - Item.func_150891_b(stack1.func_77973_b()); 
/*      */         return stack2.func_77952_i() - stack1.func_77952_i();
/*      */       }
/*      */     };
/*      */   
/*      */   public static Comparator<ItemStack> stackComparatorNBT = new Comparator<ItemStack>()
/*      */     {
/*      */       public int compare(ItemStack stack1, ItemStack stack2) {
/*      */         int compareResult = LootPPHelper.stackComparator.compare(stack1, stack2);
/*      */         if (compareResult == 0 && stack1 != null && stack2 != null) {
/*      */           if (stack1.func_77978_p() == null && stack2.func_77978_p() == null)
/*      */             return 0; 
/*      */           if (stack1.func_77978_p() == null && stack2.func_77978_p() != null)
/*      */             return 1; 
/*      */           if (stack1.func_77978_p() != null && stack2.func_77978_p() == null)
/*      */             return -1; 
/*      */           return LootPPHelper.compareNBT((NBTBase)stack2.func_77978_p(), (NBTBase)stack1.func_77978_p()) ? 0 : (stack2.func_77978_p().hashCode() - stack1.func_77978_p().hashCode());
/*      */         } 
/*      */         return compareResult;
/*      */       }
/*      */     };
/*      */   
/*      */   public static class BlockMeta
/*      */   {
/*      */     public Block block;
/*      */     public int meta;
/*      */     
/*      */     public BlockMeta(Block blockToSet, int metaToSet) {
/*      */       this.block = blockToSet;
/*      */       this.meta = metaToSet;
/*      */     }
/*      */     
/*      */     public BlockMeta(IBlockState state) {
/*      */       this.block = state.func_177230_c();
/*      */       this.meta = this.block.func_176201_c(state);
/*      */     }
/*      */     
/*      */     public String toString() {
/*      */       return "{ Block: " + Block.field_149771_c.func_177774_c(this.block) + ", Metadata: " + this.meta + " }";
/*      */     }
/*      */   }
/*      */   
/*      */   public static Comparator<BlockMeta> blockComparator = new Comparator<BlockMeta>()
/*      */     {
/*      */       public int compare(LootPPHelper.BlockMeta blockMeta1, LootPPHelper.BlockMeta blockMeta2) {
/*      */         if (blockMeta1 == null && blockMeta2 == null)
/*      */           return 0; 
/*      */         if (blockMeta1 == null && blockMeta2 != null)
/*      */           return 1; 
/*      */         if (blockMeta1 != null && blockMeta2 == null)
/*      */           return -1; 
/*      */         if (blockMeta1.block == null && blockMeta2.block == null)
/*      */           return 0; 
/*      */         if (blockMeta1.block == null && blockMeta2.block != null)
/*      */           return 1; 
/*      */         if (blockMeta1.block != null && blockMeta2.block == null)
/*      */           return -1; 
/*      */         if (blockMeta2.block != blockMeta1.block)
/*      */           return Block.field_149771_c.func_177774_c(blockMeta2.block).toString().compareTo(Block.field_149771_c.func_177774_c(blockMeta1.block).toString()); 
/*      */         return blockMeta2.meta - blockMeta1.meta;
/*      */       }
/*      */     };
/*      */   
/*      */   public static Comparator<NBTTagCompound> comparatorNBT = new Comparator<NBTTagCompound>()
/*      */     {
/*      */       public int compare(NBTTagCompound tag1, NBTTagCompound tag2) {
/*      */         return LootPPHelper.compareNBT((NBTBase)tag1, (NBTBase)tag2) ? 0 : (tag1.hashCode() - tag2.hashCode());
/*      */       }
/*      */     };
/*      */   
/*      */   public static LootPPFuelHandler fuelHandler = new LootPPFuelHandler();
/*      */   
/*      */   public LootPPHelper() {
/*  266 */     System.out.println("[Loot++] Attempting to get chest contents.");
/*      */     
/*      */     try {
/*  269 */       contents = ChestGenHooks.class.getDeclaredField("contents");
/*  270 */       contents.setAccessible(true);
/*  271 */       gotContents = true;
/*      */     }
/*  273 */     catch (Exception e) {
/*      */       
/*  275 */       System.out.println("[Loot++] Couldn't get chest contents! =(");
/*  276 */       e.printStackTrace();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  281 */     System.out.println("[Loot++] Attempting to get chest info.");
/*      */     
/*      */     try {
/*  284 */       chestInfo = ChestGenHooks.class.getDeclaredField("chestInfo");
/*  285 */       chestInfo.setAccessible(true);
/*  286 */       gotChestInfo = true;
/*      */     }
/*  288 */     catch (Exception e) {
/*      */       
/*  290 */       System.out.println("[Loot++] Couldn't get chest info! =(");
/*  291 */       e.printStackTrace();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  296 */     System.out.println("[Loot++] Attempting to get furnace experience map.");
/*      */     
/*      */     try {
/*  299 */       experienceMap = null;
/*      */       try {
/*  301 */         experienceMap = FurnaceRecipes.class.getDeclaredField("field_77605_c");
/*      */       }
/*  303 */       catch (Exception e) {
/*  304 */         experienceMap = FurnaceRecipes.class.getDeclaredField("experienceList");
/*      */       } 
/*  306 */       experienceMap.setAccessible(true);
/*  307 */       gotFurnaceXP = true;
/*      */     }
/*  309 */     catch (Exception e) {
/*      */       
/*  311 */       System.out.println("[Loot++] Couldn't get furnace experience map! =(");
/*  312 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */   public static boolean loadedDropsAndChestLoot = false; public static boolean loadedRecipes = false; public static boolean gotContents = false; public static boolean gotChestInfo = false; public static boolean gotFortressContents = false; public static boolean gotFurnaceXP = false; public static Field contents;
/*      */   public static Field chestInfo;
/*      */   public static Field experienceMap;
/*      */   
/*  319 */   public enum DropType { ITEM('i'),
/*  320 */     ENTITY('e'),
/*  321 */     COMMAND('c');
/*      */     
/*      */     public final char charType;
/*      */     
/*      */     DropType(char charTypeToSet) {
/*  326 */       this.charType = charTypeToSet;
/*      */     } }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DropInfo
/*      */   {
/*      */     public LootPPHelper.DropType dropType;
/*      */     
/*      */     public int weight;
/*      */     
/*      */     public LootPPHelper.DropInfoEntity getDropInfoEntity() {
/*  338 */       return (this instanceof LootPPHelper.DropInfoEntity) ? (LootPPHelper.DropInfoEntity)this : null;
/*      */     }
/*      */     
/*      */     public LootPPHelper.DropInfoItem getDropInfoItem() {
/*  342 */       return (this instanceof LootPPHelper.DropInfoItem) ? (LootPPHelper.DropInfoItem)this : null;
/*      */     }
/*      */     
/*      */     public LootPPHelper.DropInfoCommand getDropInfoCommand() {
/*  346 */       return (this instanceof LootPPHelper.DropInfoCommand) ? (LootPPHelper.DropInfoCommand)this : null;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class DropInfoEntity
/*      */     extends DropInfo
/*      */   {
/*      */     public NBTTagCompound entityTag;
/*      */ 
/*      */     
/*      */     public DropInfoEntity(NBTTagCompound eToSpawn, int dropWeight) {
/*  358 */       this.entityTag = eToSpawn;
/*  359 */       this.weight = dropWeight;
/*  360 */       this.dropType = LootPPHelper.DropType.ENTITY;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  364 */       return "{ Type: " + this.dropType.name() + ", Weight: " + this.weight + ", Entity Tag: " + this.entityTag + "}";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class DropInfoItem
/*      */     extends DropInfo
/*      */   {
/*      */     public ItemStack stack;
/*      */     
/*      */     public int min;
/*      */     public int max;
/*      */     
/*      */     public DropInfoItem(ItemStack iStack, int amountMin, int amountMax, int dropWeight) {
/*  378 */       this.stack = iStack;
/*  379 */       this.min = amountMin;
/*  380 */       this.max = amountMax;
/*  381 */       this.weight = dropWeight;
/*  382 */       this.dropType = LootPPHelper.DropType.ITEM;
/*      */     }
/*      */     
/*      */     public String toString() {
/*  386 */       return "{ Type: " + this.dropType.name() + ", Weight: " + this.weight + ", Min: " + this.min + ", Max: " + this.max + ", Item: " + this.stack + "}";
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class DropInfoCommand
/*      */     extends DropInfo
/*      */   {
/*      */     public String command;
/*      */ 
/*      */     
/*      */     public DropInfoCommand(String commandToSet, int dropWeight) {
/*  398 */       this.command = commandToSet;
/*  399 */       this.weight = dropWeight;
/*  400 */       this.dropType = LootPPHelper.DropType.COMMAND;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class EntityDropInfo
/*      */   {
/*      */     public float chance;
/*      */     
/*      */     public boolean playerKill;
/*      */     
/*      */     public boolean increasedByLooting;
/*      */     
/*      */     public ArrayList<ArrayList<LootPPHelper.DropInfo>> dropList;
/*      */     
/*      */     public EntityDropInfo(float probability, boolean dropOnPlayerKill, boolean lootingIncreases) {
/*  416 */       this.chance = probability;
/*  417 */       this.playerKill = dropOnPlayerKill;
/*  418 */       this.increasedByLooting = lootingIncreases;
/*  419 */       this.dropList = new ArrayList<ArrayList<LootPPHelper.DropInfo>>();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public static class BlockDropInfo
/*      */   {
/*      */     public float chance;
/*      */     
/*      */     public boolean playerMined;
/*      */     public boolean affectedBySilk;
/*      */     public boolean increasedByFortune;
/*      */     public ArrayList<ArrayList<LootPPHelper.DropInfo>> dropList;
/*      */     
/*      */     public BlockDropInfo(float probability, boolean dropOnPlayerKill, boolean silkAffects, boolean fortuneIncreases) {
/*  434 */       this.chance = probability;
/*  435 */       this.playerMined = dropOnPlayerKill;
/*  436 */       this.affectedBySilk = silkAffects;
/*  437 */       this.increasedByFortune = fortuneIncreases;
/*  438 */       this.dropList = new ArrayList<ArrayList<LootPPHelper.DropInfo>>();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*  443 */   public static Set<String> chestTypes = new HashSet<String>();
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean creepersDropAllRecords = true;
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean creepersDropRecords = true;
/*      */ 
/*      */   
/*  454 */   public static TreeMap<NBTTagCompound, Set<ItemStack>> entityDropRemovals = new TreeMap<NBTTagCompound, Set<ItemStack>>(comparatorNBT);
/*  455 */   public static TreeMap<NBTTagCompound, ArrayList<EntityDropInfo>> entityDropAdditions = new TreeMap<NBTTagCompound, ArrayList<EntityDropInfo>>(comparatorNBT);
/*  456 */   public static TreeMap<BlockMeta, Set<ItemStack>> blockDropRemovals = new TreeMap<BlockMeta, Set<ItemStack>>(blockComparator);
/*  457 */   public static TreeMap<BlockMeta, ArrayList<BlockDropInfo>> blockDropAdditions = new TreeMap<BlockMeta, ArrayList<BlockDropInfo>>(blockComparator);
/*      */ 
/*      */ 
/*      */   
/*  461 */   public static TreeMap<ItemStack, Item.ToolMaterial> addedToolMaterials = new TreeMap<ItemStack, Item.ToolMaterial>(stackComparator);
/*      */   static {
/*  463 */     addedToolMaterials.put(new ItemStack(Item.func_150898_a(Blocks.field_150344_f), 1, 32767), Item.ToolMaterial.WOOD);
/*  464 */     addedToolMaterials.put(new ItemStack(Item.func_150898_a(Blocks.field_150347_e), 1, 32767), Item.ToolMaterial.STONE);
/*  465 */     addedToolMaterials.put(new ItemStack(Items.field_151042_j, 1, 32767), Item.ToolMaterial.IRON);
/*  466 */     addedToolMaterials.put(new ItemStack(Items.field_151043_k, 1, 32767), Item.ToolMaterial.GOLD);
/*  467 */     addedToolMaterials.put(new ItemStack(Items.field_151045_i, 1, 32767), Item.ToolMaterial.EMERALD);
/*      */     
/*  469 */     Item.ToolMaterial toolMaterial = EnumHelper.addToolMaterial("lpp_leather", 0, 59, 2.0F, 0.0F, 15);
/*  470 */     toolMaterial.customCraftingMaterial = Items.field_151116_aA;
/*  471 */     addedToolMaterials.put(new ItemStack(toolMaterial.customCraftingMaterial, 1, 32767), toolMaterial);
/*      */   }
/*  473 */   public static TreeMap<ItemStack, ItemArmor.ArmorMaterial> addedArmourMaterials = new TreeMap<ItemStack, ItemArmor.ArmorMaterial>(stackComparator); public IWorldGenerator surfaceGen; public static File configFolder; public static File idFolder;
/*      */   static {
/*  475 */     addedArmourMaterials.put(new ItemStack(Items.field_151116_aA, 1, 32767), ItemArmor.ArmorMaterial.LEATHER);
/*  476 */     addedArmourMaterials.put(new ItemStack(Items.field_151042_j, 1, 32767), ItemArmor.ArmorMaterial.IRON);
/*  477 */     addedArmourMaterials.put(new ItemStack(Items.field_151043_k, 1, 32767), ItemArmor.ArmorMaterial.GOLD);
/*  478 */     addedArmourMaterials.put(new ItemStack(Items.field_151045_i, 1, 32767), ItemArmor.ArmorMaterial.DIAMOND);
/*      */     
/*  480 */     ItemArmor.ArmorMaterial temp = EnumHelper.addArmorMaterial("lpp_wood", "lpp_wood", 5, new int[] { 1, 3, 2, 1 }, 15);
/*  481 */     temp.customCraftingMaterial = Item.func_150898_a(Blocks.field_150344_f);
/*  482 */     addedArmourMaterials.put(new ItemStack(temp.customCraftingMaterial, 1, 32767), temp);
/*  483 */     temp = EnumHelper.addArmorMaterial("lpp_stone", "lpp_stone", 5, new int[] { 1, 3, 2, 1 }, 15);
/*  484 */     temp.customCraftingMaterial = Item.func_150898_a(Blocks.field_150347_e);
/*  485 */     addedArmourMaterials.put(new ItemStack(temp.customCraftingMaterial, 1, 32767), temp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  495 */   public static CreativeTabs tabLootPP = new CreativeTabs("tabLootPP")
/*      */     {
/*      */       
/*      */       public Item func_78016_d()
/*      */       {
/*  500 */         return LootPPItems.generalDummyIcon;
/*      */       }
/*      */     };
/*      */   
/*  504 */   public static CreativeTabs tabLootPPAdditions = (new CreativeTabs("tabLootPPAdditions")
/*      */     {
/*      */       
/*      */       public Item func_78016_d()
/*      */       {
/*  509 */         return LootPPItems.additionsDummyIcon;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public boolean hasSearchBar() {
/*  515 */         return true;
/*      */       }
/*  517 */     }).func_78025_a("item_search.png");
/*      */   
/*  519 */   public static HashMap<String, ArrayList<ItemStack>> additionsToDisplay = new HashMap<String, ArrayList<ItemStack>>();
/*  520 */   public static HashMap<String, LPPCreativeTabs> addedTabs = new HashMap<String, LPPCreativeTabs>();
/*      */   
/*      */   public static class LPPCreativeTabs
/*      */     extends CreativeTabs {
/*      */     public LPPCreativeTabs(String label) {
/*  525 */       super(label);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public String func_78024_c() {
/*  531 */       return func_78013_b();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Item func_78016_d() {
/*  537 */       return func_151244_d().func_77973_b();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public ItemStack func_151244_d() {
/*  543 */       ArrayList<ItemStack> additions = LootPPHelper.additionsToDisplay.get(func_78013_b());
/*  544 */       if (additions != null && !additions.isEmpty()) {
/*  545 */         return additions.get(0);
/*      */       }
/*      */       
/*  548 */       return new ItemStack(LootPPItems.additionsDummyIcon);
/*      */     }
/*      */   }
/*      */   
/*  552 */   public static HashMap<EntityLiving, LPPEntityAIRangedAttack> rangedAIs = new HashMap<EntityLiving, LPPEntityAIRangedAttack>();
/*  553 */   public static HashMap<EntityLiving, LPPEntityAIRangedAttack> meleeAIs = new HashMap<EntityLiving, LPPEntityAIRangedAttack>();
/*  554 */   public static HashMap<EntityLiving, EntityAIBase> originalRangedAIs = new HashMap<EntityLiving, EntityAIBase>();
/*  555 */   public static HashMap<EntityLiving, EntityAIBase> originalMeleeAIs = new HashMap<EntityLiving, EntityAIBase>();
/*  556 */   public static ArrayList<EntityLiving> delayedAIs = new ArrayList<EntityLiving>();
/*      */ 
/*      */ 
/*      */   
/*      */   public static int compareStacks(ItemStack stack1, ItemStack stack2) {
/*  561 */     if (stack1 == null && stack2 == null) {
/*  562 */       return 0;
/*      */     }
/*      */     
/*  565 */     if (stack1 == null && stack2 != null) {
/*  566 */       return 1;
/*      */     }
/*      */     
/*  569 */     if (stack1 != null && stack2 == null) {
/*  570 */       return -1;
/*      */     }
/*      */     
/*  573 */     if (stack2.func_77973_b() != stack1.func_77973_b()) {
/*  574 */       return Item.func_150891_b(stack2.func_77973_b()) - Item.func_150891_b(stack1.func_77973_b());
/*      */     }
/*      */     
/*  577 */     if (stack1.func_77952_i() == 32767 || stack2.func_77952_i() == 32767) {
/*  578 */       return 0;
/*      */     }
/*      */     
/*  581 */     return stack2.func_77952_i() - stack1.func_77952_i();
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isQuickdraw(Enchantment enchant) {
/*  586 */     if (enchant != null && enchant.func_77320_a() != null) {
/*      */       
/*  588 */       String name = StatCollector.func_74838_a(enchant.func_77320_a().toLowerCase());
/*  589 */       if (name.contains("quickdraw") || name.contains("drawnback")) {
/*  590 */         return true;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  595 */     return false;
/*      */   }
/*      */   public static EntityPlayerMP getPlayerByUsername(String name) {
/*      */     EntityPlayerMP entityplayermp;
/*  599 */     Iterator<EntityPlayerMP> iterator = (MinecraftServer.func_71276_C().func_71203_ab()).field_72404_b.iterator();
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/*  604 */       if (!iterator.hasNext())
/*      */       {
/*  606 */         return null;
/*      */       }
/*      */       
/*  609 */       entityplayermp = iterator.next();
/*      */     }
/*  611 */     while (!entityplayermp.func_70005_c_().equalsIgnoreCase(name));
/*      */     
/*  613 */     return entityplayermp;
/*      */   }
/*      */ 
/*      */   
/*      */   public static void mergeNBT(NBTTagCompound base, NBTTagCompound other) {
/*  618 */     Iterator<String> iterator = other.func_150296_c().iterator();
/*      */     
/*  620 */     while (iterator.hasNext()) {
/*      */       
/*  622 */       String s = iterator.next();
/*  623 */       NBTBase nbtbase = other.func_74781_a(s);
/*      */       
/*  625 */       if (nbtbase.func_74732_a() == 10) {
/*      */         
/*  627 */         if (base.func_150297_b(s, 10)) {
/*      */           
/*  629 */           NBTTagCompound nbttagcompound1 = base.func_74775_l(s);
/*  630 */           mergeNBT(nbttagcompound1, (NBTTagCompound)nbtbase);
/*      */           
/*      */           continue;
/*      */         } 
/*  634 */         base.func_74782_a(s, nbtbase.func_74737_b());
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  639 */       base.func_74782_a(s, nbtbase.func_74737_b());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean compareNBT(NBTBase part, NBTBase full) {
/*  646 */     if (part == full)
/*      */     {
/*  648 */       return true;
/*      */     }
/*  650 */     if (part == null)
/*      */     {
/*  652 */       return true;
/*      */     }
/*  654 */     if (full == null)
/*      */     {
/*  656 */       return false;
/*      */     }
/*  658 */     if (!part.getClass().equals(full.getClass()))
/*      */     {
/*  660 */       return false;
/*      */     }
/*  662 */     if (part instanceof NBTTagCompound) {
/*      */       String s; NBTBase nbtbase2;
/*  664 */       NBTTagCompound nbttagcompound = (NBTTagCompound)part;
/*  665 */       NBTTagCompound nbttagcompound1 = (NBTTagCompound)full;
/*  666 */       Iterator<String> iterator = nbttagcompound.func_150296_c().iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       do {
/*  672 */         if (!iterator.hasNext())
/*      */         {
/*  674 */           return true;
/*      */         }
/*      */         
/*  677 */         s = iterator.next();
/*  678 */         nbtbase2 = nbttagcompound.func_74781_a(s);
/*      */       }
/*  680 */       while (compareNBT(nbtbase2, nbttagcompound1.func_74781_a(s)));
/*      */       
/*  682 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  686 */     return part.equals(full);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean hasAllTags(NBTBase tagsToCheck, NBTBase baseNBT, boolean compareLists)
/*      */   {
/*  692 */     if (tagsToCheck == baseNBT)
/*      */     {
/*  694 */       return true;
/*      */     }
/*  696 */     if (tagsToCheck == null)
/*      */     {
/*  698 */       return true;
/*      */     }
/*  700 */     if (baseNBT == null)
/*      */     {
/*  702 */       return false;
/*      */     }
/*  704 */     if (!tagsToCheck.getClass().equals(baseNBT.getClass()))
/*      */     {
/*  706 */       return false;
/*      */     }
/*  708 */     if (tagsToCheck instanceof NBTTagCompound) {
/*      */       String s; NBTBase nbtbase3;
/*  710 */       NBTTagCompound nbttagcompound = (NBTTagCompound)tagsToCheck;
/*  711 */       NBTTagCompound nbttagcompound1 = (NBTTagCompound)baseNBT;
/*  712 */       Iterator<String> iterator = nbttagcompound.func_150296_c().iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       do {
/*  718 */         if (!iterator.hasNext())
/*      */         {
/*  720 */           return true;
/*      */         }
/*      */         
/*  723 */         s = iterator.next();
/*  724 */         nbtbase3 = nbttagcompound.func_74781_a(s);
/*      */       }
/*  726 */       while (hasAllTags(nbtbase3, nbttagcompound1.func_74781_a(s), compareLists));
/*      */       
/*  728 */       return false;
/*      */     } 
/*  730 */     if (tagsToCheck instanceof NBTTagList && compareLists) {
/*      */       
/*  732 */       NBTTagList nbttaglist = (NBTTagList)tagsToCheck;
/*  733 */       NBTTagList nbttaglist1 = (NBTTagList)baseNBT;
/*      */       
/*  735 */       if (nbttaglist.func_74745_c() == 0)
/*      */       {
/*  737 */         return (nbttaglist1.func_74745_c() == 0);
/*      */       }
/*      */ 
/*      */       
/*  741 */       int i = 0;
/*      */       
/*  743 */       while (i < nbttaglist.func_74745_c()) {
/*      */         
/*  745 */         NBTBase nbtbase2 = nbttaglist.func_179238_g(i);
/*  746 */         boolean flag1 = false;
/*  747 */         int j = 0;
/*      */ 
/*      */ 
/*      */         
/*  751 */         while (j < nbttaglist1.func_74745_c()) {
/*      */           
/*  753 */           if (!hasAllTags(nbtbase2, nbttaglist1.func_179238_g(j), compareLists)) {
/*      */             
/*  755 */             j++;
/*      */             
/*      */             continue;
/*      */           } 
/*  759 */           flag1 = true;
/*      */         } 
/*      */         
/*  762 */         if (!flag1)
/*      */         {
/*  764 */           return false;
/*      */         }
/*      */         
/*  767 */         i++;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  772 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  777 */     return tagsToCheck.equals(baseNBT); } public static DropInfo getDropInfo(char type, String dropString, boolean comment, String title) { String parts[], itemName, entityName, weightString, minString, str1, command, maxString, nbtString; int weight; String str2; NBTBase nbt; String metaString;
/*      */     NBTTagCompound entityNBT;
/*      */     NBTBase nBTBase1;
/*      */     int i, min, max, j, meta;
/*      */     Item item;
/*      */     ItemStack itemStack;
/*  783 */     DropInfo infoToReturn = null;
/*      */     
/*  785 */     switch (type) {
/*      */       case 'i':
/*  787 */         parts = dropString.split("-", 6);
/*      */         
/*  789 */         if (parts.length < 2) {
/*  790 */           LootPPNotifier.notifyWrongNumberOfParts(comment, title, dropString);
/*  791 */           return null;
/*      */         } 
/*      */         
/*  794 */         itemName = parts[0];
/*  795 */         minString = parts[1];
/*      */         
/*  797 */         maxString = minString;
/*  798 */         str2 = "1";
/*  799 */         metaString = "0";
/*  800 */         nBTBase1 = null;
/*      */         
/*  802 */         if (parts.length > 2) {
/*  803 */           maxString = parts[2];
/*      */         }
/*      */         
/*  806 */         if (parts.length > 3) {
/*  807 */           str2 = parts[3];
/*      */         }
/*      */         
/*  810 */         if (parts.length > 4) {
/*  811 */           metaString = parts[4];
/*      */         }
/*      */         
/*  814 */         if (parts.length > 5) {
/*      */           
/*      */           try {
/*  817 */             NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(parts[5].trim());
/*      */           }
/*  819 */           catch (NBTException e) {
/*      */             
/*  821 */             if (!comment) {
/*  822 */               e.printStackTrace();
/*  823 */               LootPPNotifier.notifyNBT(comment, title, parts[6].trim(), e.getMessage());
/*      */             } 
/*  825 */             nBTBase1 = null;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/*  830 */         min = 1;
/*  831 */         max = 1;
/*  832 */         j = 1;
/*  833 */         meta = 0;
/*      */ 
/*      */         
/*      */         try {
/*  837 */           min = Integer.valueOf(minString).intValue();
/*  838 */           max = Integer.valueOf(maxString).intValue();
/*  839 */           j = Integer.valueOf(str2).intValue();
/*  840 */           meta = Integer.valueOf(metaString).intValue();
/*      */         }
/*  842 */         catch (Exception e) {
/*  843 */           if (!comment) {
/*  844 */             System.err.println("[Loot++] Caught an exception while loading a drop addition.");
/*  845 */             e.printStackTrace();
/*  846 */             LootPPNotifier.notifyNumber(comment, title, new String[] { minString, maxString, str2, metaString });
/*      */           } 
/*      */         } 
/*      */         
/*  850 */         if (min < 0) min = 0; 
/*  851 */         if (max < min) max = min; 
/*  852 */         if (meta < 0) meta = 0; 
/*  853 */         if (j <= 0) j = 1;
/*      */         
/*  855 */         item = (Item)Item.field_150901_e.func_82594_a(itemName);
/*      */         
/*  857 */         if (item == null) {
/*  858 */           LootPPNotifier.notifyNonexistant(comment, title, itemName);
/*  859 */           return null;
/*      */         } 
/*      */         
/*  862 */         itemStack = new ItemStack(item);
/*      */         
/*  864 */         if (nBTBase1 != null) {
/*  865 */           itemStack.func_77982_d((NBTTagCompound)nBTBase1);
/*      */         }
/*      */         
/*  868 */         itemStack.func_77964_b(meta);
/*      */         
/*  870 */         if (LootPlusPlusMod.debug) System.out.println("[Loot++] Created item drop. Item: " + itemStack + ", Min: " + min + ", Max: " + max + ", Weight: " + j); 
/*  871 */         infoToReturn = new DropInfoItem(itemStack, min, max, j);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  975 */         return infoToReturn;case 'e': parts = dropString.split("-", 3); if (parts.length < 1) { LootPPNotifier.notifyWrongNumberOfParts(comment, title, dropString); return null; }  entityName = parts[0]; str1 = "1"; nbtString = "{}"; if (parts.length > 1) str1 = parts[1];  if (parts.length > 2) nbtString = parts[2];  nbt = null; entityNBT = null; try { NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(nbtString); if (nBTTagCompound != null) entityNBT = nBTTagCompound;  } catch (NBTException e) { if (!comment) { e.printStackTrace(); LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage()); }  entityNBT = null; }  if (entityNBT == null) entityNBT = new NBTTagCompound();  i = 1; try { i = Integer.valueOf(str1).intValue(); } catch (NumberFormatException e) { if (!comment) { System.err.println("[Loot++] Caught an exception while loading a drop addition."); e.printStackTrace(); LootPPNotifier.notifyNumber(comment, title, str1); }  }  if (i <= 0) i = 1;  if (LootPlusPlusMod.debug) System.out.println("[Loot++] Created entity drop. Entity: " + entityName + ", NBT Tag: " + entityNBT + ", Weight: " + i);  entityNBT.func_74778_a("id", entityName); infoToReturn = new DropInfoEntity(entityNBT, i); return infoToReturn;case 'c': parts = dropString.split("-", 2); if (parts.length < 2) { LootPPNotifier.notifyWrongNumberOfParts(comment, title, dropString); return null; }  weightString = parts[0]; command = parts[1]; weight = 1; try { weight = Integer.valueOf(weightString).intValue(); } catch (NumberFormatException e) { if (!comment) { System.err.println("[Loot++] Caught an exception while loading a drop addition."); e.printStackTrace(); LootPPNotifier.notifyNumber(comment, title, weightString); }  }  if (weight <= 0) weight = 1;  if (LootPlusPlusMod.debug) System.out.println("[Loot++] Created command drop. Command: " + command + ", Weight: " + weight);  infoToReturn = new DropInfoCommand(command, weight); return infoToReturn;
/*      */     } 
/*      */     LootPPNotifier.notify(comment, title, "Unrecognized drop type character: " + type);
/*      */     return null; }
/*      */    public static void dropEntityDropAdditions(LivingDropsEvent event, EntityDropInfo drop, Random rand) {
/*  980 */     if (drop.playerKill && !event.recentlyHit) {
/*      */       return;
/*      */     }
/*  983 */     if (rand.nextFloat() > drop.chance + (drop.increasedByLooting ? (0.01F * event.lootingLevel) : 0.0F)) {
/*      */       return;
/*      */     }
/*  986 */     if (drop.dropList == null || drop.dropList.isEmpty()) {
/*      */       return;
/*      */     }
/*  989 */     ArrayList<DropInfo> listToUse = drop.dropList.get(0);
/*      */     
/*  991 */     int totalWeight = 0;
/*      */     
/*  993 */     for (ArrayList<DropInfo> infoList : drop.dropList) {
/*  994 */       if (!infoList.isEmpty() && infoList.get(0) != null) {
/*  995 */         totalWeight += ((DropInfo)infoList.get(0)).weight;
/*      */       }
/*      */     } 
/*      */     
/*  999 */     if (totalWeight <= 0) {
/* 1000 */       System.out.println("[Loot++] Problem while adding drops! Weights should never be 0 or negative!");
/* 1001 */       totalWeight = 1;
/*      */     } 
/*      */     
/* 1004 */     int randomInt = rand.nextInt(totalWeight) + 1;
/* 1005 */     totalWeight = 0;
/*      */     
/* 1007 */     for (ArrayList<DropInfo> infoList : drop.dropList) {
/* 1008 */       if (!infoList.isEmpty() && infoList.get(0) != null) {
/* 1009 */         totalWeight += ((DropInfo)infoList.get(0)).weight;
/* 1010 */         if (totalWeight >= randomInt) {
/* 1011 */           listToUse = infoList;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1017 */     for (DropInfo toUse : listToUse) {
/*      */       
/* 1019 */       if (toUse.dropType == DropType.ITEM) {
/*      */ 
/*      */         
/* 1022 */         DropInfoItem infoItem = toUse.getDropInfoItem();
/*      */         
/* 1024 */         if (infoItem == null) {
/*      */           continue;
/*      */         }
/* 1027 */         int amountDiff = infoItem.max - infoItem.min;
/* 1028 */         if (amountDiff < 0) {
/* 1029 */           amountDiff = 0;
/*      */         }
/* 1031 */         int numToDrop = infoItem.min + ((amountDiff == 0) ? 0 : rand.nextInt(amountDiff + 1));
/*      */         
/* 1033 */         if (drop.increasedByLooting && 
/* 1034 */           event.lootingLevel > 0)
/*      */         {
/* 1036 */           numToDrop += rand.nextInt(event.lootingLevel + 1);
/*      */         }
/*      */ 
/*      */         
/* 1040 */         if (infoItem.stack == null) {
/*      */           return;
/*      */         }
/* 1043 */         ItemStack droppedItem = new ItemStack(infoItem.stack.func_77973_b());
/*      */         
/* 1045 */         droppedItem.func_77982_d(infoItem.stack.func_77978_p());
/* 1046 */         droppedItem.field_77994_a = numToDrop;
/* 1047 */         droppedItem.func_77964_b(infoItem.stack.func_77952_i());
/*      */         
/* 1049 */         EntityItem toDrop = new EntityItem(event.entity.field_70170_p, event.entity.field_70165_t, event.entity.field_70163_u, event.entity.field_70161_v, droppedItem);
/* 1050 */         toDrop.func_174867_a(10);
/*      */         
/* 1052 */         if (LootPlusPlusMod.debug) System.out.println("[Loot++] Dropping " + numToDrop + " of " + droppedItem.func_82833_r());
/*      */         
/* 1054 */         event.drops.add(toDrop);
/*      */       } 
/*      */       
/* 1057 */       if (toUse.dropType == DropType.ENTITY) {
/*      */ 
/*      */         
/* 1060 */         DropInfoEntity infoEntity = toUse.getDropInfoEntity();
/*      */         
/* 1062 */         if (infoEntity == null) {
/*      */           continue;
/*      */         }
/* 1065 */         int numToDrop = 1;
/*      */         
/* 1067 */         if (drop.increasedByLooting && 
/* 1068 */           event.lootingLevel > 0)
/*      */         {
/* 1070 */           numToDrop += rand.nextInt(event.lootingLevel + 1);
/*      */         }
/*      */ 
/*      */         
/* 1074 */         for (int i = 0; i < numToDrop; i++) {
/* 1075 */           Entity entity1 = EntityList.func_75615_a(infoEntity.entityTag, event.entity.field_70170_p);
/*      */           
/* 1077 */           if (entity1 instanceof EntityLiving && infoEntity.entityTag.func_150296_c().size() == 1)
/*      */           {
/* 1079 */             ((EntityLiving)entity1).func_180482_a(event.entity.field_70170_p.func_175649_E(event.entity.func_180425_c()), null);
/*      */           }
/*      */           
/* 1082 */           if (entity1 != null) {
/*      */             
/* 1084 */             entity1.func_70012_b(event.entity.field_70165_t + rand.nextDouble() * 0.1D, event.entity.field_70163_u + rand.nextDouble() * 0.1D, event.entity.field_70161_v + rand.nextDouble() * 0.1D, entity1.field_70177_z, entity1.field_70125_A);
/*      */             
/* 1086 */             event.entity.field_70170_p.func_72838_d(entity1);
/* 1087 */             Entity entity2 = entity1;
/*      */             
/* 1089 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Spawning Entity: " + infoEntity.entityTag.func_74779_i("id"));
/*      */             
/* 1091 */             for (NBTTagCompound nbttagcompound1 = infoEntity.entityTag; entity2 != null && nbttagcompound1.func_150297_b("Riding", 10); nbttagcompound1 = nbttagcompound1.func_74775_l("Riding")) {
/*      */               
/* 1093 */               Entity entity = EntityList.func_75615_a(nbttagcompound1.func_74775_l("Riding"), event.entity.field_70170_p);
/*      */               
/* 1095 */               if (entity instanceof EntityLiving && infoEntity.entityTag.func_150296_c().size() == 1)
/*      */               {
/* 1097 */                 ((EntityLiving)entity).func_180482_a(event.entity.field_70170_p.func_175649_E(event.entity.func_180425_c()), null);
/*      */               }
/*      */               
/* 1100 */               if (entity != null) {
/*      */                 
/* 1102 */                 entity.func_70012_b(entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v, entity.field_70177_z, entity.field_70125_A);
/* 1103 */                 event.entity.field_70170_p.func_72838_d(entity);
/* 1104 */                 entity2.func_70078_a(entity);
/*      */                 
/* 1106 */                 if (LootPlusPlusMod.debug) System.out.println("[Loot++] Spawning Entity as Mount: " + nbttagcompound1.func_74779_i("id"));
/*      */               
/*      */               } 
/* 1109 */               entity2 = entity;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1115 */       if (toUse.dropType == DropType.COMMAND) {
/*      */ 
/*      */         
/* 1118 */         DropInfoCommand infoCommand = toUse.getDropInfoCommand();
/*      */         
/* 1120 */         if (infoCommand == null) {
/*      */           continue;
/*      */         }
/* 1123 */         int numToDrop = 1;
/*      */         
/* 1125 */         if (drop.increasedByLooting && 
/* 1126 */           event.lootingLevel > 0)
/*      */         {
/* 1128 */           numToDrop += rand.nextInt(event.lootingLevel + 1);
/*      */         }
/*      */ 
/*      */         
/* 1132 */         for (int i = 0; i < numToDrop; i++) {
/*      */           try {
/* 1134 */             CommandSenderGeneric sender = new CommandSenderGeneric(event.entity.func_70005_c_(), event.entity.field_70170_p, new Vec3(event.entity.field_70165_t, event.entity.field_70163_u, event.entity.field_70161_v));
/* 1135 */             ICommandManager manager = MinecraftServer.func_71276_C().func_71187_D();
/* 1136 */             manager.func_71556_a((ICommandSender)sender, infoCommand.command);
/*      */           }
/* 1138 */           catch (Exception e) {
/* 1139 */             System.err.println("[Loot++] Problem while running command from item!");
/* 1140 */             e.printStackTrace();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void removeBlockDrop(BlockEvent.HarvestDropsEvent event, Iterator it, ItemStack stack, ItemStack current) {
/* 1148 */     if (compareStacks(stack, current) == 0 && (
/* 1149 */       stack.func_77978_p() == null || stack.func_77978_p().func_82582_d() || stack.func_77978_p().equals(current.func_77978_p()))) {
/* 1150 */       if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removed Block Drop: " + Item.field_150901_e.func_177774_c(stack.func_77973_b()) + " for block " + event.state); 
/* 1151 */       it.remove();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public static void dropBlockDropAdditions(BlockEvent.HarvestDropsEvent event, BlockDropInfo drop, Random rand) {
/* 1157 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Attempting to drop something for: " + Block.field_149771_c.func_177774_c(event.state.func_177230_c()));
/*      */     
/* 1159 */     if (drop.playerMined && event.harvester == null) {
/*      */       return;
/*      */     }
/* 1162 */     if ((drop.affectedBySilk && !event.isSilkTouching) || (!drop.affectedBySilk && event.isSilkTouching)) {
/*      */       return;
/*      */     }
/* 1165 */     if (rand.nextFloat() > drop.chance + (drop.increasedByFortune ? (0.01F * event.fortuneLevel) : 0.0F)) {
/*      */       return;
/*      */     }
/* 1168 */     if (drop.dropList == null || drop.dropList.isEmpty()) {
/*      */       return;
/*      */     }
/* 1171 */     ArrayList<DropInfo> listToUse = drop.dropList.get(0);
/*      */     
/* 1173 */     int totalWeight = 0;
/*      */     
/* 1175 */     for (ArrayList<DropInfo> infoList : drop.dropList) {
/* 1176 */       if (!infoList.isEmpty() && infoList.get(0) != null) {
/* 1177 */         totalWeight += ((DropInfo)infoList.get(0)).weight;
/*      */       }
/*      */     } 
/*      */     
/* 1181 */     if (totalWeight <= 0) {
/* 1182 */       System.out.println("[Loot++] Problem while adding drops! Weights should never be 0 or negative!");
/* 1183 */       totalWeight = 1;
/*      */     } 
/*      */     
/* 1186 */     int randomInt = rand.nextInt(totalWeight) + 1;
/* 1187 */     totalWeight = 0;
/*      */     
/* 1189 */     for (ArrayList<DropInfo> infoList : drop.dropList) {
/* 1190 */       if (!infoList.isEmpty() && infoList.get(0) != null) {
/* 1191 */         totalWeight += ((DropInfo)infoList.get(0)).weight;
/* 1192 */         if (totalWeight >= randomInt) {
/* 1193 */           listToUse = infoList;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1199 */     for (DropInfo toUse : listToUse) {
/* 1200 */       if (toUse.dropType == DropType.ITEM) {
/*      */ 
/*      */         
/* 1203 */         DropInfoItem infoItem = toUse.getDropInfoItem();
/*      */         
/* 1205 */         if (infoItem == null) {
/*      */           continue;
/*      */         }
/* 1208 */         int amountDiff = infoItem.max - infoItem.min;
/* 1209 */         if (amountDiff < 0) {
/* 1210 */           amountDiff = 0;
/*      */         }
/* 1212 */         int numToDrop = infoItem.min + ((amountDiff == 0) ? 0 : rand.nextInt(amountDiff + 1));
/*      */         
/* 1214 */         if (drop.increasedByFortune && 
/* 1215 */           event.fortuneLevel > 0)
/*      */         {
/* 1217 */           numToDrop += rand.nextInt(event.fortuneLevel + 1);
/*      */         }
/*      */ 
/*      */         
/* 1221 */         if (infoItem.stack == null) {
/*      */           return;
/*      */         }
/* 1224 */         ItemStack droppedItem = new ItemStack(infoItem.stack.func_77973_b());
/*      */         
/* 1226 */         droppedItem.func_77982_d(infoItem.stack.func_77978_p());
/* 1227 */         droppedItem.field_77994_a = numToDrop;
/* 1228 */         droppedItem.func_77964_b(infoItem.stack.func_77952_i());
/*      */         
/* 1230 */         if (LootPlusPlusMod.debug) System.out.println("[Loot++] Dropping Item: " + droppedItem); 
/* 1231 */         event.drops.add(droppedItem);
/*      */       } 
/*      */       
/* 1234 */       if (toUse.dropType == DropType.ENTITY) {
/*      */ 
/*      */         
/* 1237 */         DropInfoEntity infoEntity = toUse.getDropInfoEntity();
/*      */         
/* 1239 */         if (infoEntity == null) {
/*      */           continue;
/*      */         }
/* 1242 */         int numToDrop = 1;
/*      */         
/* 1244 */         if (drop.increasedByFortune && 
/* 1245 */           event.fortuneLevel > 0)
/*      */         {
/* 1247 */           numToDrop += rand.nextInt(event.fortuneLevel + 1);
/*      */         }
/*      */ 
/*      */         
/* 1251 */         for (int i = 0; i < numToDrop; i++) {
/* 1252 */           Entity entity1 = EntityList.func_75615_a(infoEntity.entityTag, event.world);
/*      */           
/* 1254 */           if (entity1 instanceof EntityLiving && infoEntity.entityTag.func_150296_c().size() == 1)
/*      */           {
/* 1256 */             ((EntityLiving)entity1).func_180482_a(event.world.func_175649_E(event.pos), null);
/*      */           }
/*      */ 
/*      */           
/* 1260 */           if (entity1 != null) {
/*      */             
/* 1262 */             entity1.func_70012_b(event.pos.func_177958_n() + 0.5D + rand.nextDouble() * 0.1D, event.pos.func_177956_o() + 0.5D + rand.nextDouble() * 0.1D, event.pos.func_177952_p() + 0.5D + rand.nextDouble() * 0.1D, entity1.field_70177_z, entity1.field_70125_A);
/*      */             
/* 1264 */             event.world.func_72838_d(entity1);
/* 1265 */             Entity entity2 = entity1;
/*      */             
/* 1267 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Spawning Entity: " + infoEntity.entityTag.func_74779_i("id"));
/*      */             
/* 1269 */             for (NBTTagCompound nbttagcompound1 = infoEntity.entityTag; entity2 != null && nbttagcompound1.func_150297_b("Riding", 10); nbttagcompound1 = nbttagcompound1.func_74775_l("Riding")) {
/*      */               
/* 1271 */               Entity entity = EntityList.func_75615_a(nbttagcompound1.func_74775_l("Riding"), event.world);
/*      */               
/* 1273 */               if (entity != null) {
/*      */                 
/* 1275 */                 entity.func_70012_b(entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v, entity.field_70177_z, entity.field_70125_A);
/* 1276 */                 event.world.func_72838_d(entity);
/* 1277 */                 entity2.func_70078_a(entity);
/*      */                 
/* 1279 */                 if (LootPlusPlusMod.debug) System.out.println("[Loot++] Spawning Entity as Mount: " + nbttagcompound1.func_74779_i("id"));
/*      */               
/*      */               } 
/* 1282 */               entity2 = entity;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1288 */       if (toUse.dropType == DropType.COMMAND) {
/*      */ 
/*      */         
/* 1291 */         DropInfoCommand infoCommand = toUse.getDropInfoCommand();
/*      */         
/* 1293 */         if (infoCommand == null) {
/*      */           continue;
/*      */         }
/* 1296 */         int numToDrop = 1;
/*      */         
/* 1298 */         if (drop.increasedByFortune && 
/* 1299 */           event.fortuneLevel > 0)
/*      */         {
/* 1301 */           numToDrop += rand.nextInt(event.fortuneLevel + 1);
/*      */         }
/*      */ 
/*      */         
/* 1305 */         for (int i = 0; i < numToDrop; i++) {
/*      */           try {
/* 1307 */             CommandSenderGeneric sender = new CommandSenderGeneric("Server", event.world, event.pos);
/* 1308 */             ICommandManager manager = MinecraftServer.func_71276_C().func_71187_D();
/* 1309 */             manager.func_71556_a((ICommandSender)sender, infoCommand.command);
/*      */           }
/* 1311 */           catch (Exception e) {
/* 1312 */             System.err.println("[Loot++] Problem while running command from item!");
/* 1313 */             e.printStackTrace();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void dropThrownDropAdditions(ItemAddedThrowable item, Entity thrown) {
/* 1321 */     Random rand = new Random();
/*      */     
/* 1323 */     if (rand.nextFloat() > item.chance) {
/*      */       return;
/*      */     }
/* 1326 */     if (item.dropList == null || item.dropList.isEmpty()) {
/*      */       return;
/*      */     }
/* 1329 */     ArrayList<DropInfo> listToUse = item.dropList.get(0);
/*      */     
/* 1331 */     int totalWeight = 0;
/*      */     
/* 1333 */     for (ArrayList<DropInfo> infoList : (Iterable<ArrayList<DropInfo>>)item.dropList) {
/* 1334 */       if (!infoList.isEmpty() && infoList.get(0) != null) {
/* 1335 */         totalWeight += ((DropInfo)infoList.get(0)).weight;
/*      */       }
/*      */     } 
/*      */     
/* 1339 */     if (totalWeight <= 0) {
/* 1340 */       System.out.println("[Loot++] Problem while adding drops! Weights should never be 0 or negative!");
/* 1341 */       totalWeight = 1;
/*      */     } 
/*      */     
/* 1344 */     int randomInt = rand.nextInt(totalWeight) + 1;
/* 1345 */     totalWeight = 0;
/*      */     
/* 1347 */     for (ArrayList<DropInfo> infoList : (Iterable<ArrayList<DropInfo>>)item.dropList) {
/* 1348 */       if (!infoList.isEmpty() && infoList.get(0) != null) {
/* 1349 */         totalWeight += ((DropInfo)infoList.get(0)).weight;
/* 1350 */         if (totalWeight >= randomInt) {
/* 1351 */           listToUse = infoList;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1357 */     for (DropInfo toUse : listToUse) {
/*      */       
/* 1359 */       if (toUse.dropType == DropType.ITEM) {
/*      */ 
/*      */         
/* 1362 */         DropInfoItem infoItem = toUse.getDropInfoItem();
/*      */         
/* 1364 */         if (infoItem == null) {
/*      */           continue;
/*      */         }
/* 1367 */         int amountDiff = infoItem.max - infoItem.min;
/* 1368 */         if (amountDiff < 0) {
/* 1369 */           amountDiff = 0;
/*      */         }
/* 1371 */         int numToDrop = infoItem.min + ((amountDiff == 0) ? 0 : rand.nextInt(amountDiff + 1));
/*      */         
/* 1373 */         if (infoItem.stack == null) {
/*      */           return;
/*      */         }
/* 1376 */         ItemStack droppedItem = new ItemStack(infoItem.stack.func_77973_b());
/*      */         
/* 1378 */         droppedItem.func_77982_d(infoItem.stack.func_77978_p());
/* 1379 */         droppedItem.field_77994_a = numToDrop;
/* 1380 */         droppedItem.func_77964_b(infoItem.stack.func_77952_i());
/*      */         
/* 1382 */         EntityItem toDrop = new EntityItem(thrown.field_70170_p, thrown.field_70165_t, thrown.field_70163_u, thrown.field_70161_v, droppedItem);
/* 1383 */         toDrop.func_174867_a(10);
/*      */         
/* 1385 */         thrown.field_70170_p.func_72838_d((Entity)toDrop);
/*      */       } 
/*      */       
/* 1388 */       if (toUse.dropType == DropType.ENTITY) {
/*      */ 
/*      */         
/* 1391 */         DropInfoEntity infoEntity = toUse.getDropInfoEntity();
/*      */         
/* 1393 */         if (infoEntity == null) {
/*      */           continue;
/*      */         }
/*      */         
/* 1397 */         Entity entity1 = EntityList.func_75615_a(infoEntity.entityTag, thrown.field_70170_p);
/*      */         
/* 1399 */         if (entity1 instanceof EntityLiving && infoEntity.entityTag.func_150296_c().size() == 1)
/*      */         {
/* 1401 */           ((EntityLiving)entity1).func_180482_a(thrown.field_70170_p.func_175649_E(thrown.func_180425_c()), null);
/*      */         }
/*      */         
/* 1404 */         if (entity1 != null) {
/*      */           
/* 1406 */           entity1.func_70012_b(thrown.field_70165_t + rand.nextDouble() * 0.1D, thrown.field_70163_u + rand.nextDouble() * 0.1D, thrown.field_70161_v + rand.nextDouble() * 0.1D, entity1.field_70177_z, entity1.field_70125_A);
/*      */           
/* 1408 */           thrown.field_70170_p.func_72838_d(entity1);
/* 1409 */           Entity entity2 = entity1;
/*      */           
/* 1411 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Spawning Entity: " + infoEntity.entityTag.func_74779_i("id"));
/*      */           
/* 1413 */           for (NBTTagCompound nbttagcompound1 = infoEntity.entityTag; entity2 != null && nbttagcompound1.func_150297_b("Riding", 10); nbttagcompound1 = nbttagcompound1.func_74775_l("Riding")) {
/*      */             
/* 1415 */             Entity entity = EntityList.func_75615_a(nbttagcompound1.func_74775_l("Riding"), thrown.field_70170_p);
/*      */             
/* 1417 */             if (entity instanceof EntityLiving && infoEntity.entityTag.func_150296_c().size() == 1)
/*      */             {
/* 1419 */               ((EntityLiving)entity).func_180482_a(thrown.field_70170_p.func_175649_E(thrown.func_180425_c()), null);
/*      */             }
/*      */             
/* 1422 */             if (entity != null) {
/*      */               
/* 1424 */               entity.func_70012_b(entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v, entity.field_70177_z, entity.field_70125_A);
/* 1425 */               thrown.field_70170_p.func_72838_d(entity);
/* 1426 */               entity2.func_70078_a(entity);
/*      */               
/* 1428 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Spawning Entity as Mount: " + nbttagcompound1.func_74779_i("id"));
/*      */             
/*      */             } 
/* 1431 */             entity2 = entity;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1436 */       if (toUse.dropType == DropType.COMMAND) {
/*      */ 
/*      */         
/* 1439 */         DropInfoCommand infoCommand = toUse.getDropInfoCommand();
/*      */         
/* 1441 */         if (infoCommand == null) {
/*      */           continue;
/*      */         }
/*      */         try {
/* 1445 */           CommandSenderGeneric sender = new CommandSenderGeneric(thrown.func_70005_c_(), thrown.field_70170_p, new Vec3(thrown.field_70165_t, thrown.field_70163_u, thrown.field_70161_v));
/* 1446 */           ICommandManager manager = MinecraftServer.func_71276_C().func_71187_D();
/* 1447 */           manager.func_71556_a((ICommandSender)sender, infoCommand.command);
/*      */         }
/* 1449 */         catch (Exception e) {
/* 1450 */           System.err.println("[Loot++] Problem while running command from item!");
/* 1451 */           e.printStackTrace();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void addAddedBowAIToMob(EntityLiving mob) {
/* 1458 */     Iterator<EntityAITasks.EntityAITaskEntry> iterator = mob.field_70714_bg.field_75782_a.iterator();
/* 1459 */     int rangedPriority = 2;
/* 1460 */     int meleePriority = 2;
/* 1461 */     EntityAIBase rangedTask = null;
/* 1462 */     EntityAIBase meleeTask = null;
/*      */     
/* 1464 */     while (iterator.hasNext()) {
/*      */       
/* 1466 */       EntityAITasks.EntityAITaskEntry entry = iterator.next();
/*      */       
/* 1468 */       if (entry.field_75733_a instanceof EntityAIArrowAttack) {
/* 1469 */         rangedPriority = entry.field_75731_b;
/* 1470 */         rangedTask = entry.field_75733_a;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1475 */     while (iterator.hasNext()) {
/*      */       
/* 1477 */       EntityAITasks.EntityAITaskEntry entry = iterator.next();
/*      */       
/* 1479 */       if (entry.field_75733_a instanceof net.minecraft.entity.ai.EntityAIAttackOnCollide) {
/* 1480 */         meleePriority = entry.field_75731_b;
/* 1481 */         meleeTask = entry.field_75733_a;
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 1488 */     LPPEntityAIRangedAttack aiArrow = new LPPEntityAIRangedAttack((IRangedAttackMob)mob, 1.0D, 20, 60, 15.0F);
/* 1489 */     if (rangedTask instanceof EntityAIArrowAttack) {
/* 1490 */       aiArrow.entityMoveSpeed = ((Double)ObfuscationReflectionHelper.getPrivateValue(EntityAIArrowAttack.class, rangedTask, new String[] { "entityMoveSpeed", "field_75321_e" })).doubleValue();
/* 1491 */       aiArrow.baseRangedAttackTime = ((Integer)ObfuscationReflectionHelper.getPrivateValue(EntityAIArrowAttack.class, rangedTask, new String[] { "field_96561_g" })).intValue();
/* 1492 */       aiArrow.maxRangedAttackTime = ((Integer)ObfuscationReflectionHelper.getPrivateValue(EntityAIArrowAttack.class, rangedTask, new String[] { "maxRangedAttackTime", "field_75325_h" })).intValue();
/* 1493 */       aiArrow.maxAttackDistance = ((Float)ObfuscationReflectionHelper.getPrivateValue(EntityAIArrowAttack.class, rangedTask, new String[] { "field_96562_i" })).floatValue();
/*      */     } 
/*      */     
/* 1496 */     if (rangedTask != null) {
/* 1497 */       mob.field_70714_bg.func_85156_a(rangedTask);
/* 1498 */       originalRangedAIs.put(mob, rangedTask);
/*      */     } 
/*      */     
/* 1501 */     mob.field_70714_bg.func_75776_a(rangedPriority, aiArrow);
/* 1502 */     rangedAIs.put(mob, aiArrow);
/*      */     
/* 1504 */     if (meleeTask != null) {
/* 1505 */       mob.field_70714_bg.func_85156_a(meleeTask);
/* 1506 */       originalRangedAIs.put(mob, meleeTask);
/*      */       
/* 1508 */       mob.field_70714_bg.func_75776_a(meleePriority, aiArrow);
/* 1509 */       meleeAIs.put(mob, aiArrow);
/*      */     } 
/*      */     
/* 1512 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added bow task for mob '" + mob + "'."); 
/*      */   }
/*      */   
/*      */   public static void removeAddedBowAIFromMob(EntityLiving mob) {
/* 1516 */     Iterator<EntityAITasks.EntityAITaskEntry> iterator = mob.field_70714_bg.field_75782_a.iterator();
/* 1517 */     int rangedPriority = 2;
/* 1518 */     int meleePriority = 2;
/* 1519 */     EntityAIBase rangedTask = rangedAIs.get(mob);
/* 1520 */     EntityAIBase meleeTask = meleeAIs.get(mob);
/*      */     
/* 1522 */     if (rangedTask != null) {
/* 1523 */       while (iterator.hasNext()) {
/*      */         
/* 1525 */         EntityAITasks.EntityAITaskEntry entry = iterator.next();
/*      */         
/* 1527 */         if (entry.field_75733_a == rangedTask) {
/* 1528 */           rangedPriority = entry.field_75731_b;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1532 */       mob.field_70714_bg.func_85156_a(rangedTask);
/*      */     } 
/*      */     
/* 1535 */     if (meleeTask != null) {
/* 1536 */       while (iterator.hasNext()) {
/*      */         
/* 1538 */         EntityAITasks.EntityAITaskEntry entry = iterator.next();
/*      */         
/* 1540 */         if (entry.field_75733_a == meleeTask) {
/* 1541 */           meleePriority = entry.field_75731_b;
/*      */           break;
/*      */         } 
/*      */       } 
/* 1545 */       mob.field_70714_bg.func_85156_a(meleeTask);
/*      */     } 
/*      */     
/* 1548 */     if (originalRangedAIs.containsKey(mob)) {
/* 1549 */       mob.field_70714_bg.func_75776_a(rangedPriority, originalRangedAIs.get(mob));
/*      */     }
/*      */     
/* 1552 */     if (originalMeleeAIs.containsKey(mob)) {
/* 1553 */       mob.field_70714_bg.func_75776_a(meleePriority, originalMeleeAIs.get(mob));
/* 1554 */       originalMeleeAIs.remove(mob);
/*      */     } 
/*      */     
/* 1557 */     rangedAIs.remove(mob);
/* 1558 */     meleeAIs.remove(mob);
/* 1559 */     originalRangedAIs.remove(mob);
/* 1560 */     originalMeleeAIs.remove(mob);
/* 1561 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removed bow task from mob '" + mob + "'."); 
/*      */   }
/*      */   
/*      */   public static void generateLoot(String type, IInventory inventory) {
/*      */     try {
/* 1566 */       if (chestTypes.contains(type)) {
/* 1567 */         int count = ChestGenHooks.getCount(type, rand);
/* 1568 */         if (count == 0) {
/* 1569 */           ItemStack itemToGenerate = ChestGenHooks.getOneItem(type, rand);
/* 1570 */           inventory.func_70299_a(0, itemToGenerate);
/*      */         } else {
/*      */           
/* 1573 */           WeightedRandomChestContent.func_177630_a(rand, ChestGenHooks.getItems(type, rand), inventory, count);
/*      */         }
/*      */       
/*      */       } 
/* 1577 */     } catch (Exception e) {
/* 1578 */       FMLLog.warning("[Loot++] Caught an exception while generating chest loot.", new Object[0]);
/* 1579 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */