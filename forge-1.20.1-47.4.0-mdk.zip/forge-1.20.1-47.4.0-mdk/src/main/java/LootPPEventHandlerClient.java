/*    */ package com.tmtravlr.lootplusplus;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.additions.ItemAddedBow;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraftforge.client.event.FOVUpdateEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LootPPEventHandlerClient
/*    */ {
/*    */   @SubscribeEvent
/*    */   public void onFOVUpdate(FOVUpdateEvent event) {
/* 21 */     EntityPlayer player = event.entity;
/*    */     
/* 23 */     if (player.func_71039_bw() && player.func_71011_bu().func_77973_b() instanceof ItemAddedBow) {
/*    */       
/* 25 */       ItemAddedBow bow = (ItemAddedBow)player.func_71011_bu().func_77973_b();
/*    */       
/* 27 */       int i = player.func_71057_bx();
/* 28 */       float f1 = i / bow.getDrawTime(player.func_71011_bu());
/*    */       
/* 30 */       if (f1 > 1.0F) {
/*    */         
/* 32 */         f1 = 1.0F;
/*    */       }
/*    */       else {
/*    */         
/* 36 */         f1 *= f1;
/*    */       } 
/*    */       
/* 39 */       event.newfov *= 1.0F - f1 * 0.15F;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPEventHandlerClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */