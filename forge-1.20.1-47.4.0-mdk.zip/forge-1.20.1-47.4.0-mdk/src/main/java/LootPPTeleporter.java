/*     */ package com.tmtravlr.lootplusplus;
/*     */ 
/*     */ import java.util.EnumSet;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.player.EntityPlayerMP;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.server.S07PacketRespawn;
/*     */ import net.minecraft.network.play.server.S12PacketEntityVelocity;
/*     */ import net.minecraft.network.play.server.S1DPacketEntityEffect;
/*     */ import net.minecraft.network.play.server.S1FPacketSetExperience;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.Teleporter;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraft.world.WorldProvider;
/*     */ import net.minecraft.world.WorldServer;
/*     */ import net.minecraftforge.fml.common.FMLCommonHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LootPPTeleporter
/*     */   extends Teleporter
/*     */ {
/*     */   private WorldServer worldServer;
/*     */   private double x;
/*     */   private double y;
/*     */   private double z;
/*     */   private float pitch;
/*     */   private float yaw;
/*     */   private double motionX;
/*     */   private double motionY;
/*     */   private double motionZ;
/*     */   
/*     */   public LootPPTeleporter(WorldServer worldServerOld, double xToSet, double yToSet, double zToSet, float pitchToSet, float yawToSet, double motionXToSet, double motionYToSet, double motionZToSet) {
/*  47 */     super(worldServerOld);
/*  48 */     this.worldServer = worldServerOld;
/*  49 */     this.x = xToSet;
/*  50 */     this.y = yToSet;
/*  51 */     this.z = zToSet;
/*  52 */     this.pitch = pitchToSet;
/*  53 */     this.yaw = yawToSet;
/*  54 */     this.motionX = motionXToSet;
/*  55 */     this.motionY = motionYToSet;
/*  56 */     this.motionZ = motionZToSet;
/*     */   }
/*     */   
/*     */   public LootPPTeleporter(WorldServer worldServerOld, double xToSet, double yToSet, double zToSet, float pitchToSet, float yawToSet) {
/*  60 */     this(worldServerOld, xToSet, yToSet, zToSet, pitchToSet, yawToSet, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180266_a(Entity entity, float par8) {
/*  65 */     entity.func_70012_b(this.x, this.y, this.z, this.yaw, this.pitch);
/*  66 */     entity.func_70034_d(this.yaw);
/*  67 */     entity.field_70159_w = this.motionX;
/*  68 */     entity.field_70181_x = this.motionY;
/*  69 */     entity.field_70179_y = this.motionZ;
/*     */     
/*  71 */     if (entity instanceof EntityPlayerMP) {
/*  72 */       EntityPlayerMP player = (EntityPlayerMP)entity;
/*  73 */       player.field_71135_a.func_147359_a((Packet)new S12PacketEntityVelocity((Entity)player));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void teleportEntity(Entity entity, World newWorld, double x, double y, double z) {
/*  81 */     teleportEntity(entity, newWorld, x, y, z, entity.field_70125_A, entity.field_70177_z, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void teleportEntity(Entity entity, World newWorld, double x, double y, double z, float pitch, float yaw) {
/*  86 */     teleportEntity(entity, newWorld, x, y, z, pitch, yaw, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Entity teleportEntity(Entity entity, World newWorld, double x, double y, double z, float pitch, float yaw, double motionX, double motionY, double motionZ) {
/*  91 */     int dimension = newWorld.field_73011_w.func_177502_q();
/*  92 */     int currentDimension = entity.field_70170_p.field_73011_w.func_177502_q();
/*  93 */     if (dimension != currentDimension)
/*     */     {
/*  95 */       return transferEntityToDimension(entity, dimension, x, y, z, pitch, yaw, motionX, motionY, motionZ);
/*     */     }
/*     */     
/*  98 */     entity.func_70012_b(x, y, z, yaw, pitch);
/*  99 */     entity.func_70034_d(yaw);
/* 100 */     entity.field_70159_w = motionX;
/* 101 */     entity.field_70181_x = motionY;
/* 102 */     entity.field_70179_y = motionZ;
/*     */     
/* 104 */     return entity;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void teleportPlayer(EntityPlayerMP player, EnumSet packetSet, World newWorld, double x, double y, double z) {
/* 109 */     teleportPlayer(player, packetSet, newWorld, x, y, z, player.field_70125_A, player.field_70177_z, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void teleportPlayer(EntityPlayerMP player, EnumSet packetSet, World newWorld, double x, double y, double z, float pitch, float yaw) {
/* 114 */     teleportPlayer(player, packetSet, newWorld, x, y, z, pitch, yaw, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void teleportPlayer(EntityPlayerMP player, EnumSet packetSet, World newWorld, double x, double y, double z, float pitch, float yaw, double motionX, double motionY, double motionZ) {
/* 120 */     int dimension = newWorld.field_73011_w.func_177502_q();
/* 121 */     int currentDimension = player.field_70170_p.field_73011_w.func_177502_q();
/* 122 */     if (currentDimension != dimension) {
/*     */       
/* 124 */       if (!newWorld.field_72995_K) {
/* 125 */         if (currentDimension != 1) {
/* 126 */           player.field_71133_b.func_71203_ab().transferPlayerToDimension(player, dimension, new LootPPTeleporter(player.field_71133_b.func_71218_a(dimension), x, y, z, pitch, yaw, motionX, motionY, motionZ));
/*     */         } else {
/* 128 */           forceTeleportPlayerFromEnd(player, dimension, new LootPPTeleporter(player.field_71133_b.func_71218_a(dimension), x, y, z, pitch, yaw, motionX, motionY, motionZ));
/*     */         } 
/* 130 */         player.field_71135_a.func_147359_a((Packet)new S1FPacketSetExperience(player.field_71106_cc, player.field_71067_cb, player.field_71068_ca));
/*     */       } 
/*     */     } else {
/*     */       
/* 134 */       if (packetSet != null) {
/* 135 */         player.field_71135_a.func_175089_a(x, y, z, yaw, pitch, packetSet);
/*     */       } else {
/*     */         
/* 138 */         player.field_71135_a.func_147364_a(x, y, z, yaw, pitch);
/*     */       } 
/* 140 */       player.func_70034_d(yaw);
/* 141 */       player.field_70159_w = motionX;
/* 142 */       player.field_70181_x = motionY;
/* 143 */       player.field_70179_y = motionZ;
/* 144 */       player.field_71135_a.func_147359_a((Packet)new S12PacketEntityVelocity((Entity)player));
/*     */       
/* 146 */       newWorld.func_72866_a((Entity)player, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void forceTeleportPlayerFromEnd(EntityPlayerMP player, int newDimension, Teleporter colourfulTeleporter) {
/* 154 */     int j = player.field_71093_bK;
/* 155 */     WorldServer worldServerOld = player.field_71133_b.func_71218_a(player.field_71093_bK);
/* 156 */     player.field_71093_bK = newDimension;
/* 157 */     WorldServer worldServerNew = player.field_71133_b.func_71218_a(player.field_71093_bK);
/* 158 */     player.field_71135_a.func_147359_a((Packet)new S07PacketRespawn(player.field_71093_bK, player.field_70170_p.func_175659_aa(), player.field_70170_p.func_72912_H().func_76067_t(), player.field_71134_c.func_73081_b()));
/* 159 */     worldServerOld.func_72973_f((Entity)player);
/* 160 */     player.field_70128_L = false;
/*     */     
/* 162 */     WorldProvider pOld = worldServerOld.field_73011_w;
/* 163 */     WorldProvider pNew = worldServerNew.field_73011_w;
/* 164 */     double moveFactor = pOld.getMovementFactor() / pNew.getMovementFactor();
/* 165 */     double d0 = player.field_70165_t * moveFactor;
/* 166 */     double d1 = player.field_70161_v * moveFactor;
/* 167 */     float f = player.field_70177_z;
/*     */     
/* 169 */     worldServerOld.field_72984_F.func_76320_a("placing");
/* 170 */     d0 = MathHelper.func_76125_a((int)d0, -29999872, 29999872);
/* 171 */     d1 = MathHelper.func_76125_a((int)d1, -29999872, 29999872);
/* 172 */     if (player.func_70089_S()) {
/*     */       
/* 174 */       player.func_70012_b(d0, player.field_70163_u, d1, player.field_70177_z, player.field_70125_A);
/* 175 */       colourfulTeleporter.func_180266_a((Entity)player, f);
/* 176 */       worldServerNew.func_72838_d((Entity)player);
/* 177 */       worldServerNew.func_72866_a((Entity)player, false);
/*     */     } 
/* 179 */     worldServerOld.field_72984_F.func_76319_b();
/*     */     
/* 181 */     player.func_70029_a((World)worldServerNew);
/*     */     
/* 183 */     player.field_71133_b.func_71203_ab().func_72375_a(player, worldServerOld);
/* 184 */     player.field_71135_a.func_147364_a(player.field_70165_t, player.field_70163_u, player.field_70161_v, player.field_70177_z, player.field_70125_A);
/* 185 */     player.field_71134_c.func_73080_a(worldServerNew);
/* 186 */     player.field_71133_b.func_71203_ab().func_72354_b(player, worldServerNew);
/* 187 */     player.field_71133_b.func_71203_ab().func_72385_f(player);
/* 188 */     Iterator<PotionEffect> iterator = player.func_70651_bq().iterator();
/* 189 */     while (iterator.hasNext()) {
/*     */       
/* 191 */       PotionEffect potioneffect = iterator.next();
/* 192 */       player.field_71135_a.func_147359_a((Packet)new S1DPacketEntityEffect(player.func_145782_y(), potioneffect));
/*     */     } 
/* 194 */     FMLCommonHandler.instance().firePlayerChangedDimensionEvent((EntityPlayer)player, j, newDimension);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static Entity transferEntityToDimension(Entity toTeleport, int newDimension, double x, double y, double z, float pitch, float yaw, double motionX, double motionY, double motionZ) {
/* 200 */     if (!toTeleport.field_70128_L) {
/*     */       
/* 202 */       toTeleport.field_70170_p.field_72984_F.func_76320_a("changeDimension");
/* 203 */       MinecraftServer minecraftserver = MinecraftServer.func_71276_C();
/* 204 */       int oldDimension = toTeleport.field_71093_bK;
/* 205 */       WorldServer worldServerOld = minecraftserver.func_71218_a(oldDimension);
/* 206 */       WorldServer worldServerNew = minecraftserver.func_71218_a(newDimension);
/* 207 */       toTeleport.field_71093_bK = newDimension;
/*     */       
/* 209 */       toTeleport.field_70170_p.func_72900_e(toTeleport);
/* 210 */       toTeleport.field_70128_L = false;
/* 211 */       toTeleport.field_70170_p.field_72984_F.func_76320_a("reposition");
/* 212 */       if (oldDimension == 1) {
/* 213 */         forceTeleportEntityFromEnd(toTeleport, newDimension, new LootPPTeleporter(worldServerOld, x, y, z, pitch, yaw, motionX, motionY, motionZ), worldServerNew);
/*     */       } else {
/* 215 */         minecraftserver.func_71203_ab().transferEntityToWorld(toTeleport, oldDimension, worldServerOld, worldServerNew, new LootPPTeleporter(worldServerOld, x, y, z, pitch, yaw, motionX, motionY, motionZ));
/*     */       } 
/* 217 */       toTeleport.field_70170_p.field_72984_F.func_76318_c("reloading");
/* 218 */       Entity entity = EntityList.func_75620_a(EntityList.func_75621_b(toTeleport), (World)worldServerNew);
/* 219 */       if (entity != null) {
/*     */         
/* 221 */         entity.func_180432_n(toTeleport);
/* 222 */         worldServerNew.func_72838_d(entity);
/*     */       } 
/* 224 */       toTeleport.field_70128_L = true;
/* 225 */       toTeleport.field_70170_p.field_72984_F.func_76319_b();
/* 226 */       worldServerOld.func_82742_i();
/* 227 */       worldServerNew.func_82742_i();
/* 228 */       toTeleport.field_70170_p.field_72984_F.func_76319_b();
/*     */       
/* 230 */       return entity;
/*     */     } 
/* 232 */     return toTeleport;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void forceTeleportEntityFromEnd(Entity entity, int newDimension, Teleporter teleporter, WorldServer worldServerNew) {
/* 237 */     worldServerNew.func_72838_d(entity);
/* 238 */     entity.func_70012_b(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, entity.field_70177_z, entity.field_70125_A);
/* 239 */     worldServerNew.func_72866_a(entity, false);
/* 240 */     teleporter.func_180266_a(entity, 0.0F);
/*     */     
/* 242 */     entity.func_70029_a((World)worldServerNew);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\LootPPTeleporter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */