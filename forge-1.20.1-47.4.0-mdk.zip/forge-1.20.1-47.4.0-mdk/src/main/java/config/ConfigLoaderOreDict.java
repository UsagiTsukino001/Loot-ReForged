/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderOreDict
/*     */   extends ConfigLoader
/*     */ {
/*  22 */   public static ConfigLoaderOreDict instance = new ConfigLoaderOreDict();
/*     */   
/*     */   ConfigLoaderOreDict() {
/*  25 */     this.namesToExtras.put("additions", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  29 */     return "ore_dictionary";
/*     */   }
/*     */   
/*     */   public void loadOreDict() {
/*  33 */     Configuration oreDictConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  35 */     oreDictConfig.load();
/*     */ 
/*     */     
/*  38 */     oreDictConfig.setCategoryComment("additions", "Add items to the ore dictionary in the following format:\n\n      <Ore Dictionary entry name>_____<Item name>_____<Item metadata (-1 for any)>\n\nFor instance, to add the default records to the 'record' category, you could write\nsomething like:\n\n      record_____lootplusplus:creative1_____-1\n\nfor each record.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     ArrayList<String> additions = ConfigExtrasLoader.combineLists(oreDictConfig.get("additions", "additions", new String[0]).getStringList(), this.namesToExtras.get("additions"));
/*     */     
/*  68 */     for (int index = 0; index < additions.size(); index++) {
/*  69 */       String addition = additions.get(index);
/*     */       
/*  71 */       boolean comment = false;
/*  72 */       String title = getFileName() + ".cfg 'additions' #" + (index + 1);
/*     */       
/*  74 */       if (addition.length() > 0) {
/*  75 */         comment = (addition.charAt(0) == '#');
/*     */       }
/*     */       
/*  78 */       String[] parts = addition.split("_____");
/*     */       
/*  80 */       if (parts.length != 3) {
/*  81 */         if (!addition.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, addition);
/*     */       
/*     */       } else {
/*     */         
/*  85 */         String type = parts[0];
/*  86 */         String itemName = parts[1];
/*  87 */         String metaString = parts[2];
/*     */         
/*  89 */         Object itemObj = Item.field_150901_e.func_82594_a(itemName);
/*     */         
/*  91 */         if (itemObj == null || !(itemObj instanceof Item)) {
/*  92 */           LootPPNotifier.notifyNonexistant(comment, title, itemName);
/*     */         }
/*     */         else {
/*     */           
/*  96 */           Item item = (Item)itemObj;
/*  97 */           int meta = 32767;
/*     */           
/*     */           try {
/* 100 */             meta = Integer.valueOf(metaString).intValue();
/*     */           }
/* 102 */           catch (NumberFormatException e) {
/* 103 */             if (!comment) {
/* 104 */               System.err.println("[Loot++] Caught exception while trying to add ore dictionary entry for " + itemName);
/* 105 */               e.printStackTrace();
/* 106 */               LootPPNotifier.notifyNumber(comment, title, metaString);
/*     */             } 
/*     */           } 
/*     */           
/* 110 */           OreDictionary.registerOre(type, new ItemStack(item, 1, (meta < 0) ? 32767 : meta));
/*     */         } 
/*     */       } 
/* 113 */     }  oreDictConfig.save();
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderOreDict.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */