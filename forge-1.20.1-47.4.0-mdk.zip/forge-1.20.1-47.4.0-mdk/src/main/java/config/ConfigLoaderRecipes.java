/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import com.tmtravlr.lootplusplus.recipes.LootPPFakeInventoryCrafting;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.inventory.InventoryCrafting;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.CraftingManager;
/*     */ import net.minecraft.item.crafting.IRecipe;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTException;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderRecipes
/*     */   extends ConfigLoader
/*     */ {
/*  41 */   public static ConfigLoaderRecipes instance = new ConfigLoaderRecipes();
/*     */   
/*     */   ConfigLoaderRecipes() {
/*  44 */     this.namesToExtras.put("removing", new ArrayList<String>());
/*  45 */     this.namesToExtras.put("add_shaped", new ArrayList<String>());
/*  46 */     this.namesToExtras.put("add_shapeless", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  50 */     return "recipes";
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadRecipes(World world) {
/*  55 */     Configuration recipeConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  57 */     recipeConfig.load();
/*     */     
/*  59 */     List<IRecipe> recipes = CraftingManager.func_77594_a().func_77592_b();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     recipeConfig.addCustomCategoryComment("removing", "To remove existing recipes, first add the item ID. This will remove every recipe with this item\nas the output. You can also optionally include a damage (metadata) value and nbt tag, in the format:\n\n      <item id>_____<metadata (optional)>_____<nbt tag (optional)>.\n\nIf you want to remove a specific recipe with that item as the output, after the nbt you can write the recipe\nin the format (Note you must include the output item's metadata and nbt if you want to specify the recipe!):\n\n      <output item id>_____<metadata (-1 for any)>_____<nbt tag ({} for any)>_____<recipe>_____<input items>...\n\nwhere the recipe is a set of characters that look like abc,def,ghi which represent crafting slots: \n\n      a  b  c\n      d  e  f\n      g  h  i\n\nand any space is interpereted as a blank spot, so a diamond axe could be represented as 'dd ,ds , s '\n\n      d  d  []\n      d  s  []\n      [] s  []\n\nWhere d represents diamond, s represents stick, and [] is an empty slot. To specify what items the\ncharacters represent, in the input items section, for each character, write an entry in the form:\n\n      ..._____<character>_____<item id>_____<metadata (-1 for any)>_____<nbt data ({} for any>_____...\n\n###############################################  Examples  #############################################\n- For a simple example, 'minecraft:diamond_helmet' will remove any recipes that give you a diamond helmet.\n- Writing 'minecraft:wool_____5' will get rid of all recipes that output lime wool.\n\nTo remove the recipe for torches that uses charcoal and keep the one that uses coal, you could write:\nminecraft:torch_____-1_____{}_____c,s_____c_____minecraft:coal_____1_____{}_____s_____minecraft:stick_____0_____{}\n\nNote the metadata for the coal is 1, which means charcoal, and the metadata for the stick is 0, not -1.\nIf you can't get a recipe to work, it might be good to play around with changing the metadata to 0 or -1.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     ArrayList<String> recipeList = ConfigExtrasLoader.combineLists(recipeConfig.get("removing", "Recipes to remove:", new String[0]).getStringList(), this.namesToExtras.get("removing"));
/*     */     int index;
/* 103 */     for (index = 0; index < recipeList.size(); index++) {
/* 104 */       String entry = recipeList.get(index);
/*     */       
/* 106 */       boolean comment = false;
/* 107 */       String title = getFileName() + ".cfg 'removing' #" + (index + 1);
/*     */       
/* 109 */       if (entry.length() > 0) {
/* 110 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/* 113 */       Item outputItem = null;
/* 114 */       int outputMeta = -1;
/* 115 */       String outputNBTString = "{}";
/*     */       
/* 117 */       String specificRecipe = "";
/* 118 */       HashMap<Character, ItemStack> recipeItems = new HashMap<Character, ItemStack>();
/*     */       
/*     */       try {
/* 121 */         String[] subEntries = entry.split("_____");
/*     */         
/* 123 */         if (entry.equals("")) {
/*     */           continue;
/*     */         }
/*     */         
/* 127 */         Object outputObj = Item.field_150901_e.func_82594_a(subEntries[0]);
/*     */         
/* 129 */         if (outputObj == null || !(outputObj instanceof Item)) {
/* 130 */           LootPPNotifier.notifyNonexistant(comment, title, subEntries[0]);
/*     */         }
/*     */         
/* 133 */         outputItem = (Item)outputObj;
/*     */ 
/*     */         
/* 136 */         if (subEntries.length > 1)
/*     */         {
/* 138 */           outputMeta = Integer.parseInt(subEntries[1]);
/*     */         }
/*     */         
/* 141 */         if (subEntries.length > 2)
/*     */         {
/* 143 */           outputNBTString = subEntries[2];
/*     */         }
/*     */         
/* 146 */         if (subEntries.length > 3) {
/*     */ 
/*     */           
/* 149 */           specificRecipe = subEntries[3];
/*     */           
/* 151 */           for (int i = 4; i + 3 < subEntries.length; i += 4) {
/* 152 */             char character = subEntries[i].charAt(0);
/*     */             
/* 154 */             Object itemObj = Item.field_150901_e.func_82594_a(subEntries[i + 1]);
/*     */             
/* 156 */             if (itemObj == null || !(itemObj instanceof Item)) {
/* 157 */               LootPPNotifier.notifyNonexistant(comment, title, subEntries[i + 1]);
/*     */             }
/*     */             else {
/*     */               
/* 161 */               Item item = (Item)itemObj;
/*     */               
/* 163 */               int itemMeta = Integer.parseInt(subEntries[i + 2]);
/* 164 */               NBTTagCompound tag = null;
/*     */               
/* 166 */               if (!subEntries[i + 3].isEmpty() && !subEntries[i + 3].equals("{}")) {
/*     */                 try {
/* 168 */                   NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(subEntries[i + 3]);
/*     */                   
/* 170 */                   if (nBTTagCompound != null) {
/* 171 */                     tag = nBTTagCompound;
/*     */                   }
/*     */                 }
/* 174 */                 catch (NBTException e) {
/* 175 */                   if (!comment) {
/* 176 */                     e.printStackTrace();
/* 177 */                     LootPPNotifier.notifyNBT(comment, title, subEntries[i + 3], e.getMessage());
/*     */                   } 
/* 179 */                   tag = null;
/*     */                 } 
/*     */               }
/*     */ 
/*     */               
/* 184 */               ItemStack stack = new ItemStack(item, 1, (itemMeta == -1) ? 32767 : itemMeta);
/*     */               
/* 186 */               if (tag != null) {
/* 187 */                 stack.func_77982_d(tag);
/*     */               }
/*     */               
/* 190 */               recipeItems.put(Character.valueOf(character), stack);
/*     */             }
/*     */           
/*     */           }
/*     */         
/*     */         } 
/* 196 */       } catch (Exception e) {
/* 197 */         if (!comment) {
/* 198 */           System.out.println("[Loot++] Encountered an exception while loading in a recipe to remove!");
/* 199 */           e.printStackTrace();
/* 200 */           LootPPNotifier.notify(comment, title, "=( Unexpected problem '" + e.getMessage() + "' while loading a recipe to remove: " + entry);
/*     */         } 
/*     */       } 
/*     */       
/* 204 */       if (outputItem != null) {
/* 205 */         List currentRecipes = CraftingManager.func_77594_a().func_77592_b();
/*     */         
/* 207 */         NBTTagCompound outputNBT = null;
/* 208 */         if (outputNBTString != null && !outputNBTString.equals("") && !outputNBTString.equals("{}")) {
/*     */           try {
/* 210 */             NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(outputNBTString);
/*     */             
/* 212 */             if (nBTTagCompound != null) {
/* 213 */               outputNBT = nBTTagCompound;
/*     */             }
/*     */           }
/* 216 */           catch (NBTException e) {
/* 217 */             if (!comment) {
/* 218 */               LootPPNotifier.notifyNBT(comment, title, outputNBTString, e.getMessage());
/* 219 */               e.printStackTrace();
/*     */             } 
/* 221 */             outputNBT = null;
/*     */           } 
/*     */         }
/*     */         
/* 225 */         int count = 0;
/* 226 */         Iterator it = currentRecipes.iterator();
/* 227 */         while (it.hasNext()) {
/* 228 */           Object obj = it.next();
/*     */           try {
/* 230 */             ItemStack recipeOutput = null;
/*     */             
/* 232 */             if (obj instanceof IRecipe && !(obj instanceof net.minecraft.item.crafting.RecipesMapExtending) && !(obj instanceof net.minecraft.item.crafting.RecipeFireworks)) {
/* 233 */               IRecipe recipe = (IRecipe)obj;
/*     */ 
/*     */               
/* 236 */               if (specificRecipe != null && !specificRecipe.equals("")) {
/*     */                 
/* 238 */                 LootPPFakeInventoryCrafting lootPPFakeInventoryCrafting = new LootPPFakeInventoryCrafting(3);
/*     */                 
/* 240 */                 String[] craftingParts = specificRecipe.split(",");
/*     */                 
/* 242 */                 for (int i = 0; i < craftingParts.length && i < 3; i++) {
/* 243 */                   for (int j = 0; j < craftingParts[i].length() && j < 3; j++) {
/* 244 */                     ItemStack toSet = null;
/* 245 */                     if (craftingParts[i].charAt(j) != ' ' && recipeItems.containsKey(Character.valueOf(craftingParts[i].charAt(j)))) {
/* 246 */                       toSet = recipeItems.get(Character.valueOf(craftingParts[i].charAt(j)));
/*     */                     }
/* 248 */                     lootPPFakeInventoryCrafting.func_70299_a(i * 3 + j, toSet);
/*     */                   } 
/*     */                 } 
/* 251 */                 if (recipe.func_77569_a((InventoryCrafting)lootPPFakeInventoryCrafting, world)) {
/* 252 */                   recipeOutput = recipe.func_77572_b((InventoryCrafting)lootPPFakeInventoryCrafting);
/*     */                 }
/*     */               } else {
/*     */                 
/* 256 */                 recipeOutput = recipe.func_77571_b();
/*     */               } 
/*     */               
/* 259 */               if (recipeOutput != null && recipeOutput.func_77973_b() == outputItem && (
/* 260 */                 outputMeta == -1 || recipeOutput.func_77952_i() == outputMeta) && (
/* 261 */                 outputNBT == null || recipeOutput.func_77978_p() == null || outputNBT.equals(recipeOutput.func_77978_p()))) {
/* 262 */                 if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removing Recipe " + recipe + " giving item " + recipeOutput); 
/* 263 */                 count++;
/* 264 */                 it.remove();
/*     */               
/*     */               }
/*     */             
/*     */             }
/*     */           
/*     */           }
/* 271 */           catch (Exception e) {
/* 272 */             if (!comment) {
/* 273 */               System.err.println("[Loot++] Caught an exception while trying to remove a crafting recipe.");
/* 274 */               e.printStackTrace();
/* 275 */               LootPPNotifier.notify(comment, title, "=( Unexpected problem '" + e.getMessage() + "' while removing a recipe: " + entry);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 280 */         if (count == 0) {
/* 281 */           if (specificRecipe != null && !specificRecipe.equals("")) {
/* 282 */             LootPPNotifier.notify(comment, title, "Couldn't find a recipe that matched '" + specificRecipe + "'.");
/*     */           } else {
/*     */             
/* 285 */             LootPPNotifier.notify(comment, title, "Couldn't find a recipe with object '" + Item.field_150901_e.func_177774_c(outputItem) + "' as the output.");
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/*     */       continue;
/*     */     } 
/* 292 */     recipeConfig.addCustomCategoryComment("add_shaped", "Add each recipe on a new line in the following format: \n      <output item id>_____<amount>_____<metadata>_____<nbt tag ({} for blank)>_____<recipe>_____<input items>...\n\nWhere the recipe is a set of characters that look like abc,def,ghi which represent crafting slots: \n\n      a  b  c\n      d  e  f\n      g  h  i\n\nand any space is interpereted as a blank spot, so a diamond axe could be represented as 'dd ,ds , s '\n\n      d  d  []\n      d  s  []\n      [] s  []\n\nWhere d represents diamond, s represents stick, and [] is an empty slot. To specify what items the\ncharacters represent, in the input items section, for each character, write an entry in the form:\n\n      ..._____<character>_____<item id>_____<metadata (-1 for any)>_____<nbt data ({} for any>_____...\n\nIf you want to add an ore dictionary entry, put the string in quotes in place of the item id,\nso for instance: \n\n      ..._____s_____\"stickWood\"_____-1_____{}_____... \n\n###############################################  Examples  #############################################\nFor example, if you wanted to add a recipe for a diamond axe that used sugar cane instead of sticks,\nyou could write:\n\n      minecraft:diamond_axe_____1_____0_____{}_____dd,ds, s_____d_____minecraft:diamond_____0_____{}_____s_____minecraft:reeds_____0_____{}\n\nAnd if you wanted to add a recipe to add feather falling to diamond boots using feathers, you could write:\n\n      minecraft:diamond_boots_____1_____0_____{ench:[{id:2,lvl:1}]}_____fff,fdf,fff_____d_____minecraft:diamond_boots_____0_____{}_____f_____minecraft:feather_____0_____{}\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 327 */     recipeList = ConfigExtrasLoader.combineLists(recipeConfig.get("add_shaped", "Recipes to add:", new String[0]).getStringList(), this.namesToExtras.get("add_shaped"));
/*     */     
/* 329 */     for (index = 0; index < recipeList.size(); index++) {
/* 330 */       String entry = recipeList.get(index);
/*     */       
/* 332 */       boolean comment = false;
/* 333 */       String title = getFileName() + ".cfg 'add_shaped' #" + (index + 1);
/*     */       
/* 335 */       if (entry.length() > 0) {
/* 336 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/* 339 */       Item outputItem = null;
/* 340 */       int outputMeta = 0;
/* 341 */       int outputAmount = 1;
/* 342 */       String outputNBTString = "{}";
/* 343 */       boolean isOreRecipe = false;
/* 344 */       String recipeString = "";
/* 345 */       HashMap<Character, Object> recipeItems = new HashMap<Character, Object>();
/*     */       
/*     */       try {
/* 348 */         String[] subEntries = entry.split("_____");
/*     */         
/* 350 */         if (subEntries.length < 8) {
/* 351 */           if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */           
/*     */           continue;
/*     */         } 
/* 355 */         String outputItemName = subEntries[0];
/* 356 */         String amountString = subEntries[1];
/* 357 */         String metaString = subEntries[2];
/* 358 */         outputNBTString = subEntries[3];
/* 359 */         recipeString = subEntries[4];
/*     */         
/* 361 */         Object outputObj = Item.field_150901_e.func_82594_a(subEntries[0]);
/*     */         
/* 363 */         if (outputObj == null || !(outputObj instanceof Item)) {
/* 364 */           LootPPNotifier.notifyNonexistant(comment, title, subEntries[0]);
/*     */           
/*     */           continue;
/*     */         } 
/* 368 */         outputItem = (Item)outputObj;
/*     */         
/*     */         try {
/* 371 */           outputAmount = Integer.parseInt(amountString);
/* 372 */           outputMeta = Integer.parseInt(metaString);
/*     */         }
/* 374 */         catch (NumberFormatException e) {
/* 375 */           if (!comment) {
/* 376 */             e.printStackTrace();
/* 377 */             LootPPNotifier.notifyNumber(comment, title, new String[] { amountString, metaString });
/*     */             
/*     */             continue;
/*     */           } 
/*     */         } 
/* 382 */         boolean valid = true;
/*     */         
/* 384 */         for (int i = 5; i + 3 < subEntries.length; i += 4) {
/* 385 */           char character = subEntries[i].charAt(0);
/*     */           
/* 387 */           Object itemObj = null;
/* 388 */           boolean oreEntry = false;
/*     */ 
/*     */ 
/*     */           
/* 392 */           if (subEntries[i + 1].charAt(0) == '"') {
/*     */             
/* 394 */             recipeItems.put(Character.valueOf(character), subEntries[i + 1].substring(1, subEntries[i + 1].length() - 1));
/*     */             
/* 396 */             isOreRecipe = true;
/*     */           } else {
/*     */             
/* 399 */             itemObj = Item.field_150901_e.func_82594_a(subEntries[i + 1]);
/*     */           } 
/*     */           
/* 402 */           if (itemObj != null && itemObj instanceof Item) {
/* 403 */             Item item = (Item)itemObj;
/*     */             
/* 405 */             int itemMeta = Integer.parseInt(subEntries[i + 2]);
/* 406 */             NBTTagCompound nBTTagCompound = null;
/*     */             
/*     */             try {
/* 409 */               NBTTagCompound nBTTagCompound1 = JsonToNBT.func_180713_a(subEntries[i + 3]);
/*     */               
/* 411 */               if (nBTTagCompound1 != null) {
/* 412 */                 nBTTagCompound = nBTTagCompound1;
/*     */               }
/*     */             }
/* 415 */             catch (NBTException e) {
/* 416 */               if (!comment) {
/* 417 */                 e.printStackTrace();
/* 418 */                 LootPPNotifier.notifyNBT(comment, title, subEntries[i + 3], e.getMessage());
/* 419 */                 valid = false;
/*     */               } 
/* 421 */               nBTTagCompound = null;
/*     */             } 
/*     */ 
/*     */             
/* 425 */             ItemStack stack = new ItemStack(item, 1, (itemMeta < 0) ? 32767 : itemMeta);
/*     */             
/* 427 */             if (nBTTagCompound != null) {
/* 428 */               stack.func_77982_d(nBTTagCompound);
/*     */             }
/*     */             
/* 431 */             recipeItems.put(Character.valueOf(character), stack);
/*     */           
/*     */           }
/* 434 */           else if (subEntries[i + 1].charAt(0) != '"') {
/* 435 */             LootPPNotifier.notifyNonexistant(comment, title, subEntries[i + 1]);
/* 436 */             valid = false;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 441 */         if (!valid) {
/*     */           continue;
/*     */         }
/*     */         
/* 445 */         ItemStack outputStack = new ItemStack(outputItem, outputAmount, outputMeta);
/*     */         
/* 447 */         ArrayList<Object> recipe = new ArrayList();
/*     */ 
/*     */         
/* 450 */         recipe.addAll(Arrays.asList((Object[])recipeString.split(",")));
/*     */ 
/*     */         
/* 453 */         for (Iterator<Character> iterator = recipeItems.keySet().iterator(); iterator.hasNext(); ) { char charId = ((Character)iterator.next()).charValue();
/* 454 */           recipe.add(Character.valueOf(charId));
/* 455 */           recipe.add(recipeItems.get(Character.valueOf(charId))); }
/*     */ 
/*     */         
/* 458 */         NBTTagCompound tag = null;
/*     */         
/* 460 */         if (outputNBTString != null && !outputNBTString.equals("{}") && !outputNBTString.equals(""))
/*     */           
/* 462 */           try { NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(outputNBTString);
/*     */             
/* 464 */             if (nBTTagCompound != null) {
/* 465 */               tag = nBTTagCompound;
/*     */             } }
/*     */           
/* 468 */           catch (NBTException e)
/* 469 */           { if (!comment)
/* 470 */             { e.printStackTrace();
/* 471 */               LootPPNotifier.notifyNBT(comment, title, outputNBTString, e.getMessage()); }
/*     */             else
/*     */             
/* 474 */             { tag = null;
/*     */ 
/*     */ 
/*     */               
/* 478 */               if (tag != null)
/* 479 */                 outputStack.func_77982_d(tag);  }  }   if (tag != null) outputStack.func_77982_d(tag);
/*     */ 
/*     */ 
/*     */         
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 489 */       catch (Exception e) {
/* 490 */         if (!comment) {
/* 491 */           System.err.println("[Loot++] Caught an exception while trying to add a recipe!");
/* 492 */           e.printStackTrace();
/* 493 */           LootPPNotifier.notify(comment, title, "=( Unexpected problem '" + e.getMessage() + "' while adding a shaped recipe: '" + entry + "'.");
/*     */         } 
/*     */         continue;
/*     */       } 
/*     */     } 
/* 498 */     recipeConfig.addCustomCategoryComment("add_shapeless", "Add each shapeless recipe on a new line in the following format: \n      <output item id>_____<amount>_____<metadata>_____<nbt tag ({} for blank)>_____<input items (up to 9)>...\n\nwhere the input items are in the format:\n\n      ..._____<item id>_____<metadata (-1 for any)>_____<nbt data ({} for any>_____...\n\nIf you want to add an ore dictionary entry, put the string in quotes in place of the item id,\nso for instance \n\n      ..._____\"woodStick\"_____-1_____{}_____... \n\n###############################################  Examples  #############################################\nFor example, if you want to add a recipe for mushroom stew that requires a water bucket, you could write:\n\n      minecraft:mushroom_stew_____1_____0_____{}_____minecraft:red_mushroom_____0_____{}_____minecraft:brown_mushroom_____0_____{}_____minecraft:bowl_____0_____{}_____minecraft:water_bucket_____0_____{}\n\nNote that you will get the bucket back, since it's the container item for the water bucket.\nIf you wanted to add a recipe to add sharpness to a diamond sword using a cactus, you could write:\n\n      minecraft:diamond_sword_____1_____0_____{ench:[{id:16,lvl:1}]}_____minecraft:diamond_sword_____0_____{}_____minecraft:cactus_____0_____{}\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 520 */     recipeList = ConfigExtrasLoader.combineLists(recipeConfig.get("add_shapeless", "Recipes to add:", new String[0]).getStringList(), this.namesToExtras.get("add_shapeless"));
/*     */     
/* 522 */     for (index = 0; index < recipeList.size(); index++) {
/* 523 */       String entry = recipeList.get(index);
/*     */       
/* 525 */       boolean comment = false;
/* 526 */       String title = getFileName() + ".cfg 'add_shapeless' #" + (index + 1);
/*     */       
/* 528 */       if (entry.length() > 0) {
/* 529 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/* 532 */       Item outputItem = null;
/* 533 */       int outputMeta = -1;
/* 534 */       int outputAmount = 1;
/* 535 */       String outputNBTString = "{}";
/* 536 */       boolean isOreRecipe = false;
/* 537 */       ArrayList<Object> recipeItems = new ArrayList();
/*     */       
/*     */       try {
/* 540 */         String[] subEntries = entry.split("_____");
/*     */         
/* 542 */         if (subEntries.length < 7) {
/* 543 */           if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */           
/*     */           continue;
/*     */         } 
/* 547 */         Object outputObj = Item.field_150901_e.func_82594_a(subEntries[0]);
/*     */         
/* 549 */         if (outputObj == null || !(outputObj instanceof Item)) {
/* 550 */           LootPPNotifier.notifyNonexistant(comment, title, subEntries[0]);
/*     */           
/*     */           continue;
/*     */         } 
/* 554 */         outputItem = (Item)outputObj;
/*     */         
/* 556 */         outputAmount = Integer.parseInt(subEntries[1]);
/* 557 */         outputMeta = Integer.parseInt(subEntries[2]);
/* 558 */         outputNBTString = subEntries[3];
/* 559 */         boolean valid = true;
/*     */         
/* 561 */         for (int i = 4; i + 2 < subEntries.length && i < 32; i += 3) {
/* 562 */           Object itemObj = null;
/* 563 */           boolean oreEntry = false;
/*     */           
/* 565 */           if (subEntries[i].charAt(0) == '"') {
/* 566 */             recipeItems.add(subEntries[i].substring(1, subEntries[i].length() - 1));
/*     */             
/* 568 */             isOreRecipe = true;
/*     */           } else {
/*     */             
/* 571 */             itemObj = Item.field_150901_e.func_82594_a(subEntries[i]);
/*     */           } 
/*     */           
/* 574 */           if (itemObj != null && itemObj instanceof Item) {
/* 575 */             Item item = (Item)itemObj;
/*     */             
/* 577 */             int itemMeta = Integer.parseInt(subEntries[i + 1]);
/* 578 */             NBTTagCompound nBTTagCompound = null;
/*     */             
/*     */             try {
/* 581 */               NBTTagCompound nBTTagCompound1 = JsonToNBT.func_180713_a(subEntries[i + 2]);
/*     */               
/* 583 */               if (nBTTagCompound1 != null) {
/* 584 */                 nBTTagCompound = nBTTagCompound1;
/*     */               }
/*     */             }
/* 587 */             catch (NBTException e) {
/* 588 */               if (!comment) {
/* 589 */                 LootPPNotifier.notifyNBT(comment, title, subEntries[i + 2], e.getMessage());
/* 590 */                 valid = false;
/* 591 */                 e.printStackTrace();
/*     */               } 
/* 593 */               nBTTagCompound = null;
/*     */             } 
/*     */ 
/*     */             
/* 597 */             ItemStack stack = new ItemStack(item, 1, (itemMeta == -1) ? 32767 : itemMeta);
/*     */             
/* 599 */             if (nBTTagCompound != null) {
/* 600 */               stack.func_77982_d(nBTTagCompound);
/*     */             }
/*     */             
/* 603 */             recipeItems.add(stack);
/*     */           
/*     */           }
/* 606 */           else if (subEntries[i].charAt(0) != '"') {
/* 607 */             LootPPNotifier.notifyNonexistant(comment, title, subEntries[i + 1]);
/* 608 */             valid = false;
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 613 */         if (!valid) {
/*     */           continue;
/*     */         }
/*     */         
/* 617 */         ItemStack outputStack = new ItemStack(outputItem, outputAmount, outputMeta);
/*     */         
/* 619 */         NBTTagCompound tag = null;
/*     */         
/* 621 */         if (outputNBTString != null && !outputNBTString.equals("{}") && !outputNBTString.equals(""))
/*     */           
/* 623 */           try { NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(outputNBTString);
/*     */             
/* 625 */             if (nBTTagCompound != null) {
/* 626 */               tag = nBTTagCompound;
/*     */             } }
/*     */           
/* 629 */           catch (NBTException e)
/* 630 */           { if (!comment)
/* 631 */             { LootPPNotifier.notifyNBT(comment, title, outputNBTString, e.getMessage());
/* 632 */               e.printStackTrace(); }
/*     */             else
/*     */             
/* 635 */             { tag = null;
/*     */ 
/*     */ 
/*     */               
/* 639 */               if (tag != null)
/* 640 */                 outputStack.func_77982_d(tag);  }  }   if (tag != null) outputStack.func_77982_d(tag);
/*     */ 
/*     */ 
/*     */         
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 650 */       catch (Exception e) {
/* 651 */         if (!comment) {
/* 652 */           System.err.println("[Loot++] Caught an exception while trying to add a recipe!");
/* 653 */           e.printStackTrace();
/* 654 */           LootPPNotifier.notify(comment, title, "=( Unexpected problem '" + e.getMessage() + "' while adding a shapeless recipe: '" + entry + "'.");
/*     */         } 
/*     */         continue;
/*     */       } 
/*     */     } 
/* 659 */     recipeConfig.save();
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderRecipes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */