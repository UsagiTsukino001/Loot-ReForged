/*    */ package com.tmtravlr.lootplusplus.config;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraftforge.common.config.Configuration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigLoaderStackSize
/*    */   extends ConfigLoader
/*    */ {
/* 20 */   public static ConfigLoaderStackSize instance = new ConfigLoaderStackSize();
/*    */   
/*    */   ConfigLoaderStackSize() {
/* 23 */     this.namesToExtras.put("stack_sizes", new ArrayList<String>());
/*    */   }
/*    */   
/*    */   public String getFileName() {
/* 27 */     return "stack_size";
/*    */   }
/*    */   
/*    */   public void loadStackSizes() {
/* 31 */     Configuration stackSizeConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*    */     
/* 33 */     stackSizeConfig.load();
/*    */     
/* 35 */     stackSizeConfig.setCategoryComment("stack_sizes", "You can change the stack size of any item/block in the following format:\n\n      <Item/Block name>_____<Stack size>\n\nFor instance, if you want to allow potions to stack up to 3, you could put:\n\n      minecraft:potion_____3");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     ArrayList<String> additionsList = ConfigExtrasLoader.combineLists(stackSizeConfig.get("stack_sizes", "stack_sizes", new String[0]).getStringList(), this.namesToExtras.get("stack_sizes"));
/*    */     
/* 46 */     for (int index = 0; index < additionsList.size(); index++) {
/* 47 */       String addition = additionsList.get(index);
/*    */       
/* 49 */       boolean comment = false;
/* 50 */       String title = getFileName() + ".cfg 'stack_sizes' #" + (index + 1);
/*    */       
/* 52 */       if (addition.length() > 0) {
/* 53 */         comment = (addition.charAt(0) == '#');
/*    */       }
/*    */       
/* 56 */       String[] parts = addition.split("_____");
/*    */       
/* 58 */       if (parts.length != 2) {
/* 59 */         if (!addition.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, addition);
/*    */       
/*    */       } else {
/*    */         
/* 63 */         String itemName = parts[0];
/* 64 */         int stackSize = 64;
/*    */         
/*    */         try {
/* 67 */           stackSize = Integer.valueOf(parts[1]).intValue();
/*    */         }
/* 69 */         catch (NumberFormatException e) {
/* 70 */           if (!comment) {
/* 71 */             System.err.println("[Loot++] Caught exception while trying to modify stack size of " + itemName);
/* 72 */             e.printStackTrace();
/* 73 */             LootPPNotifier.notifyNumber(comment, title, parts[1]);
/*    */           } 
/*    */         } 
/*    */         
/* 77 */         Object itemObj = Item.field_150901_e.func_82594_a(itemName);
/*    */         
/* 79 */         if (itemObj == null || !(itemObj instanceof Item)) {
/* 80 */           LootPPNotifier.notifyNonexistant(comment, title, itemName);
/*    */         }
/*    */         else {
/*    */           
/* 84 */           Item item = (Item)itemObj;
/*    */           
/* 86 */           item.func_77625_d(stackSize);
/*    */         } 
/*    */       } 
/* 89 */     }  stackSizeConfig.save();
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderStackSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */