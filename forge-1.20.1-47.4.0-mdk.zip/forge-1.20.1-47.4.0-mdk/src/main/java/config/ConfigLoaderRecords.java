/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import com.tmtravlr.lootplusplus.additions.ItemAddedRecord;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderRecords
/*     */   extends ConfigLoader
/*     */ {
/*  23 */   public static ConfigLoaderRecords instance = new ConfigLoaderRecords();
/*     */   
/*     */   ConfigLoaderRecords() {
/*  26 */     this.namesToExtras.put("records", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  30 */     return "records";
/*     */   }
/*     */   
/*     */   public void loadRecordConfig() {
/*  34 */     Configuration recordConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  36 */     recordConfig.load();
/*     */ 
/*     */ 
/*     */     
/*  40 */     recordConfig.addCustomCategoryComment("records", "To add new records, you will have to do 4 things:\n1.) Add a .ogg sound file to the resource pack in the assets/lootplusplus/sounds/records folder.\n\n2.) Add a .json model file to the resource pack in the assets/lootplusplus/models/item folder.\n\n3.) Edit the sounds.json file in the resource pack, adding a new entry in the form:\n  \"records.<record name>\": {\n    \"category\": \"record\",\n    \"sounds\": [\n      {\n        \"name\": \"records/<record name>\",\n        \"stream\": true\n      }\n    ]\n  }\nwhere <record name> is the name of the ogg file (withough .ogg)\n\n4.) Add an entry to this list in the form <record name>-<description>,\nwhere the record name is the name of the ogg file (without .ogg) and the model file\n(without .json). The description is what will display when the record plays.\n\nThe resource pack you can download has records for all the default music.\nDon't forget to load in and edit the resource pack!\n\nThe following are already set up correctly in the resource pack. You can add each\nline to the list below as examples (delete the # in front of them).\n\ncreative1-C418 - Biome Fest\ncreative2-C418 - Blind Spots\ncreative3-C418 - Haunt Muskie\ncreative4-C418 - Aria Math\ncreative5-C418 - Dreiton\ncreative6-C418 - Taswell\nend-C418 - The End\ncredits-C418 - Alpha\nnether1-C418 - Concrete Halls\nnether2-C418 - Dead Voxel\nnether3-C418 - Warmth\nnether4-C418 - Ballad of the Cats\nmenu1-C418 - Mutation\nmenu2-C418 - Moog City 2\nmenu3-C418 - Beginning 2\nmenu4-C418 - Floating Trees\ncalm1-C418 - Minecraft\ncalm2-C418 - Clark\ncalm3-C418 - Sweden\nhal1-C418 - Subwoofer Lullaby\nhal2-C418 - Living Mice\nhal3-C418 - Haggstrom\nhal4-C418 - Danny\nnuance1-C418 - Key\nnuance2-C418 - Oxygï¿½ne\npiano1-C418 - Dry Hands\npiano2-C418 - Wet Hands\npiano3-C418 - Mice on Venus");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     ArrayList<String> additionsList = ConfigExtrasLoader.combineLists(recordConfig.get("records", "List of records:", new String[0]).getStringList(), this.namesToExtras.get("records"));
/*     */     
/*  98 */     LootPPHelper.creepersDropAllRecords = recordConfig.get("options", "Creepers drop any type of record (vanilla or modded) when killed by skeletons?", true).getBoolean();
/*  99 */     LootPPHelper.creepersDropRecords = recordConfig.get("options", "Creepers can drop records when killed by skeletons?", true).getBoolean();
/*     */ 
/*     */     
/* 102 */     for (int index = 0; index < additionsList.size(); index++) {
/* 103 */       String entry = additionsList.get(index);
/*     */       
/* 105 */       boolean comment = false;
/* 106 */       String title = getFileName() + ".cfg #" + (index + 1);
/*     */       
/* 108 */       if (entry.length() > 0) {
/* 109 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/* 112 */       if (!comment) {
/*     */         
/* 114 */         String[] parts = entry.split("-", 2);
/*     */         
/* 116 */         if (parts.length != 2) {
/* 117 */           if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */         
/*     */         } else {
/*     */           
/* 121 */           String recordName = parts[0];
/* 122 */           String description = parts[1];
/*     */           
/* 124 */           Item customRecord = (new ItemAddedRecord(recordName, description)).func_77655_b(recordName);
/* 125 */           GameRegistry.registerItem(customRecord, recordName);
/* 126 */           LootPlusPlusMod.proxy.registerItemRender(customRecord);
/*     */         } 
/*     */       } 
/*     */     } 
/* 130 */     recordConfig.save();
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderRecords.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */