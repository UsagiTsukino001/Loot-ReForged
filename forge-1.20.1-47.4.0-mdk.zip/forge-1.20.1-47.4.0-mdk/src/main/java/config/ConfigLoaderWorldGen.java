/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import com.tmtravlr.lootplusplus.worldGen.WorldGenSurfaceBlocks;
/*     */ import com.tmtravlr.lootplusplus.worldGen.WorldGenUndergroundBlocks;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraftforge.common.BiomeDictionary;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ import net.minecraftforge.common.config.Property;
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderWorldGen
/*     */   extends ConfigLoader
/*     */ {
/*  24 */   public static ConfigLoaderWorldGen instance = new ConfigLoaderWorldGen();
/*     */   
/*     */   ConfigLoaderWorldGen() {
/*  27 */     this.namesToExtras.put("surface", new ArrayList<String>());
/*  28 */     this.namesToExtras.put("underground", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  32 */     return "world_gen";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadWorldGen() {
/*  38 */     Configuration genConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     genConfig.load();
/*     */     
/*  46 */     Property temp = genConfig.get("add_world_gen", "surface", new String[0]);
/*  47 */     temp.comment = "This adds blocks generating on solid surfaces like flowers (could be underground too):\n\n      <Block name>_____<Block metadata>_____<Block NBT ({} for none)>_____<Bonemeal (true or false)>_____<Chance per chunk (0.0 to 1.0)>_____<Tries per chunk>_____<Group size>_____<Tries per group>_____<Height min>_____<Height max>_____<Block beneath blacklist>_____<Block beneath whitelist>_____<Material beneath blacklist>_____<Material beneath whitelist>_____<Biome blacklist>_____<Biome whitelist>_____<Biome type blacklist>_____<Biome type whitelist>_____<Dimension blacklist>_____<Dimension whitelist>\n\n- The <Block name> is the name the block that will generate.\n- The <Block metadata> is the metadata of the block that will generate.\n- The <Block NBT> is the nbt data of the block that will generate, or {} for none.\n- If <Bonemeal> is true, if the block is a bonemeal-able plant, the generator will attempt\nto apply bonemeal to it (useful for generating trees from saplings).\n- The <Chance per chunk> is the chance (between 0.0 and 1.0) that the block will attempt\nto generate in the chunk\n- The <Tries per chunk> is the number of times the block will attempt to generate in the\nchunk. It should be at least 1.\n- The <Group size> is the cubed area in which a group of the give block will attempt to\ngenerate. It should be at least 1.\n- The <Tries per group> is the number of times the block will attempt to generate in the\ngroup area mentioned above. It should be at least 1.\n- The <Height min> is the minimum height at which the blocks will try to generate. It should\nbe 0 or greater, and smaller than 256.\n- The <Height max> is the maximum height at which the blocks will try to generate. It should\nbe larger or equal to the minimum and smaller than 256.\n- The <Block beneath blacklist> is a list of blocks that this should not generate on.\n- The <Block beneath whitelist> is a list of blocks that this should generate on. Overrides\nthe blacklist.\n- The <Material beneath blacklist> is a list of materials that this should not generate on.\n- The <Material beneath whitelist> is a list of materials that this should generate on.\nOverrides the blacklist. The possible values for the whitelist and the blacklist are:\n\n      air, anvil, cactus, cake, carpet, circuits, clay, cloth, coral, craftedSnow, dragonEgg, fire\n      glass, gourd, grass, ground, ice, iron, lava, leaves, packedIce, piston, plants, portal\n      redstoneLight, rock, sand, snow, sponge, tnt, vine, water, web, wood\n\n- The <Biome blacklist> is a list of biome names that this should not generate in.\n- The <Biome whitelist> is a list of biome names that this should generate in. Overrides\nthe blacklist.\n- The <Biome type blacklist> is a list of biome types that this should not generate in.\n- The <Biome type whitelist> is a list of biome types that this should generate in. The\n'vanilla' forge values for the whitelist and blacklist are:\n\n      HOT, COLD, SPARSE, DENSE, WET, DRY, SAVANNA, CONIFEROUS, JUNGLE, SPOOKY, DEAD, LUSH,\n      NETHER, END, MUSHROOM, MAGICAL, OCEAN, RIVER, WATER, MESA, FOREST, PLAINS, MOUNTAIN,\n      HILLS, SWAMP, SANDY, SNOWY, WASTELAND, BEACH\n\n- The <Dimension blacklist> is a list of dimension ids that this should not generate in.\n- The <Dimension whitelist> is a list of dimension ids that this should generate in. Overrides\nthe blacklist.\n\nFor example, you could generate ruby flowers (assuming you added them in the block_additions)\nwhich generate in any plains or forest biomes on blocks with the ground material like so:\n\n      lootplusplus:ruby_flower_____0_____{}_____false_____0.7_____20_____6_____64_____0_____255_____-_____-_____-_____ground-grass_____-_____-_____-_____PLAINS-FOREST_____-_____-";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     ArrayList<String> infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("surface"));
/*     */     int index;
/* 100 */     for (index = 0; index < infoList.size(); index++) {
/* 101 */       String info = infoList.get(index);
/* 102 */       String title = getFileName() + ".cfg 'surface' #" + (index + 1);
/*     */       
/* 104 */       boolean comment = false;
/*     */       
/* 106 */       if (info.length() > 0) {
/* 107 */         comment = (info.charAt(0) == '#');
/*     */       }
/*     */       
/* 110 */       String[] parts = info.split("_____");
/*     */       
/* 112 */       if (parts.length != 20) {
/* 113 */         if (!info.equals("")) {
/* 114 */           LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 119 */         String blockName = parts[0];
/* 120 */         int meta = 0;
/* 121 */         String nbtString = parts[2];
/* 122 */         boolean bonemeal = false;
/* 123 */         float chancePerChunk = 0.3F;
/* 124 */         int triesChunk = 20;
/* 125 */         int groupSize = 8;
/* 126 */         int triesGroup = 64;
/* 127 */         int heightMin = 0;
/* 128 */         int heightMax = 255;
/* 129 */         String[] blocksBeneathBl = parts[10].split("-");
/* 130 */         String[] blocksBeneathWl = parts[11].split("-");
/* 131 */         String[] materialsBeneathBl = parts[12].split("-");
/* 132 */         String[] materialsBeneathWl = parts[13].split("-");
/* 133 */         String[] biomeBl = parts[14].split("-");
/* 134 */         String[] biomeWl = parts[15].split("-");
/* 135 */         String[] biomeTypeBl = parts[16].split("-");
/* 136 */         String[] biomeTypeWl = parts[17].split("-");
/* 137 */         String[] dimensionBl = parts[18].split("-");
/* 138 */         String[] dimensionWl = parts[19].split("-");
/*     */         
/*     */         try {
/* 141 */           meta = Integer.valueOf(parts[1]).intValue();
/* 142 */           bonemeal = Boolean.valueOf(parts[3]).booleanValue();
/* 143 */           chancePerChunk = Float.valueOf(parts[4]).floatValue();
/* 144 */           triesChunk = Integer.valueOf(parts[5]).intValue();
/* 145 */           groupSize = Integer.valueOf(parts[6]).intValue();
/* 146 */           triesGroup = Integer.valueOf(parts[7]).intValue();
/* 147 */           heightMin = Integer.valueOf(parts[8]).intValue();
/* 148 */           heightMax = Integer.valueOf(parts[9]).intValue();
/*     */         }
/* 150 */         catch (NumberFormatException e) {
/* 151 */           if (!comment) {
/* 152 */             System.err.println("[Loot++] Caught exception while trying to add surface world gen for " + blockName);
/* 153 */             e.printStackTrace();
/* 154 */             LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[3], parts[4], parts[5], parts[6], parts[7], parts[8], parts[9] });
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 159 */         meta = MathHelper.func_76125_a(meta, 0, 15);
/* 160 */         chancePerChunk = MathHelper.func_76131_a(chancePerChunk, 0.0F, 1.0F);
/* 161 */         if (triesChunk < 1) triesChunk = 1; 
/* 162 */         if (groupSize < 1) groupSize = 1; 
/* 163 */         if (triesGroup < 1) triesGroup = 1; 
/* 164 */         heightMin = MathHelper.func_76125_a(heightMin, 0, 255);
/* 165 */         heightMax = MathHelper.func_76125_a(heightMax, heightMin, 255);
/*     */         
/* 167 */         Object blockObj = Block.field_149771_c.func_82594_a(blockName);
/*     */         
/* 169 */         if (blockObj == null || !(blockObj instanceof Block)) {
/* 170 */           LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*     */         }
/*     */         else {
/*     */           
/* 174 */           Block block = (Block)blockObj;
/*     */           
/* 176 */           NBTTagCompound tileTag = null;
/*     */           
/* 178 */           if (!nbtString.equals("") && !nbtString.equals("{}")) {
/*     */             try {
/* 180 */               tileTag = JsonToNBT.func_180713_a(nbtString.trim());
/*     */             }
/* 182 */             catch (Exception e) {
/*     */               
/* 184 */               if (!comment) {
/* 185 */                 LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage());
/* 186 */                 e.printStackTrace();
/*     */               } 
/* 188 */               tileTag = null;
/*     */             } 
/*     */           }
/*     */           
/* 192 */           IBlockState toGenerate = block.func_176203_a(meta);
/*     */ 
/*     */ 
/*     */           
/* 196 */           WorldGenSurfaceBlocks.SurfaceGenInfo genInfo = new WorldGenSurfaceBlocks.SurfaceGenInfo(toGenerate, tileTag, bonemeal, chancePerChunk, triesChunk, groupSize, triesGroup, heightMin, heightMax);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 201 */           for (String part : blocksBeneathBl) {
/* 202 */             if (!part.equals("")) {
/* 203 */               blockObj = Block.field_149771_c.func_82594_a(part);
/*     */               
/* 205 */               if (blockObj == null || !(blockObj instanceof Block)) {
/* 206 */                 LootPPNotifier.notifyNonexistant(comment, title, part);
/*     */               }
/*     */               else {
/*     */                 
/* 210 */                 genInfo.blocksBl.add((Block)blockObj);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 215 */           for (String part : blocksBeneathWl) {
/* 216 */             if (!part.equals("")) {
/* 217 */               blockObj = Block.field_149771_c.func_82594_a(part);
/*     */               
/* 219 */               if (blockObj == null || !(blockObj instanceof Block)) {
/* 220 */                 LootPPNotifier.notifyNonexistant(comment, title, part);
/*     */               }
/*     */               else {
/*     */                 
/* 224 */                 genInfo.blocksWl.add((Block)blockObj);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 229 */           for (String part : materialsBeneathBl) {
/* 230 */             if (!part.equals("")) {
/* 231 */               Material material = ConfigLoaderBlocks.getMaterialFromString(part);
/*     */               
/* 233 */               if (material == null) {
/* 234 */                 LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + part);
/*     */               }
/*     */               else {
/*     */                 
/* 238 */                 genInfo.materialsBl.add(material);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 243 */           for (String part : materialsBeneathWl) {
/* 244 */             if (!part.equals("")) {
/* 245 */               Material material = ConfigLoaderBlocks.getMaterialFromString(part);
/*     */               
/* 247 */               if (material == null) {
/* 248 */                 LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + part);
/*     */               }
/*     */               else {
/*     */                 
/* 252 */                 genInfo.materialsWl.add(material);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 257 */           for (String part : biomeBl) {
/* 258 */             if (!part.equals("")) {
/* 259 */               genInfo.biomeBl.add(part.toLowerCase());
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 264 */           for (String part : biomeWl) {
/* 265 */             if (!part.equals("")) {
/* 266 */               genInfo.biomeWl.add(part.toLowerCase());
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 271 */           for (String part : biomeTypeBl) {
/* 272 */             if (!part.equals("")) {
/* 273 */               BiomeDictionary.Type biomeType = BiomeDictionary.Type.getType(part, new BiomeDictionary.Type[0]);
/*     */               
/* 275 */               genInfo.biomeTypeBl.add(biomeType);
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 280 */           for (String part : biomeTypeWl) {
/* 281 */             if (!part.equals("")) {
/* 282 */               BiomeDictionary.Type biomeType = BiomeDictionary.Type.getType(part, new BiomeDictionary.Type[0]);
/*     */               
/* 284 */               genInfo.biomeTypeWl.add(biomeType);
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 289 */           for (String part : dimensionBl) {
/* 290 */             if (!part.equals("")) {
/*     */               try {
/* 292 */                 genInfo.dimensionBl.add(Integer.valueOf(Integer.parseInt(part)));
/*     */               }
/* 294 */               catch (NumberFormatException e) {
/* 295 */                 e.printStackTrace();
/* 296 */                 LootPPNotifier.notifyNumber(comment, title, part);
/*     */               } 
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 302 */           for (String part : dimensionWl) {
/* 303 */             if (!part.equals("")) {
/*     */               try {
/* 305 */                 genInfo.dimensionWl.add(Integer.valueOf(Integer.parseInt(part)));
/*     */               }
/* 307 */               catch (NumberFormatException e) {
/* 308 */                 e.printStackTrace();
/* 309 */                 LootPPNotifier.notifyNumber(comment, title, part);
/*     */               } 
/*     */             }
/*     */           } 
/*     */           
/* 314 */           WorldGenSurfaceBlocks.surfaceGens.add(genInfo);
/*     */           
/* 316 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added surface world gen for block " + blockName); 
/*     */         } 
/*     */       } 
/*     */     } 
/* 320 */     temp = genConfig.get("add_world_gen", "underground", new String[0]);
/* 321 */     temp.comment = "This adds blocks generating inside other blocks like ores:\n\n      <Block name>_____<Block metadata>_____<Block NBT ({} for none)>_____<Chance per chunk (0.0 to 1.0)>_____<Tries per chunk>_____<Vein length min>-<Vein length max (optional)>_____<Vein thickness min>-<Vein thickness max>_____<Height min>_____<Height max>_____<Block blacklist>_____<Block whitelist>_____<Material beneath blacklist>_____<Material beneath whitelist>_____<Biome blacklist>_____<Biome whitelist>_____<Biome type blacklist>_____<Biome type whitelist>_____<Dimension blacklist>_____<Dimension whitelist>\n\n- The <Block name> is the name the block that will generate.\n- The <Block metadata> is the metadata of the block that will generate.\n- The <Block NBT> is the nbt data of the block that will generate, or {} for none.\n- The <Chance per chunk> is the chance (between 0.0 and 1.0) that the block will attempt\nto generate in the chunk\n- The <Tries per chunk> is the number of times the block will attempt to generate in the\nchunk. It should be at least 1.\n- The <Vein length min and max> are the minimum and maximum lengths of the ore vein. The\nmin should be at least 1, and the max should be bigger or equal to the min, if included.\n- The <Vein thickness min and max> are the minimum and maximum thickness of the ore vein. The\nmin should be at least 1, and the max should be bigger or equal to the min, if included.\n- The <Height min> is the minimum height at which the blocks will try to generate. It should\nbe 0 or greater, and smaller than 256.\n- The <Height max> is the maximum height at which the blocks will try to generate. It should\nbe larger or equal to the minimum and smaller than 256.\n- The <Block blacklist> is a list of blocks that this should not generate in.\n- The <Block whitelist> is a list of blocks that this should generate in. Overrides\nthe blacklist.\n- The <Material beneath blacklist> is a list of materials that this should not generate on.\n- The <Material beneath whitelist> is a list of materials that this should generate on.\nOverrides the blacklist. The possible values for the whitelist and the blacklist are:\n\n      air, anvil, cactus, cake, carpet, circuits, clay, cloth, coral, craftedSnow, dragonEgg, fire\n      glass, gourd, grass, ground, ice, iron, lava, leaves, packedIce, piston, plants, portal\n      redstoneLight, rock, sand, snow, sponge, tnt, vine, water, web, wood\n\n- The <Biome blacklist> is a list of biome names that this should not generate in.\n- The <Biome whitelist> is a list of biome names that this should generate in. Overrides\nthe blacklist.\n- The <Biome type blacklist> is a list of biome types that this should not generate in.\n- The <Biome type whitelist> is a list of biome types that this should generate in. The\n'vanilla' forge values for the whitelist and blacklist are:\n\n      HOT, COLD, SPARSE, DENSE, WET, DRY, SAVANNA, CONIFEROUS, JUNGLE, SPOOKY, DEAD, LUSH,\n      NETHER, END, MUSHROOM, MAGICAL, OCEAN, RIVER, WATER, MESA, FOREST, PLAINS, MOUNTAIN,\n      HILLS, SWAMP, SANDY, SNOWY, WASTELAND, BEACH\n\n- The <Dimension blacklist> is a list of dimension ids that this should not generate in.\n- The <Dimension whitelist> is a list of dimension ids that this should generate in. Overrides\nthe blacklist.\n\nFor example, you could generate ruby ore (assuming you added it in the block_additions)\nin every biome with rarity more like diamonds, except they generate more in\ndesert-like biomes, with these two entries:\n\n      lootplusplus:ruby_ore_____0_____{}_____0.8_____2_____1-2_____1-2_____0_____20_____-_____stone_____-_____-_____-_____-_____-_____-_____-_____-\n      lootplusplus:ruby_ore_____0_____{}_____0.8_____2_____1-2_____1_____0_____30_____-_____stone_____-_____-_____-_____-_____-_____DRY-SANDY-SAVANNA_____-_____-";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 372 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("underground"));
/*     */     
/* 374 */     for (index = 0; index < infoList.size(); index++) {
/* 375 */       String info = infoList.get(index);
/* 376 */       String title = getFileName() + ".cfg 'underground' #" + (index + 1);
/*     */       
/* 378 */       boolean comment = false;
/*     */       
/* 380 */       if (info.length() > 0) {
/* 381 */         comment = (info.charAt(0) == '#');
/*     */       }
/*     */       
/* 384 */       String[] parts = info.split("_____");
/*     */       
/* 386 */       if (parts.length != 19) {
/* 387 */         if (!info.equals("")) {
/* 388 */           LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 393 */         String blockName = parts[0];
/* 394 */         int meta = 0;
/* 395 */         String nbtString = parts[2];
/* 396 */         float chancePerChunk = 0.3F;
/* 397 */         int triesChunk = 20;
/* 398 */         int veinLengthMin = 1;
/* 399 */         int veinLengthMax = 2;
/* 400 */         int veinThicknessMin = 2;
/* 401 */         int veinThicknessMax = 2;
/* 402 */         int heightMin = 0;
/* 403 */         int heightMax = 255;
/* 404 */         String[] blocksBeneathBl = parts[9].split("-");
/* 405 */         String[] blocksBeneathWl = parts[10].split("-");
/* 406 */         String[] materialsBeneathBl = parts[11].split("-");
/* 407 */         String[] materialsBeneathWl = parts[12].split("-");
/* 408 */         String[] biomeBl = parts[13].split("-");
/* 409 */         String[] biomeWl = parts[14].split("-");
/* 410 */         String[] biomeTypeBl = parts[15].split("-");
/* 411 */         String[] biomeTypeWl = parts[16].split("-");
/* 412 */         String[] dimensionBl = parts[17].split("-");
/* 413 */         String[] dimensionWl = parts[18].split("-");
/*     */         
/*     */         try {
/* 416 */           meta = Integer.valueOf(parts[1]).intValue();
/* 417 */           chancePerChunk = Float.valueOf(parts[3]).floatValue();
/* 418 */           triesChunk = Integer.valueOf(parts[4]).intValue();
/*     */           
/* 420 */           String[] subParts = parts[5].split("-");
/* 421 */           veinLengthMin = Integer.valueOf(subParts[0]).intValue();
/* 422 */           veinLengthMax = (subParts.length > 1) ? Integer.valueOf(subParts[1]).intValue() : veinLengthMin;
/*     */           
/* 424 */           subParts = parts[6].split("-");
/* 425 */           veinThicknessMin = Integer.valueOf(subParts[0]).intValue();
/* 426 */           veinThicknessMax = (subParts.length > 1) ? Integer.valueOf(subParts[1]).intValue() : veinThicknessMin;
/*     */           
/* 428 */           heightMin = Integer.valueOf(parts[7]).intValue();
/* 429 */           heightMax = Integer.valueOf(parts[8]).intValue();
/*     */         }
/* 431 */         catch (Exception e) {
/* 432 */           if (!comment) {
/* 433 */             System.err.println("[Loot++] Caught exception while trying to add underground world gen for " + blockName);
/* 434 */             e.printStackTrace();
/* 435 */             LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[3], parts[4], parts[5], parts[6], parts[7], parts[8] });
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 440 */         meta = MathHelper.func_76125_a(meta, 0, 15);
/* 441 */         chancePerChunk = MathHelper.func_76131_a(chancePerChunk, 0.0F, 1.0F);
/* 442 */         if (triesChunk < 1) triesChunk = 1; 
/* 443 */         if (veinLengthMin < 1) veinLengthMin = 1; 
/* 444 */         if (veinLengthMax < veinLengthMin) veinLengthMax = veinLengthMin; 
/* 445 */         if (veinThicknessMin < 1) veinThicknessMin = 1; 
/* 446 */         if (veinThicknessMax < veinThicknessMin) veinThicknessMax = veinThicknessMin; 
/* 447 */         heightMin = MathHelper.func_76125_a(heightMin, 0, 255);
/* 448 */         heightMax = MathHelper.func_76125_a(heightMax, heightMin, 255);
/*     */         
/* 450 */         Object blockObj = Block.field_149771_c.func_82594_a(blockName);
/*     */         
/* 452 */         if (blockObj == null || !(blockObj instanceof Block)) {
/* 453 */           LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*     */         }
/*     */         else {
/*     */           
/* 457 */           Block block = (Block)blockObj;
/*     */           
/* 459 */           NBTTagCompound tileTag = null;
/*     */           
/* 461 */           if (!nbtString.equals("") && !nbtString.equals("{}")) {
/*     */             try {
/* 463 */               tileTag = JsonToNBT.func_180713_a(nbtString.trim());
/*     */             }
/* 465 */             catch (Exception e) {
/*     */               
/* 467 */               if (!comment) {
/* 468 */                 LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage());
/* 469 */                 e.printStackTrace();
/*     */               } 
/* 471 */               tileTag = null;
/*     */             } 
/*     */           }
/*     */           
/* 475 */           IBlockState toGenerate = block.func_176203_a(meta);
/*     */ 
/*     */ 
/*     */           
/* 479 */           WorldGenUndergroundBlocks.UndergroundGenInfo genInfo = new WorldGenUndergroundBlocks.UndergroundGenInfo(toGenerate, tileTag, chancePerChunk, triesChunk, veinLengthMin, veinLengthMax, veinThicknessMin, veinThicknessMax, heightMin, heightMax);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 484 */           for (String part : blocksBeneathBl) {
/* 485 */             if (!part.equals("")) {
/* 486 */               blockObj = Block.field_149771_c.func_82594_a(part);
/*     */               
/* 488 */               if (blockObj == null || !(blockObj instanceof Block)) {
/* 489 */                 LootPPNotifier.notifyNonexistant(comment, title, part);
/*     */               }
/*     */               else {
/*     */                 
/* 493 */                 genInfo.blocksBl.add((Block)blockObj);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 498 */           for (String part : blocksBeneathWl) {
/* 499 */             if (!part.equals("")) {
/* 500 */               blockObj = Block.field_149771_c.func_82594_a(part);
/*     */               
/* 502 */               if (blockObj == null || !(blockObj instanceof Block)) {
/* 503 */                 LootPPNotifier.notifyNonexistant(comment, title, part);
/*     */               }
/*     */               else {
/*     */                 
/* 507 */                 genInfo.blocksWl.add((Block)blockObj);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 512 */           for (String part : materialsBeneathBl) {
/* 513 */             if (!part.equals("")) {
/* 514 */               Material material = ConfigLoaderBlocks.getMaterialFromString(part);
/*     */               
/* 516 */               if (material == null) {
/* 517 */                 LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + part);
/*     */               }
/*     */               else {
/*     */                 
/* 521 */                 genInfo.materialsBl.add(material);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 526 */           for (String part : materialsBeneathWl) {
/* 527 */             if (!part.equals("")) {
/* 528 */               Material material = ConfigLoaderBlocks.getMaterialFromString(part);
/*     */               
/* 530 */               if (material == null) {
/* 531 */                 LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + part);
/*     */               }
/*     */               else {
/*     */                 
/* 535 */                 genInfo.materialsWl.add(material);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */           
/* 540 */           for (String part : biomeBl) {
/* 541 */             if (!part.equals("")) {
/* 542 */               genInfo.biomeBl.add(part.toLowerCase());
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 547 */           for (String part : biomeWl) {
/* 548 */             if (!part.equals("")) {
/* 549 */               genInfo.biomeWl.add(part.toLowerCase());
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 554 */           for (String part : biomeTypeBl) {
/* 555 */             if (!part.equals("")) {
/* 556 */               BiomeDictionary.Type biomeType = BiomeDictionary.Type.getType(part, new BiomeDictionary.Type[0]);
/*     */               
/* 558 */               genInfo.biomeTypeBl.add(biomeType);
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 563 */           for (String part : biomeTypeWl) {
/* 564 */             if (!part.equals("")) {
/* 565 */               BiomeDictionary.Type biomeType = BiomeDictionary.Type.getType(part, new BiomeDictionary.Type[0]);
/*     */               
/* 567 */               genInfo.biomeTypeWl.add(biomeType);
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 572 */           for (String part : dimensionBl) {
/* 573 */             if (!part.equals("")) {
/*     */               try {
/* 575 */                 genInfo.dimensionBl.add(Integer.valueOf(Integer.parseInt(part)));
/*     */               }
/* 577 */               catch (NumberFormatException e) {
/* 578 */                 e.printStackTrace();
/* 579 */                 LootPPNotifier.notifyNumber(comment, title, part);
/*     */               } 
/*     */             }
/*     */           } 
/*     */ 
/*     */           
/* 585 */           for (String part : dimensionWl) {
/* 586 */             if (!part.equals("")) {
/*     */               try {
/* 588 */                 genInfo.dimensionWl.add(Integer.valueOf(Integer.parseInt(part)));
/*     */               }
/* 590 */               catch (NumberFormatException e) {
/* 591 */                 e.printStackTrace();
/* 592 */                 LootPPNotifier.notifyNumber(comment, title, part);
/*     */               } 
/*     */             }
/*     */           } 
/*     */           
/* 597 */           WorldGenUndergroundBlocks.undergroundGens.add(genInfo);
/*     */           
/* 599 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added underground world gen for block " + blockName); 
/*     */         } 
/*     */       } 
/* 602 */     }  genConfig.save();
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderWorldGen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */