/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPItems;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderEntityDrops
/*     */   extends ConfigLoader
/*     */ {
/*  32 */   public static ConfigLoaderEntityDrops instance = new ConfigLoaderEntityDrops();
/*     */   
/*     */   ConfigLoaderEntityDrops() {
/*  35 */     this.namesToExtras.put("removing", new ArrayList<String>());
/*  36 */     this.namesToExtras.put("adding", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  40 */     return "entity_drops";
/*     */   }
/*     */   
/*     */   public void loadEntityDrops() {
/*  44 */     Configuration entityDropConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  46 */     entityDropConfig.load();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     entityDropConfig.addCustomCategoryComment("removing", "To remove an item drop from an entity, add entries, each on a new line\nin the format:\n\n      <Entity name (any for any)>_____<Entity NBT tag ({} for any)>_____<Item name>_____<Metadata (optional, or -1 for any)>_____<NBT tag (optional)>.\n\nSo if you wanted to remove rotten flesh as a drop from zombies, you could put\n\n      Zombie_____{}_____minecraft:rotten_flesh\n\nThis will prevent any rotten flesh from dropping from zombies.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  61 */     ArrayList<String> dropsList = ConfigExtrasLoader.combineLists(entityDropConfig.get("removing", "Drops to remove from entities:", new String[0]).getStringList(), this.namesToExtras.get("removing"));
/*     */     
/*  63 */     int index = 0; while (true) { if (index < dropsList.size()) {
/*  64 */         String entry = dropsList.get(index);
/*  65 */         String[] split = entry.split("_____", 5);
/*     */         
/*  67 */         boolean comment = false;
/*  68 */         String title = getFileName() + ".cfg 'removing' #" + (index + 1);
/*     */         
/*  70 */         if (entry.length() > 0) {
/*  71 */           comment = (entry.charAt(0) == '#');
/*     */         }
/*     */         
/*  74 */         if (split.length < 3) {
/*  75 */           LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */         }
/*     */         else {
/*     */           
/*  79 */           String entityName = split[0];
/*  80 */           String entityNBTString = split[1];
/*  81 */           String itemName = split[2];
/*  82 */           String metaString = "-1";
/*  83 */           String nbtString = "{}";
/*     */           
/*  85 */           if (split.length > 3) {
/*  86 */             metaString = split[3];
/*     */           }
/*     */           
/*  89 */           if (split.length > 4) {
/*  90 */             nbtString = split[4];
/*     */           }
/*     */           
/*  93 */           int meta = -1;
/*     */           
/*     */           try {
/*  96 */             meta = Integer.valueOf(metaString).intValue();
/*     */           }
/*  98 */           catch (NumberFormatException e) {
/*  99 */             if (!comment) {
/* 100 */               e.printStackTrace();
/* 101 */               LootPPNotifier.notifyNumber(comment, title, metaString);
/*     */             } 
/*     */           } 
/*     */           
/* 105 */           if (meta < 0) {
/* 106 */             meta = 32767;
/*     */           }
/*     */ 
/*     */           
/* 110 */           NBTTagCompound entityNBT = null;
/* 111 */           NBTTagCompound dropNBT = null;
/*     */ 
/*     */           
/* 114 */           if (!entityNBTString.equals("") && !entityNBTString.equals("{}")) {
/*     */             
/*     */             try {
/* 117 */               NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(entityNBTString.trim());
/* 118 */               entityNBT = nBTTagCompound;
/*     */             }
/* 120 */             catch (Exception e) {
/*     */               
/* 122 */               if (!comment) {
/* 123 */                 e.printStackTrace();
/* 124 */                 LootPPNotifier.notifyNBT(comment, title, entityNBTString, e.getMessage());
/*     */               } 
/* 126 */               entityNBT = null;
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/* 131 */           if (!nbtString.equals("") && !nbtString.equals("{}")) {
/*     */             
/*     */             try {
/* 134 */               NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(nbtString.trim());
/* 135 */               dropNBT = nBTTagCompound;
/*     */             }
/* 137 */             catch (Exception e) {
/*     */               
/* 139 */               if (!comment) {
/* 140 */                 e.printStackTrace();
/* 141 */                 LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage());
/*     */               } 
/* 143 */               dropNBT = null;
/*     */             } 
/*     */           }
/*     */           
/* 147 */           Item item = null;
/*     */           
/* 149 */           if (itemName.equalsIgnoreCase("any") || itemName.equalsIgnoreCase("all"))
/* 150 */           { item = LootPPItems.generalDummyIcon; }
/*     */           else
/*     */           
/* 153 */           { Object itemObj = Item.field_150901_e.func_82594_a(itemName);
/*     */             
/* 155 */             if (itemObj == null || !(itemObj instanceof Item))
/* 156 */             { LootPPNotifier.notifyNonexistant(comment, title, itemName); }
/*     */             else
/*     */             
/* 159 */             { item = (Item)itemObj;
/*     */ 
/*     */               
/* 162 */               ItemStack stack = new ItemStack(item, 1, meta); }  index++; }  ItemStack itemStack = new ItemStack(item, 1, meta);
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       index++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     entityDropConfig.addCustomCategoryComment("adding", "There are two types of drops to add: items and entities.\n\nIn either case, the first options should be:\n\n      <Entity name (any for any)>-<Rarity>-<Only player kill (true or false)>-<Affected by looting (true or false)>-<Entity NBT (optional)>,\n\nWhere:- The <Entity name> is the name of the entity, as appears in the Entity IDs.txt file.\n- The <Rarity> is the probability of the drop, from 0.0 to 1.0.\n- If <Only player kill> is true, the drop will only drop if the entity is killed by a\nplayer.\n- If <Affected by looting> is true, the drops will increase if killed with a weapon\nenchanted with looting.\n\nNext you can specify the items or entities to drop, in a list. The list should be in the formats:\n\n      ..._____i-<Item id>-<Min>-<Max>-<Weight (optional)>-<Metadata (optional)>-<NBT Tag (optional)>_____...\n\nfor items, or:\n\n      ..._____e-<Entity id>-<Weight (optional)>-<NBT tag (optional)>_____...\n\nfor entities, or:\n\n      ..._____c-<Weight>-<Command>_____...\n\nfor commands, where:\n- The <Item id> or<Entity id> is the string id for the item or entity.- The <Weight> is the chance that this drop will be chosen out of all the combined weights.\nMake sure it's bigger than 0. If you don't specify the weight, it will default to 1.\n- And the <Command> is a command you want to run where the block breaks.\n\nAlso, you can put %%%%% between drops to create groups of drops. In a group, only the weight of\nthe first drop will count.\n\n###############################################  Examples  #############################################\nIf you wanted zombies to drop feathers, you could write:\n\n      Zombie-1.0-false-true_____i-minecraft:feather-1-3\n\nIf you wanted silverfish to have a chance to drop extra xp when killed by a player, you could put:\n\n      Silverfish-0.7-true-false_____e-XPOrb-1-{Value:1}_____e-XPOrb-1-{Value:2}_____e-XPOrb-1-{Value:3}\n\nIf you wanted wither skeletons to drop fire charges 50% of the time, you could put:\n\n      Skeleton-0.5-false-true-{SkeletonType:1}_____i-minecraft:fire_charge-1-1");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     dropsList = ConfigExtrasLoader.combineLists(entityDropConfig.get("adding", "Drops to add to entities:", new String[0]).getStringList(), this.namesToExtras.get("adding"));
/*     */     
/* 241 */     for (index = 0; index < dropsList.size(); index++) {
/* 242 */       String entry = dropsList.get(index);
/*     */       
/* 244 */       boolean comment = false;
/* 245 */       String title = getFileName() + ".cfg 'adding' #" + (index + 1);
/*     */       
/* 247 */       if (entry.length() > 0) {
/* 248 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/*     */       try {
/* 252 */         String[] dropStrings = entry.split("_____");
/*     */         
/* 254 */         if (dropStrings.length < 2) {
/* 255 */           if (!entry.equals("")) {
/* 256 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 261 */           String[] split = dropStrings[0].split("-", 5);
/*     */           
/* 263 */           if (split.length < 4) {
/* 264 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, dropStrings[0]);
/*     */           }
/*     */           else {
/*     */             
/* 268 */             String entityName = split[0];
/* 269 */             String rarityString = split[1];
/* 270 */             String pkString = split[2];
/* 271 */             String lootingString = split[3];
/*     */             
/* 273 */             float rarity = 1.0F;
/* 274 */             boolean pk = false;
/* 275 */             boolean looting = true;
/* 276 */             NBTTagCompound entityNBT = null;
/*     */             
/* 278 */             ArrayList<ArrayList<LootPPHelper.DropInfo>> entityDrops = new ArrayList<ArrayList<LootPPHelper.DropInfo>>();
/*     */             
/*     */             try {
/* 281 */               rarity = Float.valueOf(rarityString).floatValue();
/* 282 */               pk = Boolean.valueOf(pkString).booleanValue();
/* 283 */               looting = Boolean.valueOf(lootingString).booleanValue();
/*     */             }
/* 285 */             catch (Exception e) {
/* 286 */               if (!comment) {
/* 287 */                 e.printStackTrace();
/* 288 */                 LootPPNotifier.notifyNumber(comment, title, new String[] { rarityString, pkString, lootingString });
/*     */               } 
/*     */             } 
/*     */             
/* 292 */             if (rarity < 0.0F) rarity = 0.0F; 
/* 293 */             if (rarity > 1.0F) rarity = 1.0F;
/*     */             
/* 295 */             if (split.length > 4 && !split[4].equals("") && !split[4].equals("{}")) {
/*     */               
/*     */               try {
/* 298 */                 NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(split[4].trim());
/* 299 */                 entityNBT = nBTTagCompound;
/*     */               }
/* 301 */               catch (Exception e) {
/*     */                 
/* 303 */                 if (!comment) {
/* 304 */                   e.printStackTrace();
/* 305 */                   LootPPNotifier.notifyNBT(comment, title, split[4], e.getMessage());
/*     */                 } 
/* 307 */                 entityNBT = null;
/*     */               } 
/*     */             }
/*     */             
/* 311 */             if (entityNBT == null) {
/* 312 */               entityNBT = new NBTTagCompound();
/*     */             }
/*     */             
/* 315 */             if (!entityName.equalsIgnoreCase("any")) {
/* 316 */               entityNBT.func_74778_a("id", entityName);
/*     */             }
/*     */             
/* 319 */             for (int i = 1; i < dropStrings.length; i++) {
/* 320 */               String dropString = dropStrings[i];
/*     */               
/* 322 */               if (!dropString.equals("")) {
/*     */ 
/*     */ 
/*     */                 
/* 326 */                 String[] subParts = dropString.split("%%%%%");
/*     */                 
/* 328 */                 ArrayList<LootPPHelper.DropInfo> infoList = new ArrayList<LootPPHelper.DropInfo>();
/*     */                 
/* 330 */                 for (int j = 0; j < subParts.length; j++) {
/*     */                   
/* 332 */                   String subString = subParts[j];
/*     */                   
/* 334 */                   int dashIndex = subString.indexOf("-");
/*     */                   
/* 336 */                   if (dashIndex >= 0) {
/*     */ 
/*     */ 
/*     */                     
/* 340 */                     char type = subString.charAt(0);
/*     */                     
/* 342 */                     LootPPHelper.DropInfo info = LootPPHelper.getDropInfo(type, subString.substring(dashIndex + 1), comment, title);
/*     */                     
/* 344 */                     if (info != null) {
/* 345 */                       infoList.add(info);
/*     */                     }
/*     */                   } 
/*     */                 } 
/*     */                 
/* 350 */                 if (!infoList.isEmpty()) {
/* 351 */                   entityDrops.add(infoList);
/*     */                 }
/*     */               } 
/*     */             } 
/* 355 */             if (!entityDrops.isEmpty())
/* 356 */             { if (LootPlusPlusMod.debug) System.out.println("[Loot++] Adding Drops to entity " + entityName);
/*     */               
/* 358 */               if (LootPPHelper.entityDropAdditions.containsKey(entityNBT)) {
/* 359 */                 ArrayList<LootPPHelper.EntityDropInfo> existingList = (ArrayList<LootPPHelper.EntityDropInfo>)LootPPHelper.entityDropAdditions.get(entityNBT);
/* 360 */                 if (existingList == null) {
/* 361 */                   existingList = new ArrayList<LootPPHelper.EntityDropInfo>();
/*     */                 }
/* 363 */                 LootPPHelper.EntityDropInfo toAdd = new LootPPHelper.EntityDropInfo(rarity, pk, looting);
/* 364 */                 toAdd.dropList = entityDrops;
/* 365 */                 existingList.add(toAdd);
/* 366 */                 LootPPHelper.entityDropAdditions.put(entityNBT, existingList);
/*     */               } else {
/*     */                 
/* 369 */                 ArrayList<LootPPHelper.EntityDropInfo> newList = new ArrayList<LootPPHelper.EntityDropInfo>();
/* 370 */                 LootPPHelper.EntityDropInfo toAdd = new LootPPHelper.EntityDropInfo(rarity, pk, looting);
/* 371 */                 toAdd.dropList = entityDrops;
/* 372 */                 newList.add(toAdd);
/* 373 */                 LootPPHelper.entityDropAdditions.put(entityNBT, newList);
/*     */               }
/*     */                }
/*     */             
/* 377 */             else if (LootPlusPlusMod.debug) { System.out.println("[Loot++] Drops List was empty for " + entityName + "!"); } 
/*     */           } 
/*     */         } 
/* 380 */       } catch (Exception e) {
/* 381 */         if (!comment) {
/* 382 */           System.err.println("[Loot++] Caught an exception while trying to load entity drops.");
/* 383 */           e.printStackTrace();
/* 384 */           LootPPNotifier.notify(comment, title, "=( Unexpected problem '" + e.getMessage() + "' while loading entitiy drop additions for: " + entry);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 389 */     entityDropConfig.save();
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderEntityDrops.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */