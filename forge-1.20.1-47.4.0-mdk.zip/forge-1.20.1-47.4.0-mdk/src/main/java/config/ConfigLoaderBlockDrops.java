/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPItems;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderBlockDrops
/*     */   extends ConfigLoader
/*     */ {
/*  38 */   public static ConfigLoaderBlockDrops instance = new ConfigLoaderBlockDrops();
/*     */   
/*     */   ConfigLoaderBlockDrops() {
/*  41 */     this.namesToExtras.put("removing", new ArrayList<String>());
/*  42 */     this.namesToExtras.put("adding", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  46 */     return "block_drops";
/*     */   }
/*     */   
/*     */   public void loadBlockDrops() {
/*  50 */     Configuration blockDropConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  52 */     blockDropConfig.load();
/*     */ 
/*     */ 
/*     */     
/*  56 */     blockDropConfig.addCustomCategoryComment("removing", "To remove an item drops from a block, add entries, each on a new line\nin the format:\n\n      <Block id>_____<Block metadata (-1 for any)>_____<Item name>_____<Metadata (optional, -1 for any)>_____<NBT tag (optional)>\n\nSo if you wanted to remove coal as a drop from coal ore, you could put\n\n      minecraft:coal_ore_____-1_____minecraft:coal\n\nThis would prevent any coal dropping from coal ore.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     List<String> dropsList = ConfigExtrasLoader.combineLists(blockDropConfig.get("removing", "Drops to remove from blocks:", new String[0]).getStringList(), this.namesToExtras.get("removing"));
/*     */     
/*  68 */     int index = 0; while (true) { if (index < dropsList.size()) {
/*  69 */         String entry = dropsList.get(index);
/*     */         
/*  71 */         String[] parts = entry.split("_____");
/*     */ 
/*     */         
/*  74 */         boolean comment = false;
/*  75 */         String title = getFileName() + ".cfg 'removing' #" + index + '\001';
/*     */         
/*  77 */         if (entry.length() > 0) {
/*  78 */           comment = (entry.charAt(0) == '#');
/*     */         }
/*     */         
/*  81 */         if (parts.length < 3) {
/*  82 */           if (!entry.equals("")) {
/*  83 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/*  88 */           String blockName = parts[0];
/*  89 */           int blockMeta = -1;
/*  90 */           String itemName = parts[2];
/*  91 */           int itemMeta = -1;
/*  92 */           String nbtString = "{}";
/*     */           
/*     */           try {
/*  95 */             blockMeta = Integer.valueOf(parts[1]).intValue();
/*  96 */             if (parts.length > 3) {
/*  97 */               itemMeta = Integer.valueOf(parts[3]).intValue();
/*     */             }
/*     */           }
/* 100 */           catch (NumberFormatException e) {
/* 101 */             if (!comment) {
/* 102 */               System.err.println("[Loot++] Caught an exception while trying to remove a block drop from " + blockName);
/* 103 */               e.printStackTrace();
/* 104 */               LootPPNotifier.notifyNumber(comment, title, parts[1] + ((parts.length > 3) ? (", " + parts[3]) : ""));
/*     */             } 
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 110 */           if (blockMeta < 0) {
/* 111 */             blockMeta = 32767;
/*     */           }
/* 113 */           if (itemMeta < 0) {
/* 114 */             itemMeta = 32767;
/*     */           }
/*     */ 
/*     */           
/* 118 */           Object blockObj = Block.field_149771_c.func_82594_a(blockName);
/*     */           
/* 120 */           if (blockObj == null || !(blockObj instanceof Block)) {
/* 121 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*     */           }
/*     */           else {
/*     */             
/* 125 */             Block block = (Block)blockObj;
/*     */             
/* 127 */             Item item = null;
/* 128 */             if (itemName.equalsIgnoreCase("any") || itemName.equalsIgnoreCase("all"))
/* 129 */             { item = LootPPItems.generalDummyIcon; }
/*     */             else
/*     */             
/* 132 */             { Object itemObj = Item.field_150901_e.func_82594_a(itemName);
/*     */               
/* 134 */               if (itemObj == null || !(itemObj instanceof Item))
/* 135 */               { LootPPNotifier.notifyNonexistant(comment, title, itemName); }
/*     */               else
/*     */               
/* 138 */               { item = (Item)itemObj;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 144 */                 NBTTagCompound nbt = null; }  index++; }  Object object = null;
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       index++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     blockDropConfig.addCustomCategoryComment("adding", "There are a few types of drops to add: items, entities, and commands.\n\nIn either case, the first options should be:\n\n      <Block Id>-<Rarity>-<Only player mined (true or false)>-<Drop with silk touch (true or false)>-<Affected by fortune (true or false)>-<Block metadata (optional)>,\n\nWhere:\n- The <Block Id> is the string id for the block as seen in the 'Block and Item IDs.txt' file.\n- The <Rarity> is the rarity of the drop, from 0.0 to 1.0\n- If <Only player mined> is true, drop will only drop if the block is broken by a player.\n- If <Drop with silk touch> is true, the drop will only drop if broken with a tool enchanted\nwith silk touch. If false, it will only drop if not broken with a silk touch tool. So word of\nwarning, if you want it to drop in either case, you need to add 2 entries, with true and false.\n- If <Affected by fortune> is true, the drops will increase if broken with a tool enchanted\nwith fortune.\n\nNext you can specify the items or entities to drop, in a list. The list should be in the formats:\n\n      ..._____i-<Item id>-<Min>-<Max>-<Weight (optional)>-<Metadata (optional)>-<NBT Tag (optional)>_____...\n\nfor items, or:\n\n      ..._____e-<Entity id>-<Weight (optional)>-<NBT tag (optional)>_____...\n\nfor entities, or:\n\n      ..._____c-<Weight>-<Command>_____...\n\nfor commands, where:\n- The <Item id> or<Entity id> is the string id for the item or entity.- The <Weight> is the chance that this drop will be chosen out of all the combined weights.\nMake sure it's bigger than 0. If you don't specify the weight, it will default to 1.\n- And the <Command> is a command you want to run where the block breaks.\n\nAlso, you can put %%%%% between drops to create groups of drops. In a group, only the weight of\nthe first drop will count.\n\n###############################################  Examples  #############################################\nIf you wanted to add charcoal as a drop to coal ore (perhaps after removing coal), you could write:\n\n      minecraft:coal_ore-1.0-false-false-true_____i-minecraft:coal-1-1-1-1\n\nIf you wanted gold ore to drop 1-3 gold nuggets instead of the ore, you could first remove the gold block drop\nin the removing section then add the following entries (for the nuggets, and add the silk touch back in):\n\n      minecraft:gold_ore-1.0-false-false-true_____i-minecraft:gold_nugget-1-3\n      minecraft:gold_ore-1.0-false-true-false_____i-minecraft:gold_ore-1-1\n\nIf you also wanted the gold ore to drop xp when mined, you could also add:\n\n      minecraft:gold_ore-0.7-true-false-false_____e-XPOrb-1-{Value:1}_____e-XPOrb-1-{Value:2}_____e-XPOrb-1-{Value:3}\n\nTo create a group of drops, say for a fictitious 'wolf_ore' that drops a wolf spawn egg\nand plays a barking sound when broken:\n\n      lootplusplus:wolf_ore-1.0-false-false-false_____i-minecraft:spawn_egg-1-1-1-95%%%%%c-1-playsound mob.wolf.bark @a ~ ~ ~");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     dropsList = ConfigExtrasLoader.combineLists(blockDropConfig.get("adding", "Drops to add to blocks:", new String[0]).getStringList(), this.namesToExtras.get("adding"));
/*     */     
/* 235 */     for (index = 0; index < dropsList.size(); index++) {
/* 236 */       String entry = dropsList.get(index);
/*     */ 
/*     */       
/* 239 */       boolean comment = false;
/* 240 */       String title = getFileName() + ".cfg 'adding' #" + index + '\001';
/*     */       
/* 242 */       if (entry.length() > 0) {
/* 243 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/*     */       try {
/* 247 */         String[] dropStrings = entry.split("_____");
/*     */         
/* 249 */         if (dropStrings.length < 2) {
/* 250 */           if (!entry.equals("")) {
/* 251 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 256 */           String[] split = dropStrings[0].split("-");
/*     */           
/* 258 */           if (split.length < 5) {
/* 259 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, dropStrings[0]);
/*     */           }
/*     */           else {
/*     */             
/* 263 */             String blockName = split[0];
/* 264 */             String rarityString = split[1];
/* 265 */             String playerString = split[2];
/* 266 */             String silkString = split[3];
/* 267 */             String fortuneString = split[4];
/* 268 */             int blockMeta = -1;
/*     */             
/* 270 */             Object blockObj = Block.field_149771_c.func_82594_a(blockName);
/*     */             
/* 272 */             if (blockObj == null || !(blockObj instanceof Block)) {
/* 273 */               LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*     */             }
/*     */             else {
/*     */               
/* 277 */               Block block = (Block)blockObj;
/*     */               
/* 279 */               float rarity = 1.0F;
/* 280 */               boolean bool1 = false;
/* 281 */               boolean silk = true;
/* 282 */               boolean fortune = true;
/* 283 */               ArrayList<ArrayList<LootPPHelper.DropInfo>> blockDrops = new ArrayList<ArrayList<LootPPHelper.DropInfo>>();
/*     */               
/*     */               try {
/* 286 */                 rarity = Float.valueOf(rarityString).floatValue();
/* 287 */                 bool1 = Boolean.valueOf(playerString).booleanValue();
/* 288 */                 silk = Boolean.valueOf(silkString).booleanValue();
/* 289 */                 fortune = Boolean.valueOf(fortuneString).booleanValue();
/* 290 */                 if (split.length > 5) {
/* 291 */                   blockMeta = Integer.valueOf(split[5]).intValue();
/*     */                 }
/*     */               }
/* 294 */               catch (NumberFormatException e) {
/* 295 */                 if (!comment) {
/* 296 */                   System.err.println("[Loot++] Caught an exception while loading a block drop addition.");
/* 297 */                   e.printStackTrace();
/* 298 */                   LootPPNotifier.notifyNumber(comment, title, rarityString + ", " + playerString + ", " + silkString + ", " + fortuneString + ((split.length > 5) ? (", " + split[5]) : ""));
/*     */                 } 
/*     */               } 
/*     */               
/* 302 */               MathHelper.func_76131_a(rarity, 0.0F, 1.0F);
/*     */               
/* 304 */               if (blockMeta < 0) {
/* 305 */                 blockMeta = 32767;
/*     */               }
/*     */               
/* 308 */               for (int i = 1; i < dropStrings.length; i++) {
/* 309 */                 String dropString = dropStrings[i];
/*     */                 
/* 311 */                 if (!dropString.equals("")) {
/*     */ 
/*     */ 
/*     */                   
/* 315 */                   String[] subParts = dropString.split("%%%%%");
/*     */                   
/* 317 */                   ArrayList<LootPPHelper.DropInfo> infoList = new ArrayList<LootPPHelper.DropInfo>();
/*     */                   
/* 319 */                   for (int j = 0; j < subParts.length; j++) {
/*     */                     
/* 321 */                     String subString = subParts[j];
/*     */                     
/* 323 */                     int dashIndex = subString.indexOf("-");
/*     */                     
/* 325 */                     if (dashIndex >= 0) {
/*     */ 
/*     */ 
/*     */                       
/* 329 */                       char type = subString.charAt(0);
/*     */                       
/* 331 */                       LootPPHelper.DropInfo info = LootPPHelper.getDropInfo(type, subString.substring(dashIndex + 1), comment, title);
/*     */                       
/* 333 */                       if (info != null) {
/* 334 */                         infoList.add(info);
/*     */                       }
/*     */                     } 
/*     */                   } 
/*     */                   
/* 339 */                   if (!infoList.isEmpty()) {
/* 340 */                     blockDrops.add(infoList);
/*     */                   }
/*     */                 } 
/*     */               } 
/*     */               
/* 345 */               if (!blockDrops.isEmpty())
/* 346 */               { addAdditionForState(new LootPPHelper.BlockMeta(block, blockMeta), blockDrops, rarity, bool1, silk, fortune);
/*     */                  }
/*     */               
/* 349 */               else if (LootPlusPlusMod.debug) { System.out.println("[Loot++] Drops List was empty for " + blockName + "!"); } 
/*     */             } 
/*     */           } 
/*     */         } 
/* 353 */       } catch (Exception e) {
/* 354 */         if (!comment) {
/* 355 */           System.err.println("[Loot++] Caught an exception while loading block drops.");
/* 356 */           e.printStackTrace();
/* 357 */           LootPPNotifier.notify(comment, title, "=( Unexpected problem '" + e.getMessage() + "' while loading block drop additions for: " + entry);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 362 */     blockDropConfig.save();
/*     */   }
/*     */   
/*     */   private void addRemovalForState(LootPPHelper.BlockMeta blockMeta, ItemStack itemStack) {
/* 366 */     Set<ItemStack> itemSet = (Set<ItemStack>)LootPPHelper.blockDropRemovals.get(blockMeta);
/*     */     
/* 368 */     if (itemSet == null) {
/* 369 */       itemSet = new HashSet<ItemStack>();
/*     */     }
/* 371 */     itemSet.add(itemStack);
/*     */     
/* 373 */     LootPPHelper.blockDropRemovals.put(blockMeta, itemSet);
/*     */     
/* 375 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removing drop '" + itemStack + "' for blockstate '" + blockMeta + "'."); 
/*     */   }
/*     */   
/*     */   private void addAdditionForState(LootPPHelper.BlockMeta blockMeta, ArrayList<ArrayList<LootPPHelper.DropInfo>> blockDrops, float rarity, boolean player, boolean silk, boolean fortune) {
/* 379 */     ArrayList<LootPPHelper.BlockDropInfo> blockDropList = new ArrayList<LootPPHelper.BlockDropInfo>();
/*     */     
/* 381 */     blockDropList = (ArrayList<LootPPHelper.BlockDropInfo>)LootPPHelper.blockDropAdditions.get(blockMeta);
/* 382 */     if (blockDropList == null) {
/* 383 */       blockDropList = new ArrayList<LootPPHelper.BlockDropInfo>();
/*     */     }
/*     */     
/* 386 */     LootPPHelper.BlockDropInfo toAdd = new LootPPHelper.BlockDropInfo(rarity, player, silk, fortune);
/* 387 */     toAdd.dropList = blockDrops;
/* 388 */     blockDropList.add(toAdd);
/*     */     
/* 390 */     LootPPHelper.blockDropAdditions.put(blockMeta, blockDropList);
/* 391 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Adding " + toAdd.dropList.size() + " drop" + ((toAdd.dropList.size() == 1) ? "" : "s") + " for blockstate '" + blockMeta + "'."); 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderBlockDrops.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */