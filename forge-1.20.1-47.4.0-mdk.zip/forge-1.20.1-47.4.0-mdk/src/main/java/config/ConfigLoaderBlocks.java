/*      */ package com.tmtravlr.lootplusplus.config;
/*      */ import com.tmtravlr.lootplusplus.LootPPBlocks;
/*      */ import com.tmtravlr.lootplusplus.LootPPItems;
/*      */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*      */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedCake;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedCarpet;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedCrops;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedDoor;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedFenceGate;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedFurnace;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedLadder;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedMetadata;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedPillar;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedSlab;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedStairs;
/*      */ import com.tmtravlr.lootplusplus.additions.BlockAddedWall;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemBlockAdded;
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import net.minecraft.block.Block;
/*      */ import net.minecraft.block.material.Material;
/*      */ import net.minecraft.init.Blocks;
/*      */ import net.minecraft.item.Item;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.potion.Potion;
/*      */ import net.minecraft.potion.PotionEffect;
/*      */ import net.minecraft.util.BlockPos;
/*      */ import net.minecraft.util.MathHelper;
/*      */ import net.minecraftforge.common.config.Configuration;
/*      */ import net.minecraftforge.common.config.Property;
/*      */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*      */ 
/*      */ public class ConfigLoaderBlocks extends ConfigLoader {
/*   35 */   public static ConfigLoaderBlocks instance = new ConfigLoaderBlocks();
/*      */   Configuration blockConfig;
/*      */   
/*      */   ConfigLoaderBlocks() {
/*   39 */     this.namesToExtras.put("generic", new ArrayList<String>());
/*   40 */     this.namesToExtras.put("multiple_metadata", new ArrayList<String>());
/*   41 */     this.namesToExtras.put("logs_pillars", new ArrayList<String>());
/*   42 */     this.namesToExtras.put("plants", new ArrayList<String>());
/*   43 */     this.namesToExtras.put("slabs", new ArrayList<String>());
/*   44 */     this.namesToExtras.put("stairs", new ArrayList<String>());
/*   45 */     this.namesToExtras.put("tiles_carpets", new ArrayList<String>());
/*   46 */     this.namesToExtras.put("panes_bars", new ArrayList<String>());
/*   47 */     this.namesToExtras.put("walls", new ArrayList<String>());
/*   48 */     this.namesToExtras.put("fences", new ArrayList<String>());
/*   49 */     this.namesToExtras.put("buttons", new ArrayList<String>());
/*   50 */     this.namesToExtras.put("pressure_plates", new ArrayList<String>());
/*   51 */     this.namesToExtras.put("doors", new ArrayList<String>());
/*   52 */     this.namesToExtras.put("fence_gates", new ArrayList<String>());
/*   53 */     this.namesToExtras.put("ladders", new ArrayList<String>());
/*   54 */     this.namesToExtras.put("furnaces", new ArrayList<String>());
/*   55 */     this.namesToExtras.put("crafting_tables", new ArrayList<String>());
/*   56 */     this.namesToExtras.put("cakes", new ArrayList<String>());
/*   57 */     this.namesToExtras.put("crops", new ArrayList<String>());
/*      */   }
/*      */   
/*      */   public String getFileName() {
/*   61 */     return "block_additions";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadBlockAdditions() {
/*   67 */     this.blockConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   73 */     this.blockConfig.load();
/*      */     
/*   75 */     Property temp = this.blockConfig.get("add_generic", "generic", new String[0]);
/*   76 */     temp.comment = "This adds full 1m cube with a very long list of options in the format:\n\n      <Block name>_____<Block display name>_____<Block material>_____<Falls (like sand, true or false)>_____<Beacon Base (true or false)>_____<Hardness>_____<Explosion resistance>_____<Harvesting item type>_____<Harvest level (-1 for any)>_____<Light emitted>_____<Slipperiness>_____<Fire Spread Speed>_____<Flammability>_____<Opacity>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Block material> is one of the default materials (determines some things about\nthe block like footstep sounds and such). The possible values are:\n\n      air, anvil, cactus, cake, carpet, circuits, clay, cloth, coral, craftedSnow, dragonEgg, fire\n      glass, gourd, grass, ground, ice, iron, lava, leaves, packedIce, piston, plants, portal\n      redstoneLight, rock, sand, snow, sponge, tnt, vine, water, web, wood\n\n- If <Falls> is true, the block will fall like sand.\n- If <Beacon Base> is true, the block can be used for beacon bases.\n- The <Hardness> is a float that determines how long the block takes to break. If it is\nnegative, the block will be unbreakable like bedrock.\n- The <Explosion resistance> is a float that represents how resistant the block is to explosions.\n- The <Harvesting item type> is a tool type. The default options are 'pickaxe', 'shovel',\n'axe', or 'none'.\n- The <Harvest level> is what level of tool can harvest the block if the tool type is not\n'none'; the default levels are wood and gold = 0, stone = 1, iron = 2, and diamond = 3.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The <Slipperiness> is how slippery the block is, with 0.6 as normal and ice as 0.98.\n- The higher the <Fire spread speed>, the faster the block will catch fire (0 for none).\n- The higher the <Flammability>, the faster the block will burn and disappear (0 for none).\n- The <Opacity> is how opaque the block is, with 0 being transparent, and 255 being almost\ntotally opaque. If -1, the block will be totally opaque.\n\nHere are some examples of what default blocks would look like:\n\nWood Planks: planks_oak_____Oak Planks_____wood_____false_____false_____2.0_____5.0_____axe_____-1_____0.0_____0.6_____5_____20_____-1\nStone:       stone_____Stone_____rock_____false_____false_____1.5_____10.0_____pickaxe_____0_____0.0_____0.6_____0_____0_____-1\nIron:        iron_block_____Iron Block_____metal_____false_____true_____5.0_____10.0_____pickaxe_____1_____0.0_____0.6_____0_____0_____-1\nSand:        sand_____Sand_____sand_____true_____false_____0.5_____0.0_____shovel_____-1_____0.0_____0.6_____0_____0_____-1\nGlowstone:   glowstone_____Glowstone_____glass_____false_____false_____0.3_____0.0_____none_____-1_____1.0_____0.6_____0_____0_____-1\nPacked Ice:  packed_ice_____Packed Ice_____glass_____false_____false_____0.5_____0.0_____pickaxe_____-1_____0.0_____0.98_____0_____0_____-1\nIce:         ice_____Ice_____ice_____false_____false_____0.5_____0.0_____pickaxe_____-1_____0.0_____0.98_____0_____0_____3\nObsidian:    obsidian_____Obsidian_____rock_____false_____false_____50.0_____2000.0_____pickaxe_____3_____0.0_____0.6_____0_____0_____-1\nBedrock:     bedrock_____Bedrock_____rock_____false_____false_____-1.0_____6000000.0_____pickaxe_____-1_____0.0_____0.6_____0_____0_____-1\nGlass:       glass_____Glass_____glass_____false_____false_____0.3_____0.0_____none_____-1_____0.0_____0.6_____0_____0_____0\n\nFor an example, if you wanted to add a ruby ore and resource block for ruby, you could put:\n\n      ruby_ore_____Ruby Ore_____rock_____false_____false_____3.0_____5.0_____pickaxe_____2_____0.0_____0.6_____0_____0_____-1\n      ruby_block_____Ruby Block_____iron_____false_____true_____5.0_____10.0_____pickaxe_____2_____0.0_____0.6_____0_____0_____-1";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  126 */     ArrayList<String> infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("generic"));
/*      */     int index;
/*  128 */     for (index = 0; index < infoList.size(); index++) {
/*  129 */       String info = infoList.get(index);
/*  130 */       String title = getFileName() + ".cfg 'generic' #" + (index + 1);
/*      */       
/*  132 */       boolean comment = false;
/*      */       
/*  134 */       if (info.length() > 0) {
/*  135 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  138 */       if (!comment) {
/*      */         
/*  140 */         String[] parts = info.split("_____");
/*      */         
/*  142 */         if (parts.length != 14) {
/*  143 */           if (!info.equals("")) {
/*  144 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  149 */           String blockName = parts[0];
/*  150 */           String displayName = parts[1];
/*  151 */           String materialName = parts[2];
/*  152 */           boolean falls = false;
/*  153 */           boolean beaconBase = false;
/*  154 */           float hardness = 1.0F;
/*  155 */           float resistance = 0.0F;
/*  156 */           String toolType = parts[7];
/*  157 */           int harvestLevel = -1;
/*  158 */           float lightEmitted = 0.0F;
/*  159 */           float slipperiness = 0.0F;
/*  160 */           int fireSpread = 0;
/*  161 */           int flammability = 0;
/*  162 */           int opacity = -1;
/*      */           
/*      */           try {
/*  165 */             falls = Boolean.valueOf(parts[3]).booleanValue();
/*  166 */             beaconBase = Boolean.valueOf(parts[4]).booleanValue();
/*  167 */             hardness = Float.valueOf(parts[5]).floatValue();
/*  168 */             resistance = Float.valueOf(parts[6]).floatValue();
/*  169 */             harvestLevel = Integer.valueOf(parts[8]).intValue();
/*  170 */             lightEmitted = Float.valueOf(parts[9]).floatValue();
/*  171 */             slipperiness = Float.valueOf(parts[10]).floatValue();
/*  172 */             fireSpread = Integer.valueOf(parts[11]).intValue();
/*  173 */             flammability = Integer.valueOf(parts[12]).intValue();
/*  174 */             opacity = Integer.valueOf(parts[13]).intValue();
/*      */           }
/*  176 */           catch (NumberFormatException e) {
/*  177 */             if (!comment) {
/*  178 */               System.err.println("[Loot++] Caught exception while trying to add a generic block " + blockName);
/*  179 */               e.printStackTrace();
/*  180 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[5], parts[6], parts[8], parts[9], parts[10], parts[11], parts[12], parts[13] });
/*      */             } 
/*      */           } 
/*  183 */           slipperiness = MathHelper.func_76131_a(slipperiness, 0.2F, 0.98F);
/*      */           
/*  185 */           Material blockMaterial = getMaterialFromString(materialName);
/*      */           
/*  187 */           if (blockMaterial == null) {
/*  188 */             LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + materialName);
/*      */           } else {
/*      */             Block block;
/*      */ 
/*      */             
/*  193 */             if (falls) {
/*  194 */               block = (new BlockAddedFalling(blockMaterial, opacity, beaconBase, toolType, harvestLevel, slipperiness, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(getSoundsFromString(materialName)).func_149715_a(lightEmitted).func_149663_c(blockName);
/*      */             } else {
/*      */               
/*  197 */               block = (new BlockAdded(blockMaterial, opacity, beaconBase, toolType, harvestLevel, slipperiness, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(getSoundsFromString(materialName)).func_149715_a(lightEmitted).func_149663_c(blockName);
/*      */             } 
/*  199 */             LootPPBlocks.addedBlocks.add(block);
/*  200 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/*  201 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/*  202 */             Blocks.field_150480_ab.func_180686_a(block, fireSpread, flammability);
/*      */             
/*  204 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom generic block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  208 */     }  temp = this.blockConfig.get("add_generic", "multiple_metadata", new String[0]);
/*  209 */     temp.comment = "This adds full 1m cube with 16 metadata values and options in the format:\n\n      <Block name>_____<Block display name 0>_____<Block display name 1>_____<Block display name 2>_____<Block display name 3>_____<Block display name 4>_____<Block display name 5>_____<Block display name 6>_____<Block display name 7>_____<Block display name 8>_____<Block display name 9>_____<Block display name 10>_____<Block display name 11>_____<Block display name 12>_____<Block display name 13>_____<Block display name 14>_____<Block display name 15>_____<Block material>_____<Beacon Base (true or false)>_____<Hardness>_____<Explosion resistance>_____<Harvesting item type>_____<Harvest level (-1 for any)>_____<Light emitted>_____<Slipperiness>_____<Fire Spread Speed>_____<Flammability>_____<Opacity>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>_0.json to <Block name>_15. Note that in your\nblockstates, you should have an entry for every metadata, from \"metadata=0\": to \"metadata=15\":\n- The <Block display name>s are what people will see ingame while holding the block.\n- The <Block material> is one of the default materials (determines some things about\nthe block like footstep sounds and such). The possible values are:\n\n      air, anvil, cactus, cake, carpet, circuits, clay, cloth, coral, craftedSnow, dragonEgg, fire\n      glass, gourd, grass, ground, ice, iron, lava, leaves, packedIce, piston, plants, portal\n      redstoneLight, rock, sand, snow, sponge, tnt, vine, water, web, wood\n\n- If <Beacon Base> is true, the block can be used for beacon bases.\n- The <Hardness> is a float that determines how long the block takes to break. If it is\nnegative, the block will be unbreakable like bedrock.\n- The <Explosion resistance> is a float that represents how resistant the block is to explosions.\n- The <Harvesting item type> is a tool type. The default options are 'pickaxe', 'shovel',\n'axe', or 'none'.\n- The <Harvest level> is what level of tool can harvest the block if the tool type is not\n'none'; the default levels are wood and gold = 0, stone = 1, iron = 2, and diamond = 3.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The <Slipperiness> is how slippery the block is, with 0.6 as normal and ice as 0.98.\n- The higher the <Fire spread speed>, the faster the block will catch fire (0 for none).\n- The higher the <Flammability>, the faster the block will burn and disappear (0 for none).\n- The <Opacity> is how opaque the block is, with 0 being transparent, and 255 being almost\ntotally opaque. If -1, the block will be totally opaque.\n\nHere are some examples of what default blocks would look like:\n\nWool:             wool_____White Wool_____Orange Wool_____Magenta Wool_____Light Blue Wool_____Yellow Wool_____Lime Wool_____Pink Wool_____Grey Wool_____Light Grey Wool_____Cyan Wool_____Purple Wool_____Blue Wool_____Brown Wool_____Green Wool_____Red Wool_____Black Wool_____cloth_____false_____0.8_____0.0_____none_____-1_____0.0_____0.6_____30_____60_____-1\nStained Glass:    stained_glass_____White Stained Glass_____Orange Stained Glass_____Magenta Stained Glass_____Light Blue Stained Glass_____Yellow Stained Glass_____Lime Stained Glass_____Pink Stained Glass_____Grey Stained Glass_____Light Grey Stained Glass_____Cyan Stained Glass_____Purple Stained Glass_____Blue Stained Glass_____Brown Stained Glass_____Green Stained Glass_____Red Stained Glass_____Black Stained Glass_____glass_____false_____0.3_____0.0_____none_____-1_____0.0_____0.6_____0_____0_____0\n\nFor an example, if you wanted to add 16 colours of bricks, assuming that you have\n16 models that you list in the blockstates file, you could put:\n\n      stained_bricks_____White Bricks_____Orange Bricks_____Magenta Bricks_____Light Blue Bricks_____Yellow Bricks_____Lime Bricks_____Pink Bricks_____Grey Bricks_____Light Grey Bricks_____Cyan Bricks_____Purple Bricks_____Blue Bricks_____Brown Bricks_____Green Bricks_____Red Bricks_____Black Bricks_____rock_____false_____3.0_____5.0_____pickaxe_____0_____0.0_____0.6_____0_____0_____-1";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  251 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("multiple_metadata"));
/*      */     
/*  253 */     for (index = 0; index < infoList.size(); index++) {
/*  254 */       String info = infoList.get(index);
/*  255 */       String title = getFileName() + ".cfg 'generic' #" + (index + 1);
/*      */       
/*  257 */       boolean comment = false;
/*      */       
/*  259 */       if (info.length() > 0) {
/*  260 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  263 */       if (!comment) {
/*      */         
/*  265 */         String[] parts = info.split("_____");
/*      */         
/*  267 */         if (parts.length != 28) {
/*  268 */           if (!info.equals("")) {
/*  269 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  274 */           String[] displayNames = new String[16];
/*      */           
/*  276 */           String blockName = parts[0];
/*  277 */           displayNames[0] = parts[1];
/*  278 */           displayNames[1] = parts[2];
/*  279 */           displayNames[2] = parts[3];
/*  280 */           displayNames[3] = parts[4];
/*  281 */           displayNames[4] = parts[5];
/*  282 */           displayNames[5] = parts[6];
/*  283 */           displayNames[6] = parts[7];
/*  284 */           displayNames[7] = parts[8];
/*  285 */           displayNames[8] = parts[9];
/*  286 */           displayNames[9] = parts[10];
/*  287 */           displayNames[10] = parts[11];
/*  288 */           displayNames[11] = parts[12];
/*  289 */           displayNames[12] = parts[13];
/*  290 */           displayNames[13] = parts[14];
/*  291 */           displayNames[14] = parts[15];
/*  292 */           displayNames[15] = parts[16];
/*  293 */           String materialName = parts[17];
/*  294 */           boolean beaconBase = false;
/*  295 */           float hardness = 1.0F;
/*  296 */           float resistance = 0.0F;
/*  297 */           String toolType = parts[21];
/*  298 */           int harvestLevel = -1;
/*  299 */           float lightEmitted = 0.0F;
/*  300 */           float slipperiness = 0.0F;
/*  301 */           int fireSpread = 0;
/*  302 */           int flammability = 0;
/*  303 */           int opacity = -1;
/*      */           
/*      */           try {
/*  306 */             beaconBase = Boolean.valueOf(parts[18]).booleanValue();
/*  307 */             hardness = Float.valueOf(parts[19]).floatValue();
/*  308 */             resistance = Float.valueOf(parts[20]).floatValue();
/*  309 */             harvestLevel = Integer.valueOf(parts[22]).intValue();
/*  310 */             lightEmitted = Float.valueOf(parts[23]).floatValue();
/*  311 */             slipperiness = Float.valueOf(parts[24]).floatValue();
/*  312 */             fireSpread = Integer.valueOf(parts[25]).intValue();
/*  313 */             flammability = Integer.valueOf(parts[26]).intValue();
/*  314 */             opacity = Integer.valueOf(parts[27]).intValue();
/*      */           }
/*  316 */           catch (NumberFormatException e) {
/*  317 */             if (!comment) {
/*  318 */               System.err.println("[Loot++] Caught exception while trying to add a generic block " + blockName);
/*  319 */               e.printStackTrace();
/*  320 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[18], parts[19], parts[20], parts[22], parts[23], parts[24], parts[25], parts[26], parts[27] });
/*      */             } 
/*      */           } 
/*  323 */           slipperiness = MathHelper.func_76131_a(slipperiness, 0.2F, 0.98F);
/*      */           
/*  325 */           Material blockMaterial = getMaterialFromString(materialName);
/*      */           
/*  327 */           if (blockMaterial == null) {
/*  328 */             LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + materialName);
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/*  334 */             Block block = (new BlockAddedMetadata(blockMaterial, opacity, beaconBase, toolType, harvestLevel, slipperiness, displayNames)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(getSoundsFromString(materialName)).func_149715_a(lightEmitted).func_149663_c(blockName);
/*      */             
/*  336 */             LootPPBlocks.addedBlocks.add(block);
/*  337 */             GameRegistry.registerBlock(block, ItemBlockAddedMultipleMeta.class, blockName);
/*  338 */             LootPlusPlusMod.proxy.registerVariants(Item.func_150898_a(block), new String[] { "lootplusplus:" + blockName + "_0", "lootplusplus:" + blockName + "_1", "lootplusplus:" + blockName + "_2", "lootplusplus:" + blockName + "_3", "lootplusplus:" + blockName + "_4", "lootplusplus:" + blockName + "_5", "lootplusplus:" + blockName + "_6", "lootplusplus:" + blockName + "_7", "lootplusplus:" + blockName + "_8", "lootplusplus:" + blockName + "_9", "lootplusplus:" + blockName + "_10", "lootplusplus:" + blockName + "_11", "lootplusplus:" + blockName + "_12", "lootplusplus:" + blockName + "_13", "lootplusplus:" + blockName + "_14", "lootplusplus:" + blockName + "_15" });
/*  339 */             for (int i = 0; i < 16; i++) {
/*  340 */               LootPlusPlusMod.proxy.registerBlockRenderWithDamage(block, i, blockName + "_" + i);
/*      */             }
/*  342 */             Blocks.field_150480_ab.func_180686_a(block, fireSpread, flammability);
/*      */             
/*  344 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom 16 meta block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  348 */     }  temp = this.blockConfig.get("add_generic", "logs/pillars", new String[0]);
/*  349 */     temp.comment = "This adds a pillar-like block with a very long list of options in the format:\n\n      <Block name>_____<Block display name>_____<Block material>_____<Beacon Base (true or false)>_____<Hardness>_____<Explosion resistance>_____<Harvesting item type>_____<Harvest level (-1 for any)>_____<Light emitted>_____<Slipperiness>_____<Fire Spread Speed>_____<Flammability>_____<Opacity>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Block material> is one of the default materials (determines some things about\nthe block like footstep sounds and such). The possible values are:\n\n      air, anvil, cactus, cake, carpet, circuits, clay, cloth, coral, craftedSnow, dragonEgg, fire\n      glass, gourd, grass, ground, ice, iron, lava, leaves, packedIce, piston, plants, portal\n      redstoneLight, rock, sand, snow, sponge, tnt, vine, water, web, wood\n\n- If <Beacon Base> is true, the block can be used for beacon bases.\n- The <Hardness> is a float that determines how long the block takes to break. If it is\nnegative, the block will be unbreakable like bedrock.\n- The <Explosion resistance> is a float that represents how resistant the block is to explosions.\n- The <Harvesting item type> is a tool type. The default options are 'pickaxe', 'shovel',\n'axe', or 'none'.\n- The <Harvest level> is what level of tool can harvest the block if the tool type is not\n'none'; the default levels are wood and gold = 0, stone = 1, iron = 2, and diamond = 3.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The <Slipperiness> is how slippery the block is, with 0.6 as normal and ice as 0.98.\n- The higher the <Fire spread speed>, the faster the block will catch fire (0 for none).\n- The higher the <Flammability>, the faster the block will burn and disappear (0 for none).\n- The <Opacity> is how opaque the block is, with 0 being transparent, and 255 being almost\ntotally opaque. If -1, the block will be totally opaque.\nHere are some examples of what default blocks would look like:\n\nOak Logs:      log_oak_____Oak Log_____wood_____false_____2.0_____0.0_____axe_____-1_____0.0_____0.6_____5_____5_____-1\nQuartz Pillar: quartz_pillar_____Quartz Pillar_____rock_____false_____0.8_____0.0_____pickaxe_____0_____0.0_____0.6_____0_____0_____-1\n\nFor an example, if you wanted to add a ruby pillar, you could put:\n\n      ruby_pillar_____Ruby Pillar_____iron_____true_____5.0_____10.0_____pickaxe_____2_____0.0_____0.6_____0_____0_____-1";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  389 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("logs_pillars"));
/*      */     
/*  391 */     for (index = 0; index < infoList.size(); index++) {
/*  392 */       String info = infoList.get(index);
/*  393 */       String title = getFileName() + ".cfg 'logs/pillars' #" + (index + 1);
/*      */       
/*  395 */       boolean comment = false;
/*      */       
/*  397 */       if (info.length() > 0) {
/*  398 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  401 */       if (!comment) {
/*      */         
/*  403 */         String[] parts = info.split("_____");
/*      */         
/*  405 */         if (parts.length != 13) {
/*  406 */           if (!info.equals("")) {
/*  407 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  412 */           String blockName = parts[0];
/*  413 */           String displayName = parts[1];
/*  414 */           String materialName = parts[2];
/*  415 */           boolean beaconBase = false;
/*  416 */           float hardness = 1.0F;
/*  417 */           float resistance = 0.0F;
/*  418 */           String toolType = parts[6];
/*  419 */           int harvestLevel = -1;
/*  420 */           float lightEmitted = 0.0F;
/*  421 */           float slipperiness = 0.0F;
/*  422 */           int fireSpread = 0;
/*  423 */           int flammability = 0;
/*  424 */           int opacity = -1;
/*      */           
/*      */           try {
/*  427 */             beaconBase = Boolean.valueOf(parts[3]).booleanValue();
/*  428 */             hardness = Float.valueOf(parts[4]).floatValue();
/*  429 */             resistance = Float.valueOf(parts[5]).floatValue();
/*  430 */             harvestLevel = Integer.valueOf(parts[7]).intValue();
/*  431 */             lightEmitted = Float.valueOf(parts[8]).floatValue();
/*  432 */             slipperiness = Float.valueOf(parts[9]).floatValue();
/*  433 */             fireSpread = Integer.valueOf(parts[10]).intValue();
/*  434 */             flammability = Integer.valueOf(parts[11]).intValue();
/*  435 */             opacity = Integer.valueOf(parts[12]).intValue();
/*      */           }
/*  437 */           catch (NumberFormatException e) {
/*  438 */             if (!comment) {
/*  439 */               System.err.println("[Loot++] Caught exception while trying to add a generic block " + blockName);
/*  440 */               e.printStackTrace();
/*  441 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[5], parts[7], parts[8], parts[9], parts[10], parts[11], parts[12] });
/*      */             } 
/*      */           } 
/*      */           
/*  445 */           slipperiness = MathHelper.func_76131_a(slipperiness, 0.2F, 0.98F);
/*      */           
/*  447 */           Material blockMaterial = getMaterialFromString(materialName);
/*      */           
/*  449 */           if (blockMaterial == null) {
/*  450 */             LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + materialName);
/*      */           }
/*      */           else {
/*      */             
/*  454 */             Block block = (new BlockAddedPillar(blockMaterial, opacity, beaconBase, toolType, harvestLevel, slipperiness, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(getSoundsFromString(materialName)).func_149715_a(lightEmitted).func_149663_c(blockName);
/*  455 */             LootPPBlocks.addedBlocks.add(block);
/*  456 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/*  457 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/*  458 */             Blocks.field_150480_ab.func_180686_a(block, fireSpread, flammability);
/*      */             
/*  460 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom pillar block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  464 */     }  temp = this.blockConfig.get("adding_decoration", "plants", new String[0]);
/*  465 */     temp.comment = "This adds a 'plant' (single crossed texture) in the format:\n\n      <Block name>_____<Block display name>_____<Block material>_____<Hardness>_____<Explosion resistance>_____<Harvesting item type>_____<Harvest level (-1 for any)>_____<Light emitted>_____<Fire Spread Speed>_____<Flammability>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Block material> is one of the default materials (determines some things about\nthe block like footstep sounds and such). The possible values are:\n\n      air, anvil, cactus, cake, carpet, circuits, clay, cloth, coral, craftedSnow, dragonEgg, fire\n      glass, gourd, grass, ground, ice, iron, lava, leaves, packedIce, piston, plants, portal\n      redstoneLight, rock, sand, snow, sponge, tnt, vine, water, web, wood\n\n- The <Hardness> is a float that determines how long the block takes to break.\n- The <Explosion resistance> is a float that represents how resistant the block is to explosions.\n- The <Harvesting item type> is a tool type. The default options are 'pickaxe', 'shovel',\n'axe', or 'none'.\n- The <Harvest level> is what level of tool can harvest the block if the tool type is not\n'none'; the default levels are wood and gold = 0, stone = 1, iron = 2, and diamond = 3.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The higher the <Fire spread speed>, the faster the block will catch fire (0 for none).\n- The higher the <Flammability>, the faster the block will burn and disappear (0 for none).\n\nHere is an example of what a default flower would look like:\n\n      dandelion_____Dandelion_____plants_____0.0_____0.0_____none_____-1_____0.0_____60_____100\n\nFor an example, if you wanted to add a ruby ore and resource block for ruby, you could put:\n\n      ruby_flower_____Ruby Flower_____plants_____0.0_____0.0_____none_____-1_____0.0_____60_____100\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  499 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("plants"));
/*      */     
/*  501 */     for (index = 0; index < infoList.size(); index++) {
/*  502 */       String info = infoList.get(index);
/*  503 */       String title = getFileName() + ".cfg 'plants' #" + (index + 1);
/*      */       
/*  505 */       boolean comment = false;
/*      */       
/*  507 */       if (info.length() > 0) {
/*  508 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  511 */       if (!comment) {
/*      */         
/*  513 */         String[] parts = info.split("_____");
/*      */         
/*  515 */         if (parts.length != 10) {
/*  516 */           if (!info.equals("")) {
/*  517 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  522 */           String blockName = parts[0];
/*  523 */           String displayName = parts[1];
/*  524 */           String materialName = parts[2];
/*  525 */           float hardness = 1.0F;
/*  526 */           float resistance = 0.0F;
/*  527 */           String toolType = parts[5];
/*  528 */           int harvestLevel = -1;
/*  529 */           float lightEmitted = 0.0F;
/*  530 */           int fireSpread = 0;
/*  531 */           int flammability = 0;
/*      */           
/*      */           try {
/*  534 */             hardness = Float.valueOf(parts[3]).floatValue();
/*  535 */             resistance = Float.valueOf(parts[4]).floatValue();
/*  536 */             harvestLevel = Integer.valueOf(parts[6]).intValue();
/*  537 */             lightEmitted = Float.valueOf(parts[7]).floatValue();
/*  538 */             fireSpread = Integer.valueOf(parts[8]).intValue();
/*  539 */             flammability = Integer.valueOf(parts[9]).intValue();
/*      */           }
/*  541 */           catch (NumberFormatException e) {
/*  542 */             if (!comment) {
/*  543 */               System.err.println("[Loot++] Caught exception while trying to add a plant block " + blockName);
/*  544 */               e.printStackTrace();
/*  545 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[6], parts[7], parts[8], parts[9] });
/*      */             } 
/*      */           } 
/*      */           
/*  549 */           Material blockMaterial = getMaterialFromString(materialName);
/*      */           
/*  551 */           if (blockMaterial == null) {
/*  552 */             LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + materialName);
/*      */           }
/*      */           else {
/*      */             
/*  556 */             Block block = (new BlockAddedPlant(blockMaterial, toolType, harvestLevel, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(getSoundsFromString(materialName)).func_149715_a(lightEmitted).func_149663_c(blockName);
/*  557 */             LootPPBlocks.addedBlocks.add(block);
/*  558 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/*  559 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/*  560 */             Blocks.field_150480_ab.func_180686_a(block, fireSpread, flammability);
/*      */             
/*  562 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom plant block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  566 */     }  temp = this.blockConfig.get("adding_decoration", "slabs", new String[0]);
/*  567 */     temp.comment = "This adds a half slab based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json, and also files for the double block\nassets/lootplusplus/blockstates/<Block name>_double.json and\nassets/lootplusplus/models/item/<Block name>_double.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n\nHere are some examples of what default blocks would look like:\n\nWood Slab:    wooden_slab_____Oak Slab_____minecraft:planks_____0\nStone Slab:   stone_slab_____Stone Slab_____minecraft:stone_____0\n\nFor an example, if you wanted to add a ruby slab, you could put:\n\n      ruby_block_slab_____Ruby Block Slab_____lootplusplus:ruby_block_____0\n      ruby_pillar_slab_____Ruby Pillar Slab_____lootplusplus:ruby_pillar_____0";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  591 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("slabs"));
/*      */     
/*  593 */     for (index = 0; index < infoList.size(); index++) {
/*  594 */       String info = infoList.get(index);
/*  595 */       String title = getFileName() + ".cfg 'slabs' #" + (index + 1);
/*      */       
/*  597 */       boolean comment = false;
/*      */       
/*  599 */       if (info.length() > 0) {
/*  600 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  603 */       if (!comment) {
/*      */         
/*  605 */         String[] parts = info.split("_____");
/*      */         
/*  607 */         if (parts.length != 4) {
/*  608 */           if (!info.equals("")) {
/*  609 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  614 */           String blockName = parts[0];
/*  615 */           String displayName = parts[1];
/*  616 */           String existingBlockName = parts[2];
/*  617 */           int meta = 0;
/*  618 */           float hardness = 1.0F;
/*  619 */           float resistance = 0.0F;
/*      */           
/*  621 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/*  623 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/*  624 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/*  628 */             Block base = (Block)blockObj;
/*      */ 
/*      */             
/*      */             try {
/*  632 */               meta = Integer.valueOf(parts[3]).intValue();
/*  633 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/*  634 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/*  636 */             catch (Exception e) {
/*  637 */               if (!comment) {
/*  638 */                 System.err.println("[Loot++] Caught exception while trying to add a slab " + blockName);
/*  639 */                 e.printStackTrace();
/*  640 */                 if (e instanceof NumberFormatException) {
/*  641 */                   LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/*  646 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/*  648 */             Material blockMaterial = base.func_149688_o();
/*      */ 
/*      */             
/*  651 */             Block half = (new BlockAddedSlab(blockMaterial, base.func_149662_c() ? -1 : base.func_149717_k(), base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), base.field_149765_K, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName);
/*  652 */             Block full = (new BlockAddedSlabFull(blockMaterial, base.func_149662_c() ? -1 : base.func_149717_k(), base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), base.field_149765_K, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName + "_double");
/*  653 */             ((BlockAddedSlab)half).full = full;
/*  654 */             ((BlockAddedSlab)full).slab = half;
/*  655 */             LootPPBlocks.addedBlocks.add(half);
/*  656 */             LootPPBlocks.addedBlocks.add(full);
/*  657 */             GameRegistry.registerBlock(half, ItemBlockAddedSlab.class, blockName);
/*  658 */             GameRegistry.registerBlock(full, null, blockName + "_double");
/*  659 */             LootPlusPlusMod.proxy.registerBlockRender(half);
/*  660 */             LootPlusPlusMod.proxy.registerBlockRender(full);
/*  661 */             Blocks.field_150480_ab.func_180686_a(half, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*  662 */             Blocks.field_150480_ab.func_180686_a(full, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/*  664 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom half slab block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  668 */     }  temp = this.blockConfig.get("adding_decoration", "stairs", new String[0]);
/*  669 */     temp.comment = "This adds stairs based on an existing block:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block these stairs should be based on.\n- The <Existing block metadata> is the metadata of the block these are based on.\n\nHere are some examples of what default blocks would look like:\n\nOak wood stairs:   oak_stairs_____Oak Stairs_____minecraft:planks_____0\nStone Brick Slab:  stonebrick_stairs_____Stone Brick Stairs_____minecraft:stonebrick_____0\n\nFor an example, if you wanted to add a ruby ore and resource block for ruby, you could put:\n\n      ruby_block_stairs_____Ruby Block Stairs_____lootplusplus:ruby_block_____0";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  690 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("stairs"));
/*      */     
/*  692 */     for (index = 0; index < infoList.size(); index++) {
/*  693 */       String info = infoList.get(index);
/*  694 */       String title = getFileName() + ".cfg 'stairs' #" + (index + 1);
/*      */       
/*  696 */       boolean comment = false;
/*      */       
/*  698 */       if (info.length() > 0) {
/*  699 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  702 */       if (!comment) {
/*      */         
/*  704 */         String[] parts = info.split("_____");
/*      */         
/*  706 */         if (parts.length != 4) {
/*  707 */           if (!info.equals("")) {
/*  708 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  713 */           String blockName = parts[0];
/*  714 */           String displayName = parts[1];
/*  715 */           String existingBlockName = parts[2];
/*  716 */           int meta = 0;
/*      */           
/*      */           try {
/*  719 */             meta = Integer.valueOf(parts[3]).intValue();
/*      */           }
/*  721 */           catch (NumberFormatException e) {
/*  722 */             if (!comment) {
/*  723 */               System.err.println("[Loot++] Caught exception while trying to add stairs " + blockName);
/*  724 */               e.printStackTrace();
/*  725 */               LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */             } 
/*      */           } 
/*      */           
/*  729 */           meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */           
/*  731 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/*  733 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/*  734 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/*  738 */             Block base = (Block)blockObj;
/*      */             
/*  740 */             Block block = (new BlockAddedStairs(base, meta, displayName)).func_149663_c(blockName);
/*  741 */             LootPPBlocks.addedBlocks.add(block);
/*  742 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/*  743 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/*  744 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/*  746 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom stairs block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  750 */     }  temp = this.blockConfig.get("adding_decoration", "tiles/carpets", new String[0]);
/*  751 */     temp.comment = "This adds a carpet-like block based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n\nFor an example, if you wanted to add a ruby block tile, you could put:\n\n      ruby_tile_____Ruby Tile_____lootplusplus:ruby_block_____0";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  767 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("tiles_carpets"));
/*      */     
/*  769 */     for (index = 0; index < infoList.size(); index++) {
/*  770 */       String info = infoList.get(index);
/*  771 */       String title = getFileName() + ".cfg 'tiles/carpets' #" + (index + 1);
/*      */       
/*  773 */       boolean comment = false;
/*      */       
/*  775 */       if (info.length() > 0) {
/*  776 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  779 */       if (!comment) {
/*      */         
/*  781 */         String[] parts = info.split("_____");
/*      */         
/*  783 */         if (parts.length != 4) {
/*  784 */           if (!info.equals("")) {
/*  785 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  790 */           String blockName = parts[0];
/*  791 */           String displayName = parts[1];
/*  792 */           String existingBlockName = parts[2];
/*  793 */           int meta = 0;
/*  794 */           float hardness = 1.0F;
/*  795 */           float resistance = 0.0F;
/*      */           
/*  797 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/*  799 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/*  800 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/*  804 */             Block base = (Block)blockObj;
/*      */ 
/*      */             
/*      */             try {
/*  808 */               meta = Integer.valueOf(parts[3]).intValue();
/*  809 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/*  810 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/*  812 */             catch (Exception e) {
/*  813 */               if (!comment) {
/*  814 */                 System.err.println("[Loot++] Caught exception while trying to add carpet " + blockName);
/*  815 */                 e.printStackTrace();
/*  816 */                 if (e instanceof NumberFormatException) {
/*  817 */                   LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/*  822 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/*  824 */             Material blockMaterial = base.func_149688_o();
/*      */             
/*  826 */             Block block = (new BlockAddedCarpet(blockMaterial, base.func_149717_k(), base.func_149662_c(), false, base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), base.field_149765_K, displayName)).func_149711_c(hardness / 2.0F).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName);
/*  827 */             LootPPBlocks.addedBlocks.add(block);
/*  828 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/*  829 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/*  830 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/*  832 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom carpet block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  836 */     }  temp = this.blockConfig.get("adding_decoration", "panes/bars", new String[0]);
/*  837 */     temp.comment = "This adds a glass-pane-like block based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n\nHere are some examples of what default blocks would look like:\n\nGlass Pane:  glass_pane_____Glass Pane_____minecraft:glass_____0\nIron Bars:   iron_bars_____Iron Bars_____minecraft:iron_block_____0\n\nFor an example, if you wanted to add ruby bars, you could put:\n\n      ruby_bars_____Ruby Bars_____lootplusplus:ruby_block_____0";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  858 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("panes_bars"));
/*      */     
/*  860 */     for (index = 0; index < infoList.size(); index++) {
/*  861 */       String info = infoList.get(index);
/*  862 */       String title = getFileName() + ".cfg 'panes/bars' #" + (index + 1);
/*      */       
/*  864 */       boolean comment = false;
/*      */       
/*  866 */       if (info.length() > 0) {
/*  867 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  870 */       if (!comment) {
/*      */         
/*  872 */         String[] parts = info.split("_____");
/*      */         
/*  874 */         if (parts.length != 4) {
/*  875 */           if (!info.equals("")) {
/*  876 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  881 */           String blockName = parts[0];
/*  882 */           String displayName = parts[1];
/*  883 */           String existingBlockName = parts[2];
/*  884 */           int meta = 0;
/*  885 */           float hardness = 1.0F;
/*  886 */           float resistance = 0.0F;
/*      */           
/*  888 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/*  890 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/*  891 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/*  895 */             Block base = (Block)blockObj;
/*      */ 
/*      */             
/*      */             try {
/*  899 */               meta = Integer.valueOf(parts[3]).intValue();
/*  900 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/*  901 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/*  903 */             catch (Exception e) {
/*  904 */               if (!comment) {
/*  905 */                 System.err.println("[Loot++] Caught exception while trying to add a pane " + blockName);
/*  906 */                 e.printStackTrace();
/*  907 */                 if (e instanceof NumberFormatException) {
/*  908 */                   LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/*  913 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/*  915 */             Material blockMaterial = base.func_149688_o();
/*      */             
/*  917 */             Block block = (new BlockAddedPane(blockMaterial, base.func_149662_c(), base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), base.field_149765_K, displayName)).func_149711_c(hardness / 2.0F).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName);
/*  918 */             LootPPBlocks.addedBlocks.add(block);
/*  919 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/*  920 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/*  921 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/*  923 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom pane block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  927 */     }  temp = this.blockConfig.get("adding_decoration", "walls", new String[0]);
/*  928 */     temp.comment = "This adds a cobblestone wall-like block based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n\nFor an example, if you wanted to add a ruby block wall, you could put:\n\n      ruby_wall_____Ruby Wall_____lootplusplus:ruby_block_____0";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  944 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("walls"));
/*      */     
/*  946 */     for (index = 0; index < infoList.size(); index++) {
/*  947 */       String info = infoList.get(index);
/*  948 */       String title = getFileName() + ".cfg 'walls' #" + (index + 1);
/*      */       
/*  950 */       boolean comment = false;
/*      */       
/*  952 */       if (info.length() > 0) {
/*  953 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  956 */       if (!comment) {
/*      */         
/*  958 */         String[] parts = info.split("_____");
/*      */         
/*  960 */         if (parts.length != 4) {
/*  961 */           if (!info.equals("")) {
/*  962 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/*  967 */           String blockName = parts[0];
/*  968 */           String displayName = parts[1];
/*  969 */           String existingBlockName = parts[2];
/*  970 */           int meta = 0;
/*  971 */           float hardness = 1.0F;
/*  972 */           float resistance = 0.0F;
/*      */           
/*  974 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/*  976 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/*  977 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/*  981 */             Block base = (Block)blockObj;
/*      */ 
/*      */             
/*      */             try {
/*  985 */               meta = Integer.valueOf(parts[3]).intValue();
/*  986 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/*  987 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/*  989 */             catch (Exception e) {
/*  990 */               if (!comment) {
/*  991 */                 System.err.println("[Loot++] Caught exception while trying to add a wall " + blockName);
/*  992 */                 e.printStackTrace();
/*  993 */                 if (e instanceof NumberFormatException) {
/*  994 */                   LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/*  999 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/* 1001 */             Material blockMaterial = base.func_149688_o();
/*      */             
/* 1003 */             Block block = (new BlockAddedWall(base, base.func_149662_c(), base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), displayName)).func_149715_a(base.func_149750_m()).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149663_c(blockName);
/* 1004 */             LootPPBlocks.addedBlocks.add(block);
/* 1005 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1006 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1007 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/* 1009 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom wall block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1013 */     }  temp = this.blockConfig.get("adding_decoration", "fences", new String[0]);
/* 1014 */     temp.comment = "This adds a fence-like block based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n\nFor an example, if you wanted to add a ruby block fence, you could put:\n\n      ruby_fence_____Ruby Fence_____lootplusplus:ruby_block_____0";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1030 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("fences"));
/*      */     
/* 1032 */     for (index = 0; index < infoList.size(); index++) {
/* 1033 */       String info = infoList.get(index);
/* 1034 */       String title = getFileName() + ".cfg 'fences' #" + (index + 1);
/*      */       
/* 1036 */       boolean comment = false;
/*      */       
/* 1038 */       if (info.length() > 0) {
/* 1039 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1042 */       if (!comment) {
/*      */         
/* 1044 */         String[] parts = info.split("_____");
/*      */         
/* 1046 */         if (parts.length != 4) {
/* 1047 */           if (!info.equals("")) {
/* 1048 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1053 */           String blockName = parts[0];
/* 1054 */           String displayName = parts[1];
/* 1055 */           String existingBlockName = parts[2];
/* 1056 */           int meta = 0;
/* 1057 */           float hardness = 1.0F;
/* 1058 */           float resistance = 0.0F;
/*      */           
/* 1060 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/* 1062 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/* 1063 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/* 1067 */             Block base = (Block)blockObj;
/*      */ 
/*      */             
/*      */             try {
/* 1071 */               meta = Integer.valueOf(parts[3]).intValue();
/* 1072 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/* 1073 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/* 1075 */             catch (Exception e) {
/* 1076 */               if (!comment) {
/* 1077 */                 System.err.println("[Loot++] Caught exception while trying to add fence " + blockName);
/* 1078 */                 e.printStackTrace();
/* 1079 */                 if (e instanceof NumberFormatException) {
/* 1080 */                   LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/* 1085 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/* 1087 */             Material blockMaterial = base.func_149688_o();
/*      */             
/* 1089 */             Block block = (new BlockAddedFence(blockMaterial, base.func_149662_c(), base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName);
/* 1090 */             LootPPBlocks.addedBlocks.add(block);
/* 1091 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1092 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1093 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/* 1095 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom fence block: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1099 */     }  temp = this.blockConfig.get("adding_redstone_interacting", "buttons", new String[0]);
/* 1100 */     temp.comment = "This adds a button block based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>_____<Pressed time>_____<Arrows Trigger>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n- The <Pressed time> is how many ticks the button will stay pressed for. For wood buttons\nthis is 30, and for stone, 20 (Note there are 20 ticks per second).\n- If <Arrows trigger> is true, arrows will set off the button.\n\nFor an example, if you wanted to add a ruby button, which presses for 2 seconds, you could put:\n\n      ruby_button_____Ruby Button_____lootplusplus:ruby_block_____0_____40_____false";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1119 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("buttons"));
/*      */     
/* 1121 */     for (index = 0; index < infoList.size(); index++) {
/* 1122 */       String info = infoList.get(index);
/* 1123 */       String title = getFileName() + ".cfg 'buttons' #" + (index + 1);
/*      */       
/* 1125 */       boolean comment = false;
/*      */       
/* 1127 */       if (info.length() > 0) {
/* 1128 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1131 */       if (!comment) {
/*      */         
/* 1133 */         String[] parts = info.split("_____");
/*      */         
/* 1135 */         if (parts.length != 6) {
/* 1136 */           if (!info.equals("")) {
/* 1137 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1142 */           String blockName = parts[0];
/* 1143 */           String displayName = parts[1];
/* 1144 */           String existingBlockName = parts[2];
/* 1145 */           int meta = 0;
/* 1146 */           int tickRate = 20;
/* 1147 */           boolean arrowsTrigger = false;
/* 1148 */           float hardness = 1.0F;
/* 1149 */           float resistance = 0.0F;
/*      */           
/* 1151 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/* 1153 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/* 1154 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/* 1158 */             Block base = (Block)blockObj;
/*      */ 
/*      */             
/*      */             try {
/* 1162 */               meta = Integer.valueOf(parts[3]).intValue();
/* 1163 */               tickRate = Integer.valueOf(parts[4]).intValue();
/* 1164 */               arrowsTrigger = Boolean.valueOf(parts[5]).booleanValue();
/* 1165 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/* 1166 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/* 1168 */             catch (Exception e) {
/* 1169 */               if (!comment) {
/* 1170 */                 System.err.println("[Loot++] Caught exception while trying to add button " + blockName);
/* 1171 */                 e.printStackTrace();
/* 1172 */                 if (e instanceof NumberFormatException) {
/* 1173 */                   LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[5] });
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/* 1178 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/* 1180 */             Material blockMaterial = base.func_149688_o();
/*      */             
/* 1182 */             Block block = (new BlockAddedButton(arrowsTrigger, base.func_149662_c(), tickRate, base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), displayName)).func_149711_c(hardness / 2.0F).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName);
/* 1183 */             LootPPBlocks.addedBlocks.add(block);
/* 1184 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1185 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1186 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/* 1188 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom button: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1192 */     }  temp = this.blockConfig.get("adding_redstone_interacting", "pressure_plates", new String[0]);
/* 1193 */     temp.comment = "This adds a pressure plate block based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>_____<Pressed time>_____<Weight>_____<What triggers>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n- The <Pressed time> is how many ticks the plate will stay pressed for. For wood buttons\nthis is 30, and for stone, 20 (Note there are 20 ticks per second).\n- The <Weight> is how many valid entities have to be on the plate for it to output a full\nrestone signal.\n- <What triggers> determines what sets off the pressure plate. The valid options are\n\n      everything, mobs, players, items\n\nThe default pressure plates could be represented with:\n\nWooden:  wooden_pressure_plate_____Wooden Pressure Plate_____minecraft:planks_____0_____20_____1_____everything\nStone:   stone_pressure_plate_____Stone Pressure Plate_____minecraft:stone_____0_____20_____1_____mobs\nIron:    iron_pressure_plate_____Iron Pressure Plate_____minecraft:iron_block_____0_____10_____150_____everything\nGold:    gold_pressure_plate_____Gold Pressure Plate_____minecraft:gold_block_____0_____10_____15_____everything\n\nFor an example, if you wanted to add a ruby pressure plate that will give a full redstone\nsignal when 10 players stand on it, and stays pressed for 2 seconds, you could put:\n\n      ruby_pressure_plate_____Ruby Pressure Plate_____lootplusplus:ruby_block_____0_____40_____10_____players";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1224 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("pressure_plates"));
/*      */     
/* 1226 */     for (index = 0; index < infoList.size(); index++) {
/* 1227 */       String info = infoList.get(index);
/* 1228 */       String title = getFileName() + ".cfg 'pressure_plates' #" + (index + 1);
/*      */       
/* 1230 */       boolean comment = false;
/*      */       
/* 1232 */       if (info.length() > 0) {
/* 1233 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1236 */       if (!comment) {
/*      */         
/* 1238 */         String[] parts = info.split("_____");
/*      */         
/* 1240 */         if (parts.length != 7) {
/* 1241 */           if (!info.equals("")) {
/* 1242 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1247 */           String blockName = parts[0];
/* 1248 */           String displayName = parts[1];
/* 1249 */           String existingBlockName = parts[2];
/* 1250 */           int meta = 0;
/* 1251 */           int time = 10;
/* 1252 */           int weight = 1;
/* 1253 */           String sensitivityName = parts[6];
/* 1254 */           float hardness = 1.0F;
/* 1255 */           float resistance = 0.0F;
/*      */           
/* 1257 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/* 1259 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/* 1260 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/* 1264 */             Block base = (Block)blockObj;
/*      */ 
/*      */             
/*      */             try {
/* 1268 */               meta = Integer.valueOf(parts[3]).intValue();
/* 1269 */               time = Integer.valueOf(parts[4]).intValue();
/* 1270 */               weight = Integer.valueOf(parts[5]).intValue();
/* 1271 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/* 1272 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/* 1274 */             catch (Exception e) {
/* 1275 */               if (!comment) {
/* 1276 */                 System.err.println("[Loot++] Caught exception while trying to add pressure plate " + blockName);
/* 1277 */                 e.printStackTrace();
/* 1278 */                 if (e instanceof NumberFormatException) {
/* 1279 */                   LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[5] });
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/* 1284 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/* 1286 */             if (weight < 1) {
/* 1287 */               weight = 1;
/*      */             }
/*      */             
/* 1290 */             Material blockMaterial = base.func_149688_o();
/*      */             
/* 1292 */             Block block = (new BlockAddedPressurePlate(blockMaterial, sensitivityName, time, weight, base.func_149662_c(), base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), displayName)).func_149711_c(hardness / 2.0F).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName);
/* 1293 */             LootPPBlocks.addedBlocks.add(block);
/* 1294 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1295 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1296 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/* 1298 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom pressure plate: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1302 */     }  temp = this.blockConfig.get("adding_redstone_interacting", "doors", new String[0]);
/* 1303 */     temp.comment = "This adds a door block based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>_____<Only redstone opens (true or false)>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Item name> is the name the door item will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include an item model for the door item at\nassets/lootplusplus/models/item/<Block name>_item.json\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n- If <Only redstone opens> is true, the door can only be openned with a redstone signal\n\nThe default doors could be represented with:\n\nWooden: wooden_door_____Wooden Door_____minecraft:planks_____0_____false\nIron:   iron_door_____Iron Door_____minecraft:iron_block_____0_____true\n\nFor an example, if you wanted to add a ruby door that only opens with redstone, you could put:\n\n      ruby_door_____Ruby Door_____lootplusplus:ruby_block_____0_____true";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1329 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("doors"));
/*      */     
/* 1331 */     for (index = 0; index < infoList.size(); index++) {
/* 1332 */       String info = infoList.get(index);
/* 1333 */       String title = getFileName() + ".cfg 'doors' #" + (index + 1);
/*      */       
/* 1335 */       boolean comment = false;
/*      */       
/* 1337 */       if (info.length() > 0) {
/* 1338 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1341 */       if (!comment) {
/*      */         
/* 1343 */         String[] parts = info.split("_____");
/*      */         
/* 1345 */         if (parts.length != 5) {
/* 1346 */           if (!info.equals("")) {
/* 1347 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1352 */           String blockName = parts[0];
/* 1353 */           String displayName = parts[1];
/* 1354 */           String existingBlockName = parts[2];
/* 1355 */           int meta = 0;
/* 1356 */           boolean onlyRedstone = false;
/* 1357 */           float hardness = 1.0F;
/* 1358 */           float resistance = 0.0F;
/*      */           
/* 1360 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/* 1362 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/* 1363 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/* 1367 */             Block base = (Block)blockObj;
/*      */             
/*      */             try {
/* 1370 */               meta = Integer.valueOf(parts[3]).intValue();
/* 1371 */               onlyRedstone = Boolean.valueOf(parts[4]).booleanValue();
/* 1372 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/* 1373 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/* 1375 */             catch (Exception e) {
/* 1376 */               if (!comment) {
/* 1377 */                 System.err.println("[Loot++] Caught exception while trying to add door " + blockName);
/* 1378 */                 e.printStackTrace();
/* 1379 */                 if (e instanceof NumberFormatException) {
/* 1380 */                   LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4] });
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/* 1385 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/* 1387 */             Block block = (new BlockAddedDoor(base.func_149688_o(), onlyRedstone, base.func_149662_c(), base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), base.field_149765_K, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName);
/* 1388 */             Item blockItem = (new ItemBlockAddedDoor(block)).func_77655_b(blockName);
/* 1389 */             LootPPBlocks.addedBlocks.add(block);
/* 1390 */             LootPPItems.addedItems.add(blockItem);
/* 1391 */             GameRegistry.registerBlock(block, null, blockName);
/* 1392 */             GameRegistry.registerItem(blockItem, blockName);
/* 1393 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1394 */             LootPlusPlusMod.proxy.registerItemRender(blockItem);
/* 1395 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/* 1397 */             ((BlockAddedDoor)block).doorItem = blockItem;
/*      */             
/* 1399 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom door: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1403 */     }  temp = this.blockConfig.get("adding_redstone_interacting", "fence_gates", new String[0]);
/* 1404 */     temp.comment = "This adds a fence gate based on an existing block in the format:\n\n      <Block name>_____<Block display name>_____<Existing block name>_____<Existing block metadata>_____<Only redstone opens (true or false)>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Existing block name> is the name of the block the slab should be based on.\n- The <Existing block metadata> is the metadata of the block it is based on.\n- If <Only redstone opens> is true, the door can only be openned with a redstone signal\n\nFor an example, if you wanted to add a ruby fence gate that only opens with redstone, you could put:\n\n      ruby_fence_gate_____Ruby Fence Gate_____lootplusplus:ruby_block_____0_____true";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1421 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("fence_gates"));
/*      */     
/* 1423 */     for (index = 0; index < infoList.size(); index++) {
/* 1424 */       String info = infoList.get(index);
/* 1425 */       String title = getFileName() + ".cfg 'fence_gates' #" + (index + 1);
/*      */       
/* 1427 */       boolean comment = false;
/*      */       
/* 1429 */       if (info.length() > 0) {
/* 1430 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1433 */       if (!comment) {
/*      */         
/* 1435 */         String[] parts = info.split("_____");
/*      */         
/* 1437 */         if (parts.length != 5) {
/* 1438 */           if (!info.equals("")) {
/* 1439 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1444 */           String blockName = parts[0];
/* 1445 */           String displayName = parts[1];
/* 1446 */           String existingBlockName = parts[2];
/* 1447 */           int meta = 0;
/* 1448 */           boolean onlyRedstone = false;
/* 1449 */           float hardness = 1.0F;
/* 1450 */           float resistance = 0.0F;
/*      */           
/* 1452 */           Object blockObj = Block.field_149771_c.func_82594_a(existingBlockName);
/*      */           
/* 1454 */           if (blockObj == null || !(blockObj instanceof Block) || blockObj == Blocks.field_150350_a) {
/* 1455 */             LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*      */           }
/*      */           else {
/*      */             
/* 1459 */             Block base = (Block)blockObj;
/*      */             
/*      */             try {
/* 1462 */               meta = Integer.valueOf(parts[3]).intValue();
/* 1463 */               onlyRedstone = Boolean.valueOf(parts[4]).booleanValue();
/* 1464 */               hardness = base.func_176195_g(null, new BlockPos(0, 0, 0));
/* 1465 */               resistance = base.func_149638_a(null) * 5.0F / 3.0F;
/*      */             }
/* 1467 */             catch (Exception e) {
/* 1468 */               if (!comment) {
/* 1469 */                 System.err.println("[Loot++] Caught exception while trying to add fence gate " + blockName);
/* 1470 */                 e.printStackTrace();
/* 1471 */                 if (e instanceof NumberFormatException) {
/* 1472 */                   LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4] });
/*      */                 }
/*      */               } 
/*      */             } 
/*      */             
/* 1477 */             meta = MathHelper.func_76125_a(meta, 0, 15);
/*      */             
/* 1479 */             Material blockMaterial = base.func_149688_o();
/*      */             
/* 1481 */             Block block = (new BlockAddedFenceGate(blockMaterial, onlyRedstone, base.func_149662_c(), base.getHarvestTool(base.func_176203_a(meta)), base.getHarvestLevel(base.func_176203_a(meta)), base.field_149765_K, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(base.field_149762_H).func_149715_a(base.func_149750_m()).func_149663_c(blockName);
/* 1482 */             LootPPBlocks.addedBlocks.add(block);
/* 1483 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1484 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1485 */             Blocks.field_150480_ab.func_180686_a(block, Blocks.field_150480_ab.func_176534_d(base), Blocks.field_150480_ab.func_176532_c(base));
/*      */             
/* 1487 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom fence gate: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1491 */     }  temp = this.blockConfig.get("adding_interactable", "ladders", new String[0]);
/* 1492 */     temp.comment = "This adds a ladder block in the format:\n\n      <Block name>_____<Block display name>_____<Hardness>_____<Explosion resistance>_____<Harvesting item type>_____<Harvest level (-1 for any)>_____<Light emitted>_____<Fire Spread Speed>_____<Flammability>_____<Slipperiness>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Hardness> is a float that determines how long the block takes to break.\n- The <Explosion resistance> is a float that represents how resistant the block is to explosions.\n- The <Harvesting item type> is a tool type. The default options are 'pickaxe', 'shovel',\n'axe', or 'none'.\n- The <Harvest level> is what level of tool can harvest the block if the tool type is not\n'none'; the default levels are wood and gold = 0, stone = 1, iron = 2, and diamond = 3.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The higher the <Fire spread speed>, the faster the block will catch fire (0 for none).\n- The higher the <Flammability>, the faster the block will burn and disappear (0 for none).\n- The <Slipperiness> is how slippery the block is, with 0.6 as normal and ice as 0.98.\n\nFor an example, if you wanted to add a ruby ladder, you could put:\n\n      ruby_ladder_____Ruby Ladder_____3.0_____10.0_____pickaxe_____2_____0.0_____0_____0_____0.6\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1516 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("ladders"));
/*      */     
/* 1518 */     for (index = 0; index < infoList.size(); index++) {
/* 1519 */       String info = infoList.get(index);
/* 1520 */       String title = getFileName() + ".cfg 'ladders' #" + (index + 1);
/*      */       
/* 1522 */       boolean comment = false;
/*      */       
/* 1524 */       if (info.length() > 0) {
/* 1525 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1528 */       if (!comment) {
/*      */         
/* 1530 */         String[] parts = info.split("_____");
/*      */         
/* 1532 */         if (parts.length != 10) {
/* 1533 */           if (!info.equals("")) {
/* 1534 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1539 */           String blockName = parts[0];
/* 1540 */           String displayName = parts[1];
/* 1541 */           float hardness = 1.0F;
/* 1542 */           float resistance = 0.0F;
/* 1543 */           String toolType = parts[4];
/* 1544 */           int harvestLevel = -1;
/* 1545 */           float lightEmitted = 0.0F;
/* 1546 */           int fireSpread = 0;
/* 1547 */           int flammability = 0;
/* 1548 */           float slipperiness = 0.6F;
/*      */           
/*      */           try {
/* 1551 */             hardness = Float.valueOf(parts[2]).floatValue();
/* 1552 */             resistance = Float.valueOf(parts[3]).floatValue();
/* 1553 */             harvestLevel = Integer.valueOf(parts[5]).intValue();
/* 1554 */             lightEmitted = Float.valueOf(parts[6]).floatValue();
/* 1555 */             fireSpread = Integer.valueOf(parts[7]).intValue();
/* 1556 */             flammability = Integer.valueOf(parts[8]).intValue();
/* 1557 */             slipperiness = Float.valueOf(parts[9]).floatValue();
/*      */           }
/* 1559 */           catch (NumberFormatException e) {
/* 1560 */             if (!comment) {
/* 1561 */               System.err.println("[Loot++] Caught exception while trying to add a ladder " + blockName);
/* 1562 */               e.printStackTrace();
/* 1563 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[2], parts[3], parts[5], parts[6], parts[7], parts[8], parts[9] });
/*      */             } 
/*      */           } 
/*      */           
/* 1567 */           slipperiness = MathHelper.func_76131_a(slipperiness, 0.2F, 0.98F);
/*      */           
/* 1569 */           Block block = (new BlockAddedLadder(toolType, harvestLevel, slipperiness, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(Block.field_149774_o).func_149715_a(lightEmitted).func_149663_c(blockName);
/* 1570 */           LootPPBlocks.addedBlocks.add(block);
/* 1571 */           GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1572 */           LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1573 */           Blocks.field_150480_ab.func_180686_a(block, fireSpread, flammability);
/*      */           
/* 1575 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom ladder: lootplusplus:" + blockName); 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1579 */     temp = this.blockConfig.get("adding_interactable", "furnaces", new String[0]);
/* 1580 */     temp.comment = "This adds a furnace block in the format:\n\n      <Block name>_____<Block display name>_____<Block material>_____<Hardness>_____<Explosion resistance>_____<Harvesting item type>_____<Harvest level (-1 for any)>_____<Light emitted>_____<Slipperiness>_____<Speed>_____<Opacity>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack with suffixes _lit and _unlit. So the files would be at\nassets/lootplusplus/blockstates/<Block name>_lit.json, assets/lootplusplus/models/item/<Block name>_lit.json,\nassets/lootplusplus/blockstates/<Block name>_unlit.json, assets/lootplusplus/models/item/<Block name>_unlit.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Block material> is one of the default materials. (In this case the material is hard\ncoded to be 'rock', so this will only determine mining/footstep sounds!) The possible values are:\n\n      air, anvil, cactus, cake, carpet, circuits, clay, cloth, coral, craftedSnow, dragonEgg, fire\n      glass, gourd, grass, ground, ice, iron, lava, leaves, packedIce, piston, plants, portal\n      redstoneLight, rock, sand, snow, sponge, tnt, vine, water, web, wood\n\n- The <Hardness> is a float that determines how long the block takes to break.\n- The <Explosion resistance> is a float that represents how resistant the block is to explosions.\n- The <Harvesting item type> is a tool type. The default options are 'pickaxe', 'shovel',\n'axe', or 'none'.\n- The <Harvest level> is what level of tool can harvest the block if the tool type is not\n'none'; the default levels are wood and gold = 0, stone = 1, iron = 2, and diamond = 3.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The <Slipperiness> is how slippery the block is, with 0.6 as normal and ice as 0.98.\n- The <Speed> is how fast the furnace runs, with 1.0 being normal, 2.0 twice as fast, ect.\n- The <Opacity> is how opaque the block is, with 0 being transparent, and 255 being almost\ntotally opaque. If -1, the block will be totally opaque.\n\nFor an example, if you wanted to add a ruby furnace which is a bit faster, you could put:\n\n      ruby_furnace_____Ruby Furnace_____iron_____3.0_____10.0_____pickaxe_____2_____0.0_____0.6_____1.5_____-1\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1613 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("furnaces"));
/*      */     
/* 1615 */     for (index = 0; index < infoList.size(); index++) {
/* 1616 */       String info = infoList.get(index);
/* 1617 */       String title = getFileName() + ".cfg 'furnaces' #" + (index + 1);
/*      */       
/* 1619 */       boolean comment = false;
/*      */       
/* 1621 */       if (info.length() > 0) {
/* 1622 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1625 */       if (!comment) {
/*      */         
/* 1627 */         String[] parts = info.split("_____");
/*      */         
/* 1629 */         if (parts.length != 11) {
/* 1630 */           if (!info.equals("")) {
/* 1631 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1636 */           String blockName = parts[0];
/* 1637 */           String displayName = parts[1];
/* 1638 */           String materialName = parts[2];
/* 1639 */           float hardness = 1.0F;
/* 1640 */           float resistance = 0.0F;
/* 1641 */           String toolType = parts[5];
/* 1642 */           int harvestLevel = -1;
/* 1643 */           float light = 0.0F;
/* 1644 */           float slipperiness = 0.6F;
/* 1645 */           float speed = 1.0F;
/* 1646 */           int opacity = -1;
/*      */           
/*      */           try {
/* 1649 */             hardness = Float.valueOf(parts[3]).floatValue();
/* 1650 */             resistance = Float.valueOf(parts[4]).floatValue();
/* 1651 */             harvestLevel = Integer.valueOf(parts[6]).intValue();
/* 1652 */             light = Float.valueOf(parts[7]).floatValue();
/* 1653 */             slipperiness = Float.valueOf(parts[8]).floatValue();
/* 1654 */             speed = Float.valueOf(parts[9]).floatValue();
/* 1655 */             opacity = Integer.valueOf(parts[10]).intValue();
/*      */           
/*      */           }
/* 1658 */           catch (NumberFormatException e) {
/* 1659 */             if (!comment) {
/* 1660 */               System.err.println("[Loot++] Caught exception while trying to add a furnace block " + blockName);
/* 1661 */               e.printStackTrace();
/* 1662 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[6], parts[7], parts[8], parts[9], parts[10] });
/*      */             } 
/*      */           } 
/*      */           
/* 1666 */           slipperiness = MathHelper.func_76131_a(slipperiness, 0.2F, 0.98F);
/*      */           
/* 1668 */           Material blockMaterial = getMaterialFromString(materialName);
/*      */           
/* 1670 */           if (blockMaterial == null) {
/* 1671 */             LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + materialName);
/*      */           }
/*      */           else {
/*      */             
/* 1675 */             Block block = (new BlockAddedFurnace(blockMaterial, speed, toolType, opacity, harvestLevel, light, slipperiness, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(getSoundsFromString(materialName)).func_149663_c(blockName);
/* 1676 */             LootPPBlocks.addedBlocks.add(block);
/* 1677 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1678 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/*      */             
/* 1680 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom furnace: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1684 */     }  temp = this.blockConfig.get("adding_interactable", "crafting_tables", new String[0]);
/* 1685 */     temp.comment = "This adds a crafting table with options in the format:\n\n      <Block name>_____<Block display name>_____<Block material>_____<Hardness>_____<Explosion resistance>_____<Harvesting item type>_____<Harvest level (-1 for any)>_____<Light emitted>_____<Slipperiness>_____<Fire Spread Speed>_____<Flammability>_____<Opacity>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Block display name> is what people will see ingame while holding the block.\n- The <Block material> is one of the default materials (determines some things about\nthe block like footstep sounds and such). The possible values are:\n\n      air, anvil, cactus, cake, carpet, circuits, clay, cloth, coral, craftedSnow, dragonEgg, fire\n      glass, gourd, grass, ground, ice, iron, lava, leaves, packedIce, piston, plants, portal\n      redstoneLight, rock, sand, snow, sponge, tnt, vine, water, web, wood\n\n- The <Hardness> is a float that determines how long the block takes to break. If it is\nnegative, the block will be unbreakable like bedrock.\n- The <Explosion resistance> is a float that represents how resistant the block is to explosions.\n- The <Harvesting item type> is a tool type. The default options are 'pickaxe', 'shovel',\n'axe', or 'none'.\n- The <Harvest level> is what level of tool can harvest the block if the tool type is not\n'none'; the default levels are wood and gold = 0, stone = 1, iron = 2, and diamond = 3.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The <Slipperiness> is how slippery the block is, with 0.6 as normal and ice as 0.98.\n- The higher the <Fire spread speed>, the faster the block will catch fire (0 for none).\n- The higher the <Flammability>, the faster the block will burn and disappear (0 for none).\n- The <Opacity> is how opaque the block is, with 0 being transparent, and 255 being almost\ntotally opaque. If -1, the block will be totally opaque.\nFor an example, if you wanted to add a ruby block crafting table, you could put:\n\n      ruby_crafting_table_____Ruby Crafting Table_____iron_____5.0_____10.0_____pickaxe_____2_____0.0_____0.6_____0_____0_____-1";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1719 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("crafting_tables"));
/*      */     
/* 1721 */     for (index = 0; index < infoList.size(); index++) {
/* 1722 */       String info = infoList.get(index);
/* 1723 */       String title = getFileName() + ".cfg 'crafting_tables' #" + (index + 1);
/*      */       
/* 1725 */       boolean comment = false;
/*      */       
/* 1727 */       if (info.length() > 0) {
/* 1728 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1731 */       if (!comment) {
/*      */         
/* 1733 */         String[] parts = info.split("_____");
/*      */         
/* 1735 */         if (parts.length != 12) {
/* 1736 */           if (!info.equals("")) {
/* 1737 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1742 */           String blockName = parts[0];
/* 1743 */           String displayName = parts[1];
/* 1744 */           String materialName = parts[2];
/* 1745 */           float hardness = 1.0F;
/* 1746 */           float resistance = 0.0F;
/* 1747 */           String toolType = parts[5];
/* 1748 */           int harvestLevel = -1;
/* 1749 */           float lightEmitted = 0.0F;
/* 1750 */           float slipperiness = 0.0F;
/* 1751 */           int fireSpread = 0;
/* 1752 */           int flammability = 0;
/* 1753 */           int opacity = -1;
/*      */           
/*      */           try {
/* 1756 */             hardness = Float.valueOf(parts[3]).floatValue();
/* 1757 */             resistance = Float.valueOf(parts[4]).floatValue();
/* 1758 */             harvestLevel = Integer.valueOf(parts[6]).intValue();
/* 1759 */             lightEmitted = Float.valueOf(parts[7]).floatValue();
/* 1760 */             slipperiness = Float.valueOf(parts[8]).floatValue();
/* 1761 */             fireSpread = Integer.valueOf(parts[9]).intValue();
/* 1762 */             flammability = Integer.valueOf(parts[10]).intValue();
/* 1763 */             opacity = Integer.valueOf(parts[11]).intValue();
/*      */           }
/* 1765 */           catch (NumberFormatException e) {
/* 1766 */             if (!comment) {
/* 1767 */               System.err.println("[Loot++] Caught exception while trying to add a crafting table " + blockName);
/* 1768 */               e.printStackTrace();
/* 1769 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[6], parts[7], parts[8], parts[9], parts[10], parts[11] });
/*      */             } 
/*      */           } 
/*      */           
/* 1773 */           slipperiness = MathHelper.func_76131_a(slipperiness, 0.2F, 0.98F);
/*      */           
/* 1775 */           Material blockMaterial = getMaterialFromString(materialName);
/*      */           
/* 1777 */           if (blockMaterial == null) {
/* 1778 */             LootPPNotifier.notify(comment, title, "Couldn't find a material for name: " + materialName);
/*      */           }
/*      */           else {
/*      */             
/* 1782 */             Block block = (new BlockAddedWorkbench(blockMaterial, opacity, toolType, harvestLevel, slipperiness, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(getSoundsFromString(materialName)).func_149715_a(lightEmitted).func_149663_c(blockName);
/*      */             
/* 1784 */             LootPPBlocks.addedBlocks.add(block);
/* 1785 */             GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1786 */             LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1787 */             Blocks.field_150480_ab.func_180686_a(block, fireSpread, flammability);
/*      */             
/* 1789 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom crafting table: lootplusplus:" + blockName); 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1793 */     }  temp = this.blockConfig.get("adding_interactable", "cakes", new String[0]);
/* 1794 */     temp.comment = "This adds a cake block with options in the format:\n\n      <Block name>_____<Block display name>_____<Hardness>_____<Explosion resistance>_____<Light emitted>_____<Slipperiness>_____<Fire Spread Speed>_____<Flammability>_____<Number of bites>_____<Hunger restored>_____<Saturation restored>_____<Always edible? (true or false)>_____<Potion effects given (optional)>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Hardness> is a float that determines how long the block takes to break. If it is\nnegative, the block will be unbreakable like bedrock.\n- The <Explosion resistance> is a float that represents how resistant the block is to explosions.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The <Slipperiness> is how slippery the block is, with 0.6 as normal and ice as 0.98.\n- The higher the <Fire spread speed>, the faster the block will catch fire (0 for none).\n- The higher the <Flammability>, the faster the block will burn and disappear (0 for none).\n- The <Number of bites> is how many bites the cake has.\n- The <Hunger restored> is the number of hunger points restored\n- The <Saturation restored> is the percentage of saturation restored\n- If <Always edible> is true, you can eat the cake even if you're not hungry\n- Finally the potions the food gives you is a list of potion effects in the format:\n\n      ..._____<Potion effect id>-<Potion duration>-<Potion level (0 is 1)>-<Probability (between 0.0 and 1.0)>-<Particle type (normal, faded, none)>_____...\n\nFor example, the vanilla cake (lol, I always laugh at that) would look like:\n\n      cake_____Cake_____0.3_____0.0_____0.0_____0.6_____0_____0_____7_____2_____0.1_____false\n\nFor an example, if you wanted to add a ruby cake that gives you health boost and is always\nedible, you could put:\n\n      ruby_apple_cake_____§bRuby Apple Cake_____0.6_____10.0_____0.0_____0.6_____0_____0_____7_____4_____0.5_____true_____10-150-1-1.0-normal_____21-2400-1-1.0-normal";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1826 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("cakes"));
/*      */     
/* 1828 */     for (index = 0; index < infoList.size(); index++) {
/* 1829 */       String info = infoList.get(index);
/* 1830 */       String title = getFileName() + ".cfg 'cakes' #" + (index + 1);
/*      */       
/* 1832 */       boolean comment = false;
/*      */       
/* 1834 */       if (info.length() > 0) {
/* 1835 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1838 */       if (!comment) {
/*      */         
/* 1840 */         String[] parts = info.split("_____");
/*      */         
/* 1842 */         if (parts.length < 12) {
/* 1843 */           if (!info.equals("")) {
/* 1844 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1849 */           String blockName = parts[0];
/* 1850 */           String displayName = parts[1];
/* 1851 */           float hardness = 1.0F;
/* 1852 */           float resistance = 0.0F;
/* 1853 */           float lightEmitted = 0.0F;
/* 1854 */           float slipperiness = 0.0F;
/* 1855 */           int fireSpread = 0;
/* 1856 */           int flammability = 0;
/* 1857 */           int slices = 7;
/* 1858 */           int hunger = 2;
/* 1859 */           float saturation = 0.1F;
/* 1860 */           boolean alwaysEat = false;
/*      */           
/*      */           try {
/* 1863 */             hardness = Float.valueOf(parts[2]).floatValue();
/* 1864 */             resistance = Float.valueOf(parts[3]).floatValue();
/* 1865 */             lightEmitted = Float.valueOf(parts[4]).floatValue();
/* 1866 */             slipperiness = Float.valueOf(parts[5]).floatValue();
/* 1867 */             fireSpread = Integer.valueOf(parts[6]).intValue();
/* 1868 */             flammability = Integer.valueOf(parts[7]).intValue();
/* 1869 */             slices = Integer.valueOf(parts[8]).intValue();
/* 1870 */             hunger = Integer.valueOf(parts[9]).intValue();
/* 1871 */             saturation = Float.valueOf(parts[10]).floatValue();
/* 1872 */             alwaysEat = Boolean.valueOf(parts[11]).booleanValue();
/*      */           }
/* 1874 */           catch (NumberFormatException e) {
/* 1875 */             if (!comment) {
/* 1876 */               System.err.println("[Loot++] Caught exception while trying to add a cake block " + blockName);
/* 1877 */               e.printStackTrace();
/* 1878 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[2], parts[3], parts[4], parts[5], parts[6], parts[7], parts[8], parts[9], parts[10], parts[11] });
/*      */             } 
/*      */           } 
/* 1881 */           BlockAddedCake.nextNumBites = slices;
/* 1882 */           Block block = (new BlockAddedCake(slipperiness, slices, hunger, saturation, alwaysEat, displayName)).func_149711_c(hardness).func_149752_b(resistance).func_149672_a(getSoundsFromString("cake")).func_149715_a(lightEmitted).func_149663_c(blockName);
/*      */           
/* 1884 */           LootPPBlocks.addedBlocks.add(block);
/* 1885 */           GameRegistry.registerBlock(block, ItemBlockAdded.class, blockName);
/* 1886 */           LootPlusPlusMod.proxy.registerBlockRender(block);
/* 1887 */           Blocks.field_150480_ab.func_180686_a(block, fireSpread, flammability);
/*      */           
/* 1889 */           if (parts.length > 12) {
/* 1890 */             for (int i = 12; i < parts.length; i++) {
/* 1891 */               String[] potionParts = parts[i].split("-");
/*      */               
/* 1893 */               if (potionParts.length != 5) {
/* 1894 */                 LootPPNotifier.notifyWrongNumberOfParts(comment, title, parts[i]);
/*      */                 
/*      */                 continue;
/*      */               } 
/* 1898 */               Potion potion = Potion.func_180142_b(potionParts[0]);
/* 1899 */               int potionDuration = 100;
/* 1900 */               int potionAmplifier = 0;
/* 1901 */               float probability = 1.0F;
/* 1902 */               String particles = potionParts[4];
/*      */               
/* 1904 */               if (potion == null) {
/*      */                 try {
/* 1906 */                   int effectId = Integer.valueOf(potionParts[0]).intValue();
/* 1907 */                   potion = Potion.field_76425_a[effectId];
/*      */                 }
/* 1909 */                 catch (NumberFormatException numberFormatException) {}
/*      */                 
/* 1911 */                 if (potion == null) {
/* 1912 */                   LootPPNotifier.notify(comment, title, "Couldn't find potion effect '" + potionParts[0] + "'");
/*      */                   
/*      */                   continue;
/*      */                 } 
/*      */               } 
/*      */               try {
/* 1918 */                 potionDuration = Integer.valueOf(potionParts[1]).intValue();
/* 1919 */                 potionAmplifier = Integer.valueOf(potionParts[2]).intValue();
/* 1920 */                 probability = Float.valueOf(potionParts[3]).floatValue();
/*      */               }
/* 1922 */               catch (NumberFormatException e) {
/* 1923 */                 if (!comment) {
/* 1924 */                   System.err.println("[Loot++] Caught an exception while trying to create a cake " + blockName);
/* 1925 */                   e.printStackTrace();
/* 1926 */                   LootPPNotifier.notifyNumber(comment, title, new String[] { potionParts[1], potionParts[2], potionParts[3] });
/*      */                 } 
/*      */               } 
/* 1929 */               PotionEffect effect = new PotionEffect(potion.func_76396_c(), potionDuration, potionAmplifier);
/* 1930 */               ((BlockAddedCake)block).addPotionEffect(effect, probability, particles);
/*      */               continue;
/*      */             } 
/*      */           }
/* 1934 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom cake block: lootplusplus:" + blockName);
/*      */         
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadCropAdditions() {
/* 1952 */     Property temp = this.blockConfig.get("adding_crops", "crops", new String[0]);
/* 1953 */     temp.comment = "This adds a crop block with options in the format:\n\n      <Block name>_____<Block display name>_____<Seed item name>_____<Seed item metadata>_____<Light emitted>_____<Fire Spread Speed>_____<Flammability>_____<Can bonemeal (true or false)>_____<Nether plant (true or false)>_____<Right click to harvest (true or false)>\n\n- The <Block name> is the name the block will be registered with (note that a\n'lootplusplus:' will be added to the front; don't add anything with a colon\nyourself!). You should also include a blockstate and item model file for each added\nblock in your resource pack at assets/lootplusplus/blockstates/<Block name>.json and\nassets/lootplusplus/models/item/<Block name>.json.\n- The <Seed item name> is the name of the item that is considered the seed for this crop.\n- The <Seed item metadata> is the metadata value of the seed item, with -1 for any.\n- The <Light emitted> is how much the block glows, from 0.0 to 1.0.\n- The higher the <Fire spread speed>, the faster the block will catch fire (0 for none).\n- The higher the <Flammability>, the faster the block will burn and disappear (0 for none).\n- If <Can bonemeal> is true, bonemeal will grow the crops.\n- If <Nether plant> is true, the crop should be planted on soul sand like nether wart.\n- If <Right click to harvest> is true, you can harvest and replant the crop by right clicking.\n\nFor example, wheat and nether wart would look something like:\n\n      wheat_____Wheat_____wheat_seeds_____-1_____0.0_____0_____0_____true_____false_____false\n      nether_wart_____Nether Wart_____nether_wart_____-1_____0.0_____0_____0_____false_____true_____false\n\nFor an example, if you wanted to add a 'ruby crop' that you can right click harvest, you could put:\n\n      ruby_crop_____Ruby Crop_____lootplusplus:ruby_____-1_____0.0_____0_____0_____true_____false_____true";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1979 */     ArrayList<String> infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("crops"));
/*      */     
/* 1981 */     for (int index = 0; index < infoList.size(); index++) {
/* 1982 */       String info = infoList.get(index);
/* 1983 */       String title = getFileName() + ".cfg 'crops' #" + (index + 1);
/*      */       
/* 1985 */       boolean comment = false;
/*      */       
/* 1987 */       if (info.length() > 0) {
/* 1988 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1991 */       if (!comment) {
/*      */         
/* 1993 */         String[] parts = info.split("_____");
/*      */         
/* 1995 */         if (parts.length < 10) {
/* 1996 */           if (!info.equals("")) {
/* 1997 */             LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 2002 */           String blockName = parts[0];
/* 2003 */           String displayName = parts[1];
/* 2004 */           String seedItemName = parts[2];
/* 2005 */           int seedItemMeta = -1;
/* 2006 */           float lightEmitted = 0.0F;
/* 2007 */           int fireSpread = 0;
/* 2008 */           int flammability = 0;
/* 2009 */           boolean bonemeal = true;
/* 2010 */           boolean nether = false;
/* 2011 */           boolean rightClick = false;
/*      */           
/*      */           try {
/* 2014 */             seedItemMeta = Integer.valueOf(parts[3]).intValue();
/* 2015 */             lightEmitted = Float.valueOf(parts[4]).floatValue();
/* 2016 */             fireSpread = Integer.valueOf(parts[5]).intValue();
/* 2017 */             flammability = Integer.valueOf(parts[6]).intValue();
/* 2018 */             bonemeal = Boolean.valueOf(parts[7]).booleanValue();
/* 2019 */             nether = Boolean.valueOf(parts[8]).booleanValue();
/* 2020 */             rightClick = Boolean.valueOf(parts[9]).booleanValue();
/*      */           }
/* 2022 */           catch (NumberFormatException e) {
/* 2023 */             if (!comment) {
/* 2024 */               System.err.println("[Loot++] Caught exception while trying to add a cake block " + blockName);
/* 2025 */               e.printStackTrace();
/* 2026 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[5], parts[6], parts[7], parts[8], parts[9] });
/*      */             } 
/*      */           } 
/*      */           
/* 2030 */           if (seedItemMeta < 0) seedItemMeta = 32767;
/*      */           
/* 2032 */           Object itemObj = Item.field_150901_e.func_82594_a(seedItemName);
/*      */           
/* 2034 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 2035 */             LootPPNotifier.notifyNonexistant(comment, title, seedItemName);
/*      */           }
/*      */           
/* 2038 */           Item item = (Item)itemObj;
/*      */           
/* 2040 */           ItemStack seedItem = new ItemStack(item, 1, seedItemMeta);
/*      */           
/* 2042 */           if (BlockAddedCrops.itemToCrop.keySet().contains(seedItem))
/* 2043 */           { LootPPNotifier.notify(comment, title, "A custom crop block is already registered for 'seed' item " + seedItemName + " with meta " + seedItemMeta); }
/*      */           
/*      */           else
/*      */           
/* 2047 */           { Block block = (new BlockAddedCrops(seedItem, bonemeal, nether, rightClick, displayName)).func_149672_a(getSoundsFromString("plants")).func_149715_a(lightEmitted).func_149663_c(blockName);
/*      */             
/* 2049 */             LootPPBlocks.addedBlocks.add(block);
/* 2050 */             GameRegistry.registerBlock(block, null, blockName);
/*      */             
/* 2052 */             Blocks.field_150480_ab.func_180686_a(block, fireSpread, flammability); } 
/*      */         } 
/*      */       } 
/* 2055 */     }  this.blockConfig.save();
/*      */   }
/*      */ 
/*      */   
/*      */   public static Material getMaterialFromString(String materialName) {
/* 2060 */     if (materialName.equalsIgnoreCase("air")) return Material.field_151579_a; 
/* 2061 */     if (materialName.equalsIgnoreCase("anvil")) return Material.field_151574_g; 
/* 2062 */     if (materialName.equalsIgnoreCase("cactus")) return Material.field_151570_A; 
/* 2063 */     if (materialName.equalsIgnoreCase("cake")) return Material.field_151568_F; 
/* 2064 */     if (materialName.equalsIgnoreCase("carpet")) return Material.field_151593_r; 
/* 2065 */     if (materialName.equalsIgnoreCase("circuits")) return Material.field_151594_q; 
/* 2066 */     if (materialName.equalsIgnoreCase("clay")) return Material.field_151571_B; 
/* 2067 */     if (materialName.equalsIgnoreCase("cloth")) return Material.field_151580_n; 
/* 2068 */     if (materialName.equalsIgnoreCase("coral")) return Material.field_151589_v; 
/* 2069 */     if (materialName.equalsIgnoreCase("craftedSnow")) return Material.field_151596_z; 
/* 2070 */     if (materialName.equalsIgnoreCase("dragonEgg")) return Material.field_151566_D; 
/* 2071 */     if (materialName.equalsIgnoreCase("fire")) return Material.field_151581_o; 
/* 2072 */     if (materialName.equalsIgnoreCase("glass")) return Material.field_151592_s; 
/* 2073 */     if (materialName.equalsIgnoreCase("gourd")) return Material.field_151572_C; 
/* 2074 */     if (materialName.equalsIgnoreCase("grass")) return Material.field_151577_b; 
/* 2075 */     if (materialName.equalsIgnoreCase("ground")) return Material.field_151578_c; 
/* 2076 */     if (materialName.equalsIgnoreCase("ice")) return Material.field_151588_w; 
/* 2077 */     if (materialName.equalsIgnoreCase("iron")) return Material.field_151573_f; 
/* 2078 */     if (materialName.equalsIgnoreCase("lava")) return Material.field_151587_i; 
/* 2079 */     if (materialName.equalsIgnoreCase("leaves")) return Material.field_151584_j; 
/* 2080 */     if (materialName.equalsIgnoreCase("packedIce")) return Material.field_151598_x; 
/* 2081 */     if (materialName.equalsIgnoreCase("piston")) return Material.field_76233_E; 
/* 2082 */     if (materialName.equalsIgnoreCase("plants")) return Material.field_151585_k; 
/* 2083 */     if (materialName.equalsIgnoreCase("portal")) return Material.field_151567_E; 
/* 2084 */     if (materialName.equalsIgnoreCase("redstoneLight")) return Material.field_151591_t; 
/* 2085 */     if (materialName.equalsIgnoreCase("rock")) return Material.field_151576_e; 
/* 2086 */     if (materialName.equalsIgnoreCase("sand")) return Material.field_151595_p; 
/* 2087 */     if (materialName.equalsIgnoreCase("snow")) return Material.field_151597_y; 
/* 2088 */     if (materialName.equalsIgnoreCase("sponge")) return Material.field_151583_m; 
/* 2089 */     if (materialName.equalsIgnoreCase("tnt")) return Material.field_151590_u; 
/* 2090 */     if (materialName.equalsIgnoreCase("vine")) return Material.field_151582_l; 
/* 2091 */     if (materialName.equalsIgnoreCase("water")) return Material.field_151586_h; 
/* 2092 */     if (materialName.equalsIgnoreCase("web")) return Material.field_151569_G; 
/* 2093 */     if (materialName.equalsIgnoreCase("wood")) return Material.field_151575_d;
/*      */     
/* 2095 */     return null;
/*      */   }
/*      */   
/*      */   public static Block.SoundType getSoundsFromString(String materialName) {
/* 2099 */     if (materialName.equalsIgnoreCase("anvil")) return Block.field_149788_p; 
/* 2100 */     if (materialName.equalsIgnoreCase("cactus")) return Block.field_149775_l; 
/* 2101 */     if (materialName.equalsIgnoreCase("cake")) return Block.field_149775_l; 
/* 2102 */     if (materialName.equalsIgnoreCase("carpet")) return Block.field_149775_l; 
/* 2103 */     if (materialName.equalsIgnoreCase("circuits")) return Block.field_149769_e; 
/* 2104 */     if (materialName.equalsIgnoreCase("clay")) return Block.field_149767_g; 
/* 2105 */     if (materialName.equalsIgnoreCase("cloth")) return Block.field_149775_l; 
/* 2106 */     if (materialName.equalsIgnoreCase("coral")) return Block.field_149779_h; 
/* 2107 */     if (materialName.equalsIgnoreCase("craftedSnow")) return Block.field_149773_n; 
/* 2108 */     if (materialName.equalsIgnoreCase("dragonEgg")) return Block.field_149780_i; 
/* 2109 */     if (materialName.equalsIgnoreCase("fire")) return Block.field_149775_l; 
/* 2110 */     if (materialName.equalsIgnoreCase("glass")) return Block.field_149778_k; 
/* 2111 */     if (materialName.equalsIgnoreCase("gourd")) return Block.field_149766_f; 
/* 2112 */     if (materialName.equalsIgnoreCase("grass")) return Block.field_149779_h; 
/* 2113 */     if (materialName.equalsIgnoreCase("ground")) return Block.field_149767_g; 
/* 2114 */     if (materialName.equalsIgnoreCase("ice")) return Block.field_149778_k; 
/* 2115 */     if (materialName.equalsIgnoreCase("iron")) return Block.field_149777_j; 
/* 2116 */     if (materialName.equalsIgnoreCase("lava")) return Block.field_149780_i; 
/* 2117 */     if (materialName.equalsIgnoreCase("leaves")) return Block.field_149779_h; 
/* 2118 */     if (materialName.equalsIgnoreCase("packedIce")) return Block.field_149778_k; 
/* 2119 */     if (materialName.equalsIgnoreCase("piston")) return Block.field_149780_i; 
/* 2120 */     if (materialName.equalsIgnoreCase("plants")) return Block.field_149779_h; 
/* 2121 */     if (materialName.equalsIgnoreCase("portal")) return Block.field_149780_i; 
/* 2122 */     if (materialName.equalsIgnoreCase("redstoneLight")) return Block.field_149780_i; 
/* 2123 */     if (materialName.equalsIgnoreCase("rock")) return Block.field_149780_i; 
/* 2124 */     if (materialName.equalsIgnoreCase("sand")) return Block.field_149776_m; 
/* 2125 */     if (materialName.equalsIgnoreCase("snow")) return Block.field_149773_n; 
/* 2126 */     if (materialName.equalsIgnoreCase("sponge")) return Block.field_149779_h; 
/* 2127 */     if (materialName.equalsIgnoreCase("tnt")) return Block.field_149779_h; 
/* 2128 */     if (materialName.equalsIgnoreCase("vine")) return Block.field_149779_h; 
/* 2129 */     if (materialName.equalsIgnoreCase("water")) return Block.field_149780_i; 
/* 2130 */     if (materialName.equalsIgnoreCase("web")) return Block.field_149780_i; 
/* 2131 */     if (materialName.equalsIgnoreCase("wood")) return Block.field_149766_f;
/*      */     
/* 2133 */     return Block.field_149769_e;
/*      */   }
/*      */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderBlocks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */