/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTException;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.WeightedRandomChestContent;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderChestLoot
/*     */   extends ConfigLoader
/*     */ {
/*  34 */   public static ConfigLoaderChestLoot instance = new ConfigLoaderChestLoot();
/*     */   
/*     */   ConfigLoaderChestLoot() {
/*  37 */     this.namesToExtras.put("custom_chest_content", new ArrayList<String>());
/*  38 */     this.namesToExtras.put("min_max_amounts", new ArrayList<String>());
/*     */   }
/*     */   
/*  41 */   public static HashMap<String, ArrayList<String>> extraExisting = new HashMap<String, ArrayList<String>>();
/*     */   
/*     */   public String getFileName() {
/*  44 */     return "chest_content";
/*     */   }
/*     */ 
/*     */   
/*     */   public void loadExtras(File folder) {
/*  49 */     super.loadExtras(folder);
/*     */     
/*  51 */     Set<String> defaultChestTypes = getChestTypes();
/*  52 */     for (String type : defaultChestTypes) {
/*  53 */       String filePath = "config/" + getFileName() + "/" + type.toLowerCase() + "_additions.txt";
/*     */       
/*  55 */       ArrayList<String> extraList = extraExisting.get(type);
/*     */       
/*  57 */       if (extraList == null)
/*     */       {
/*  59 */         extraList = new ArrayList<String>();
/*     */       }
/*     */       
/*  62 */       ConfigExtrasLoader.readFileIntoList(folder, filePath, extraList);
/*     */       
/*  64 */       extraExisting.put(type, extraList);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadChestContent() {
/*  73 */     Configuration chestContent = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*  74 */     Random rand = new Random(0L);
/*     */     
/*  76 */     chestContent.load();
/*     */     
/*  78 */     chestContent.addCustomCategoryComment("_instructions", "************   Instructions   *************\nFor the default entries, they are formatted as follows:\n\n      <min items>-<max items>-<weight>-<metadata>.\n\nDisable them by setting the weights to 0.\nTo add new things, put items in the lists in the format:\n\n      <name>-<min items>-<max items>-<weight>-<metadata (optional)>-<NBT Tag (optional)>.\n\nSo, say, if you wanted to add 6-10 slime balls to the bonus chest with a weight of\n10, you could put:\n\n      minecraft:slime_ball-6-10-10\n\nNote the NBT tag is optional, and so is the metadata (defaults to 0), so you don't have\nto include them.\nYou can also add entries to custom chest types in custom_chest in the form:\n\n      <type>-<name>-<min items>-<max items>-<weight>-<metadata (optional)>-<NBT Tag (optional)>.\nTo change the number of items that generate in a chest, in the '_min_max_amounts' section,\nchange the numbers which are in the format:\n\n      <chest type>-<min items in chest>-<max items in chest>");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 104 */     Set<String> defaultChestTypes = getChestTypes();
/*     */     
/* 106 */     LootPPHelper.chestTypes.addAll(defaultChestTypes);
/*     */ 
/*     */ 
/*     */     
/* 110 */     for (String type : defaultChestTypes) {
/* 111 */       loadDefaultContent(chestContent, type, type + "_default");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 118 */     for (String type : defaultChestTypes) {
/* 119 */       ArrayList<String> arrayList = ConfigExtrasLoader.combineLists(chestContent.get(type.toLowerCase() + "_additions", type + " Additions:", new String[0]).getStringList(), extraExisting.get(type));
/* 120 */       addEntriesFromStringList(type, arrayList);
/*     */     } 
/*     */     
/* 123 */     ArrayList<String> contentList = ConfigExtrasLoader.combineLists(chestContent.get("custom_chest_type", "Custom Chest Type Content:", new String[0]).getStringList(), this.namesToExtras.get("custom_chest_content"));
/* 124 */     addCustomEntriesFromStringArray(contentList);
/*     */ 
/*     */ 
/*     */     
/* 128 */     HashMap<String, ChestGenHooks> loadedChestInfo = null;
/* 129 */     if (LootPPHelper.gotChestInfo) {
/*     */       try {
/* 131 */         loadedChestInfo = (HashMap<String, ChestGenHooks>)LootPPHelper.chestInfo.get(null);
/*     */       }
/* 133 */       catch (Exception e) {
/* 134 */         System.err.println("[Loot++] Error while getting chest info.");
/* 135 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 139 */     String[] configContent = chestContent.get("_min_max_amounts", "min_max_amounts", new String[0]).getStringList();
/* 140 */     contentList = ConfigExtrasLoader.combineLists(configContent, this.namesToExtras.get("min_max_amounts"));
/*     */     
/* 142 */     Set<String> chestTypesFound = new HashSet<String>();
/* 143 */     chestTypesFound.addAll(LootPPHelper.chestTypes);
/*     */     
/* 145 */     int index = 0;
/* 146 */     for (String entry : contentList) {
/* 147 */       boolean comment = false;
/* 148 */       String title = getFileName() + ".cfg '_min_max_amounts'";
/*     */       
/* 150 */       if (entry.length() > 0) {
/* 151 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/* 154 */       String[] parts = entry.split("-");
/*     */       
/* 156 */       if (parts.length != 3) {
/* 157 */         LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */         
/*     */         continue;
/*     */       } 
/* 161 */       String type = parts[0];
/* 162 */       int min = 1;
/* 163 */       int max = 1;
/*     */       
/*     */       try {
/* 166 */         min = Integer.valueOf(parts[1]).intValue();
/* 167 */         max = Integer.valueOf(parts[2]).intValue();
/*     */       }
/* 169 */       catch (NumberFormatException e) {
/* 170 */         LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[2] });
/* 171 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 174 */       if (min < 0) {
/* 175 */         min = 0;
/*     */       }
/* 177 */       if (max < min) {
/* 178 */         max = min;
/*     */       }
/*     */       
/* 181 */       if (LootPPHelper.gotChestInfo && loadedChestInfo != null && loadedChestInfo.containsKey(type)) {
/* 182 */         ChestGenHooks chest = loadedChestInfo.get(type);
/*     */         
/* 184 */         if (chest.getMin() != min) {
/* 185 */           chest.setMin(min);
/*     */         }
/*     */         
/* 188 */         if (chest.getMax() != max) {
/* 189 */           chest.setMax(max);
/*     */         }
/*     */         
/* 192 */         if (LootPlusPlusMod.debug) System.out.println("[Loot++] Set chest size for type '" + type + "' to min: " + min + ", max: " + max);
/*     */         
/* 194 */         chestTypesFound.remove(type);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     if (!chestTypesFound.isEmpty()) {
/* 204 */       ArrayList<String> newEntries = new ArrayList<String>();
/*     */       
/* 206 */       for (String type : chestTypesFound) {
/* 207 */         if (LootPPHelper.gotChestInfo && loadedChestInfo != null && loadedChestInfo.containsKey(type)) {
/* 208 */           ChestGenHooks chest = loadedChestInfo.get(type);
/* 209 */           newEntries.add(type + "-" + chest.getMin() + "-" + chest.getMax());
/*     */         } 
/*     */       } 
/*     */       
/* 213 */       if (!newEntries.isEmpty()) {
/* 214 */         String[] finalEntries = new String[configContent.length + newEntries.size()];
/*     */         int i;
/* 216 */         for (i = 0; i < configContent.length; i++) {
/* 217 */           finalEntries[i] = configContent[i];
/*     */         }
/*     */         
/* 220 */         for (i = configContent.length; i < finalEntries.length; i++) {
/* 221 */           finalEntries[i] = newEntries.get(i - configContent.length);
/*     */         }
/* 223 */         chestContent.get("_min_max_amounts", "min_max_amounts", new String[0]).set(finalEntries);
/*     */       } 
/*     */     } 
/*     */     
/* 227 */     chestContent.save();
/* 228 */     index++;
/*     */   }
/*     */   
/*     */   private Set<String> getChestTypes() {
/* 232 */     Set<String> defaultChestTypes = new HashSet<String>();
/* 233 */     defaultChestTypes.addAll(Arrays.asList(new String[] { "bonusChest", "dungeonChest", "mineshaftCorridor", "pyramidDesertyChest", "pyramidJungleChest", "pyramidJungleDispenser", "strongholdCorridor", "strongholdCrossing", "strongholdLibrary", "villageBlacksmith", "netherFortress" }));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 238 */     if (LootPPHelper.gotChestInfo) {
/*     */       try {
/* 240 */         HashMap<String, ChestGenHooks> loadedChestInfo = (HashMap<String, ChestGenHooks>)LootPPHelper.chestInfo.get(null);
/* 241 */         defaultChestTypes = loadedChestInfo.keySet();
/* 242 */       } catch (Exception e) {
/* 243 */         System.out.println("[Loot++] Caught Exception while trying to load in chest info.");
/* 244 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 248 */     return defaultChestTypes;
/*     */   }
/*     */   
/*     */   private void loadDefaultContent(Configuration chestContent, String type, String optionName) {
/* 252 */     List<WeightedRandomChestContent> chestContentList = ChestGenHooks.getInfo(type).getItems(new Random(0L));
/*     */     
/* 254 */     if (LootPPHelper.gotContents) {
/*     */       try {
/* 256 */         chestContentList = (List<WeightedRandomChestContent>)LootPPHelper.contents.get(ChestGenHooks.getInfo(type));
/* 257 */       } catch (Exception e) {
/* 258 */         System.out.println("[Loot++] Caught Exception while trying to load in " + type + " contents.");
/* 259 */         e.printStackTrace();
/*     */       } 
/*     */     }
/* 262 */     for (WeightedRandomChestContent content : chestContentList) {
/* 263 */       if (content != null && content.field_76297_b != null && content.field_76297_b.func_77973_b() != null) {
/* 264 */         String options = "" + content.field_76295_d + "-" + content.field_76296_e + "-" + content.field_76292_a;
/*     */         
/* 266 */         String nbtTag = !content.field_76297_b.func_77942_o() ? "" : ("-" + content.field_76297_b.func_77978_p().toString());
/* 267 */         nbtTag = nbtTag.replace('"', '\'');
/* 268 */         if (nbtTag.length() > 100) {
/* 269 */           nbtTag = nbtTag.substring(0, 100);
/*     */         }
/* 271 */         options = chestContent.get(optionName, Item.field_150901_e.func_177774_c(content.field_76297_b.func_77973_b()) + "-" + content.field_76297_b.func_77952_i() + nbtTag, options).getString();
/*     */         
/* 273 */         setDefaultContentDataFromString(options, content, getFileName() + ".cfg '" + optionName + "'");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void addCustomEntriesFromStringArray(ArrayList<String> entries) {
/* 279 */     for (int index = 0; index < entries.size(); index++) {
/* 280 */       String options = entries.get(index);
/*     */       
/* 282 */       boolean comment = false;
/* 283 */       String title = getFileName() + ".cfg 'custom_chest_type' #" + (index + 1);
/*     */       
/* 285 */       if (options.length() > 0) {
/* 286 */         comment = (options.charAt(0) == '#');
/*     */       }
/*     */       
/* 289 */       String[] parts = options.split("-", 7);
/*     */       
/* 291 */       if (parts.length < 5) {
/* 292 */         if (!options.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, options);
/*     */       
/*     */       } else {
/*     */         
/* 296 */         String type = parts[0];
/* 297 */         String name = parts[1];
/* 298 */         String minString = parts[2];
/* 299 */         String maxString = parts[3];
/* 300 */         String weightString = parts[4];
/* 301 */         String metaString = "0";
/* 302 */         String nbtString = "{}";
/* 303 */         NBTTagCompound nbt = null;
/*     */         
/* 305 */         if (parts.length > 5) {
/* 306 */           metaString = parts[5];
/*     */         }
/*     */         
/* 309 */         if (parts.length > 6) {
/* 310 */           nbtString = parts[6];
/*     */         }
/*     */         
/* 313 */         if (!nbtString.equals("") && !nbtString.equals("{}")) {
/*     */           try {
/* 315 */             nbt = JsonToNBT.func_180713_a(nbtString.trim());
/*     */           }
/* 317 */           catch (Exception e) {
/*     */             
/* 319 */             if (!comment) {
/* 320 */               LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage());
/* 321 */               e.printStackTrace();
/*     */             } 
/* 323 */             nbt = null;
/*     */           } 
/*     */         }
/*     */         
/* 327 */         Object itemObj = Item.field_150901_e.func_82594_a(name);
/*     */         
/* 329 */         if (itemObj == null || !(itemObj instanceof Item)) {
/* 330 */           LootPPNotifier.notifyNonexistant(comment, title, name);
/*     */         }
/*     */         else {
/*     */           
/* 334 */           Item item = (Item)itemObj;
/*     */           
/* 336 */           ItemStack itemStack = new ItemStack(item);
/*     */           
/* 338 */           if (nbt != null) {
/* 339 */             itemStack.func_77982_d(nbt);
/*     */           }
/*     */           
/* 342 */           int min = 1;
/* 343 */           int max = 1;
/* 344 */           int weight = 0;
/* 345 */           int meta = 0;
/*     */           
/*     */           try {
/* 348 */             min = Integer.valueOf(minString).intValue();
/* 349 */             max = Integer.valueOf(maxString).intValue();
/* 350 */             weight = Integer.valueOf(weightString).intValue();
/* 351 */             meta = Integer.valueOf(metaString).intValue();
/*     */           }
/* 353 */           catch (Exception e) {
/* 354 */             if (!comment) {
/* 355 */               e.printStackTrace();
/* 356 */               LootPPNotifier.notifyNumber(comment, title, new String[] { minString, maxString, weightString, metaString });
/*     */             } 
/*     */           } 
/*     */           
/* 360 */           if (min < 0) min = 0; 
/* 361 */           if (max < min) max = min; 
/* 362 */           if (meta < 0) meta = 0; 
/* 363 */           if (weight < 0) weight = 0;
/*     */           
/* 365 */           itemStack.func_77964_b(meta);
/* 366 */           WeightedRandomChestContent content = new WeightedRandomChestContent(itemStack, min, max, weight);
/* 367 */           ChestGenHooks.getInfo(type).addItem(content);
/*     */           
/* 369 */           if (ChestGenHooks.getInfo(type).getMax() == 0 && ChestGenHooks.getInfo(type).getMin() == 0) {
/* 370 */             ChestGenHooks.getInfo(type).setMin(3);
/* 371 */             ChestGenHooks.getInfo(type).setMax(9);
/*     */           } 
/*     */           
/* 374 */           LootPPHelper.chestTypes.add(type);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   } private void addEntriesFromStringList(String type, ArrayList<String> entries) {
/* 379 */     for (int index = 0; index < entries.size(); index++) {
/* 380 */       String options = entries.get(index);
/* 381 */       String[] parts = options.split("-", 6);
/*     */       
/* 383 */       boolean comment = false;
/* 384 */       String title = getFileName() + ".cfg '" + type.toLowerCase() + "_additions' #" + (index + 1);
/*     */       
/* 386 */       if (options.length() > 0) {
/* 387 */         comment = (options.charAt(0) == '#');
/*     */       }
/*     */       
/* 390 */       if (parts.length < 4) {
/* 391 */         if (!options.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, options);
/*     */       
/*     */       } else {
/*     */         
/* 395 */         String name = parts[0];
/* 396 */         String minString = parts[1];
/* 397 */         String maxString = parts[2];
/* 398 */         String weightString = parts[3];
/* 399 */         String metaString = "0";
/* 400 */         String nbtString = "{}";
/* 401 */         NBTBase nbt = null;
/*     */         
/* 403 */         if (parts.length > 4) {
/* 404 */           metaString = parts[4];
/*     */         }
/*     */         
/* 407 */         if (parts.length > 5) {
/* 408 */           nbtString = parts[5];
/*     */         }
/*     */         
/* 411 */         if (!nbtString.equals("") && !nbtString.equals("{}")) {
/*     */           try {
/* 413 */             NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(nbtString.trim());
/*     */           }
/* 415 */           catch (NBTException e) {
/*     */             
/* 417 */             if (!comment) {
/* 418 */               LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage());
/* 419 */               e.printStackTrace();
/*     */             } 
/* 421 */             nbt = null;
/*     */           } 
/*     */         }
/*     */         
/* 425 */         Object itemObj = Item.field_150901_e.func_82594_a(name);
/*     */         
/* 427 */         if (itemObj == null || !(itemObj instanceof Item)) {
/* 428 */           LootPPNotifier.notifyNonexistant(comment, title, name);
/*     */         }
/*     */         else {
/*     */           
/* 432 */           Item item = (Item)itemObj;
/*     */           
/* 434 */           ItemStack itemStack = new ItemStack(item);
/*     */           
/* 436 */           if (nbt != null) {
/* 437 */             itemStack.func_77982_d((NBTTagCompound)nbt);
/*     */           }
/*     */           
/* 440 */           int min = 1;
/* 441 */           int max = 1;
/* 442 */           int weight = 0;
/* 443 */           int meta = 0;
/*     */           
/*     */           try {
/* 446 */             min = Integer.valueOf(minString).intValue();
/* 447 */             max = Integer.valueOf(maxString).intValue();
/* 448 */             weight = Integer.valueOf(weightString).intValue();
/* 449 */             meta = Integer.valueOf(metaString).intValue();
/*     */           }
/* 451 */           catch (NumberFormatException e) {
/* 452 */             if (!comment) {
/* 453 */               LootPPNotifier.notifyNumber(comment, title, new String[] { minString, maxString, weightString, metaString });
/* 454 */               e.printStackTrace();
/*     */             } 
/*     */           } 
/*     */           
/* 458 */           if (min < 0) min = 0; 
/* 459 */           if (max < min) max = min; 
/* 460 */           if (meta < 0) meta = 0; 
/* 461 */           if (weight < 0) weight = 0;
/*     */           
/* 463 */           itemStack.func_77964_b(meta);
/*     */           
/* 465 */           WeightedRandomChestContent content = new WeightedRandomChestContent(itemStack, min, max, weight);
/* 466 */           ChestGenHooks.getInfo(type).addItem(content);
/*     */         } 
/*     */       } 
/*     */     } 
/* 470 */     LootPPHelper.chestTypes.add(type);
/*     */   }
/*     */   
/*     */   private void setDefaultContentDataFromString(String options, WeightedRandomChestContent content, String title) {
/* 474 */     String[] parts = options.split("-");
/*     */     
/* 476 */     if (parts.length > 3) {
/* 477 */       LootPPNotifier.notifyWrongNumberOfParts(false, title, options);
/*     */       
/*     */       return;
/*     */     } 
/* 481 */     String minString = parts[0];
/* 482 */     String maxString = parts[1];
/* 483 */     String weightString = parts[2];
/*     */     
/*     */     try {
/* 486 */       int min = Integer.valueOf(minString).intValue();
/* 487 */       int max = Integer.valueOf(maxString).intValue();
/* 488 */       int weight = Integer.valueOf(weightString).intValue();
/*     */       
/* 490 */       if (min < 0) min = 0; 
/* 491 */       if (max < min) max = min; 
/* 492 */       if (weight < 0) weight = 0;
/*     */       
/* 494 */       content.field_76295_d = min;
/* 495 */       content.field_76296_e = max;
/* 496 */       content.field_76292_a = weight;
/*     */     }
/* 498 */     catch (NumberFormatException e) {
/* 499 */       LootPPNotifier.notifyNumber(false, title, new String[] { minString, maxString, weightString });
/* 500 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderChestLoot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */