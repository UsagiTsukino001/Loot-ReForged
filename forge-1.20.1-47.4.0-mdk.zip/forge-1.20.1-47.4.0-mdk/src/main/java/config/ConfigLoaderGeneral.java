/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.ItemDummyTab;
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTException;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderGeneral
/*     */   extends ConfigLoader
/*     */ {
/*  31 */   public static ConfigLoaderGeneral instance = new ConfigLoaderGeneral();
/*     */   
/*     */   ConfigLoaderGeneral() {
/*  34 */     this.namesToExtras.put("creative_menu_additions", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  38 */     return "general";
/*     */   }
/*     */   
/*     */   public void loadGeneral() {
/*  42 */     Configuration general = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  44 */     general.load();
/*     */     
/*  46 */     LootPlusPlusMod.debug = general.getBoolean("Display debug output?", "debug", false, "");
/*  47 */     LootPPHelper.generateFiles = general.getBoolean("Load info files?", "files", true, "");
/*     */     
/*  49 */     general.save();
/*     */   }
/*     */   
/*     */   public void loadCreativeAdditions() {
/*  53 */     Configuration general = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */ 
/*     */ 
/*     */     
/*  57 */     general.load();
/*     */     
/*  59 */     String[] creativeAdditions = general.getStringList("creative_menu_additions", "creative_menu", new String[0], "You can add items to the creative menu here in the format:\n\n      <Creative tab name>_____<Item name>_____<Metadata (optional)>_____<NBT tag (optional)>\n\nFor instance, you could add a wither skeleton spawn egg by putting:\n\n      Custom Spawn Eggs_____lootplusplus:custom_spawn_egg_____0_____{EntityName:Skeleton, EntityData:{SkeletonType:1}, display:{Name:\"§rSpawn Wither Skeleton\"}}\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     List<String> additionsList = ConfigExtrasLoader.combineLists(creativeAdditions, this.namesToExtras.get("creative_menu_additions"));
/*     */     
/*  68 */     for (int index = 0; index < additionsList.size(); index++) {
/*  69 */       String entry = additionsList.get(index);
/*  70 */       String title = getFileName() + ".cfg 'creative_menu_additions' #" + (index + 1);
/*     */       
/*  72 */       boolean comment = false;
/*     */       
/*  74 */       if (entry.length() > 0) {
/*  75 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/*  78 */       String[] parts = entry.split("_____");
/*     */       
/*  80 */       if (parts.length < 2) {
/*  81 */         if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */       
/*     */       } else {
/*     */         
/*  85 */         String tabName = parts[0];
/*  86 */         String itemName = parts[1];
/*  87 */         int meta = 0;
/*  88 */         String nbtString = "{}";
/*     */         
/*  90 */         if (parts.length > 2) {
/*     */           try {
/*  92 */             meta = Integer.valueOf(parts[2]).intValue();
/*     */           }
/*  94 */           catch (NumberFormatException e) {
/*  95 */             if (!comment) {
/*  96 */               System.err.println("[Loot++] Caught exception while trying to add a bow " + itemName);
/*  97 */               e.printStackTrace();
/*  98 */               LootPPNotifier.notifyNumber(comment, title, parts[2]);
/*     */             } 
/*     */           } 
/*     */         }
/*     */         
/* 103 */         Object itemObj = Item.field_150901_e.func_82594_a(itemName);
/*     */         
/* 105 */         if (itemObj == null || !(itemObj instanceof Item)) {
/* 106 */           LootPPNotifier.notifyNonexistant(comment, title, itemName);
/*     */         }
/*     */         else {
/*     */           
/* 110 */           Item item = (Item)itemObj;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 115 */           NBTTagCompound nbt = null;
/*     */           
/* 117 */           if (parts.length > 3) {
/* 118 */             nbtString = parts[3];
/*     */           }
/*     */           
/* 121 */           if (nbtString != null && !nbtString.equals("{}")) {
/*     */             
/*     */             try {
/* 124 */               NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(nbtString.trim());
/* 125 */               nbt = nBTTagCompound;
/*     */             }
/* 127 */             catch (NBTException e) {
/*     */               
/* 129 */               if (!comment) {
/* 130 */                 e.printStackTrace();
/* 131 */                 LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage());
/*     */               } 
/* 133 */               nbt = null;
/*     */             } 
/*     */           }
/*     */ 
/*     */           
/* 138 */           ItemStack itemStack = new ItemStack(item, 1, meta);
/*     */           
/* 140 */           if (nbt != null) {
/* 141 */             itemStack.func_77982_d(nbt);
/*     */           }
/*     */           
/* 144 */           ArrayList<ItemStack> additions = (ArrayList<ItemStack>)LootPPHelper.additionsToDisplay.get(tabName);
/* 145 */           if (additions == null) {
/* 146 */             additions = new ArrayList<ItemStack>();
/*     */           }
/* 148 */           additions.add(itemStack);
/* 149 */           LootPPHelper.additionsToDisplay.put(tabName, additions);
/*     */ 
/*     */           
/* 152 */           if (!LootPPHelper.addedTabs.containsKey(tabName)) {
/* 153 */             LootPPHelper.addedTabs.put(tabName, new LootPPHelper.LPPCreativeTabs(tabName));
/* 154 */             ItemDummyTab itemDummyTab = new ItemDummyTab(tabName);
/* 155 */             GameRegistry.registerItem((Item)itemDummyTab, "tab_" + tabName.replace(' ', '_'));
/*     */           } 
/*     */         } 
/*     */       } 
/* 159 */     }  general.save();
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderGeneral.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */