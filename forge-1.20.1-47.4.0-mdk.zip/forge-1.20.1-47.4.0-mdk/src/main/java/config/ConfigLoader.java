/*    */ package com.tmtravlr.lootplusplus.config;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ConfigLoader
/*    */ {
/* 16 */   public HashMap<String, ArrayList<String>> namesToExtras = new HashMap<String, ArrayList<String>>();
/*    */   
/*    */   public String getFileName() {
/* 19 */     return "";
/*    */   }
/*    */ 
/*    */   
/*    */   public void loadExtras(File folder) {
/* 24 */     for (Map.Entry<String, ArrayList<String>> entry : this.namesToExtras.entrySet())
/* 25 */       ConfigExtrasLoader.readFileIntoList(folder, "config/" + getFileName() + "/" + entry.getKey() + ".txt", (ArrayList<String>)entry.getValue()); 
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */