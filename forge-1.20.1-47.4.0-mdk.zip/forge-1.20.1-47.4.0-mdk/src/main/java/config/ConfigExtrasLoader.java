/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigExtrasLoader
/*     */ {
/*  26 */   public static HashMap<String, ConfigLoader> loadersMap = new HashMap<String, ConfigLoader>();
/*     */   
/*     */   public static final String ADDON_LOCATION = "/addons/Loot++";
/*     */   
/*     */   public static final String LUCKY_BLOCK_ADDON_LOCATION = "/addons/lucky_block";
/*     */   
/*     */   public static File lppAddonFolder;
/*     */   public static File lbAddonFolder;
/*  34 */   public static ArrayList<File> addonsList = new ArrayList<File>();
/*     */ 
/*     */   
/*     */   public static void loadAllExtras() {
/*  38 */     initLoaders();
/*     */ 
/*     */     
/*  41 */     lppAddonFolder = new File(MinecraftServer.func_71276_C().func_71238_n().getPath() + "/addons/Loot++");
/*  42 */     if (!lppAddonFolder.exists()) {
/*  43 */       lppAddonFolder.mkdirs();
/*     */ 
/*     */       
/*  46 */       createExampleAddon();
/*     */     } 
/*     */ 
/*     */     
/*  50 */     lbAddonFolder = new File(MinecraftServer.func_71276_C().func_71238_n().getPath() + "/addons/lucky_block");
/*  51 */     if (!lbAddonFolder.exists()) {
/*  52 */       lbAddonFolder = null;
/*     */     }
/*     */ 
/*     */     
/*  56 */     File[] addonFiles = lppAddonFolder.listFiles();
/*  57 */     if (addonFiles != null && addonFiles.length != 0) {
/*  58 */       for (File addon : addonFiles) {
/*  59 */         if (addon.isDirectory() || addon.getName().endsWith(".zip") || addon.getName().endsWith(".jar")) {
/*  60 */           addonsList.add(addon);
/*  61 */           LootPlusPlusMod.proxy.registerAsResourcePack(addon);
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*  66 */     if (lbAddonFolder != null) {
/*  67 */       addonFiles = lbAddonFolder.listFiles();
/*  68 */       if (addonFiles != null && addonFiles.length != 0) {
/*  69 */         for (File addon : addonFiles) {
/*  70 */           if (addon.isDirectory() || addon.getName().endsWith(".zip") || addon.getName().endsWith(".jar")) {
/*  71 */             addonsList.add(addon);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  77 */     for (File addon : addonsList) {
/*  78 */       if (LootPlusPlusMod.debug) System.out.println("[Loot++] Loading in addon file: " + addon.getPath()); 
/*  79 */       loadExtras(addon);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadExtras(File folderToLoad) {
/*  86 */     for (String loaderName : loadersMap.keySet()) {
/*  87 */       ConfigLoader loader = loadersMap.get(loaderName);
/*     */       
/*  89 */       loader.loadExtras(folderToLoad);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void readFileIntoList(File addonFolder, String filePath, ArrayList<String> extras) {
/*     */     try {
/*  99 */       BufferedReader br = null;
/* 100 */       ZipFile zipFile = null;
/*     */       
/* 102 */       if (addonFolder.isDirectory()) {
/* 103 */         File file = new File(addonFolder, filePath);
/* 104 */         if (file.exists()) {
/* 105 */           br = new BufferedReader(new FileReader(file));
/*     */         }
/*     */       } else {
/*     */         
/* 109 */         zipFile = new ZipFile(addonFolder);
/* 110 */         ZipEntry entry = zipFile.getEntry(filePath);
/* 111 */         if (entry == null) {
/* 112 */           zipFile.close();
/*     */           return;
/*     */         } 
/* 115 */         InputStream stream = zipFile.getInputStream(entry);
/* 116 */         br = new BufferedReader(new InputStreamReader(stream));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 121 */       if (br != null) {
/*     */         String line;
/*     */         
/* 124 */         while ((line = br.readLine()) != null) {
/* 125 */           extras.add(line);
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 130 */         if (zipFile != null) {
/* 131 */           zipFile.close();
/*     */         }
/*     */         
/* 134 */         br.close();
/*     */       }
/*     */     
/* 137 */     } catch (Exception e) {
/* 138 */       System.err.println("[Loot++] Caught an exception while trying to load in extra config options!");
/* 139 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static ArrayList<String> combineLists(String[] configLoaded, ArrayList<String> extraList) {
/* 145 */     ArrayList<String> toReturn = new ArrayList<String>();
/*     */     
/* 147 */     toReturn.addAll(Arrays.asList(configLoaded));
/* 148 */     if (extraList != null) {
/* 149 */       toReturn.addAll(extraList);
/*     */     }
/*     */     
/* 152 */     return toReturn;
/*     */   }
/*     */   
/*     */   private static void initLoaders() {
/* 156 */     loadersMap.put(ConfigLoaderBlockDrops.instance.getFileName(), ConfigLoaderBlockDrops.instance);
/* 157 */     loadersMap.put(ConfigLoaderBlocks.instance.getFileName(), ConfigLoaderBlocks.instance);
/* 158 */     loadersMap.put(ConfigLoaderChestLoot.instance.getFileName(), ConfigLoaderChestLoot.instance);
/* 159 */     loadersMap.put(ConfigLoaderEffects.instance.getFileName(), ConfigLoaderEffects.instance);
/* 160 */     loadersMap.put(ConfigLoaderEntityDrops.instance.getFileName(), ConfigLoaderEntityDrops.instance);
/* 161 */     loadersMap.put(ConfigLoaderFurnaceRecipes.instance.getFileName(), ConfigLoaderFurnaceRecipes.instance);
/* 162 */     loadersMap.put(ConfigLoaderGeneral.instance.getFileName(), ConfigLoaderGeneral.instance);
/* 163 */     loadersMap.put(ConfigLoaderItems.instance.getFileName(), ConfigLoaderItems.instance);
/* 164 */     loadersMap.put(ConfigLoaderOreDict.instance.getFileName(), ConfigLoaderOreDict.instance);
/* 165 */     loadersMap.put(ConfigLoaderRecipes.instance.getFileName(), ConfigLoaderRecipes.instance);
/* 166 */     loadersMap.put(ConfigLoaderRecords.instance.getFileName(), ConfigLoaderRecords.instance);
/* 167 */     loadersMap.put(ConfigLoaderStackSize.instance.getFileName(), ConfigLoaderStackSize.instance);
/* 168 */     loadersMap.put(ConfigLoaderWorldGen.instance.getFileName(), ConfigLoaderWorldGen.instance);
/* 169 */     loadersMap.put(ConfigLoaderFishingLoot.instance.getFileName(), ConfigLoaderFishingLoot.instance);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void createExampleAddon() {
/* 174 */     File exampleFolder = new File(lppAddonFolder, "Example");
/* 175 */     exampleFolder.mkdir();
/*     */ 
/*     */     
/* 178 */     File packMCMeta = new File(exampleFolder, "pack.mcmeta");
/*     */     try {
/* 180 */       PrintStream writeStream = new PrintStream(packMCMeta);
/*     */       
/* 182 */       writeStream.println("{");
/* 183 */       writeStream.println("  \"pack\": {");
/* 184 */       writeStream.println("    \"pack_format\": 1,");
/* 185 */       writeStream.println("    \"description\": \"Loot++ example addon.\"");
/* 186 */       writeStream.println("  }");
/* 187 */       writeStream.println("}");
/*     */       
/* 189 */       writeStream.close();
/*     */     }
/* 191 */     catch (IOException e) {
/* 192 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/* 196 */     File lppFolder = new File(exampleFolder, "assets/lootplusplus");
/* 197 */     lppFolder.mkdirs();
/*     */     
/* 199 */     File other = new File(lppFolder, "blockstates");
/* 200 */     other.mkdir();
/* 201 */     other = new File(lppFolder, "textures/blocks");
/* 202 */     other.mkdirs();
/* 203 */     other = new File(lppFolder, "textures/items");
/* 204 */     other.mkdirs();
/* 205 */     other = new File(lppFolder, "textures/models/armor");
/* 206 */     other.mkdirs();
/* 207 */     other = new File(lppFolder, "models/block");
/* 208 */     other.mkdirs();
/* 209 */     other = new File(lppFolder, "models/item");
/* 210 */     other.mkdirs();
/* 211 */     other = new File(lppFolder, "sounds/records");
/*     */ 
/*     */     
/* 214 */     File soundsJson = new File(lppFolder, "sounds.json");
/*     */     try {
/* 216 */       PrintStream writeStream = new PrintStream(soundsJson);
/*     */       
/* 218 */       writeStream.println("{");
/* 219 */       writeStream.println();
/* 220 */       writeStream.println("}");
/*     */       
/* 222 */       writeStream.close();
/*     */     }
/* 224 */     catch (IOException e) {
/* 225 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 230 */       File config = new File(exampleFolder, "config");
/* 231 */       config.mkdir();
/*     */       
/* 233 */       for (String folderName : loadersMap.keySet()) {
/* 234 */         ConfigLoader configLoader = loadersMap.get(folderName);
/*     */         
/* 236 */         File loader = new File(config, folderName);
/* 237 */         loader.mkdirs();
/*     */         
/* 239 */         for (String fileName : configLoader.namesToExtras.keySet()) {
/* 240 */           other = new File(loader, fileName + ".txt");
/* 241 */           other.createNewFile();
/*     */         }
/*     */       
/*     */       } 
/* 245 */     } catch (IOException e) {
/* 246 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigExtrasLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */