/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPBlocks;
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPItems;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import com.tmtravlr.lootplusplus.effects.GiveEffects;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.TreeMap;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderEffects
/*     */   extends ConfigLoader
/*     */ {
/*  33 */   public static ConfigLoaderEffects instance = new ConfigLoaderEffects();
/*     */   
/*     */   ConfigLoaderEffects() {
/*  36 */     this.namesToExtras.put("hitting_entity_to_entity", new ArrayList<String>());
/*  37 */     this.namesToExtras.put("hitting_entity_to_yourself", new ArrayList<String>());
/*  38 */     this.namesToExtras.put("digging_block", new ArrayList<String>());
/*  39 */     this.namesToExtras.put("broke_block", new ArrayList<String>());
/*  40 */     this.namesToExtras.put("right_click", new ArrayList<String>());
/*  41 */     this.namesToExtras.put("wearing_armour", new ArrayList<String>());
/*  42 */     this.namesToExtras.put("in_inventory", new ArrayList<String>());
/*  43 */     this.namesToExtras.put("held", new ArrayList<String>());
/*  44 */     this.namesToExtras.put("standing_on_block", new ArrayList<String>());
/*  45 */     this.namesToExtras.put("inside_block", new ArrayList<String>());
/*  46 */     this.namesToExtras.put("digging_block_block", new ArrayList<String>());
/*  47 */     this.namesToExtras.put("broke_block_block", new ArrayList<String>());
/*  48 */     this.namesToExtras.put("command_hitting_entity_to_entity", new ArrayList<String>());
/*  49 */     this.namesToExtras.put("command_hitting_entity_to_yourself", new ArrayList<String>());
/*  50 */     this.namesToExtras.put("command_digging_block", new ArrayList<String>());
/*  51 */     this.namesToExtras.put("command_broke_block", new ArrayList<String>());
/*  52 */     this.namesToExtras.put("command_right_click", new ArrayList<String>());
/*  53 */     this.namesToExtras.put("command_wearing_armour", new ArrayList<String>());
/*  54 */     this.namesToExtras.put("command_in_inventory", new ArrayList<String>());
/*  55 */     this.namesToExtras.put("command_held", new ArrayList<String>());
/*  56 */     this.namesToExtras.put("command_standing_on_block", new ArrayList<String>());
/*  57 */     this.namesToExtras.put("command_inside_block", new ArrayList<String>());
/*  58 */     this.namesToExtras.put("command_digging_block_block", new ArrayList<String>());
/*  59 */     this.namesToExtras.put("command_broke_block_block", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  63 */     return "item_effects";
/*     */   }
/*     */   
/*     */   public void loadItemEffects() {
/*  67 */     Configuration effectConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  69 */     effectConfig.load();
/*     */     
/*  71 */     effectConfig.addCustomCategoryComment("_instructions", "************   Instructions   *************\nThis is used to make items give you potion effects under certain situations.\nThere are a number of different situations for items, with potion effects and commands:\n\n      Give an entity a potion effect when hitting it.\n      Give yourself a potion effect when hitting an entity.\n      Get a potion effect when digging a block (item-based).\n      Get a potion effect after breaking a block (item-based).\n      Get a potion effect when right clicking an item.\n      Get a potion effect when wearing armor.\n      Get a potion effect when the item is in your inventory.\n      Get a potion effect when holding the item.\n\n      Run a command from an entity's position when hitting it.\n      Run a command from your position when hitting an entity.\n      Run a command when digging a block (item-based).\n      Run a command after breaking a block (item-based).\n      Run a command when right clicking an item.\n      Run a command when wearing armor.\n      Run a command when the item is in your inventory.\n      Run a command when holding the item.\n\nAdd entries for the potion effects in the form:\n      <Item name>_____<Item metadata (-1 for any)>_____<Item NBT ({} for any)>_____<Effect id>_____<Effect duration>_____<Effect strength>_____<Effect probability>_____<Type of Particles>\n\nAdd for the commands in the form:\n      <Item name>_____<Item metadata (-1 for any)>_____<Item NBT ({} for any)>_____<Command probability>_____<Command>\n\nWhere:\n- The item name is the string name of the item,\n- Item metadata is the metadata/damage of the item (-1 is best for tools/armour so it\nworks for any durability),\n- If not {}, the nbt will try to match the nbt on the item giving the effect,\n- The effect id and duration are the effect type and time applied in ticks,\n- The effect strength is the level of the effect, starting at 0,\n- The effect probability is the chance of the effect happening, from 0.0 to 1.0, and\n- The type of particles is either none, faded, or normal.\n\nFor the wearing armor situation, you can also add up to 3 extra armor pieces to it\nto get a 'set bonus' effect, in the format:\n\n      ..._____<Armor Item 1 name>_____<Armor Item 2 name>_____<Armor Item 3 name>\n\n\nThere are also a few events for blocks, which are:\n\n      Get a potion effect while standing on top of a block.\n      Get a potion effect while inside of a block.\n      Get a potion effect when digging a block (block-based).\n      Get a potion effect after breaking a block (block-based).\n\n      Run a command while standing on top of a block.\n      Run a command while inside of a block.\n      Run a command when digging a block (block-based).\n      Run a command after breaking a block (block-based).\n\nAdd entries for the potion effects in the form:\n      <Block name>_____<Block metadata (-1 for any)>_____<Effect id>_____<Effect duration>_____<Effect strength>_____<Effect probability>_____<Type of Particles>\n\nAdd for the commands in the form:\n      <Block name>_____<Block metadata (-1 for any)>_____<Command probability>_____<Command>\n\nWhere:\n- The block name is the string name of the block,\n- Block metadata is the metadata of the block,\n- The effect id and duration are the effect type and time applied in ticks,\n- The effect strength is the level of the effect, starting at 0,\n- The effect probability is the chance of the effect happening, from 0.0 to 1.0, and\n- The type of particles is either none, faded, or normal.\n\n------------------------------------------------------------------------------------\n\nFor instance, if you want a stone sword that has a 50% chance to apply a wither 2 effect for 5\nseconds when named 'Torment', you can put in the hitting entity (give to entity) section:\n\n      minecraft:stone_sword_____-1_____{display:{Name:Torment}}_____20_____100_____1_____0.5_____normal\n\nIf you want to give a regeneration effect to someone wearing full chain\narmor, you can put in the wearing armor section:\n\n      minecraft:chainmail_helmet_____-1_____{}_____10_____60_____0_____1.0_____none_____minecraft:chainmail_chestplate_____minecraft:chainmail_leggings_____minecraft:chainmail_boots\n\nAnd finally, if you wanted to have 'Boots of Flame', that, when named that, give you fire\nresistnace and light the block you are standing on on fire, you would put these two in the wearing\narmor and command wearing armor sections:\n\n      any_____-1_____{display:{Name:\"Boots of Flame\"}}_____1.0_____lppcondition testforblock ~ ~-1 ~ air _if_false_ lppcondition testforblock ~ ~ ~ air _if_true_ setblock ~ ~ ~ fire\n      any_____-1_____{display:{Name:\"Boots of Flame\"}}_____12_____2_____0_____1.0_____none");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 167 */     ArrayList<String> entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Hitting Entity (Give to entity)", new String[0]).getStringList(), this.namesToExtras.get("hitting_entity_to_entity")); int index;
/* 168 */     for (index = 0; index < entries.size(); index++) {
/* 169 */       String entry = entries.get(index);
/* 170 */       loadPotionEffect(entry, false, GiveEffects.entityOnHitEntityMap, "Hitting Entity (Give to Entity)", index);
/*     */     } 
/*     */     
/* 173 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Hitting Entity (Give to yourself)", new String[0]).getStringList(), this.namesToExtras.get("hitting_entity_to_yourself"));
/* 174 */     for (index = 0; index < entries.size(); index++) {
/* 175 */       String entry = entries.get(index);
/* 176 */       loadPotionEffect(entry, false, GiveEffects.youOnHitEntityMap, "Hitting Entity (Give to Yourself)", index);
/*     */     } 
/*     */     
/* 179 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Digging Block", new String[0]).getStringList(), this.namesToExtras.get("digging_block"));
/* 180 */     for (index = 0; index < entries.size(); index++) {
/* 181 */       String entry = entries.get(index);
/* 182 */       loadPotionEffect(entry, false, GiveEffects.onItemBlockDigMap, "Digging Block", index);
/*     */     } 
/*     */     
/* 185 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Broke Block", new String[0]).getStringList(), this.namesToExtras.get("broke_block"));
/* 186 */     for (index = 0; index < entries.size(); index++) {
/* 187 */       String entry = entries.get(index);
/* 188 */       loadPotionEffect(entry, false, GiveEffects.onItemBlockBrokeMap, "Broke Block", index);
/*     */     } 
/*     */     
/* 191 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Right Click", new String[0]).getStringList(), this.namesToExtras.get("right_click"));
/* 192 */     for (index = 0; index < entries.size(); index++) {
/* 193 */       String entry = entries.get(index);
/* 194 */       loadPotionEffect(entry, false, GiveEffects.onRightClickMap, "Right Click", index);
/*     */     } 
/*     */     
/* 197 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Wearing Armor (This is the one you can add extra item names to)", new String[0]).getStringList(), this.namesToExtras.get("wearing_armour"));
/* 198 */     for (index = 0; index < entries.size(); index++) {
/* 199 */       String entry = entries.get(index);
/* 200 */       loadPotionEffect(entry, true, GiveEffects.onWornMap, "Wearing Armor", index);
/*     */     } 
/*     */     
/* 203 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "In Inventory", new String[0]).getStringList(), this.namesToExtras.get("in_inventory"));
/* 204 */     for (index = 0; index < entries.size(); index++) {
/* 205 */       String entry = entries.get(index);
/* 206 */       loadPotionEffect(entry, false, GiveEffects.onPassiveMap, "In Inventory", index);
/*     */     } 
/*     */     
/* 209 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Held", new String[0]).getStringList(), this.namesToExtras.get("held"));
/* 210 */     for (index = 0; index < entries.size(); index++) {
/* 211 */       String entry = entries.get(index);
/* 212 */       loadPotionEffect(entry, false, GiveEffects.onHeldMap, "Held", index);
/*     */     } 
/*     */     
/* 215 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Standing On Block", new String[0]).getStringList(), this.namesToExtras.get("standing_on_block"));
/* 216 */     for (index = 0; index < entries.size(); index++) {
/* 217 */       String entry = entries.get(index);
/* 218 */       loadPotionEffectBlock(entry, GiveEffects.standingOnMap, "Standing On Block", index);
/*     */     } 
/*     */     
/* 221 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Inside Block", new String[0]).getStringList(), this.namesToExtras.get("inside_block"));
/* 222 */     for (index = 0; index < entries.size(); index++) {
/* 223 */       String entry = entries.get(index);
/* 224 */       loadPotionEffectBlock(entry, GiveEffects.insideMap, "Inside Block", index);
/*     */     } 
/*     */     
/* 227 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Digging Block (Block)", new String[0]).getStringList(), this.namesToExtras.get("digging_block_block"));
/* 228 */     for (index = 0; index < entries.size(); index++) {
/* 229 */       String entry = entries.get(index);
/* 230 */       loadPotionEffectBlock(entry, GiveEffects.onBlockBlockDigMap, "Digging Block (Block)", index);
/*     */     } 
/*     */     
/* 233 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("effects", "Broke Block (Block)", new String[0]).getStringList(), this.namesToExtras.get("broke_block_block"));
/* 234 */     for (index = 0; index < entries.size(); index++) {
/* 235 */       String entry = entries.get(index);
/* 236 */       loadPotionEffectBlock(entry, GiveEffects.onBlockBlockBrokeMap, "Broke Block (Block)", index);
/*     */     } 
/*     */     
/* 239 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Hitting Entity (Give to entity)", new String[0]).getStringList(), this.namesToExtras.get("command_hitting_entity_to_entity"));
/* 240 */     for (index = 0; index < entries.size(); index++) {
/* 241 */       String entry = entries.get(index);
/* 242 */       loadCommandEffect(entry, false, GiveEffects.entityOnHitEntityMap, "Hitting Entity (Give to Entity)", index);
/*     */     } 
/*     */     
/* 245 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Hitting Entity (Give to yourself)", new String[0]).getStringList(), this.namesToExtras.get("command_hitting_entity_to_yourself"));
/* 246 */     for (index = 0; index < entries.size(); index++) {
/* 247 */       String entry = entries.get(index);
/* 248 */       loadCommandEffect(entry, false, GiveEffects.youOnHitEntityMap, "Hitting Entity (Give to Yourself)", index);
/*     */     } 
/*     */     
/* 251 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Digging Block", new String[0]).getStringList(), this.namesToExtras.get("command_digging_block"));
/* 252 */     for (index = 0; index < entries.size(); index++) {
/* 253 */       String entry = entries.get(index);
/* 254 */       loadCommandEffect(entry, false, GiveEffects.onItemBlockDigMap, "Digging Block", index);
/*     */     } 
/*     */     
/* 257 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Broke Block", new String[0]).getStringList(), this.namesToExtras.get("command_broke_block"));
/* 258 */     for (index = 0; index < entries.size(); index++) {
/* 259 */       String entry = entries.get(index);
/* 260 */       loadCommandEffect(entry, false, GiveEffects.onItemBlockBrokeMap, "Broke Block", index);
/*     */     } 
/*     */     
/* 263 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Right Click", new String[0]).getStringList(), this.namesToExtras.get("command_right_click"));
/* 264 */     for (index = 0; index < entries.size(); index++) {
/* 265 */       String entry = entries.get(index);
/* 266 */       loadCommandEffect(entry, false, GiveEffects.onRightClickMap, "Right Click", index);
/*     */     } 
/*     */     
/* 269 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Wearing Armor (This is the one you can add extra item names to)", new String[0]).getStringList(), this.namesToExtras.get("command_wearing_armour"));
/* 270 */     for (index = 0; index < entries.size(); index++) {
/* 271 */       String entry = entries.get(index);
/* 272 */       loadCommandEffect(entry, true, GiveEffects.onWornMap, "Wearing Armor", index);
/*     */     } 
/*     */     
/* 275 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "In Inventory", new String[0]).getStringList(), this.namesToExtras.get("command_in_inventory"));
/* 276 */     for (index = 0; index < entries.size(); index++) {
/* 277 */       String entry = entries.get(index);
/* 278 */       loadCommandEffect(entry, false, GiveEffects.onPassiveMap, "In Inventory", index);
/*     */     } 
/*     */     
/* 281 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Held", new String[0]).getStringList(), this.namesToExtras.get("command_held"));
/* 282 */     for (index = 0; index < entries.size(); index++) {
/* 283 */       String entry = entries.get(index);
/* 284 */       loadCommandEffect(entry, false, GiveEffects.onHeldMap, "Held", index);
/*     */     } 
/*     */     
/* 287 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Standing On Block", new String[0]).getStringList(), this.namesToExtras.get("command_standing_on_block"));
/* 288 */     for (index = 0; index < entries.size(); index++) {
/* 289 */       String entry = entries.get(index);
/* 290 */       loadCommandEffectBlock(entry, GiveEffects.standingOnMap, "Standing On Block", index);
/*     */     } 
/*     */     
/* 293 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Inside Block", new String[0]).getStringList(), this.namesToExtras.get("command_inside_block"));
/* 294 */     for (index = 0; index < entries.size(); index++) {
/* 295 */       String entry = entries.get(index);
/* 296 */       loadCommandEffectBlock(entry, GiveEffects.insideMap, "Inside Block", index);
/*     */     } 
/*     */     
/* 299 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Digging Block (Block)", new String[0]).getStringList(), this.namesToExtras.get("command_digging_block_block"));
/* 300 */     for (index = 0; index < entries.size(); index++) {
/* 301 */       String entry = entries.get(index);
/* 302 */       loadCommandEffectBlock(entry, GiveEffects.onBlockBlockDigMap, "Digging Block (Block)", index);
/*     */     } 
/*     */     
/* 305 */     entries = ConfigExtrasLoader.combineLists(effectConfig.get("command effects", "Broke Block (Block)", new String[0]).getStringList(), this.namesToExtras.get("command_broke_block_block"));
/* 306 */     for (index = 0; index < entries.size(); index++) {
/* 307 */       String entry = entries.get(index);
/* 308 */       loadCommandEffectBlock(entry, GiveEffects.onBlockBlockBrokeMap, "Broke Block (Block)", index);
/*     */     } 
/*     */     
/* 311 */     effectConfig.save();
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadPotionEffect(String entry, boolean isWorn, TreeMap<ItemStack, ArrayList<GiveEffects.EffectInfo>> effectMap, String type, int index) {
/* 316 */     String[] parts = entry.split("_____");
/*     */     
/* 318 */     boolean comment = false;
/* 319 */     String title = getFileName() + ".cfg '" + type + "' #" + (index + 1);
/*     */     
/* 321 */     if (entry.length() > 0) {
/* 322 */       comment = (entry.charAt(0) == '#');
/*     */     }
/*     */     
/* 325 */     if (parts.length < 8) {
/* 326 */       if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */       
/*     */       return;
/*     */     } 
/* 330 */     String itemName = parts[0];
/* 331 */     int meta = -1;
/* 332 */     String nbtString = parts[2];
/* 333 */     Potion potion = Potion.func_180142_b(parts[3]);
/* 334 */     int effectDuration = 10;
/* 335 */     int effectStrength = 0;
/* 336 */     float probability = 1.0F;
/* 337 */     String particleType = parts[7];
/*     */     
/* 339 */     if (potion == null) {
/*     */       try {
/* 341 */         int effectId = Integer.valueOf(parts[3]).intValue();
/* 342 */         potion = Potion.field_76425_a[effectId];
/*     */       }
/* 344 */       catch (NumberFormatException numberFormatException) {}
/*     */       
/* 346 */       if (potion == null) {
/* 347 */         LootPPNotifier.notify(comment, title, "Couldn't find potion effect '" + parts[3] + "'");
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     try {
/* 353 */       meta = Integer.valueOf(parts[1]).intValue();
/* 354 */       effectDuration = Integer.valueOf(parts[4]).intValue();
/* 355 */       effectStrength = Integer.valueOf(parts[5]).intValue();
/* 356 */       probability = Float.valueOf(parts[6]).floatValue();
/*     */     }
/* 358 */     catch (NumberFormatException e) {
/* 359 */       if (!comment) {
/* 360 */         System.err.println("[Loot++] Caught an exception while trying to add an effect for item " + itemName);
/* 361 */         e.printStackTrace();
/* 362 */         LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[4], parts[5], parts[6] });
/*     */       } 
/*     */     } 
/*     */     
/* 366 */     if (meta < 0) meta = 32767;
/*     */     
/* 368 */     Item item = null;
/*     */     
/* 370 */     if (itemName.equalsIgnoreCase("any")) {
/* 371 */       item = LootPPItems.generalDummyIcon;
/*     */     } else {
/*     */       
/* 374 */       item = Item.func_111206_d(itemName);
/*     */       
/* 376 */       if (item == null) {
/* 377 */         LootPPNotifier.notifyNonexistant(comment, title, itemName);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 382 */     NBTTagCompound nbt = null;
/*     */     
/* 384 */     if (!nbtString.equals("") && !nbtString.equals("{}")) {
/*     */       try {
/* 386 */         nbt = JsonToNBT.func_180713_a(nbtString.trim());
/*     */       }
/* 388 */       catch (Exception e) {
/*     */         
/* 390 */         if (!comment) {
/* 391 */           LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage());
/* 392 */           e.printStackTrace();
/*     */         } 
/* 394 */         nbt = null;
/*     */       } 
/*     */     }
/*     */     
/* 398 */     GiveEffects.EffectInfoPotion effectInfoPotion = new GiveEffects.EffectInfoPotion(potion, effectDuration, effectStrength, probability, particleType);
/*     */     
/* 400 */     if (isWorn)
/*     */     {
/* 402 */       for (int i = 8; i < 11; i++) {
/* 403 */         if (parts.length > i) {
/* 404 */           Item extraItem = Item.func_111206_d(parts[i]);
/*     */           
/* 406 */           if (extraItem == null) {
/* 407 */             LootPPNotifier.notifyNonexistant(comment, title, parts[i]);
/*     */           }
/*     */           else {
/*     */             
/* 411 */             ItemStack extraStack = new ItemStack(extraItem, 1, 32767);
/*     */             
/* 413 */             ((GiveEffects.EffectInfo)effectInfoPotion).alsoEquipped.add(extraStack);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 418 */     ItemStack stack = new ItemStack(item, 1, meta);
/*     */     
/* 420 */     if (nbt != null) {
/* 421 */       stack.func_77982_d(nbt);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 426 */     ArrayList<GiveEffects.EffectInfo> infoList = new ArrayList<GiveEffects.EffectInfo>();
/*     */     
/* 428 */     if (effectMap.containsKey(stack)) {
/* 429 */       infoList = effectMap.get(stack);
/*     */     }
/*     */     
/* 432 */     infoList.add(effectInfoPotion);
/*     */     
/* 434 */     effectMap.put(stack, infoList);
/*     */     
/* 436 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Giving " + (isWorn ? "worn " : "") + "item '" + itemName + "' the effect " + effectInfoPotion);
/*     */   
/*     */   }
/*     */   
/*     */   private void loadCommandEffect(String entry, boolean isWorn, TreeMap<ItemStack, ArrayList<GiveEffects.EffectInfo>> effectMap, String type, int index) {
/* 441 */     String[] parts = entry.split("_____");
/*     */     
/* 443 */     boolean comment = false;
/* 444 */     String title = getFileName() + ".cfg '" + type + "' #" + (index + 1);
/*     */     
/* 446 */     if (entry.length() > 0) {
/* 447 */       comment = (entry.charAt(0) == '#');
/*     */     }
/*     */     
/* 450 */     if (parts.length < 5) {
/* 451 */       if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */       
/*     */       return;
/*     */     } 
/* 455 */     String itemName = parts[0];
/* 456 */     int meta = -1;
/* 457 */     String nbtString = parts[2];
/* 458 */     float probability = 1.0F;
/* 459 */     String command = parts[4];
/*     */     
/*     */     try {
/* 462 */       meta = Integer.valueOf(parts[1]).intValue();
/* 463 */       probability = Float.valueOf(parts[3]).floatValue();
/*     */     }
/* 465 */     catch (NumberFormatException e) {
/* 466 */       if (!comment) {
/* 467 */         System.err.println("[Loot++] Caught an exception while trying to add an effect for item " + itemName);
/* 468 */         e.printStackTrace();
/* 469 */         LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[3] });
/*     */       } 
/*     */     } 
/*     */     
/* 473 */     if (meta < 0) meta = 32767;
/*     */     
/* 475 */     Item item = null;
/*     */     
/* 477 */     if (itemName.equalsIgnoreCase("any")) {
/* 478 */       item = LootPPItems.generalDummyIcon;
/*     */     } else {
/*     */       
/* 481 */       item = Item.func_111206_d(itemName);
/*     */       
/* 483 */       if (item == null) {
/* 484 */         LootPPNotifier.notifyNonexistant(comment, title, itemName);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 489 */     NBTTagCompound nbt = null;
/*     */     
/* 491 */     if (!nbtString.equals("") && !nbtString.equals("{}")) {
/*     */       try {
/* 493 */         nbt = JsonToNBT.func_180713_a(nbtString.trim());
/*     */       }
/* 495 */       catch (Exception e) {
/*     */         
/* 497 */         if (!comment) {
/* 498 */           LootPPNotifier.notifyNBT(comment, title, nbtString, e.getMessage());
/* 499 */           e.printStackTrace();
/*     */         } 
/* 501 */         nbt = null;
/*     */       } 
/*     */     }
/*     */     
/* 505 */     GiveEffects.EffectInfoCommand effectInfoCommand = new GiveEffects.EffectInfoCommand(probability, command);
/*     */     
/* 507 */     if (isWorn)
/*     */     {
/* 509 */       for (int i = 8; i < 11; i++) {
/* 510 */         if (parts.length > i) {
/* 511 */           Item extraItem = Item.func_111206_d(parts[i]);
/*     */           
/* 513 */           if (extraItem == null) {
/* 514 */             LootPPNotifier.notifyNonexistant(comment, title, parts[i]);
/*     */           }
/*     */           else {
/*     */             
/* 518 */             ItemStack extraStack = new ItemStack(extraItem, 1, 32767);
/*     */             
/* 520 */             ((GiveEffects.EffectInfo)effectInfoCommand).alsoEquipped.add(extraStack);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 525 */     ItemStack stack = new ItemStack(item, 1, meta);
/*     */     
/* 527 */     if (nbt != null) {
/* 528 */       stack.func_77982_d(nbt);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 533 */     ArrayList<GiveEffects.EffectInfo> infoList = new ArrayList<GiveEffects.EffectInfo>();
/*     */     
/* 535 */     if (effectMap.containsKey(stack)) {
/* 536 */       infoList = effectMap.get(stack);
/*     */     }
/*     */     
/* 539 */     infoList.add(effectInfoCommand);
/*     */     
/* 541 */     effectMap.put(stack, infoList);
/*     */     
/* 543 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Giving " + (isWorn ? "worn " : "") + "item '" + itemName + "' the effect " + effectInfoCommand);
/*     */   
/*     */   }
/*     */   
/*     */   private void loadPotionEffectBlock(String entry, TreeMap<LootPPHelper.BlockMeta, ArrayList<GiveEffects.EffectInfo>> effectMap, String type, int index) {
/* 548 */     String[] parts = entry.split("_____");
/*     */     
/* 550 */     boolean comment = false;
/* 551 */     String title = getFileName() + ".cfg '" + type + "' #" + (index + 1);
/*     */     
/* 553 */     if (entry.length() > 0) {
/* 554 */       comment = (entry.charAt(0) == '#');
/*     */     }
/*     */     
/* 557 */     if (parts.length < 7) {
/* 558 */       if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */       
/*     */       return;
/*     */     } 
/* 562 */     String blockName = parts[0];
/* 563 */     int meta = -1;
/* 564 */     Potion potion = Potion.func_180142_b(parts[2]);
/* 565 */     int effectDuration = 10;
/* 566 */     int effectStrength = 0;
/* 567 */     float probability = 1.0F;
/* 568 */     String particleType = parts[6];
/*     */     
/* 570 */     if (potion == null) {
/*     */       try {
/* 572 */         int effectId = Integer.valueOf(parts[2]).intValue();
/* 573 */         potion = Potion.field_76425_a[effectId];
/*     */       }
/* 575 */       catch (NumberFormatException numberFormatException) {}
/*     */       
/* 577 */       if (potion == null) {
/* 578 */         LootPPNotifier.notify(comment, title, "Couldn't find potion effect '" + parts[2] + "'");
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     try {
/* 584 */       meta = Integer.valueOf(parts[1]).intValue();
/* 585 */       effectDuration = Integer.valueOf(parts[3]).intValue();
/* 586 */       effectStrength = Integer.valueOf(parts[4]).intValue();
/* 587 */       probability = Float.valueOf(parts[5]).floatValue();
/*     */     }
/* 589 */     catch (NumberFormatException e) {
/* 590 */       if (!comment) {
/* 591 */         System.err.println("[Loot++] Caught an exception while trying to add an effect for item " + blockName);
/* 592 */         e.printStackTrace();
/* 593 */         LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[3], parts[4], parts[5] });
/*     */       } 
/*     */     } 
/*     */     
/* 597 */     if (meta < 0) meta = 32767;
/*     */     
/* 599 */     Block block = null;
/*     */     
/* 601 */     if (blockName.equalsIgnoreCase("any")) {
/* 602 */       block = LootPPBlocks.blockCommandBlockTrigger;
/*     */     } else {
/*     */       
/* 605 */       block = Block.func_149684_b(blockName);
/*     */       
/* 607 */       if (block == null || (block == Blocks.field_150350_a && !blockName.equals("minecraft:air") && !blockName.equals("air"))) {
/* 608 */         LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 613 */     GiveEffects.EffectInfoPotion effectInfoPotion = new GiveEffects.EffectInfoPotion(potion, effectDuration, effectStrength, probability, particleType);
/*     */     
/* 615 */     LootPPHelper.BlockMeta blockInfo = new LootPPHelper.BlockMeta(block, meta);
/*     */ 
/*     */ 
/*     */     
/* 619 */     ArrayList<GiveEffects.EffectInfo> infoList = new ArrayList<GiveEffects.EffectInfo>();
/*     */     
/* 621 */     if (effectMap.containsKey(blockInfo)) {
/* 622 */       infoList = effectMap.get(blockInfo);
/*     */     }
/*     */     
/* 625 */     infoList.add(effectInfoPotion);
/*     */     
/* 627 */     effectMap.put(blockInfo, infoList);
/*     */     
/* 629 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Giving block '" + blockName + "' the effect " + effectInfoPotion);
/*     */   
/*     */   }
/*     */   
/*     */   private void loadCommandEffectBlock(String entry, TreeMap<LootPPHelper.BlockMeta, ArrayList<GiveEffects.EffectInfo>> effectMap, String type, int index) {
/* 634 */     String[] parts = entry.split("_____");
/*     */     
/* 636 */     boolean comment = false;
/* 637 */     String title = getFileName() + ".cfg '" + type + "' #" + (index + 1);
/*     */     
/* 639 */     if (entry.length() > 0) {
/* 640 */       comment = (entry.charAt(0) == '#');
/*     */     }
/*     */     
/* 643 */     if (parts.length < 4) {
/* 644 */       if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */       
/*     */       return;
/*     */     } 
/* 648 */     String blockName = parts[0];
/* 649 */     int meta = -1;
/* 650 */     float probability = 1.0F;
/* 651 */     String command = parts[3];
/*     */     
/*     */     try {
/* 654 */       meta = Integer.valueOf(parts[1]).intValue();
/* 655 */       probability = Float.valueOf(parts[2]).floatValue();
/*     */     }
/* 657 */     catch (NumberFormatException e) {
/* 658 */       if (!comment) {
/* 659 */         System.err.println("[Loot++] Caught an exception while trying to add an effect for item " + blockName);
/* 660 */         e.printStackTrace();
/* 661 */         LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[2] });
/*     */       } 
/*     */     } 
/*     */     
/* 665 */     if (meta < 0) meta = 32767;
/*     */     
/* 667 */     Block block = null;
/*     */     
/* 669 */     if (blockName.equalsIgnoreCase("any")) {
/* 670 */       block = LootPPBlocks.blockCommandBlockTrigger;
/*     */     } else {
/*     */       
/* 673 */       block = Block.func_149684_b(blockName);
/*     */       
/* 675 */       if (block == null || (block == Blocks.field_150350_a && !blockName.equals("minecraft:air") && !blockName.equals("air"))) {
/* 676 */         LootPPNotifier.notifyNonexistant(comment, title, blockName);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 681 */     GiveEffects.EffectInfoCommand effectInfoCommand = new GiveEffects.EffectInfoCommand(probability, command);
/*     */     
/* 683 */     LootPPHelper.BlockMeta blockInfo = new LootPPHelper.BlockMeta(block, meta);
/*     */ 
/*     */ 
/*     */     
/* 687 */     ArrayList<GiveEffects.EffectInfo> infoList = new ArrayList<GiveEffects.EffectInfo>();
/*     */     
/* 689 */     if (effectMap.containsKey(blockInfo)) {
/* 690 */       infoList = effectMap.get(blockInfo);
/*     */     }
/*     */     
/* 693 */     infoList.add(effectInfoCommand);
/*     */     
/* 695 */     effectMap.put(blockInfo, infoList);
/*     */     
/* 697 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Giving block '" + blockName + "' the effect " + effectInfoCommand); 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderEffects.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */