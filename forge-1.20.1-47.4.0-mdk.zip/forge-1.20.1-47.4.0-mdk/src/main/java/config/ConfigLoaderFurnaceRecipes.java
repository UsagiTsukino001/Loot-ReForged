/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTException;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderFurnaceRecipes
/*     */   extends ConfigLoader
/*     */ {
/*  34 */   public static ConfigLoaderFurnaceRecipes instance = new ConfigLoaderFurnaceRecipes();
/*     */   
/*     */   ConfigLoaderFurnaceRecipes() {
/*  37 */     this.namesToExtras.put("add_furnace_fuels", new ArrayList<String>());
/*  38 */     this.namesToExtras.put("add_smelting_recipes", new ArrayList<String>());
/*     */   }
/*     */   
/*     */   public String getFileName() {
/*  42 */     return "furnace_recipes";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadFurnaceRecipes() {
/*  48 */     Configuration furnaceConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  50 */     furnaceConfig.load();
/*     */ 
/*     */ 
/*     */     
/*  54 */     FurnaceRecipes furnaceRecipes = FurnaceRecipes.func_77602_a();
/*     */     
/*  56 */     Map<ItemStack, ItemStack> smeltingMap = furnaceRecipes.func_77599_b();
/*  57 */     Map<ItemStack, Float> experienceMap = new HashMap<ItemStack, Float>();
/*     */     
/*  59 */     if (LootPPHelper.gotFurnaceXP) {
/*     */       try {
/*  61 */         experienceMap = (Map<ItemStack, Float>)LootPPHelper.experienceMap.get(furnaceRecipes);
/*  62 */       } catch (Exception e) {
/*  63 */         System.out.println("[Loot++] Caught Exception while trying to load in furnace xp.");
/*  64 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*  68 */     furnaceConfig.addCustomCategoryComment("_instructions", "************   Instructions   *************\nFor the default entries, they are formatted as follows:\n\n      <number of items>-<amount of xp>. Disable them by setting the number of items to 0.\n\nTo add new smelting recipes, put items in the adding section in the format:\n\n      <input item id>_____<metadata (-1 for any)>_____<output item id>_____<metadata>_____<NBT Tag ({} for blank)>_____<amount>_____<xp given (optional)>\n\nFor instance, if you want to add a recipe where smelting wool of any color gives you charcoal, you can add:\n\n      minecraft:wool_____-1_____minecraft:coal_____1_____{}_____1_____1.0\n\nNote that the nbt data is ignored for smelting recipes, which is why it isn't a parameter for the input item.\n\n\nTo add new furnace fuel items, add them to the add_furnace_fuels section in the format:\n\n      <fuel item id>_____<metadata (-1 for any)>_____<burn time>\n\nFor reference, a furnace operation takes a time of 200. Coal has a burn time of 1600.");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     ArrayList<String> fuelAdditions = ConfigExtrasLoader.combineLists(furnaceConfig.get("add_furnace_fuels", "add_furnace_fuels", new String[0]).getStringList(), this.namesToExtras.get("add_furnace_fuels"));
/*     */     int index;
/*  96 */     for (index = 0; index < fuelAdditions.size(); index++) {
/*  97 */       String entry = fuelAdditions.get(index);
/*     */       
/*  99 */       boolean comment = false;
/* 100 */       String title = getFileName() + ".cfg 'add_furnace_fuels' #" + (index + 1);
/*     */       
/* 102 */       if (entry.length() > 0) {
/* 103 */         comment = (entry.charAt(0) == '#');
/*     */       }
/*     */       
/* 106 */       String[] parts = entry.split("_____");
/*     */       
/* 108 */       if (parts.length != 3) {
/* 109 */         if (!entry.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, entry);
/*     */       
/*     */       } else {
/*     */         
/* 113 */         String itemName = parts[0];
/* 114 */         int meta = -1;
/* 115 */         int burnTime = 200;
/*     */         
/*     */         try {
/* 118 */           meta = Integer.valueOf(parts[1]).intValue();
/* 119 */           burnTime = Integer.valueOf(parts[2]).intValue();
/*     */         }
/* 121 */         catch (NumberFormatException e) {
/* 122 */           if (!comment) {
/* 123 */             System.err.println("[Loot++] Caught an exception while trying to add furnace fuel " + itemName);
/* 124 */             e.printStackTrace();
/* 125 */             LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[2] });
/*     */           } 
/*     */         } 
/*     */         
/* 129 */         if (meta < 0) {
/* 130 */           meta = 32767;
/*     */         }
/*     */         
/* 133 */         Object itemObj = Item.field_150901_e.func_82594_a(itemName);
/*     */         
/* 135 */         if (itemObj == null || !(itemObj instanceof Item)) {
/* 136 */           LootPPNotifier.notifyNonexistant(comment, title, itemName);
/*     */         }
/*     */         else {
/*     */           
/* 140 */           Item item = (Item)itemObj;
/*     */           
/* 142 */           LootPPHelper.fuelHandler.addFuel(new ItemStack(item, 1, meta), burnTime);
/*     */           
/* 144 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added furnace fuel " + itemName);
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/* 149 */     Set<ItemStack> toRemove = new HashSet<ItemStack>();
/*     */     
/* 151 */     for (ItemStack stackInput : smeltingMap.keySet()) {
/* 152 */       ItemStack stackOutput = smeltingMap.get(stackInput);
/*     */ 
/*     */       
/* 155 */       float xp = 0.0F;
/* 156 */       if (experienceMap.containsKey(stackOutput)) {
/* 157 */         xp = ((Float)experienceMap.get(stackOutput)).floatValue();
/*     */       }
/*     */       
/* 160 */       if (stackInput == null || stackOutput == null || stackInput.func_77973_b() == null || stackOutput.func_77973_b() == null) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 165 */       String title = getFileName() + ".cfg 'default_smelting_recipes' input:" + stackInput + ", output:" + stackOutput;
/*     */       
/* 167 */       String result = "" + stackOutput.field_77994_a + "-" + xp;
/* 168 */       String display = "Input: " + Item.field_150901_e.func_177774_c(stackInput.func_77973_b()) + " with damage: " + stackInput.func_77952_i() + ", Output: " + Item.field_150901_e.func_177774_c(stackOutput.func_77973_b()) + " with damage: " + stackOutput.func_77952_i();
/*     */       
/* 170 */       result = furnaceConfig.get("default_smelting_recipes", display, result).getString();
/*     */       
/* 172 */       int dashIndex = result.indexOf('-');
/*     */       
/* 174 */       if (dashIndex == -1) {
/* 175 */         LootPPNotifier.notifyWrongNumberOfParts(false, title, result);
/*     */         
/*     */         continue;
/*     */       } 
/* 179 */       int size = 1;
/* 180 */       float newxp = 0.0F;
/*     */       
/* 182 */       String sizeString = result.substring(0, dashIndex);
/* 183 */       String xpString = result.substring(dashIndex + 1);
/*     */       
/*     */       try {
/* 186 */         size = Integer.valueOf(sizeString).intValue();
/* 187 */         newxp = Float.valueOf(xpString).floatValue();
/*     */       }
/* 189 */       catch (NumberFormatException e) {
/* 190 */         System.err.println("[Loot++] Caught exception while reading in furnace recipes.");
/* 191 */         e.printStackTrace();
/* 192 */         LootPPNotifier.notifyNumber(false, title, new String[] { sizeString, xpString });
/*     */       } 
/*     */       
/* 195 */       if (MathHelper.func_76135_e(xp - newxp) > 0.01D) {
/* 196 */         experienceMap.put(stackOutput, Float.valueOf(newxp));
/*     */       }
/*     */       
/* 199 */       if (size != stackOutput.field_77994_a) {
/* 200 */         if (size <= 0) {
/* 201 */           toRemove.add(stackInput);
/*     */           continue;
/*     */         } 
/* 204 */         stackOutput.field_77994_a = size;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 209 */     for (ItemStack stack : toRemove) {
/* 210 */       if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removing furnace recipe for " + Item.field_150901_e.func_177774_c(stack.func_77973_b())); 
/* 211 */       smeltingMap.remove(stack);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 216 */     ArrayList<String> smeltingList = ConfigExtrasLoader.combineLists(furnaceConfig.get("add_smelting_recipes", "add_smelting_recipes", new String[0]).getStringList(), this.namesToExtras.get("add_smelting_recipes"));
/*     */     
/* 218 */     for (index = 0; index < smeltingList.size(); index++) {
/* 219 */       String toAdd = smeltingList.get(index);
/* 220 */       String[] parts = toAdd.split("_____");
/*     */       
/* 222 */       boolean comment = false;
/* 223 */       String title = getFileName() + ".cfg 'add_smelting_recipes' #" + (index + 1);
/*     */       
/* 225 */       if (toAdd.length() > 0) {
/* 226 */         comment = (toAdd.charAt(0) == '#');
/*     */       }
/* 228 */       if (parts.length < 6) {
/* 229 */         if (!toAdd.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, toAdd);
/*     */       
/*     */       } else {
/*     */         
/* 233 */         String inputItemName = parts[0];
/* 234 */         String inputMetaString = parts[1];
/* 235 */         String outputItemName = parts[2];
/* 236 */         String outputMetaString = parts[3];
/* 237 */         String outputNBTString = parts[4];
/* 238 */         String amountString = parts[5];
/* 239 */         String xpString = "0";
/*     */         
/* 241 */         if (parts.length >= 7) {
/* 242 */           xpString = parts[6];
/*     */         }
/*     */         
/* 245 */         Object inputObj = Item.field_150901_e.func_82594_a(inputItemName);
/* 246 */         Object outputObj = Item.field_150901_e.func_82594_a(outputItemName);
/*     */         
/* 248 */         if (inputObj == null || !(inputObj instanceof Item)) {
/* 249 */           LootPPNotifier.notifyNonexistant(comment, title, inputItemName);
/*     */ 
/*     */         
/*     */         }
/* 253 */         else if (outputObj == null || !(outputObj instanceof Item)) {
/* 254 */           LootPPNotifier.notifyNonexistant(comment, title, outputItemName);
/*     */         }
/*     */         else {
/*     */           
/* 258 */           Item inputItem = (Item)inputObj;
/* 259 */           Item outputItem = (Item)outputObj;
/*     */           
/* 261 */           int inputMeta = 0;
/* 262 */           int outputMeta = 0;
/* 263 */           int amount = 1;
/* 264 */           float xp = 0.0F;
/*     */           
/*     */           try {
/* 267 */             inputMeta = Integer.valueOf(inputMetaString).intValue();
/* 268 */             outputMeta = Integer.valueOf(outputMetaString).intValue();
/* 269 */             amount = Integer.valueOf(amountString).intValue();
/* 270 */             xp = Float.valueOf(xpString).floatValue();
/*     */           }
/* 272 */           catch (NumberFormatException e) {
/* 273 */             if (!comment) {
/* 274 */               System.err.println("[Loot++] Caught an exception while trying to add a recipe for " + outputItemName);
/* 275 */               e.printStackTrace();
/* 276 */               LootPPNotifier.notifyNumber(comment, title, new String[] { inputMetaString, outputMetaString, amountString, xpString });
/*     */             } 
/*     */           } 
/*     */           
/* 280 */           if (amount < 1) amount = 1; 
/* 281 */           if (outputMeta < 0) outputMeta = 0;
/*     */ 
/*     */           
/* 284 */           NBTTagCompound outputTag = null;
/*     */           
/* 286 */           if (!outputNBTString.equals("") && !outputNBTString.equals("{}")) {
/*     */             try {
/* 288 */               NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(outputNBTString);
/*     */               
/* 290 */               if (nBTTagCompound != null) {
/* 291 */                 outputTag = nBTTagCompound;
/*     */               }
/*     */             }
/* 294 */             catch (NBTException e) {
/* 295 */               if (!comment) {
/* 296 */                 LootPPNotifier.notifyNBT(comment, title, outputNBTString, e.getMessage());
/* 297 */                 e.printStackTrace();
/*     */               } 
/* 299 */               outputTag = null;
/*     */             } 
/*     */           }
/*     */           
/* 303 */           ItemStack inputStack = new ItemStack(inputItem, 1, (inputMeta == -1) ? 32767 : inputMeta);
/* 304 */           ItemStack outputStack = new ItemStack(outputItem, amount, outputMeta);
/*     */           
/* 306 */           if (outputTag != null) {
/* 307 */             outputStack.func_77982_d(outputTag);
/*     */           }
/*     */           
/* 310 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Adding furnace smelting recipe for " + outputItemName);
/*     */           
/* 312 */           GameRegistry.addSmelting(inputStack, outputStack, xp);
/*     */         } 
/*     */       } 
/* 315 */     }  furnaceConfig.save();
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderFurnaceRecipes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */