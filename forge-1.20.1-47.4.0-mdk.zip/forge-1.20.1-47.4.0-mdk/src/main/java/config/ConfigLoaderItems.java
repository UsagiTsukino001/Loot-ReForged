/*      */ package com.tmtravlr.lootplusplus.config;
/*      */ 
/*      */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*      */ import com.tmtravlr.lootplusplus.LootPPItems;
/*      */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*      */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAdded;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedArmour;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedAxe;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedBow;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedFood;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedGun;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedHoe;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedMultiTool;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedPickaxe;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedShovel;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedSword;
/*      */ import com.tmtravlr.lootplusplus.additions.ItemAddedThrowable;
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import net.minecraft.init.Items;
/*      */ import net.minecraft.item.Item;
/*      */ import net.minecraft.item.ItemArmor;
/*      */ import net.minecraft.item.ItemStack;
/*      */ import net.minecraft.potion.Potion;
/*      */ import net.minecraft.potion.PotionEffect;
/*      */ import net.minecraftforge.common.config.Configuration;
/*      */ import net.minecraftforge.common.config.Property;
/*      */ import net.minecraftforge.common.util.EnumHelper;
/*      */ import net.minecraftforge.fml.common.registry.GameRegistry;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConfigLoaderItems
/*      */   extends ConfigLoader
/*      */ {
/*   39 */   public static ConfigLoaderItems instance = new ConfigLoaderItems();
/*      */   
/*      */   ConfigLoaderItems() {
/*   42 */     this.namesToExtras.put("generic_items", new ArrayList<String>());
/*   43 */     this.namesToExtras.put("foods", new ArrayList<String>());
/*   44 */     this.namesToExtras.put("thrown", new ArrayList<String>());
/*   45 */     this.namesToExtras.put("bows", new ArrayList<String>());
/*   46 */     this.namesToExtras.put("guns", new ArrayList<String>());
/*   47 */     this.namesToExtras.put("multitools", new ArrayList<String>());
/*   48 */     this.namesToExtras.put("materials", new ArrayList<String>());
/*   49 */     this.namesToExtras.put("swords", new ArrayList<String>());
/*   50 */     this.namesToExtras.put("pickaxes", new ArrayList<String>());
/*   51 */     this.namesToExtras.put("axes", new ArrayList<String>());
/*   52 */     this.namesToExtras.put("shovels", new ArrayList<String>());
/*   53 */     this.namesToExtras.put("hoes", new ArrayList<String>());
/*   54 */     this.namesToExtras.put("helmets", new ArrayList<String>());
/*   55 */     this.namesToExtras.put("chestplates", new ArrayList<String>());
/*   56 */     this.namesToExtras.put("leggings", new ArrayList<String>());
/*   57 */     this.namesToExtras.put("boots", new ArrayList<String>());
/*      */   }
/*      */   
/*      */   public String getFileName() {
/*   61 */     return "item_additions";
/*      */   }
/*      */ 
/*      */   
/*      */   public void loadItemAdditions() {
/*   66 */     Configuration itemConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*      */     
/*   68 */     itemConfig.load();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   75 */     Property temp = itemConfig.get("add_generic", "generic_items", new String[0]);
/*   76 */     temp.comment = "Add generic items, which have no special functions, but are good for\nintermediate crafting ingredients and such, in the format:\n\n      <Item name>_____<Item display name>_____<Shines (true or false, optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- If shines is true, the item will have the glow like enchanted\nitems, nether stars, etc.\n\nSo for instance to add a ruby, you could put\n\n      ruby_____Ruby\n\nAssuming you had an item model ruby.json in the folder mentioned above.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   95 */     ArrayList<String> infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("generic_items"));
/*      */     int index;
/*   97 */     for (index = 0; index < infoList.size(); index++) {
/*   98 */       String info = infoList.get(index);
/*   99 */       String title = getFileName() + ".cfg 'generic_items' #" + (index + 1);
/*      */       
/*  101 */       boolean comment = false;
/*      */       
/*  103 */       if (info.length() > 0) {
/*  104 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  107 */       if (!comment) {
/*      */         
/*  109 */         String[] parts = info.split("_____");
/*      */         
/*  111 */         if (parts.length < 2) {
/*  112 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/*  116 */           String itemName = parts[0];
/*  117 */           String displayName = parts[1];
/*  118 */           boolean shines = false;
/*      */           
/*  120 */           if (parts.length > 2) {
/*  121 */             shines = Boolean.valueOf(parts[2]).booleanValue();
/*      */           }
/*      */           
/*  124 */           Item generic = (new ItemAdded(shines, displayName)).func_77655_b(itemName);
/*  125 */           LootPPItems.addedItems.add(generic);
/*  126 */           GameRegistry.registerItem(generic, itemName);
/*  127 */           LootPlusPlusMod.proxy.registerItemRender(generic);
/*      */           
/*  129 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom generic item: lootplusplus:" + itemName); 
/*      */         } 
/*      */       } 
/*      */     } 
/*  133 */     temp = itemConfig.get("add_foods", "foods", new String[0]);
/*  134 */     temp.comment = "Add food items, which can be eaten and restore hunger. Add them in the format:\n\n      <Item name>_____<Item display name>_____<Shines (true or false)>_____<Food restored>_____<Saturation>_____<Wolves eat (true or false)>_____<Always edible (true or false)>_____<Time to eat>_____<Potion effects given (optional)>\n\nWhere: \n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The texture location is the name of the png file you place in the resource \npack, in the 'assets/minecraft/items' folder without the .png.\n- If shines is true, the food item will shine like enchanted items.\n- The food restored is the amount of food restored in half bars.\n- The saturation is how much saturation is given by the food (time until you\nget hungry again).- If wolves eat is true, wolves can eat the food.\n- If always edible is true, you can eat the food even if you're not hungry.\n- Time to eat is how long it takes to eat the item (32 normally).\n- Finally the potions the food gives you is a list of potion effects in the format:\n\n      ..._____<Potion effect id>-<Potion duration>-<Potion level (0 is 1)>-<Probability (between 0.0 and 1.0)>-<Particle type (normal, faded, or none)>_____...\n\nFor reference, some of the vanilla foods could be recreated with:\n\nSteak:                  cooked_beef_____Steak_____false_____8_____0.8_____true_____false_____32\nRotten Flesh:           rotten_flesh_____Rotten Flesh_____false_____4_____0.1_____true_____false_____32_____17-1200-0-0.8-normal\nGolden Apple:           golden_apple_____Golden Apple_____false_____4_____1.2_____false_____true_____32_____10-100-0-1.0-normal_____22-2400-0-1.0-normal\nEnchanted Golden Apple: enchanted_golden_apple_____Enchanted Golden Apple_____true_____4_____1.2_____false_____true_____32_____10-600-4-1.0-normal_____22-2400-0-1.0-normal_____11-6000-0-1.0-normal_____12-6000-0-1.0-normal\n\nAs an example, if you wanted to add an item like a slice of pizza, you could add:\n\n      pizza_slice_____Pizza Slice_____false_____6_____0.6_____false_____false_____32\n\nOr if you wanted to add 'ruby' apples like the vanilla golden ones but with\nhealth boost instead of absorption, you could add:\n\n      ruby_apple_____§bRuby Apple_____false_____4_____1.2_____false_____true_____32_____10-150-1-1.0-normal_____21-2400-1-1.0-normal\n      enchanted_ruby_apple_____§dRuby Apple_____true_____4_____1.2_____false_____true_____32_____10-600-4-1.0-normal_____21-2400-4-1.0-normal_____11-6000-0-1.0-normal_____12-6000-0-1.0-normal";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  173 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("foods"));
/*      */     
/*  175 */     for (index = 0; index < infoList.size(); index++) {
/*  176 */       String info = infoList.get(index);
/*  177 */       String title = getFileName() + ".cfg 'foods' #" + (index + 1);
/*      */       
/*  179 */       boolean comment = false;
/*      */       
/*  181 */       if (info.length() > 0) {
/*  182 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  185 */       if (!comment) {
/*      */         
/*  187 */         String[] parts = info.split("_____");
/*      */         
/*  189 */         if (parts.length < 8) {
/*  190 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/*  194 */           String itemName = parts[0];
/*  195 */           String displayName = parts[1];
/*  196 */           boolean shines = false;
/*  197 */           int foodRestored = 4;
/*  198 */           float saturationRestored = 0.4F;
/*  199 */           boolean wolvesEat = false;
/*  200 */           boolean alwaysEdible = false;
/*  201 */           int eatTime = 32;
/*      */           
/*      */           try {
/*  204 */             shines = Boolean.valueOf(parts[2]).booleanValue();
/*  205 */             foodRestored = Integer.valueOf(parts[3]).intValue();
/*  206 */             saturationRestored = Float.valueOf(parts[4]).floatValue();
/*  207 */             wolvesEat = Boolean.valueOf(parts[5]).booleanValue();
/*  208 */             alwaysEdible = Boolean.valueOf(parts[6]).booleanValue();
/*  209 */             eatTime = Integer.valueOf(parts[7]).intValue();
/*      */           }
/*  211 */           catch (NumberFormatException e) {
/*  212 */             if (!comment) {
/*  213 */               System.err.println("[Loot++] Caught an exception while trying to create a food item " + itemName);
/*  214 */               e.printStackTrace();
/*  215 */               LootPPNotifier.notifyNumber(comment, title, new String[] { parts[2], parts[3], parts[4], parts[5], parts[6], parts[7] });
/*      */             } 
/*      */           } 
/*      */           
/*  219 */           Item food = (new ItemAddedFood(foodRestored, saturationRestored, wolvesEat, alwaysEdible, eatTime, shines, displayName)).func_77655_b(itemName);
/*  220 */           LootPPItems.addedItems.add(food);
/*  221 */           GameRegistry.registerItem(food, itemName);
/*  222 */           LootPlusPlusMod.proxy.registerItemRender(food);
/*      */           
/*  224 */           if (parts.length > 8) {
/*  225 */             for (int i = 8; i < parts.length; i++) {
/*  226 */               String[] potionParts = parts[i].split("-");
/*      */               
/*  228 */               if (potionParts.length != 5) {
/*  229 */                 LootPPNotifier.notifyWrongNumberOfParts(comment, title, parts[i]);
/*      */                 
/*      */                 continue;
/*      */               } 
/*  233 */               Potion potion = Potion.func_180142_b(potionParts[0]);
/*  234 */               int potionDuration = 100;
/*  235 */               int potionAmplifier = 0;
/*  236 */               float probability = 1.0F;
/*  237 */               String particles = potionParts[4];
/*      */               
/*  239 */               if (potion == null) {
/*      */                 try {
/*  241 */                   int effectId = Integer.valueOf(potionParts[0]).intValue();
/*  242 */                   potion = Potion.field_76425_a[effectId];
/*      */                 }
/*  244 */                 catch (NumberFormatException numberFormatException) {}
/*      */                 
/*  246 */                 if (potion == null) {
/*  247 */                   LootPPNotifier.notify(comment, title, "Couldn't find potion effect '" + potionParts[0] + "'");
/*      */                   
/*      */                   continue;
/*      */                 } 
/*      */               } 
/*      */               try {
/*  253 */                 potionDuration = Integer.valueOf(potionParts[1]).intValue();
/*  254 */                 potionAmplifier = Integer.valueOf(potionParts[2]).intValue();
/*  255 */                 probability = Float.valueOf(potionParts[3]).floatValue();
/*      */               }
/*  257 */               catch (NumberFormatException e) {
/*  258 */                 if (!comment) {
/*  259 */                   System.err.println("[Loot++] Caught an exception while trying to create a food item " + itemName);
/*  260 */                   e.printStackTrace();
/*  261 */                   LootPPNotifier.notifyNumber(comment, title, new String[] { potionParts[1], potionParts[2], potionParts[3] });
/*      */                 } 
/*      */               } 
/*  264 */               PotionEffect effect = new PotionEffect(potion.func_76396_c(), potionDuration, potionAmplifier);
/*  265 */               ((ItemAddedFood)food).addPotionEffect(effect, probability, particles);
/*      */               continue;
/*      */             } 
/*      */           }
/*  269 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom food item: lootplusplus:" + itemName); 
/*      */         } 
/*      */       } 
/*      */     } 
/*  273 */     temp = itemConfig.get("add_thrown", "thrown", new String[0]);
/*  274 */     temp.comment = "Add thrown items, which you can throw with right click, in the format:\n\n      <Item name>_____<Item display name>_____<Shines (true or false)>_____<Damage>_____<Velocity>_____<Gravity>_____<Inaccuracy>_____<Drop Chance (Optional)>_____<Drops (Optional)>\n\nWhere:\n- The <Item name> will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The <Item display name> is what people will see in-game.\n- If <Shines> is true, the item will have the glow like enchanted\nitems, nether stars, etc.\n- the <Damage> is how much damage the thrown item will when hitting an entity.\n- The <Velocity> is how fast the thrown item will travel.\n- The <Gravity> is how much the item is affected by gravity.\n- The <Innacuracy> is how much the thrown item will 'wobble'.\n- The <Drop chance> is the chance that a drop will happen, from 0.0-1.0.\n- The <Drops> is a list of drops the item will drop when it lands\nin the same format as block and entity drops:\n\n      ..._____i-<Item id>-<Min>-<Max>-<Weight (optional)>-<Metadata (optional)>-<NBT Tag (optional)>_____...\n\nfor items, or:\n\n      ..._____e-<Entity id>-<Weight (optional)>-<NBT tag (optional)>_____...\n\nfor entities, or:\n\n      ..._____c-<Weight>-<Command>_____...\n\nfor commands, where:\n- The <Item id> or<Entity id> is the string id for the item or entity.- The <Weight> is the chance that this drop will be chosen out of all the combined weights.\nMake sure it's bigger than 0. If you don't specify the weight, it will default to 1.\n- And the <Command> is a command you want to run where the block breaks.\n\nAlso, you can put %%%%% between drops to create groups of drops. In a group, only the weight of\nthe first drop will count.\n\nSome examples of default items could be:\n\n      snowball: snowball_____Snowball_____false_____0.0_____1.5_____0.03_____0.0\n      egg: egg_____Egg_____false_____0.0_____1.5_____0.03_____0.0_____0.12_____e-Chicken-31-{Age:-24000}_____e-Chicken-1-{Age:-24000}%%%%%e-Chicken-1-{Age:-24000}%%%%%e-Chicken-1-{Age:-24000}%%%%%e-Chicken-1-{Age:-24000}\n      xp bottle: experience_bottle_____Bottle o' Enchanting_____true_____0.0_____0.7_____0.07_____-20.0_____1.0_____e-XPOrb-1-{Value:3}%%%%%c-1-playsound game.potion.smash @a ~ ~ ~_____e-XPOrb-1-{Value:3}%%%%%e-XPOrb-1-{Value:3}%%%%%c-1-playsound game.potion.smash @a ~ ~ ~_____e-XPOrb-1-{Value:7}%%%%%e-XPOrb-1-{Value:2}%%%%%c-1-playsound game.potion.smash @a ~ ~ ~_____e-XPOrb-1-{Value:7}%%%%%e-XPOrb-1-{Value:3}%%%%%e-XPOrb-1-{Value:1}%%%%%c-1-playsound game.potion.smash @a ~ ~ ~\n\nAs an example, if you wanted to add a 'grenade' that turns into TNT:\n\n      grenade_____Grenade_____false_____0.0_____1.0_____0.05_____0.0_____1.0_____e-PrimedTnt-1-{Fuse:40}\n\nAssuming you had an item model grenade.json in the folder mentioned above.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  324 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("thrown"));
/*      */     
/*  326 */     for (index = 0; index < infoList.size(); index++) {
/*  327 */       String info = infoList.get(index);
/*  328 */       String title = getFileName() + ".cfg 'thrown' #" + (index + 1);
/*      */       
/*  330 */       boolean comment = false;
/*      */       
/*  332 */       if (info.length() > 0) {
/*  333 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  336 */       if (!comment) {
/*      */         
/*  338 */         String[] parts = info.split("_____");
/*      */         
/*  340 */         if (parts.length < 7) {
/*  341 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/*  345 */           String itemName = parts[0];
/*  346 */           String displayName = parts[1];
/*  347 */           boolean shines = false;
/*  348 */           float damage = 0.0F;
/*  349 */           float velocity = 1.5F;
/*  350 */           float gravity = 0.03F;
/*  351 */           float inaccuracy = 0.0F;
/*  352 */           float chance = 0.0F;
/*  353 */           ArrayList<ArrayList<LootPPHelper.DropInfo>> thrownDrops = new ArrayList<ArrayList<LootPPHelper.DropInfo>>();
/*      */           
/*      */           try {
/*  356 */             shines = Boolean.valueOf(parts[2]).booleanValue();
/*  357 */             damage = Float.valueOf(parts[3]).floatValue();
/*  358 */             velocity = Float.valueOf(parts[4]).floatValue();
/*  359 */             gravity = Float.valueOf(parts[5]).floatValue();
/*  360 */             inaccuracy = Float.valueOf(parts[6]).floatValue();
/*      */             
/*  362 */             if (parts.length > 7) {
/*  363 */               chance = Float.valueOf(parts[7]).floatValue();
/*      */             }
/*      */           }
/*  366 */           catch (NumberFormatException e) {
/*  367 */             if (!comment) {
/*  368 */               System.err.println("[Loot++] Caught exception while trying to add a throwable item " + itemName);
/*  369 */               e.printStackTrace();
/*  370 */               LootPPNotifier.notifyNumber(comment, title, parts[2] + ", " + parts[3] + ", " + parts[4] + ", " + parts[5] + ", " + parts[6] + ((parts.length > 7) ? (", " + parts[7]) : ""));
/*      */             } 
/*      */           } 
/*      */           
/*  374 */           for (int i = 8; i < parts.length; i++) {
/*  375 */             String dropString = parts[i];
/*      */             
/*  377 */             if (!dropString.equals("")) {
/*      */ 
/*      */ 
/*      */               
/*  381 */               String[] subParts = dropString.split("%%%%%");
/*  382 */               ArrayList<LootPPHelper.DropInfo> dropList = new ArrayList<LootPPHelper.DropInfo>();
/*      */               
/*  384 */               for (int j = 0; j < subParts.length; j++) {
/*      */                 
/*  386 */                 String subString = subParts[j];
/*      */                 
/*  388 */                 int dashIndex = subString.indexOf("-");
/*      */                 
/*  390 */                 if (dashIndex >= 0) {
/*      */ 
/*      */ 
/*      */                   
/*  394 */                   char type = subString.charAt(0);
/*      */                   
/*  396 */                   LootPPHelper.DropInfo dropInfo = LootPPHelper.getDropInfo(type, subString.substring(dashIndex + 1), comment, title);
/*      */                   
/*  398 */                   if (dropInfo != null) {
/*  399 */                     dropList.add(dropInfo);
/*      */                   }
/*      */                 } 
/*      */               } 
/*      */               
/*  404 */               if (!dropList.isEmpty()) {
/*  405 */                 thrownDrops.add(dropList);
/*      */               }
/*      */             } 
/*      */           } 
/*  409 */           Item throwable = (new ItemAddedThrowable(shines, damage, velocity, gravity, inaccuracy, chance, thrownDrops, displayName)).func_77655_b(itemName);
/*  410 */           LootPPItems.addedItems.add(throwable);
/*  411 */           GameRegistry.registerItem(throwable, itemName);
/*  412 */           LootPlusPlusMod.proxy.registerItemRender(throwable);
/*      */           
/*  414 */           if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom thrown item: lootplusplus:" + itemName); 
/*      */         } 
/*      */       } 
/*      */     } 
/*  418 */     temp = itemConfig.get("additions_bows", "bows", new String[0]);
/*  419 */     temp.comment = "Add bows, which act like vanilla bows. Add them in the format:\n\n      <Item name>_____<Item display name>_____<Durability>_____<Base damage>_____<Draw time>_____<# of arrows shot>_____<Enchantability>_____<Repair item name (write none for none)>_____<Repair item meta (-1 for any)>_____<Custom ammo item (optional, must be throwable added item, defaults to minecraft:arrow)>_____<Custom Shooting Sound (optional, defaults to random.bow)>\n\nWhere: \n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). You should add 4 model files for the item\nin the resource pack at assets/lootplusplus/models/item/<Item name>,\nassets/lootplusplus/models/item/<Item name>_pulling_0,\nassets/lootplusplus/models/item/<Item name>_pulling_1, and\nassets/lootplusplus/models/item/<Item name>_pulling_2.\n- The item display name is what people will see in-game. \n- The durability is the durability of the bow.\n- The base damage is the amount of damage added to any arrows you shoot.\n- The draw time is how fast you can draw the bow.\n- The enchantability is how enchantable the bow is.\n- The repair item is what you can repair the bow with ('none' if not repairable).\n- The repair meta is the metadata for the repair item.\n- The custom ammo item is the item this bow will shoot. Leave it out or\nput minecraft:arrow for the bow to shoot arrows. If you include it, it\nmust be a throwable item you added above.\n- The custom shooting sound is what sound the bow makes when you shoot it.\n\nFor reference the vanilla bow would be something like:\n\n      bow_____Bow_____384_____0.0_____20_____1_____1_____none_____-1\n\nIf you wanted to add ruby reinforced bows, regular and double, you could put:\n\n      ruby_bow_____Ruby Reinforced Bow_____1000_____2.0_____22_____1_____5_____lootplusplus:ruby_____-1\n      ruby_double_bow_____Double Ruby Reinforced Bow_____1500_____2.0_____25_____2_____10_____lootplusplus:ruby_bow_____-1\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  451 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("bows"));
/*      */     
/*  453 */     for (index = 0; index < infoList.size(); index++) {
/*  454 */       String info = infoList.get(index);
/*  455 */       String title = getFileName() + ".cfg 'bows' #" + (index + 1);
/*      */       
/*  457 */       boolean comment = false;
/*      */       
/*  459 */       if (info.length() > 0) {
/*  460 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  463 */       if (comment)
/*      */         continue; 
/*  465 */       String[] parts = info.split("_____");
/*      */       
/*  467 */       if (parts.length < 9) {
/*  468 */         if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         continue;
/*      */       } 
/*  472 */       String itemName = parts[0];
/*  473 */       String displayName = parts[1];
/*  474 */       int durability = 384;
/*  475 */       float baseDamage = 0.0F;
/*  476 */       int drawSpeed = 72000;
/*  477 */       int arrowCount = 1;
/*  478 */       int enchantability = 1;
/*  479 */       String repairItemName = parts[7];
/*  480 */       int repairMeta = 32767;
/*  481 */       String ammoName = (parts.length > 9) ? parts[9] : "minecraft:arrow";
/*  482 */       String soundName = (parts.length > 10) ? parts[10] : "random.bow";
/*      */       
/*      */       try {
/*  485 */         durability = Integer.valueOf(parts[2]).intValue();
/*  486 */         baseDamage = Float.valueOf(parts[3]).floatValue();
/*  487 */         drawSpeed = Integer.valueOf(parts[4]).intValue();
/*  488 */         arrowCount = Integer.valueOf(parts[5]).intValue();
/*  489 */         enchantability = Integer.valueOf(parts[6]).intValue();
/*  490 */         repairMeta = Integer.valueOf(parts[8]).intValue();
/*      */       }
/*  492 */       catch (NumberFormatException e) {
/*  493 */         if (!comment) {
/*  494 */           System.err.println("[Loot++] Caught exception while trying to add a bow " + itemName);
/*  495 */           e.printStackTrace();
/*  496 */           LootPPNotifier.notifyNumber(comment, title, new String[] { parts[2], parts[3], parts[4], parts[5], parts[6], parts[8] });
/*      */         } 
/*      */       } 
/*      */       
/*  500 */       if (repairMeta < 0) {
/*  501 */         repairMeta = 32767;
/*      */       }
/*      */       
/*  504 */       if (durability <= 0) {
/*  505 */         durability = 1;
/*      */       }
/*      */       
/*  508 */       if (baseDamage < 0.0F) {
/*  509 */         baseDamage = 0.0F;
/*      */       }
/*      */       
/*  512 */       if (enchantability < 1) {
/*  513 */         enchantability = 1;
/*      */       }
/*      */       
/*  516 */       Item repairItem = null;
/*      */       
/*  518 */       if (!repairItemName.equals("none")) {
/*  519 */         repairItem = Item.func_111206_d(repairItemName);
/*      */         
/*  521 */         if (repairItem == null) {
/*  522 */           LootPPNotifier.notifyNonexistant(comment, title, repairItemName);
/*      */           
/*      */           continue;
/*      */         } 
/*      */       } 
/*      */       
/*  528 */       Item ammoItem = Item.func_111206_d(ammoName);
/*      */       
/*  530 */       if (ammoItem != Items.field_151032_g && 
/*  531 */         !(ammoItem instanceof ItemAddedThrowable)) {
/*  532 */         LootPPNotifier.notify(comment, title, "No throwable Loot++ item found called " + ammoName);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  537 */         ItemStack repairStack = null;
/*      */         
/*  539 */         if (repairItem != null) {
/*  540 */           repairStack = new ItemStack(repairItem, 1, repairMeta);
/*      */         }
/*      */         
/*  543 */         Item bow = (new ItemAddedBow(displayName, baseDamage, drawSpeed, durability, arrowCount, enchantability, repairStack, ammoItem, soundName)).func_77655_b(itemName);
/*  544 */         LootPPItems.addedItems.add(bow);
/*  545 */         GameRegistry.registerItem(bow, itemName);
/*  546 */         LootPlusPlusMod.proxy.registerVariants(bow, new String[] { "lootplusplus:" + itemName, "lootplusplus:" + itemName + "_pulling_0", "lootplusplus:" + itemName + "_pulling_1", "lootplusplus:" + itemName + "_pulling_2" });
/*  547 */         LootPlusPlusMod.proxy.registerItemRender(bow);
/*  548 */         LootPlusPlusMod.proxy.registerItemRenderWithDamage(bow, 1, itemName + "_pulling_0");
/*  549 */         LootPlusPlusMod.proxy.registerItemRenderWithDamage(bow, 2, itemName + "_pulling_1");
/*  550 */         LootPlusPlusMod.proxy.registerItemRenderWithDamage(bow, 3, itemName + "_pulling_2");
/*      */ 
/*      */         
/*  553 */         if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom bow: lootplusplus:" + itemName); 
/*      */       } 
/*      */       continue;
/*      */     } 
/*  557 */     temp = itemConfig.get("additions_guns", "guns", new String[0]);
/*  558 */     temp.comment = "Add guns, which fire on right click, then wait for a set time before\nfiring again. Add them in the format:\n\n      <Item name>_____<Item display name>_____<Durability>_____<Base damage>_____<Draw time>_____<# of arrows shot>_____<Enchantability>_____<Repair item name (write none for none)>_____<Repair item meta (-1 for any)>_____<Ammo Item>_____<Custom bullet item (must be throwable added item)>_____<Custom Shooting Sound (optional, defaults to random.bow)>\n\nWhere: \n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). You should add a model file for the item\nin the resource pack at assets/lootplusplus/models/item/<Item name>.\n- The item display name is what people will see in-game. \n- The durability is the durability of the gun.\n- The base damage is the amount of damage added to any bullets you shoot.\n- The draw time is how fast you can draw the gun.\n- The enchantability is how enchantable the gun is.\n- The repair item is what you can repair the gun with ('none' if not repairable).\n- The repair meta is the metadata for the repair item.\n- The ammo item is the item this gun will consume from your inventory\nwhen it shoots ('none' if no ammo item).\n- The shot item is the item this gun will shoot. It must be a throwable\nitem you added above.\n- The custom shooting sound is what sound the gun makes when you shoot it.\n\nIf you wanted to add ruby pistol and rifle, assuming you added 2 items above (a\ngeneric item ruby_bullets, and a throwable item ruby_shot) you could put:\n\n      ruby_pistol_____Ruby Pistol_____1000_____4.0_____20_____1_____10_____lootplusplus:ruby_____-1_____lootplusplus:ruby_bullets_____lootplusplus:ruby_shot\n      ruby_rifle_____Ruby Rifle_____1500_____7.0_____40_____1_____10_____lootplusplus:ruby_____-1_____lootplusplus:ruby_bullets_____lootplusplus:ruby_shot\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  586 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("guns"));
/*      */     
/*  588 */     for (index = 0; index < infoList.size(); index++) {
/*  589 */       String info = infoList.get(index);
/*  590 */       String title = getFileName() + ".cfg 'guns' #" + (index + 1);
/*      */       
/*  592 */       boolean comment = false;
/*      */       
/*  594 */       if (info.length() > 0) {
/*  595 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  598 */       if (comment)
/*      */         continue; 
/*  600 */       String[] parts = info.split("_____");
/*      */       
/*  602 */       if (parts.length < 11) {
/*  603 */         if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         continue;
/*      */       } 
/*  607 */       String itemName = parts[0];
/*  608 */       String displayName = parts[1];
/*  609 */       int durability = 384;
/*  610 */       float baseDamage = 0.0F;
/*  611 */       int drawSpeed = 72000;
/*  612 */       int arrowCount = 1;
/*  613 */       int enchantability = 1;
/*  614 */       String repairItemName = parts[7];
/*  615 */       int repairMeta = 32767;
/*  616 */       String ammoName = parts[9];
/*  617 */       String shotName = parts[10];
/*  618 */       String soundName = (parts.length > 11) ? parts[11] : "random.bow";
/*      */       
/*      */       try {
/*  621 */         durability = Integer.valueOf(parts[2]).intValue();
/*  622 */         baseDamage = Float.valueOf(parts[3]).floatValue();
/*  623 */         drawSpeed = Integer.valueOf(parts[4]).intValue();
/*  624 */         arrowCount = Integer.valueOf(parts[5]).intValue();
/*  625 */         enchantability = Integer.valueOf(parts[6]).intValue();
/*  626 */         repairMeta = Integer.valueOf(parts[8]).intValue();
/*      */       }
/*  628 */       catch (NumberFormatException e) {
/*  629 */         if (!comment) {
/*  630 */           System.err.println("[Loot++] Caught exception while trying to add a gun " + itemName);
/*  631 */           e.printStackTrace();
/*  632 */           LootPPNotifier.notifyNumber(comment, title, new String[] { parts[2], parts[3], parts[4], parts[5], parts[6], parts[8] });
/*      */         } 
/*      */       } 
/*      */       
/*  636 */       if (repairMeta < 0) {
/*  637 */         repairMeta = 32767;
/*      */       }
/*      */       
/*  640 */       if (durability <= 0) {
/*  641 */         durability = 1;
/*      */       }
/*      */       
/*  644 */       if (baseDamage < 0.0F) {
/*  645 */         baseDamage = 0.0F;
/*      */       }
/*      */       
/*  648 */       if (enchantability < 1) {
/*  649 */         enchantability = 1;
/*      */       }
/*      */       
/*  652 */       Item repairItem = null;
/*      */       
/*  654 */       if (!repairItemName.equals("none")) {
/*  655 */         repairItem = Item.func_111206_d(repairItemName);
/*      */         
/*  657 */         if (repairItem == null) {
/*  658 */           LootPPNotifier.notifyNonexistant(comment, title, repairItemName);
/*      */           
/*      */           continue;
/*      */         } 
/*      */       } 
/*      */       
/*  664 */       Item ammoItem = Item.func_111206_d(ammoName);
/*      */       
/*  666 */       if (!ammoName.equals("none")) {
/*  667 */         if (ammoItem == null) {
/*  668 */           LootPPNotifier.notifyNonexistant(comment, title, ammoName);
/*      */           
/*      */           continue;
/*      */         } 
/*      */       } else {
/*  673 */         ammoItem = Items.field_151032_g;
/*  674 */         arrowCount = 0;
/*      */       } 
/*      */       
/*  677 */       Item shotItem = Item.func_111206_d(shotName);
/*      */       
/*  679 */       if (!(shotItem instanceof ItemAddedThrowable)) {
/*  680 */         LootPPNotifier.notify(comment, title, "No throwable Loot++ item found called " + shotName);
/*      */       }
/*      */       else {
/*      */         
/*  684 */         ItemStack repairStack = null;
/*      */         
/*  686 */         if (repairItem != null) {
/*  687 */           repairStack = new ItemStack(repairItem, 1, repairMeta);
/*      */         }
/*      */         
/*  690 */         Item gun = (new ItemAddedGun(displayName, baseDamage, drawSpeed, durability, arrowCount, enchantability, repairStack, ammoItem, (ItemAddedThrowable)shotItem, soundName)).func_77655_b(itemName);
/*  691 */         LootPPItems.addedItems.add(gun);
/*  692 */         GameRegistry.registerItem(gun, itemName);
/*  693 */         LootPlusPlusMod.proxy.registerItemRender(gun);
/*      */ 
/*      */         
/*  696 */         if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom gun: lootplusplus:" + itemName); 
/*      */       } 
/*      */       continue;
/*      */     } 
/*  700 */     temp = itemConfig.get("additions_multitools", "multitools", new String[0]);
/*  701 */     temp.comment = "Add a multitool, which can act like multiple tools at once, in the format:\n\n      <Item name>_____<Item display name>_____<Tool type(s)>_____<Harvest level>_____<Durability>_____<Damage>_____<Efficiency>_____<Enchantability>_____<Repair item name (write none for none)>_____<Repair item meta (-1 for any)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The tool types are the classes of tool that this multitool has, with dashes between\nthem. The possible values are:\n\n      sword, pickaxe, axe, shovel, hoe\n\n- The durability, damage, and efficiency, and enchantability are what you would expect.\n- The repair item is what item you can repair the tool with. If you put 'none',\nthe multitool will not be repairable.\n- The repair item metadata is the metadata of the repair item.\n\nSo for instance, assuming that you added the ruby item in the generic\nsection and material for the item, you can add a ruby multitool that acts\nlike a pickaxe, axe, and shovel with:\n\n      ruby_paxel_____Ruby Paxel_____pickaxe-axe-shovel_____2_____1200_____6.0_____10.0_____20_____lootplusplus:ruby_____-1\n\nAssuming you had a model ruby_paxel.json in the folder mentioned above, and\nif you want to add a ruby battleaxe that acts as both a sword and an axe, you\ncould put:\n\n      ruby_battleaxe_____Ruby Battleaxe_____sword-axe_____2_____1200_____8.0_____10.0_____20_____lootplusplus:ruby_____-1\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  732 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("multitools"));
/*      */     
/*  734 */     index = 0; while (true) { String itemName, displayName, typesString; int harvestLevel, durability; float damage, efficiency; int enchantability; ItemStack repairItem; if (index < infoList.size())
/*  735 */       { String info = infoList.get(index);
/*  736 */         String title = getFileName() + ".cfg 'multitools' #" + (index + 1);
/*      */         
/*  738 */         boolean comment = false;
/*      */         
/*  740 */         if (info.length() > 0) {
/*  741 */           comment = (info.charAt(0) == '#');
/*      */         }
/*      */         
/*  744 */         if (comment)
/*      */           continue; 
/*  746 */         String[] parts = info.split("_____");
/*      */         
/*  748 */         if (parts.length != 10) {
/*  749 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */           
/*      */           continue;
/*      */         } 
/*  753 */         itemName = parts[0];
/*  754 */         displayName = parts[1];
/*  755 */         typesString = parts[2];
/*  756 */         harvestLevel = 0;
/*  757 */         durability = 100;
/*  758 */         damage = 3.0F;
/*  759 */         efficiency = 6.0F;
/*  760 */         enchantability = 10;
/*  761 */         String repairItemName = parts[8];
/*  762 */         int meta = -1;
/*      */         
/*      */         try {
/*  765 */           harvestLevel = Integer.valueOf(parts[3]).intValue();
/*  766 */           durability = Integer.valueOf(parts[4]).intValue();
/*  767 */           damage = Float.valueOf(parts[5]).floatValue();
/*  768 */           efficiency = Float.valueOf(parts[6]).floatValue();
/*  769 */           enchantability = Integer.valueOf(parts[7]).intValue();
/*  770 */           meta = Integer.valueOf(parts[9]).intValue();
/*      */         }
/*  772 */         catch (NumberFormatException e) {
/*  773 */           if (!comment) {
/*  774 */             System.err.println("[Loot++] Caught exception while trying to create tool " + itemName);
/*  775 */             e.printStackTrace();
/*  776 */             LootPPNotifier.notifyNumber(comment, title, new String[] { parts[3], parts[4], parts[5], parts[6], parts[7], parts[9] });
/*      */           } 
/*      */         } 
/*      */         
/*  780 */         if (meta < 0) {
/*  781 */           meta = 32767;
/*      */         }
/*      */         
/*  784 */         repairItem = null;
/*      */         
/*  786 */         if (!repairItemName.equalsIgnoreCase("none"))
/*  787 */         { Object itemObj = Item.field_150901_e.func_82594_a(repairItemName);
/*      */           
/*  789 */           if (itemObj == null || !(itemObj instanceof Item))
/*  790 */           { LootPPNotifier.notifyNonexistant(comment, title, repairItemName); }
/*      */           
/*      */           else
/*      */           
/*  794 */           { repairItem = new ItemStack((Item)itemObj, 1, meta);
/*      */ 
/*      */ 
/*      */             
/*  798 */             String[] toolTypes = typesString.split("-");
/*      */             
/*  800 */             Item addedItem = (new ItemAddedMultiTool(toolTypes, harvestLevel, durability, damage, efficiency, enchantability, repairItem, displayName)).func_77655_b(itemName);
/*  801 */             LootPPItems.addedItems.add(addedItem);
/*  802 */             GameRegistry.registerItem(addedItem, itemName);
/*  803 */             LootPlusPlusMod.proxy.registerItemRender(addedItem); }  continue; }  } else { break; }  String[] arrayOfString = typesString.split("-"); Item item = (new ItemAddedMultiTool(arrayOfString, harvestLevel, durability, damage, efficiency, enchantability, repairItem, displayName)).func_77655_b(itemName); LootPPItems.addedItems.add(item); GameRegistry.registerItem(item, itemName); LootPlusPlusMod.proxy.registerItemRender(item);
/*      */ 
/*      */       
/*      */       index++; }
/*      */ 
/*      */     
/*  809 */     temp = itemConfig.get("add_materials", "materials", new String[0]);
/*  810 */     temp.comment = "Use this to add materials to create weapons, tools, and armour out of.You will be able to repair the tools, ect. that have this material\nwith the given item, and this will also determine the attack damage\nof the tools/weapons. Add entries in the form:\n      <Item name>_____<Item metadata (-1 for any)>_____<Harvest level>_____<Base Durability>_____<Base Efficiency>_____<Base Damage>_____<Enchantability>_____<Armour Durability Factor>_____<Armour Protection List>\n\nFor reference, the default materials would be something like:\n\n      minecraft:planks_____-1_____0_____59_____2.0_____0.0_____15_____5_____1-3-2-1\n      minecraft:leather_____-1_____0_____59_____2.0_____0.0_____15_____5_____1-3-2-1\n      minecraft:stone_____-1_____1_____131_____4.0_____1.0_____5_____5_____1-3-2-1\n      minecraft:iron_ingot_____-1_____2_____250_____6.0_____2.0_____14_____15_____2-6-5-2\n      minecraft:gold_ingot_____-1_____0_____32_____12.0_____0.0_____22_____7_____2-5-3-1\n      minecraft:diamond_____-1_____3_____1561_____8.0_____3.0_____10_____33_____3-8-6-3\n\nSo you should model yours in the same way. You can use materials you add in the\ngeneric section by adding lootplusplus: to the front of the item name. For instance,\nassuming you added the ruby, you could write:\n\n      lootplusplus:ruby_____-1_____3_____1200_____10.0_____3.0_____20_____32_____3-8-6-3\n\nTo make rubies a material much like diamond, but faster at digging, with\nmore enchantability, and less durability.";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  834 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("materials"));
/*      */     
/*  836 */     for (index = 0; index < infoList.size(); index++) {
/*  837 */       String info = infoList.get(index);
/*  838 */       String title = getFileName() + ".cfg 'add_materials' #" + (index + 1);
/*      */       
/*  840 */       boolean comment = false;
/*      */       
/*  842 */       if (info.length() > 0) {
/*  843 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  846 */       String[] parts = info.split("_____");
/*      */       
/*  848 */       if (parts.length != 9) {
/*  849 */         if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */       
/*      */       } else {
/*      */         
/*  853 */         String itemName = parts[0];
/*  854 */         int meta = -1;
/*  855 */         int harvest = 0;
/*  856 */         int durability = 59;
/*  857 */         float efficiency = 2.0F;
/*  858 */         float damage = 0.0F;
/*  859 */         int enchantability = 15;
/*  860 */         int armourDurability = 5;
/*      */ 
/*      */         
/*      */         try {
/*  864 */           meta = Integer.valueOf(parts[1]).intValue();
/*  865 */           harvest = Integer.valueOf(parts[2]).intValue();
/*  866 */           durability = Integer.valueOf(parts[3]).intValue();
/*  867 */           efficiency = Float.valueOf(parts[4]).floatValue();
/*  868 */           damage = Float.valueOf(parts[5]).floatValue();
/*  869 */           enchantability = Integer.valueOf(parts[6]).intValue();
/*  870 */           armourDurability = Integer.valueOf(parts[7]).intValue();
/*      */         }
/*  872 */         catch (NumberFormatException e) {
/*  873 */           if (!comment) {
/*  874 */             System.err.println("[Loot++] Caught exception while trying to add material entry for " + itemName);
/*  875 */             e.printStackTrace();
/*  876 */             LootPPNotifier.notifyNumber(comment, title, new String[] { parts[1], parts[2], parts[3], parts[4], parts[5], parts[6], parts[7] });
/*      */           } 
/*      */         } 
/*      */         
/*  880 */         if (meta < 0) {
/*  881 */           meta = 32767;
/*      */         }
/*      */         
/*  884 */         String[] strengths = parts[8].split("-");
/*      */         
/*  886 */         if (strengths.length != 4) {
/*  887 */           LootPPNotifier.notifyWrongNumberOfParts(comment, title, parts[8]);
/*      */         }
/*      */         else {
/*      */           
/*  891 */           int helm = 1;
/*  892 */           int chest = 3;
/*  893 */           int legs = 2;
/*  894 */           int boots = 1;
/*      */           
/*      */           try {
/*  897 */             helm = Integer.valueOf(strengths[0]).intValue();
/*  898 */             chest = Integer.valueOf(strengths[1]).intValue();
/*  899 */             legs = Integer.valueOf(strengths[2]).intValue();
/*  900 */             boots = Integer.valueOf(strengths[3]).intValue();
/*      */           }
/*  902 */           catch (NumberFormatException e) {
/*  903 */             if (!comment) {
/*  904 */               System.err.println("[Loot++] Caught exception while trying to add material armour strengths for " + itemName);
/*  905 */               e.printStackTrace();
/*  906 */               LootPPNotifier.notifyNumber(comment, title, new String[] { strengths[0], strengths[1], strengths[2], strengths[3] });
/*      */             } 
/*      */           } 
/*      */           
/*  910 */           String name = itemName;
/*      */           
/*  912 */           int colonIndex = itemName.indexOf(':');
/*      */           
/*  914 */           if (colonIndex != -1) {
/*  915 */             name = itemName.substring(colonIndex + 1);
/*      */           }
/*      */           
/*  918 */           name = name + "_" + meta;
/*      */           
/*  920 */           Object itemObj = Item.field_150901_e.func_82594_a(itemName);
/*      */           
/*  922 */           if (itemObj == null || !(itemObj instanceof Item)) {
/*  923 */             LootPPNotifier.notifyNonexistant(comment, title, itemName);
/*      */           }
/*      */           else {
/*      */             
/*  927 */             Item item = (Item)itemObj;
/*      */ 
/*      */             
/*  930 */             Item.ToolMaterial tool = EnumHelper.addToolMaterial(name, harvest, durability, efficiency, damage, enchantability);
/*  931 */             tool.setRepairItem(new ItemStack(item, 1, meta));
/*  932 */             LootPPHelper.addedToolMaterials.put(new ItemStack(item, 1, meta), tool);
/*      */             
/*  934 */             ItemArmor.ArmorMaterial armour = EnumHelper.addArmorMaterial(name, name, armourDurability, new int[] { helm, chest, legs, boots }, enchantability);
/*  935 */             armour.customCraftingMaterial = item;
/*  936 */             LootPPHelper.addedArmourMaterials.put(new ItemStack(item, 1, meta), armour);
/*      */             
/*  938 */             if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom material: " + name); 
/*      */           } 
/*      */         } 
/*      */       } 
/*  942 */     }  temp = itemConfig.get("additions_tools", "swords", new String[0]);
/*  943 */     temp.comment = "Add swords, which act like the vanilla swords, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Added Damage (above innate material damage)>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The material item name is the material that you can repair the tool with\nwhich should be registered in the adding material section first.\n\nSo for instance, assuming that you added the ruby item\nin the generic section and material for the item, you can add a ruby sword,\ndagger, and big sword with:\n      ruby_dagger_____Ruby Dagger_____lootplusplus:ruby_____2.0\n      ruby_sword_____Ruby Sword_____lootplusplus:ruby_____4.0\n      ruby_big_sword_____Ruby Big Sword_____lootplusplus:ruby_____6.0\n\nAssuming you had a models for each in the folder mentioned above.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  965 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("swords"));
/*      */     
/*  967 */     for (index = 0; index < infoList.size(); index++) {
/*  968 */       String info = infoList.get(index);
/*  969 */       String title = getFileName() + ".cfg 'swords' #" + (index + 1);
/*      */       
/*  971 */       boolean comment = false;
/*      */       
/*  973 */       if (info.length() > 0) {
/*  974 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/*  977 */       if (!comment) {
/*      */         
/*  979 */         String[] parts = info.split("_____");
/*      */         
/*  981 */         if (parts.length < 4) {
/*  982 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/*  986 */           String itemName = parts[0];
/*  987 */           String displayName = parts[1];
/*  988 */           String materialItemName = parts[2];
/*  989 */           float damageBonus = 4.0F;
/*  990 */           int meta = -1;
/*      */           
/*      */           try {
/*  993 */             damageBonus = Float.valueOf(parts[3]).floatValue();
/*  994 */             if (parts.length > 4) {
/*  995 */               meta = Integer.valueOf(parts[4]).intValue();
/*      */             }
/*      */           }
/*  998 */           catch (NumberFormatException e) {
/*  999 */             if (!comment) {
/* 1000 */               System.err.println("[Loot++] Caught exception while trying to create sword " + itemName);
/* 1001 */               e.printStackTrace();
/* 1002 */               LootPPNotifier.notifyNumber(comment, title, parts[3] + ((parts.length > 5) ? (", " + parts[4]) : ""));
/*      */             } 
/*      */           } 
/*      */           
/* 1006 */           if (meta < 0) {
/* 1007 */             meta = 32767;
/*      */           }
/*      */           
/* 1010 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1012 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1013 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1017 */             Item item = (Item)itemObj;
/*      */             
/* 1019 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1021 */             if (!LootPPHelper.addedToolMaterials.containsKey(materialStack) || LootPPHelper.addedToolMaterials.get(materialStack) == null) {
/* 1022 */               if (!comment) {
/* 1023 */                 System.err.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1024 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/* 1029 */               Item sword = (new ItemAddedSword((Item.ToolMaterial)LootPPHelper.addedToolMaterials.get(materialStack), damageBonus, displayName)).func_77655_b(itemName);
/* 1030 */               LootPPItems.addedItems.add(sword);
/* 1031 */               GameRegistry.registerItem(sword, itemName);
/* 1032 */               LootPlusPlusMod.proxy.registerItemRender(sword);
/*      */               
/* 1034 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom sword: lootplusplus:" + itemName); 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1039 */     }  temp = itemConfig.get("additions_tools", "pickaxes", new String[0]);
/* 1040 */     temp.comment = "Add pickaxes, which act like the vanilla ones, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The material item name is the material that you can repair the tool with\nwhich should be registered in the adding material section first.\n\nSo for instance, assuming that you added the ruby item in the generic\nsection and material for the item, you can add a ruby pickaxe with:\n\n      ruby_pickaxe_____Ruby Pickaxe_____lootplusplus:ruby\n\nAssuming you had a model ruby_pickaxe.json in the folder mentioned above.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1059 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("pickaxes"));
/*      */     
/* 1061 */     for (index = 0; index < infoList.size(); index++) {
/* 1062 */       String info = infoList.get(index);
/* 1063 */       String title = getFileName() + ".cfg 'pickaxes' #" + (index + 1);
/*      */       
/* 1065 */       boolean comment = false;
/*      */       
/* 1067 */       if (info.length() > 0) {
/* 1068 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1071 */       if (!comment) {
/*      */         
/* 1073 */         String[] parts = info.split("_____");
/*      */         
/* 1075 */         if (parts.length < 3) {
/* 1076 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/* 1080 */           String itemName = parts[0];
/* 1081 */           String displayName = parts[1];
/* 1082 */           String materialItemName = parts[2];
/* 1083 */           int meta = -1;
/*      */           
/*      */           try {
/* 1086 */             if (parts.length > 3) {
/* 1087 */               meta = Integer.valueOf(parts[3]).intValue();
/*      */             }
/*      */           }
/* 1090 */           catch (NumberFormatException e) {
/* 1091 */             if (!comment) {
/* 1092 */               System.err.println("[Loot++] Caught exception while trying to create tool " + itemName);
/* 1093 */               e.printStackTrace();
/* 1094 */               LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */             } 
/*      */           } 
/*      */           
/* 1098 */           if (meta < 0) {
/* 1099 */             meta = 32767;
/*      */           }
/*      */           
/* 1102 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1104 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1105 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1109 */             Item item = (Item)itemObj;
/*      */             
/* 1111 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1113 */             if (!LootPPHelper.addedToolMaterials.containsKey(materialStack) || LootPPHelper.addedToolMaterials.get(materialStack) == null)
/* 1114 */             { if (!comment) {
/* 1115 */                 System.err.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1116 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */                }
/*      */             else
/*      */             
/* 1121 */             { Item pick = (new ItemAddedPickaxe((Item.ToolMaterial)LootPPHelper.addedToolMaterials.get(materialStack), displayName)).func_77655_b(itemName);
/* 1122 */               LootPPItems.addedItems.add(pick);
/* 1123 */               GameRegistry.registerItem(pick, itemName);
/* 1124 */               LootPlusPlusMod.proxy.registerItemRender(pick);
/*      */               
/* 1126 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom pickaxe: lootplusplus:" + itemName);  } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1130 */     }  temp = itemConfig.get("additions_tools", "axes", new String[0]);
/* 1131 */     temp.comment = "Add axes, which act like the vanilla ones, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The material item name is the material that you can repair the tool with\nwhich should be registered in the adding material section first.\n\nSo for instance, assuming that you added the ruby item in the generic\nsection and material for the item, you can add a ruby axe with:\n\n      ruby_axe_____Ruby Axe_____lootplusplus:ruby\n\nAssuming you had a model ruby_axe.json in the folder mentioned above.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1150 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("axes"));
/*      */     
/* 1152 */     for (index = 0; index < infoList.size(); index++) {
/* 1153 */       String info = infoList.get(index);
/* 1154 */       String title = getFileName() + ".cfg 'axes' #" + (index + 1);
/*      */       
/* 1156 */       boolean comment = false;
/*      */       
/* 1158 */       if (info.length() > 0) {
/* 1159 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1162 */       if (!comment) {
/*      */         
/* 1164 */         String[] parts = info.split("_____");
/*      */         
/* 1166 */         if (parts.length < 3) {
/* 1167 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/* 1171 */           String itemName = parts[0];
/* 1172 */           String displayName = parts[1];
/* 1173 */           String materialItemName = parts[2];
/* 1174 */           int meta = -1;
/*      */           
/*      */           try {
/* 1177 */             if (parts.length > 3) {
/* 1178 */               meta = Integer.valueOf(parts[3]).intValue();
/*      */             }
/*      */           }
/* 1181 */           catch (NumberFormatException e) {
/* 1182 */             if (!comment) {
/* 1183 */               System.err.println("[Loot++] Caught exception while trying to create tool " + itemName);
/* 1184 */               e.printStackTrace();
/* 1185 */               LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */             } 
/*      */           } 
/*      */           
/* 1189 */           if (meta < 0) {
/* 1190 */             meta = 32767;
/*      */           }
/*      */           
/* 1193 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1195 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1196 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1200 */             Item item = (Item)itemObj;
/*      */             
/* 1202 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1204 */             if (!LootPPHelper.addedToolMaterials.containsKey(materialStack) || LootPPHelper.addedToolMaterials.get(materialStack) == null)
/* 1205 */             { if (!comment) {
/* 1206 */                 System.err.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1207 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */                }
/*      */             else
/*      */             
/* 1212 */             { Item addedItem = (new ItemAddedAxe((Item.ToolMaterial)LootPPHelper.addedToolMaterials.get(materialStack), displayName)).func_77655_b(itemName);
/* 1213 */               LootPPItems.addedItems.add(addedItem);
/* 1214 */               GameRegistry.registerItem(addedItem, itemName);
/* 1215 */               LootPlusPlusMod.proxy.registerItemRender(addedItem);
/*      */               
/* 1217 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom axe: lootplusplus:" + itemName);  } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1221 */     }  temp = itemConfig.get("additions_tools", "shovels", new String[0]);
/* 1222 */     temp.comment = "Add a shovel, which will act like the vanilla ones, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The material item name is the material that you can repair the tool with\nwhich should be registered in the adding material section first.\n\nSo for instance, assuming that you added the ruby item in the generic\nsection and material for the item, you can add a ruby shovel with:\n\n      ruby_shovel_____Ruby Shovel_____lootplusplus:ruby\n\nAssuming you had a model ruby_shovel.json in the folder mentioned above.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1241 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("shovels"));
/*      */     
/* 1243 */     for (index = 0; index < infoList.size(); index++) {
/* 1244 */       String info = infoList.get(index);
/* 1245 */       String title = getFileName() + ".cfg 'shovels' #" + (index + 1);
/*      */       
/* 1247 */       boolean comment = false;
/*      */       
/* 1249 */       if (info.length() > 0) {
/* 1250 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1253 */       if (!comment) {
/*      */         
/* 1255 */         String[] parts = info.split("_____");
/*      */         
/* 1257 */         if (parts.length < 3) {
/* 1258 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/* 1262 */           String itemName = parts[0];
/* 1263 */           String displayName = parts[1];
/* 1264 */           String materialItemName = parts[2];
/* 1265 */           int meta = -1;
/*      */           
/*      */           try {
/* 1268 */             if (parts.length > 3) {
/* 1269 */               meta = Integer.valueOf(parts[3]).intValue();
/*      */             }
/*      */           }
/* 1272 */           catch (NumberFormatException e) {
/* 1273 */             if (!comment) {
/* 1274 */               System.err.println("[Loot++] Caught exception while trying to create tool " + itemName);
/* 1275 */               e.printStackTrace();
/* 1276 */               LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */             } 
/*      */           } 
/*      */           
/* 1280 */           if (meta < 0) {
/* 1281 */             meta = 32767;
/*      */           }
/*      */           
/* 1284 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1286 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1287 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1291 */             Item item = (Item)itemObj;
/*      */             
/* 1293 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1295 */             if (!LootPPHelper.addedToolMaterials.containsKey(materialStack) || LootPPHelper.addedToolMaterials.get(materialStack) == null)
/* 1296 */             { if (!comment) {
/* 1297 */                 System.err.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1298 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */                }
/*      */             else
/*      */             
/* 1303 */             { Item addedItem = (new ItemAddedShovel((Item.ToolMaterial)LootPPHelper.addedToolMaterials.get(materialStack), displayName)).func_77655_b(itemName);
/* 1304 */               LootPPItems.addedItems.add(addedItem);
/* 1305 */               GameRegistry.registerItem(addedItem, itemName);
/* 1306 */               LootPlusPlusMod.proxy.registerItemRender(addedItem);
/*      */               
/* 1308 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom shovel: lootplusplus:" + itemName);  } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1312 */     }  temp = itemConfig.get("additions_tools", "hoes", new String[0]);
/* 1313 */     temp.comment = "Add a hoe, which will act like the vanilla ones, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The material item name is the material that you can repair the tool with\nwhich should be registered in the adding material section first.\n\nSo for instance, assuming that you added the ruby item in the generic\nsection and material for the item, you can add a ruby hoe with:\n\n      ruby_hoe_____Ruby Hoe_____lootplusplus:ruby\n\nAssuming you had a model ruby_hoe.json in the folder mentioned above.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1332 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("hoes"));
/*      */     
/* 1334 */     for (index = 0; index < infoList.size(); index++) {
/* 1335 */       String info = infoList.get(index);
/* 1336 */       String title = getFileName() + ".cfg 'hoes' #" + (index + 1);
/*      */       
/* 1338 */       boolean comment = false;
/*      */       
/* 1340 */       if (info.length() > 0) {
/* 1341 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1344 */       if (!comment) {
/*      */         
/* 1346 */         String[] parts = info.split("_____");
/*      */         
/* 1348 */         if (parts.length < 3) {
/* 1349 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/* 1353 */           String itemName = parts[0];
/* 1354 */           String displayName = parts[1];
/* 1355 */           String materialItemName = parts[2];
/* 1356 */           int meta = -1;
/*      */           
/*      */           try {
/* 1359 */             if (parts.length > 3) {
/* 1360 */               meta = Integer.valueOf(parts[3]).intValue();
/*      */             }
/*      */           }
/* 1363 */           catch (NumberFormatException e) {
/* 1364 */             if (!comment) {
/* 1365 */               System.err.println("[Loot++] Caught exception while trying to create tool " + itemName);
/* 1366 */               e.printStackTrace();
/* 1367 */               LootPPNotifier.notifyNumber(comment, title, parts[3]);
/*      */             } 
/*      */           } 
/*      */           
/* 1371 */           if (meta < 0) {
/* 1372 */             meta = 32767;
/*      */           }
/*      */           
/* 1375 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1377 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1378 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1382 */             Item item = (Item)itemObj;
/*      */             
/* 1384 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1386 */             if (!LootPPHelper.addedToolMaterials.containsKey(materialStack) || LootPPHelper.addedToolMaterials.get(materialStack) == null)
/* 1387 */             { if (!comment) {
/* 1388 */                 System.err.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1389 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */                }
/*      */             else
/*      */             
/* 1394 */             { Item addedItem = (new ItemAddedHoe((Item.ToolMaterial)LootPPHelper.addedToolMaterials.get(materialStack), displayName)).func_77655_b(itemName);
/* 1395 */               LootPPItems.addedItems.add(addedItem);
/* 1396 */               GameRegistry.registerItem(addedItem, itemName);
/* 1397 */               LootPlusPlusMod.proxy.registerItemRender(addedItem);
/*      */               
/* 1399 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom hoe: lootplusplus:" + itemName);  } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1403 */     }  temp = itemConfig.get("additions_armor", "helmets", new String[0]);
/* 1404 */     temp.comment = "Add a helmet, which will act like the vanilla ones, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Armour model texure location>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The armour model texture name is the texture that will render on your character\nwhen the armor is worn. That one Should be in the 'assets/lootplusplus/models/armor' folder.\n\nSo for instance, assuming that you added the ruby item in the generic section\nand material for the item, you can add a ruby helmet with:\n\n      ruby_helmet_____Ruby Helmet_____lootplusplus:ruby_____lootplusplus:ruby_layer_1\n\nAssuming you had a model ruby_helmet.json in the models/item folder, and a texture\nruby_layer_1.png in the textures/models/armor folder.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1424 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("helmets"));
/*      */     
/* 1426 */     for (index = 0; index < infoList.size(); index++) {
/* 1427 */       String info = infoList.get(index);
/* 1428 */       String title = getFileName() + ".cfg 'helmets' #" + (index + 1);
/*      */       
/* 1430 */       boolean comment = false;
/*      */       
/* 1432 */       if (info.length() > 0) {
/* 1433 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1436 */       if (!comment) {
/*      */         
/* 1438 */         String[] parts = info.split("_____");
/*      */         
/* 1440 */         if (parts.length < 4) {
/* 1441 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/* 1445 */           String itemName = parts[0];
/* 1446 */           String displayName = parts[1];
/* 1447 */           String materialItemName = parts[2];
/* 1448 */           String armourTextureName = parts[3];
/* 1449 */           int meta = -1;
/*      */           
/*      */           try {
/* 1452 */             if (parts.length > 4) {
/* 1453 */               meta = Integer.valueOf(parts[4]).intValue();
/*      */             }
/*      */           }
/* 1456 */           catch (NumberFormatException e) {
/* 1457 */             if (!comment) {
/* 1458 */               System.err.println("[Loot++] Caught exception while trying to create armour " + itemName);
/* 1459 */               e.printStackTrace();
/* 1460 */               LootPPNotifier.notifyNumber(comment, title, parts[4]);
/*      */             } 
/*      */           } 
/*      */           
/* 1464 */           if (meta < 0) {
/* 1465 */             meta = 32767;
/*      */           }
/*      */           
/* 1468 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1470 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1471 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1475 */             Item item = (Item)itemObj;
/*      */             
/* 1477 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1479 */             if (!LootPPHelper.addedArmourMaterials.containsKey(materialStack) || LootPPHelper.addedArmourMaterials.get(materialStack) == null) {
/* 1480 */               if (!comment) {
/* 1481 */                 System.err.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1482 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/* 1487 */               Item addedItem = (new ItemAddedArmour((ItemArmor.ArmorMaterial)LootPPHelper.addedArmourMaterials.get(materialStack), 0, displayName, armourTextureName)).func_77655_b(itemName);
/* 1488 */               LootPPItems.addedItems.add(addedItem);
/* 1489 */               GameRegistry.registerItem(addedItem, itemName);
/* 1490 */               LootPlusPlusMod.proxy.registerItemRender(addedItem);
/*      */               
/* 1492 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom helmet: lootplusplus:" + itemName); 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1497 */     }  temp = itemConfig.get("additions_armor", "chestplates", new String[0]);
/* 1498 */     temp.comment = "Add a chestplate, which will act like the vanilla ones, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Armour model texure location>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The armour model texture name is the texture that will render on your character\nwhen the armor is worn. That one Should be in the 'assets/lootplusplus/models/armor' folder.\n\nSo for instance,\nassuming that you added the ruby item in the generic section and material\nfor the item, you can add a ruby chestplate with:\n\n      ruby_chestplate_____Ruby Chestplate_____lootplusplus:ruby_____lootplusplus:ruby_layer_1\n\nAssuming you had a model ruby_chestplate.json in the models/item folder, and a texture\nruby_layer_1.png in the textures/models/armor folder.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1519 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("chestplates"));
/*      */     
/* 1521 */     for (index = 0; index < infoList.size(); index++) {
/* 1522 */       String info = infoList.get(index);
/* 1523 */       String title = getFileName() + ".cfg 'chestplates' #" + (index + 1);
/*      */       
/* 1525 */       boolean comment = false;
/*      */       
/* 1527 */       if (info.length() > 0) {
/* 1528 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1531 */       if (!comment) {
/*      */         
/* 1533 */         String[] parts = info.split("_____");
/*      */         
/* 1535 */         if (parts.length < 4) {
/* 1536 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/* 1540 */           String itemName = parts[0];
/* 1541 */           String displayName = parts[1];
/* 1542 */           String materialItemName = parts[2];
/* 1543 */           String armourTextureName = parts[3];
/* 1544 */           int meta = -1;
/*      */           
/*      */           try {
/* 1547 */             if (parts.length > 4) {
/* 1548 */               meta = Integer.valueOf(parts[4]).intValue();
/*      */             }
/*      */           }
/* 1551 */           catch (NumberFormatException e) {
/* 1552 */             if (!comment) {
/* 1553 */               System.err.println("[Loot++] Caught exception while trying to create armour " + itemName);
/* 1554 */               e.printStackTrace();
/* 1555 */               LootPPNotifier.notifyNumber(comment, title, parts[4]);
/*      */             } 
/*      */           } 
/*      */           
/* 1559 */           if (meta < 0) {
/* 1560 */             meta = 32767;
/*      */           }
/*      */           
/* 1563 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1565 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1566 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1570 */             Item item = (Item)itemObj;
/*      */             
/* 1572 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1574 */             if (!LootPPHelper.addedArmourMaterials.containsKey(materialStack) || LootPPHelper.addedArmourMaterials.get(materialStack) == null) {
/* 1575 */               if (!comment) {
/* 1576 */                 System.out.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1577 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/* 1582 */               Item addedItem = (new ItemAddedArmour((ItemArmor.ArmorMaterial)LootPPHelper.addedArmourMaterials.get(materialStack), 1, displayName, armourTextureName)).func_77655_b(itemName);
/* 1583 */               LootPPItems.addedItems.add(addedItem);
/* 1584 */               GameRegistry.registerItem(addedItem, itemName);
/* 1585 */               LootPlusPlusMod.proxy.registerItemRender(addedItem);
/*      */               
/* 1587 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom chestplate: lootplusplus:" + itemName); 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1592 */     }  temp = itemConfig.get("additions_armor", "leggings", new String[0]);
/* 1593 */     temp.comment = "Add a pair of leggings, which will act like the vanilla ones, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Armour model texure location>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The armour model texture name is the texture that will render on your character\nwhen the armor is worn. That one Should be in the 'assets/lootplusplus/models/armor' folder.\n\nSo for instance,\nassuming that you added the ruby item in the generic section and material\nfor the item, you can add ruby leggings with:\n\n      ruby_leggings_____Ruby leggings_____lootplusplus:ruby_____lootplusplus:ruby_layer_2\n\nAssuming you had a model ruby_leggings.json in the models/item folder, and a texture\nruby_layer_2.png in the textures/models/armor folder. Note that it's layer 2 in this case,\nnot layer 1! The leggings are on a different layer.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1615 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("leggings"));
/*      */     
/* 1617 */     for (index = 0; index < infoList.size(); index++) {
/* 1618 */       String info = infoList.get(index);
/* 1619 */       String title = getFileName() + ".cfg 'leggings' #" + (index + 1);
/*      */       
/* 1621 */       boolean comment = false;
/*      */       
/* 1623 */       if (info.length() > 0) {
/* 1624 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1627 */       if (!comment) {
/*      */         
/* 1629 */         String[] parts = info.split("_____");
/*      */         
/* 1631 */         if (parts.length < 4) {
/* 1632 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/* 1636 */           String itemName = parts[0];
/* 1637 */           String displayName = parts[1];
/* 1638 */           String materialItemName = parts[2];
/* 1639 */           String armourTextureName = parts[3];
/* 1640 */           int meta = -1;
/*      */           
/*      */           try {
/* 1643 */             if (parts.length > 4) {
/* 1644 */               meta = Integer.valueOf(parts[4]).intValue();
/*      */             }
/*      */           }
/* 1647 */           catch (NumberFormatException e) {
/* 1648 */             if (!comment) {
/* 1649 */               System.err.println("[Loot++] Caught exception while trying to create armour " + itemName);
/* 1650 */               e.printStackTrace();
/* 1651 */               LootPPNotifier.notifyNumber(comment, title, parts[4]);
/*      */             } 
/*      */           } 
/*      */           
/* 1655 */           if (meta < 0) {
/* 1656 */             meta = 32767;
/*      */           }
/*      */           
/* 1659 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1661 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1662 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1666 */             Item item = (Item)itemObj;
/*      */             
/* 1668 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1670 */             if (!LootPPHelper.addedArmourMaterials.containsKey(materialStack) || LootPPHelper.addedArmourMaterials.get(materialStack) == null)
/* 1671 */             { if (!comment) {
/* 1672 */                 System.out.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1673 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */                }
/*      */             else
/*      */             
/* 1678 */             { Item addedItem = (new ItemAddedArmour((ItemArmor.ArmorMaterial)LootPPHelper.addedArmourMaterials.get(materialStack), 2, displayName, armourTextureName)).func_77655_b(itemName);
/* 1679 */               LootPPItems.addedItems.add(addedItem);
/* 1680 */               GameRegistry.registerItem(addedItem, itemName);
/* 1681 */               LootPlusPlusMod.proxy.registerItemRender(addedItem);
/*      */               
/* 1683 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom leggings: lootplusplus:" + itemName);  } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1687 */     }  temp = itemConfig.get("additions_armor", "boots", new String[0]);
/* 1688 */     temp.comment = "Add boots, which will act like the vanilla ones, in the format:\n\n      <Item name>_____<Item display name>_____<Material item name>_____<Armour model texure location>_____<Material item metadata (optional)>\n\nWhere:\n- The item name will be what the item is registered as (there will be\na 'lootplusplus:' added to the front of it automatically; don't add\nanything with a colon yourself!). Note that you should also add a model file with\nthis name in your resource pack in the folder assets/lootplusplus/models/item/<Item name>.json.\n- The item display name is what people will see in-game.\n- The armour model texture name is the texture that will render on your character\nwhen the armor is worn. That one Should be in the 'assets/lootplusplus/textures/models/armor' folder.\n\nSo for instance,\nassuming that you added the ruby item in the generic section and material\nfor the item, you can add ruby boots with:\n\n      ruby_boots_____Ruby Boots_____lootplusplus:ruby_____lootplusplus:ruby_layer_1\n\nAssuming you had a model ruby_boots.json in the models/item folder, and a texture\nruby_layer_1.png in the textures/models/armor folder.\n";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1709 */     infoList = ConfigExtrasLoader.combineLists(temp.getStringList(), this.namesToExtras.get("boots"));
/*      */     
/* 1711 */     for (index = 0; index < infoList.size(); index++) {
/* 1712 */       String info = infoList.get(index);
/* 1713 */       String title = getFileName() + ".cfg 'boots' #" + (index + 1);
/*      */       
/* 1715 */       boolean comment = false;
/*      */       
/* 1717 */       if (info.length() > 0) {
/* 1718 */         comment = (info.charAt(0) == '#');
/*      */       }
/*      */       
/* 1721 */       if (!comment) {
/*      */         
/* 1723 */         String[] parts = info.split("_____");
/*      */         
/* 1725 */         if (parts.length < 4) {
/* 1726 */           if (!info.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, info);
/*      */         
/*      */         } else {
/*      */           
/* 1730 */           String itemName = parts[0];
/* 1731 */           String displayName = parts[1];
/* 1732 */           String materialItemName = parts[2];
/* 1733 */           String armourTextureName = parts[3];
/* 1734 */           int meta = -1;
/*      */           
/*      */           try {
/* 1737 */             if (parts.length > 4) {
/* 1738 */               meta = Integer.valueOf(parts[4]).intValue();
/*      */             }
/*      */           }
/* 1741 */           catch (NumberFormatException e) {
/* 1742 */             if (!comment) {
/* 1743 */               System.err.println("[Loot++] Caught exception while trying to create armour " + itemName);
/* 1744 */               e.printStackTrace();
/* 1745 */               LootPPNotifier.notifyNumber(comment, title, parts[4]);
/*      */             } 
/*      */           } 
/*      */           
/* 1749 */           if (meta < 0) {
/* 1750 */             meta = 32767;
/*      */           }
/*      */           
/* 1753 */           Object itemObj = Item.field_150901_e.func_82594_a(materialItemName);
/*      */           
/* 1755 */           if (itemObj == null || !(itemObj instanceof Item)) {
/* 1756 */             LootPPNotifier.notifyNonexistant(comment, title, materialItemName);
/*      */           }
/*      */           else {
/*      */             
/* 1760 */             Item item = (Item)itemObj;
/*      */             
/* 1762 */             ItemStack materialStack = new ItemStack(item, 1, meta);
/*      */             
/* 1764 */             if (!LootPPHelper.addedArmourMaterials.containsKey(materialStack) || LootPPHelper.addedArmourMaterials.get(materialStack) == null) {
/* 1765 */               if (!comment) {
/* 1766 */                 System.out.println("[Loot++] Error! No item material found for item " + materialItemName + ". Did you add it to the add_materials section?");
/* 1767 */                 LootPPNotifier.notify(comment, title, "The item material '" + materialItemName + "' doesn't exist. Did you add it to the add_materials section?");
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/* 1772 */               Item addedItem = (new ItemAddedArmour((ItemArmor.ArmorMaterial)LootPPHelper.addedArmourMaterials.get(materialStack), 3, displayName, armourTextureName)).func_77655_b(itemName);
/* 1773 */               LootPPItems.addedItems.add(addedItem);
/* 1774 */               GameRegistry.registerItem(addedItem, itemName);
/* 1775 */               LootPlusPlusMod.proxy.registerItemRender(addedItem);
/*      */               
/* 1777 */               if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added custom boots: lootplusplus:" + itemName); 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1782 */     }  itemConfig.save();
/*      */   }
/*      */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderItems.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */