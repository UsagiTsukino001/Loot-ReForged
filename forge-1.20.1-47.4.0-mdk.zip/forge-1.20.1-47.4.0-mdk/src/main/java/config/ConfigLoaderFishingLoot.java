/*     */ package com.tmtravlr.lootplusplus.config;
/*     */ 
/*     */ import com.google.common.base.Predicate;
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPNotifier;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.JsonToNBT;
/*     */ import net.minecraft.nbt.NBTException;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.WeightedRandomFishable;
/*     */ import net.minecraftforge.common.FishingHooks;
/*     */ import net.minecraftforge.common.config.Configuration;
/*     */ import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
/*     */ import net.minecraftforge.fml.relauncher.ReflectionHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigLoaderFishingLoot
/*     */   extends ConfigLoader
/*     */ {
/*  27 */   private static HashSet<WeightedRandomFishable> toRemove = new HashSet<WeightedRandomFishable>();
/*  28 */   public static ConfigLoaderFishingLoot instance = new ConfigLoaderFishingLoot();
/*     */   
/*     */   ConfigLoaderFishingLoot() {
/*  31 */     this.namesToExtras.put("fish_additions", new ArrayList<String>());
/*  32 */     this.namesToExtras.put("junk_additions", new ArrayList<String>());
/*  33 */     this.namesToExtras.put("treasure_additions", new ArrayList<String>());
/*     */   }
/*     */   
/*  36 */   public static HashMap<String, ArrayList<String>> extraExisting = new HashMap<String, ArrayList<String>>();
/*     */   
/*     */   public String getFileName() {
/*  39 */     return "fishing_loot";
/*     */   }
/*     */   
/*     */   public void loadFishingLoot() {
/*  43 */     Configuration fishConfig = new Configuration(new File(LootPPHelper.configFolder, getFileName() + ".cfg"));
/*     */     
/*  45 */     fishConfig.load();
/*     */     
/*  47 */     String[] recordList = new String[0];
/*     */     
/*  49 */     fishConfig.addCustomCategoryComment("_instructions", "************   Instructions   *************\nFor the default entries, they are formatted as follows:\n\n      <damage percent>-<enchanted>-<weight>.\n\nDisable them by setting the weights to 0. The damage percent is what percent of\ndurability should be removed from the item. If enchanted is true, the item will be\nenchanted when it gets fished up.\nTo add new things, put items in the lists in the format:\n\n      <name>-<amount>-<damage percent>-<enchanted>-<weight>-<metadata (optional)>-<NBT Tag (optional)>.\n\nSo, say, if you wanted to add 3 slime balls to the junk loot with a weight of\n10, you could put:\n\n      minecraft:slime_ball-3-0.0-false-10\n\nNote the NBT tag is optional, and so is the metadata (defaults to 0), so you don't have\nto include them. Also note that the metadata is affected by the damager percent for tools,\nso if you put, say, an enchanted iron helmet that you want at 50% damage, you could put:\n\n      minecraft:iron_helmet-1-0.5-true-10\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     ArrayList<String> entries = new ArrayList<String>();
/*     */ 
/*     */ 
/*     */     
/*  76 */     ArrayList<WeightedRandomFishable> fish = (ArrayList<WeightedRandomFishable>)ReflectionHelper.getPrivateValue(FishingHooks.class, null, new String[] { "fish" });
/*     */     
/*  78 */     if (fish != null) {
/*  79 */       for (WeightedRandomFishable fishable : fish) {
/*  80 */         loadDefaultFishingLoot(fishConfig, "fish", fishable);
/*     */       }
/*     */     }
/*     */     
/*  84 */     FishingHooks.removeFish(new Predicate<WeightedRandomFishable>()
/*     */         {
/*     */           public boolean apply(WeightedRandomFishable input)
/*     */           {
/*  88 */             return !ConfigLoaderFishingLoot.toRemove.contains(input);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*  93 */     toRemove.clear();
/*     */     
/*  95 */     entries = ConfigExtrasLoader.combineLists(fishConfig.get("fish_additions", "Fish Additions:", new String[0]).getStringList(), this.namesToExtras.get("fish_additions"));
/*  96 */     for (int index = 0; index < entries.size(); index++) {
/*  97 */       String options = entries.get(index);
/*  98 */       String title = "chest_content.cfg 'fish_additions' #" + (index + 1);
/*     */       
/* 100 */       WeightedRandomFishable content = loadNewFishingLoot(title, options);
/*     */       
/* 102 */       if (content != null) {
/* 103 */         FishingHooks.addFish(content);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     ArrayList<WeightedRandomFishable> junk = (ArrayList<WeightedRandomFishable>)ReflectionHelper.getPrivateValue(FishingHooks.class, null, new String[] { "junk" });
/*     */     
/* 112 */     if (fish != null) {
/* 113 */       for (WeightedRandomFishable fishable : junk) {
/* 114 */         loadDefaultFishingLoot(fishConfig, "junk", fishable);
/*     */       }
/*     */     }
/*     */     
/* 118 */     FishingHooks.removeJunk(new Predicate<WeightedRandomFishable>()
/*     */         {
/*     */           public boolean apply(WeightedRandomFishable input)
/*     */           {
/* 122 */             return !ConfigLoaderFishingLoot.toRemove.contains(input);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 127 */     toRemove.clear();
/*     */     
/* 129 */     entries = ConfigExtrasLoader.combineLists(fishConfig.get("junk_additions", "Junk Additions:", new String[0]).getStringList(), this.namesToExtras.get("junk_additions"));
/* 130 */     for (int i = 0; i < entries.size(); i++) {
/* 131 */       String options = entries.get(i);
/* 132 */       String title = "chest_content.cfg 'junk_additions' #" + (i + 1);
/*     */       
/* 134 */       WeightedRandomFishable content = loadNewFishingLoot(title, options);
/*     */       
/* 136 */       if (content != null) {
/* 137 */         FishingHooks.addJunk(content);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     ArrayList<WeightedRandomFishable> treasure = (ArrayList<WeightedRandomFishable>)ReflectionHelper.getPrivateValue(FishingHooks.class, null, new String[] { "treasure" });
/*     */     
/* 146 */     if (fish != null) {
/* 147 */       for (WeightedRandomFishable fishable : treasure) {
/* 148 */         loadDefaultFishingLoot(fishConfig, "treasure", fishable);
/*     */       }
/*     */     }
/*     */     
/* 152 */     FishingHooks.removeTreasure(new Predicate<WeightedRandomFishable>()
/*     */         {
/*     */           public boolean apply(WeightedRandomFishable input)
/*     */           {
/* 156 */             return !ConfigLoaderFishingLoot.toRemove.contains(input);
/*     */           }
/*     */         });
/*     */ 
/*     */     
/* 161 */     toRemove.clear();
/*     */     
/* 163 */     entries = ConfigExtrasLoader.combineLists(fishConfig.get("treasure_additions", "Treasure Additions:", new String[0]).getStringList(), this.namesToExtras.get("treasure_additions"));
/* 164 */     for (int j = 0; j < entries.size(); j++) {
/* 165 */       String options = entries.get(j);
/* 166 */       String title = "chest_content.cfg 'treasure_additions' #" + (j + 1);
/*     */       
/* 168 */       WeightedRandomFishable content = loadNewFishingLoot(title, options);
/*     */       
/* 170 */       if (content != null) {
/* 171 */         FishingHooks.addTreasure(content);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 176 */     fishConfig.save();
/*     */   }
/*     */   
/*     */   public static void loadDefaultFishingLoot(Configuration fishConfig, String type, WeightedRandomFishable fishable) {
/* 180 */     ItemStack itemStack = (ItemStack)ObfuscationReflectionHelper.getPrivateValue(WeightedRandomFishable.class, fishable, new String[] { "returnStack", "field_150711_b" });
/* 181 */     float damagePercent = ((Float)ObfuscationReflectionHelper.getPrivateValue(WeightedRandomFishable.class, fishable, new String[] { "maxDamagePercent", "field_150712_c" })).floatValue();
/* 182 */     boolean enchant = ((Boolean)ObfuscationReflectionHelper.getPrivateValue(WeightedRandomFishable.class, fishable, new String[] { "enchantable", "field_150710_d" })).booleanValue();
/* 183 */     int weight = fishable.field_76292_a;
/*     */     
/* 185 */     if (itemStack == null || itemStack.func_77973_b() == null) {
/*     */       return;
/*     */     }
/*     */     
/* 189 */     String options = "" + damagePercent + "-" + enchant + "-" + weight;
/* 190 */     options = fishConfig.get(type + "_default", Item.field_150901_e.func_177774_c(itemStack.func_77973_b()) + "-" + itemStack.field_77994_a + "-" + itemStack.func_77952_i() + (!itemStack.func_77942_o() ? "" : ("-" + itemStack.func_77978_p().toString())), options).getString();
/*     */ 
/*     */     
/* 193 */     String[] parts = options.split("-");
/*     */     
/* 195 */     if (parts.length != 3) {
/* 196 */       LootPPNotifier.notifyWrongNumberOfParts(false, "fishing_loot.cfg '" + type + "_default'", options);
/*     */       
/*     */       return;
/*     */     } 
/*     */     try {
/* 201 */       damagePercent = Float.valueOf(parts[0]).floatValue();
/* 202 */       enchant = Boolean.valueOf(parts[1]).booleanValue();
/* 203 */       weight = Integer.valueOf(parts[2]).intValue();
/*     */       
/* 205 */       if (damagePercent < 0.0F) damagePercent = 0.0F; 
/* 206 */       if (weight < 0) weight = 0;
/*     */       
/* 208 */       fishable.field_76292_a = weight;
/* 209 */       ObfuscationReflectionHelper.setPrivateValue(WeightedRandomFishable.class, fishable, Float.valueOf(damagePercent), new String[] { "maxDamagePercent", "field_150712_c" });
/* 210 */       ObfuscationReflectionHelper.setPrivateValue(WeightedRandomFishable.class, fishable, Boolean.valueOf(enchant), new String[] { "enchantable", "field_150710_d" });
/*     */     }
/* 212 */     catch (NumberFormatException e) {
/* 213 */       LootPPNotifier.notifyNumber(false, "fishing_loot.cfg '" + type + "_default'", new String[] { parts[0], parts[1], parts[2] });
/* 214 */       e.printStackTrace();
/*     */       
/*     */       return;
/*     */     } 
/* 218 */     if (weight == 0) {
/* 219 */       if (LootPlusPlusMod.debug) System.out.println("[Loot++] Removing fishing loot '" + itemStack + "' with weight " + weight + ", damage percent " + damagePercent + ", and is enchanted? " + enchant); 
/* 220 */       toRemove.add(fishable);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static WeightedRandomFishable loadNewFishingLoot(String title, String options) {
/* 225 */     String[] parts = options.split("-", 7);
/*     */     
/* 227 */     boolean comment = false;
/*     */     
/* 229 */     if (options.isEmpty() || options.charAt(0) == '#')
/*     */     {
/* 231 */       return null;
/*     */     }
/*     */     
/* 234 */     if (parts.length < 5) {
/* 235 */       if (!options.equals("")) LootPPNotifier.notifyWrongNumberOfParts(comment, title, options); 
/* 236 */       return null;
/*     */     } 
/*     */     
/* 239 */     String name = parts[0];
/* 240 */     int amount = 1;
/* 241 */     float damagePercent = 0.0F;
/* 242 */     boolean enchant = false;
/* 243 */     int weight = 1;
/* 244 */     int meta = 0;
/* 245 */     NBTTagCompound nbt = null;
/*     */     
/*     */     try {
/* 248 */       amount = Integer.valueOf(parts[1]).intValue();
/* 249 */       damagePercent = Float.valueOf(parts[2]).floatValue();
/* 250 */       enchant = Boolean.valueOf(parts[3]).booleanValue();
/* 251 */       weight = Integer.valueOf(parts[4]).intValue();
/*     */       
/* 253 */       if (parts.length > 5) {
/* 254 */         meta = Integer.valueOf(parts[5]).intValue();
/*     */       }
/*     */     }
/* 257 */     catch (NumberFormatException e) {
/* 258 */       if (!comment) {
/* 259 */         LootPPNotifier.notifyNumber(comment, title, "" + parts[1] + ", " + parts[2] + ", " + parts[3] + ", " + parts[4] + ((parts.length > 5) ? (", " + parts[5]) : ""));
/* 260 */         e.printStackTrace();
/* 261 */         return null;
/*     */       } 
/*     */     } 
/* 264 */     if (amount < 1) amount = 1; 
/* 265 */     if (damagePercent < 0.0F) damagePercent = 0.0F; 
/* 266 */     if (meta < 0) meta = 0; 
/* 267 */     if (weight < 1) weight = 1;
/*     */     
/* 269 */     if (parts.length > 6 && !parts[6].equals("") && !parts[6].equals("{}")) {
/*     */       try {
/* 271 */         NBTTagCompound nBTTagCompound = JsonToNBT.func_180713_a(parts[6].trim());
/* 272 */         if (nBTTagCompound instanceof NBTTagCompound) {
/* 273 */           nbt = nBTTagCompound;
/*     */         }
/*     */       }
/* 276 */       catch (NBTException e) {
/*     */         
/* 278 */         if (!comment) {
/* 279 */           LootPPNotifier.notifyNBT(comment, title, parts[6], e.getMessage());
/* 280 */           e.printStackTrace();
/*     */         } 
/* 282 */         return null;
/*     */       } 
/*     */     }
/*     */     
/* 286 */     Object itemObj = Item.field_150901_e.func_82594_a(name);
/*     */     
/* 288 */     if (itemObj == null || !(itemObj instanceof Item)) {
/* 289 */       LootPPNotifier.notifyNonexistant(comment, title, name);
/* 290 */       return null;
/*     */     } 
/*     */     
/* 293 */     Item item = (Item)itemObj;
/*     */     
/* 295 */     ItemStack itemStack = new ItemStack(item, amount, meta);
/*     */     
/* 297 */     if (nbt != null) {
/* 298 */       itemStack.func_77982_d(nbt);
/*     */     }
/*     */     
/* 301 */     WeightedRandomFishable content = (new WeightedRandomFishable(itemStack, weight)).func_150709_a(damagePercent);
/* 302 */     if (enchant) content.func_150707_a();
/*     */     
/* 304 */     if (LootPlusPlusMod.debug) System.out.println("[Loot++] Added fishing loot '" + itemStack + "' with weight " + weight + ", damage percent " + damagePercent + ", and is enchanted? " + enchant); 
/* 305 */     return content;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\config\ConfigLoaderFishingLoot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */