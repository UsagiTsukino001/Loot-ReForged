/*     */ package com.tmtravlr.lootplusplus.loot;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPItems;
/*     */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ import net.minecraft.creativetab.CreativeTabs;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.util.WeightedRandomChestContent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.ChestGenHooks;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemLootItem
/*     */   extends Item
/*     */ {
/*  31 */   public static Map<String, Integer> typeToColorMap = new HashMap<String, Integer>();
/*     */   static {
/*  33 */     typeToColorMap.put("dungeonChestp", Integer.valueOf(5723991));
/*  34 */     typeToColorMap.put("dungeonChests", Integer.valueOf(4837732));
/*  35 */     typeToColorMap.put("bonusChestp", Integer.valueOf(15245347));
/*  36 */     typeToColorMap.put("bonusChests", Integer.valueOf(1210879));
/*  37 */     typeToColorMap.put("mineshaftCorridorp", Integer.valueOf(5723991));
/*  38 */     typeToColorMap.put("mineshaftCorridors", Integer.valueOf(16110207));
/*  39 */     typeToColorMap.put("pyramidDesertyChestp", Integer.valueOf(16446423));
/*  40 */     typeToColorMap.put("pyramidDesertyChests", Integer.valueOf(16748800));
/*  41 */     typeToColorMap.put("pyramidJungleChestp", Integer.valueOf(2268202));
/*  42 */     typeToColorMap.put("pyramidJungleChests", Integer.valueOf(63740));
/*  43 */     typeToColorMap.put("pyramidJungleDispenserp", Integer.valueOf(5211978));
/*  44 */     typeToColorMap.put("pyramidJungleDispensers", Integer.valueOf(1441536));
/*  45 */     typeToColorMap.put("strongholdCorridorp", Integer.valueOf(2578664));
/*  46 */     typeToColorMap.put("strongholdCorridors", Integer.valueOf(9958693));
/*  47 */     typeToColorMap.put("strongholdCrossingp", Integer.valueOf(16711680));
/*  48 */     typeToColorMap.put("strongholdCrossings", Integer.valueOf(6225796));
/*  49 */     typeToColorMap.put("strongholdLibraryp", Integer.valueOf(14072961));
/*  50 */     typeToColorMap.put("strongholdLibrarys", Integer.valueOf(10378003));
/*  51 */     typeToColorMap.put("villageBlacksmithp", Integer.valueOf(10235952));
/*  52 */     typeToColorMap.put("villageBlacksmiths", Integer.valueOf(15263976));
/*  53 */     typeToColorMap.put("netherFortressp", Integer.valueOf(5379092));
/*  54 */     typeToColorMap.put("netherFortresss", Integer.valueOf(16764928));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemLootItem() {
/*  63 */     func_77637_a(LootPPHelper.tabLootPP);
/*  64 */     func_77627_a(true);
/*  65 */     func_77625_d(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_150895_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/*  74 */     for (String type : LootPPHelper.chestTypes) {
/*  75 */       ItemStack toAdd = new ItemStack(LootPPItems.itemLootItem);
/*  76 */       toAdd.func_77982_d(new NBTTagCompound());
/*  77 */       toAdd.func_77978_p().func_74778_a("Type", type);
/*  78 */       list.add(toAdd);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_77653_i(ItemStack itemStack) {
/*  85 */     String type = "";
/*  86 */     if (itemStack.func_77978_p() != null) {
/*  87 */       type = itemStack.func_77978_p().func_74779_i("Type");
/*     */     }
/*  89 */     return ("" + StatCollector.func_74838_a(func_77657_g(itemStack) + ".name")).trim() + " " + type;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean requiresMultipleRenderPasses() {
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int func_82790_a(ItemStack stack, int layer) {
/* 101 */     NBTTagCompound tag = stack.func_77978_p();
/*     */     
/* 103 */     if (tag != null) {
/*     */ 
/*     */       
/* 106 */       if (tag.func_74764_b("Icon")) {
/* 107 */         return 16777215;
/*     */       }
/*     */       
/* 110 */       if ((layer == 0 && tag.func_74764_b("PrimaryColor")) || (layer != 0 && tag.func_74764_b("SecondaryColor"))) {
/* 111 */         return (layer == 0) ? tag.func_74762_e("PrimaryColor") : tag.func_74762_e("SecondaryColor");
/*     */       }
/*     */       
/* 114 */       int color = 16777215;
/*     */       
/* 116 */       if (stack.func_77978_p().func_74764_b("Type")) {
/* 117 */         String type = stack.func_77978_p().func_74779_i("Type");
/* 118 */         if (typeToColorMap.containsKey(type + ((layer == 0) ? "p" : "s"))) {
/* 119 */           color = ((Integer)typeToColorMap.get(type + ((layer == 0) ? "p" : "s"))).intValue();
/* 120 */           stack.func_77978_p().func_74768_a((layer == 0) ? "PrimaryColor" : "SecondaryColor", color);
/*     */         } else {
/*     */           
/* 123 */           Random rand = new Random((type + ((layer == 0) ? "p" : "s")).hashCode());
/* 124 */           color = rand.nextInt(16777215);
/* 125 */           tag.func_74768_a((layer == 0) ? "PrimaryColor" : "SecondaryColor", color);
/*     */         } 
/*     */       } 
/*     */       
/* 129 */       return color;
/*     */     } 
/*     */     
/* 132 */     EntityList.EntityEggInfo entityegginfo = (EntityList.EntityEggInfo)EntityList.field_75627_a.get(Integer.valueOf(stack.func_77952_i()));
/* 133 */     return (entityegginfo != null) ? ((layer == 0) ? entityegginfo.field_75611_b : entityegginfo.field_75612_c) : 16777215;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_77663_a(ItemStack stack, World world, Entity entity, int slot, boolean isHeld) {
/* 138 */     if (!world.field_72995_K && entity instanceof EntityPlayer && stack.func_77973_b() == LootPPItems.itemLootItem && 
/* 139 */       stack.func_77978_p() != null && !stack.func_77978_p().func_74767_n("Unwrap")) {
/* 140 */       ItemStack newStack = makeIntoLoot(stack, entity.field_70170_p, entity.func_180425_c());
/*     */       
/* 142 */       if (newStack != null) {
/* 143 */         EntityPlayer player = (EntityPlayer)entity;
/* 144 */         player.field_71071_by.field_70462_a[slot] = newStack;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean onEntityItemUpdate(EntityItem entityItem) {
/* 151 */     if (entityItem.func_92059_d().func_77973_b() == LootPPItems.itemLootItem && 
/* 152 */       entityItem.func_92059_d().func_77978_p() != null && !entityItem.func_92059_d().func_77978_p().func_74767_n("Unwrap")) {
/* 153 */       ItemStack newStack = makeIntoLoot(entityItem.func_92059_d(), entityItem.field_70170_p, entityItem.func_180425_c());
/*     */       
/* 155 */       if (newStack != null) {
/* 156 */         entityItem.func_92058_a(newStack);
/*     */       }
/*     */     } 
/*     */     
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77659_a(ItemStack stack, World world, EntityPlayer player) {
/* 168 */     if (!world.field_72995_K) {
/* 169 */       ItemStack newStack = makeIntoLoot(stack, world, player.func_180425_c());
/*     */       
/* 171 */       if (newStack != null) {
/* 172 */         return newStack;
/*     */       }
/*     */     } 
/*     */     
/* 176 */     return stack;
/*     */   }
/*     */   
/*     */   private ItemStack makeIntoLoot(ItemStack stack, World world, BlockPos pos) {
/*     */     try {
/* 181 */       if (stack.func_77978_p() != null && stack.func_77978_p().func_74764_b("Type") && LootPPHelper.gotChestInfo && ((HashMap)LootPPHelper.chestInfo.get(null)).keySet().contains(stack.func_77978_p().func_74779_i("Type"))) {
/* 182 */         String type = stack.func_77978_p().func_74779_i("Type");
/* 183 */         Random rand = new Random();
/* 184 */         SimulatedInventory inventory = new SimulatedInventory(world, pos);
/*     */         
/* 186 */         for (int i = 0; i < 100; i++) {
/* 187 */           WeightedRandomChestContent.func_177630_a(rand, ChestGenHooks.getItems(type, rand), inventory, 1);
/*     */           
/* 189 */           if (inventory.func_70301_a(0) != null) {
/* 190 */             return inventory.func_70301_a(0);
/*     */           }
/*     */         } 
/*     */         
/* 194 */         return ChestGenHooks.getOneItem(type, rand);
/*     */       }
/*     */     
/*     */     }
/* 198 */     catch (Exception e) {
/* 199 */       if (LootPlusPlusMod.debug) e.printStackTrace();
/*     */     
/*     */     } 
/* 202 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\loot\ItemLootItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */