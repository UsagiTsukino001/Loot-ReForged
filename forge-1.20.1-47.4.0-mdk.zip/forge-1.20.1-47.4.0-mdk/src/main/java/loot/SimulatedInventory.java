/*     */ package com.tmtravlr.lootplusplus.loot;
/*     */ 
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.ChatComponentText;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class SimulatedInventory
/*     */   extends TileEntity implements IInventory {
/*     */   ItemStack item;
/*     */   
/*     */   public SimulatedInventory(World world, BlockPos pos) {
/*  17 */     func_145834_a(world);
/*  18 */     this.field_174879_c = pos;
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_70302_i_() {
/*  23 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack func_70301_a(int slot) {
/*  28 */     return this.item;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack func_70298_a(int slot, int count) {
/*  33 */     if (this.item == null) {
/*  34 */       return null;
/*     */     }
/*  36 */     if (this.item.field_77994_a <= count) {
/*  37 */       ItemStack returnStack = this.item.func_77946_l();
/*  38 */       func_70299_a(0, (ItemStack)null);
/*  39 */       return returnStack;
/*     */     } 
/*     */     
/*  42 */     return this.item.func_77979_a(count);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70304_b(int slot) {
/*  48 */     return this.item;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70299_a(int slot, ItemStack newItem) {
/*  53 */     this.item = newItem.func_77946_l();
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_70297_j_() {
/*  58 */     return 64;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70296_d() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70300_a(EntityPlayer player) {
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_94041_b(int p_94041_1_, ItemStack p_94041_2_) {
/*  73 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_70005_c_() {
/*  78 */     return "Simulated";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_145818_k_() {
/*  83 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IChatComponent func_145748_c_() {
/*  88 */     return (IChatComponent)new ChatComponentText(func_70005_c_());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_174889_b(EntityPlayer player) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_174886_c(EntityPlayer player) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_174887_a_(int id) {
/* 103 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_174885_b(int id, int value) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_174890_g() {
/* 113 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_174888_l() {
/* 118 */     this.item = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\loot\SimulatedInventory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */