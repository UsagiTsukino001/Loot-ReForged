/*     */ package com.tmtravlr.lootplusplus.loot;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockChest;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class BlockLootChest
/*     */   extends BlockChest
/*     */ {
/*     */   public BlockLootChest(int i) {
/*  19 */     super(i);
/*  20 */     func_149647_a(LootPPHelper.tabLootPP);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
/*  25 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176455_e(World worldIn, BlockPos pos, IBlockState state) {
/*  34 */     if (worldIn.field_72995_K)
/*     */     {
/*  36 */       return state;
/*     */     }
/*     */ 
/*     */     
/*  40 */     IBlockState iblockstate1 = worldIn.func_180495_p(pos.func_177978_c());
/*  41 */     IBlockState iblockstate2 = worldIn.func_180495_p(pos.func_177968_d());
/*  42 */     IBlockState iblockstate3 = worldIn.func_180495_p(pos.func_177976_e());
/*  43 */     IBlockState iblockstate4 = worldIn.func_180495_p(pos.func_177974_f());
/*  44 */     EnumFacing enumfacing = (EnumFacing)state.func_177229_b((IProperty)field_176459_a);
/*  45 */     Block block = iblockstate1.func_177230_c();
/*  46 */     Block block1 = iblockstate2.func_177230_c();
/*  47 */     Block block2 = iblockstate3.func_177230_c();
/*  48 */     Block block3 = iblockstate4.func_177230_c();
/*     */     
/*  50 */     if (!(block instanceof BlockChest) && !(block1 instanceof BlockChest)) {
/*     */       
/*  52 */       boolean flag = block.func_149730_j();
/*  53 */       boolean flag1 = block1.func_149730_j();
/*     */       
/*  55 */       if (block2 instanceof BlockChest || block3 instanceof BlockChest) {
/*     */         EnumFacing enumfacing2;
/*  57 */         BlockPos blockpos2 = (block2 instanceof BlockChest) ? pos.func_177976_e() : pos.func_177974_f();
/*  58 */         IBlockState iblockstate7 = worldIn.func_180495_p(blockpos2.func_177978_c());
/*  59 */         IBlockState iblockstate8 = worldIn.func_180495_p(blockpos2.func_177968_d());
/*  60 */         enumfacing = EnumFacing.SOUTH;
/*     */ 
/*     */         
/*  63 */         if (block2 == this) {
/*     */           
/*  65 */           enumfacing2 = (EnumFacing)iblockstate3.func_177229_b((IProperty)field_176459_a);
/*     */         }
/*     */         else {
/*     */           
/*  69 */           enumfacing2 = (EnumFacing)iblockstate4.func_177229_b((IProperty)field_176459_a);
/*     */         } 
/*     */         
/*  72 */         if (enumfacing2 == EnumFacing.NORTH)
/*     */         {
/*  74 */           enumfacing = EnumFacing.NORTH;
/*     */         }
/*     */         
/*  77 */         Block block6 = iblockstate7.func_177230_c();
/*  78 */         Block block7 = iblockstate8.func_177230_c();
/*     */         
/*  80 */         if ((flag || block6.func_149730_j()) && !flag1 && !block7.func_149730_j())
/*     */         {
/*  82 */           enumfacing = EnumFacing.SOUTH;
/*     */         }
/*     */         
/*  85 */         if ((flag1 || block7.func_149730_j()) && !flag && !block6.func_149730_j())
/*     */         {
/*  87 */           enumfacing = EnumFacing.NORTH;
/*     */         }
/*     */       } 
/*     */     } else {
/*     */       EnumFacing enumfacing1;
/*     */       
/*  93 */       BlockPos blockpos1 = (block instanceof BlockChest) ? pos.func_177978_c() : pos.func_177968_d();
/*  94 */       IBlockState iblockstate5 = worldIn.func_180495_p(blockpos1.func_177976_e());
/*  95 */       IBlockState iblockstate6 = worldIn.func_180495_p(blockpos1.func_177974_f());
/*  96 */       enumfacing = EnumFacing.EAST;
/*     */ 
/*     */       
/*  99 */       if (block instanceof BlockChest) {
/*     */         
/* 101 */         enumfacing1 = (EnumFacing)iblockstate1.func_177229_b((IProperty)field_176459_a);
/*     */       }
/*     */       else {
/*     */         
/* 105 */         enumfacing1 = (EnumFacing)iblockstate2.func_177229_b((IProperty)field_176459_a);
/*     */       } 
/*     */       
/* 108 */       if (enumfacing1 == EnumFacing.WEST)
/*     */       {
/* 110 */         enumfacing = EnumFacing.WEST;
/*     */       }
/*     */       
/* 113 */       Block block4 = iblockstate5.func_177230_c();
/* 114 */       Block block5 = iblockstate6.func_177230_c();
/*     */       
/* 116 */       if ((block2.func_149730_j() || block4.func_149730_j()) && !block3.func_149730_j() && !block5.func_149730_j())
/*     */       {
/* 118 */         enumfacing = EnumFacing.EAST;
/*     */       }
/*     */       
/* 121 */       if ((block3.func_149730_j() || block5.func_149730_j()) && !block2.func_149730_j() && !block4.func_149730_j())
/*     */       {
/* 123 */         enumfacing = EnumFacing.WEST;
/*     */       }
/*     */     } 
/*     */     
/* 127 */     state = state.func_177226_a((IProperty)field_176459_a, (Comparable)enumfacing);
/* 128 */     worldIn.func_180501_a(pos, state, 3);
/* 129 */     return state;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_176196_c(World worldIn, BlockPos pos) {
/* 140 */     int i = 0;
/* 141 */     BlockPos blockpos1 = pos.func_177976_e();
/* 142 */     BlockPos blockpos2 = pos.func_177974_f();
/* 143 */     BlockPos blockpos3 = pos.func_177978_c();
/* 144 */     BlockPos blockpos4 = pos.func_177968_d();
/*     */     
/* 146 */     if (worldIn.func_180495_p(blockpos1).func_177230_c() instanceof BlockChest) {
/*     */       
/* 148 */       if (isDoubleChest(worldIn, blockpos1))
/*     */       {
/* 150 */         return false;
/*     */       }
/*     */       
/* 153 */       i++;
/*     */     } 
/*     */     
/* 156 */     if (worldIn.func_180495_p(blockpos2).func_177230_c() instanceof BlockChest) {
/*     */       
/* 158 */       if (isDoubleChest(worldIn, blockpos2))
/*     */       {
/* 160 */         return false;
/*     */       }
/*     */       
/* 163 */       i++;
/*     */     } 
/*     */     
/* 166 */     if (worldIn.func_180495_p(blockpos3).func_177230_c() instanceof BlockChest) {
/*     */       
/* 168 */       if (isDoubleChest(worldIn, blockpos3))
/*     */       {
/* 170 */         return false;
/*     */       }
/*     */       
/* 173 */       i++;
/*     */     } 
/*     */     
/* 176 */     if (worldIn.func_180495_p(blockpos4).func_177230_c() instanceof BlockChest) {
/*     */       
/* 178 */       if (isDoubleChest(worldIn, blockpos4))
/*     */       {
/* 180 */         return false;
/*     */       }
/*     */       
/* 183 */       i++;
/*     */     } 
/*     */     
/* 186 */     return (i <= 1);
/*     */   }
/*     */   
/*     */   private boolean isDoubleChest(World worldIn, BlockPos pos) {
/*     */     EnumFacing enumfacing;
/* 191 */     if (!(worldIn.func_180495_p(pos).func_177230_c() instanceof BlockChest))
/*     */     {
/* 193 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 197 */     Iterator<EnumFacing> iterator = EnumFacing.Plane.HORIZONTAL.iterator();
/*     */ 
/*     */ 
/*     */     
/*     */     do {
/* 202 */       if (!iterator.hasNext())
/*     */       {
/* 204 */         return false;
/*     */       }
/*     */       
/* 207 */       enumfacing = iterator.next();
/*     */     }
/* 209 */     while (!(worldIn.func_180495_p(pos.func_177972_a(enumfacing)).func_177230_c() instanceof BlockChest));
/*     */     
/* 211 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World world, int p_149915_2_) {
/* 221 */     TileEntityLootChest tileentitychest = new TileEntityLootChest();
/* 222 */     return (TileEntity)tileentitychest;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180663_b(World worldIn, BlockPos pos, IBlockState state) {
/* 228 */     worldIn.func_175713_t(pos);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\loot\BlockLootChest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */