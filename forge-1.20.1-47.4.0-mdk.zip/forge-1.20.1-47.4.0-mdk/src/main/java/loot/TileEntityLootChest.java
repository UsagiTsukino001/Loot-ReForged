/*    */ package com.tmtravlr.lootplusplus.loot;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPBlocks;
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.tileentity.TileEntityChest;
/*    */ import net.minecraft.world.LockCode;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TileEntityLootChest
/*    */   extends TileEntityChest
/*    */ {
/* 21 */   public String type = "";
/*    */ 
/*    */   
/*    */   public void func_145839_a(NBTTagCompound tag) {
/* 25 */     this.type = tag.func_74779_i("Type");
/* 26 */     super.func_145839_a(tag);
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_145841_b(NBTTagCompound tag) {
/* 31 */     tag.func_74778_a("Type", this.type);
/* 32 */     super.func_145841_b(tag);
/*    */   }
/*    */ 
/*    */   
/*    */   public void func_73660_a() {
/* 37 */     if (this.field_145850_b.func_180495_p(this.field_174879_c).func_177230_c() == LootPPBlocks.blockLootChest) {
/* 38 */       if (LootPlusPlusMod.debug) System.out.println("[Loot++] Creating a loot chest.");
/*    */       
/* 40 */       Random rand = new Random();
/*    */       
/* 42 */       IBlockState state = this.field_145850_b.func_180495_p(this.field_174879_c);
/* 43 */       int meta = state.func_177230_c().func_176201_c(state);
/*    */       
/* 45 */       if (LootPlusPlusMod.debug) System.out.println("[Loot++] Meta is " + meta);
/*    */       
/* 47 */       LockCode lock = func_174891_i();
/* 48 */       String customName = func_145818_k_() ? func_70005_c_() : null;
/*    */       
/* 50 */       this.field_145850_b.func_175656_a(this.field_174879_c, Blocks.field_150486_ae.func_176203_a(meta));
/*    */       
/* 52 */       TileEntity te = this.field_145850_b.func_175625_s(this.field_174879_c);
/*    */       
/* 54 */       if (te instanceof TileEntityChest && !this.field_145850_b.field_72995_K) {
/* 55 */         if (LootPlusPlusMod.debug) System.out.println("[Loot++] Found chest tile entity. Looking for chest type " + this.type); 
/* 56 */         TileEntityChest tec = (TileEntityChest)te;
/*    */         
/* 58 */         tec.func_174892_a(lock);
/*    */         
/* 60 */         if (customName != null) {
/* 61 */           tec.func_145976_a(customName);
/*    */         }
/*    */         
/* 64 */         LootPPHelper.generateLoot(this.type, (IInventory)tec);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\loot\TileEntityLootChest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */