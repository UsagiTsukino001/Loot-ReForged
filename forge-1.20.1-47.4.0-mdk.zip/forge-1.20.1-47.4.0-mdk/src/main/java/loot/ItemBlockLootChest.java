/*    */ package com.tmtravlr.lootplusplus.loot;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPBlocks;
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import com.tmtravlr.lootplusplus.LootPlusPlusMod;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockChest;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.nbt.NBTTagCompound;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.MathHelper;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class ItemBlockLootChest
/*    */   extends ItemBlock
/*    */ {
/*    */   public ItemBlockLootChest(Block block) {
/* 30 */     super(block);
/* 31 */     func_77637_a(LootPPHelper.tabLootPP);
/* 32 */     func_77627_a(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void func_150895_a(Item item, CreativeTabs tab, List<ItemStack> list) {
/* 42 */     for (String type : LootPPHelper.chestTypes) {
/* 43 */       ItemStack toAdd = new ItemStack(LootPPBlocks.blockLootChest);
/* 44 */       toAdd.func_77982_d(new NBTTagCompound());
/* 45 */       toAdd.func_77978_p().func_74778_a("Type", type);
/* 46 */       list.add(toAdd);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack itemStack) {
/* 53 */     String type = "";
/* 54 */     if (itemStack.func_77978_p() != null) {
/* 55 */       type = itemStack.func_77978_p().func_74779_i("Type");
/*    */     }
/* 57 */     return ("" + StatCollector.func_74838_a(func_77657_g(itemStack) + ".name")).trim() + " " + type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean placeBlockAt(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ, IBlockState newState) {
/* 71 */     EnumFacing enumfacing = EnumFacing.func_176731_b(MathHelper.func_76128_c((player.field_70177_z * 4.0F / 360.0F) + 0.5D) & 0x3).func_176734_d();
/* 72 */     newState = newState.func_177226_a((IProperty)BlockChest.field_176459_a, (Comparable)enumfacing);
/*    */     
/* 74 */     if (!world.func_180501_a(pos, newState, 3)) return false;
/*    */     
/* 76 */     IBlockState state = world.func_180495_p(pos);
/* 77 */     if (state.func_177230_c() == LootPPBlocks.blockLootChest) {
/*    */       
/* 79 */       TileEntity te = world.func_175625_s(pos);
/* 80 */       if (te != null && te instanceof TileEntityLootChest && stack.func_77978_p() != null) {
/* 81 */         TileEntityLootChest tile = (TileEntityLootChest)te;
/* 82 */         String type = stack.func_77978_p().func_74779_i("Type");
/*    */         
/* 84 */         tile.type = type;
/*    */         
/* 86 */         if (stack.func_82837_s()) {
/* 87 */           tile.func_145976_a(stack.func_82833_r());
/*    */         }
/* 89 */         if (LootPlusPlusMod.debug) System.out.println("[Loot++] Creating loot chest of type " + tile.type);
/*    */       
/*    */       } 
/*    */     } 
/* 93 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\loot\ItemBlockLootChest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */