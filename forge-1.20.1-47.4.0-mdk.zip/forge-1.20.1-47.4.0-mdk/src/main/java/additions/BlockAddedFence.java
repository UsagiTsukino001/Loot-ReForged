/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.block.BlockFence;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemLead;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.EnumWorldBlockLayer;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockAddedFence
/*    */   extends BlockFence implements InterfaceBlockAdded {
/* 19 */   public String displayName = "";
/* 20 */   public String harvestTool = "pickaxe";
/*    */   public boolean isOpaque = true;
/*    */   
/*    */   public BlockAddedFence(Material material, boolean opaque, String harvestTool, int harvestLevel, String display) {
/* 24 */     super(material);
/*    */     
/* 26 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*    */     
/* 28 */     if (harvestLevel != -1) {
/* 29 */       setHarvestLevel(harvestTool, harvestLevel);
/*    */     }
/*    */     
/* 32 */     func_149713_g(0);
/* 33 */     this.isOpaque = opaque;
/* 34 */     this.harvestTool = harvestTool;
/* 35 */     this.displayName = display;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 43 */     return worldIn.field_72995_K ? false : ItemLead.func_180618_a(playerIn, worldIn, pos);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isSideSolid(IBlockAccess world, BlockPos pos, EnumFacing side) {
/* 58 */     return (side == EnumFacing.UP);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public EnumWorldBlockLayer func_180664_k() {
/* 65 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isToolEffective(String type, IBlockState state) {
/* 78 */     return type.equals(this.harvestTool);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayName(IBlockState state) {
/* 83 */     return this.displayName;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedFence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */