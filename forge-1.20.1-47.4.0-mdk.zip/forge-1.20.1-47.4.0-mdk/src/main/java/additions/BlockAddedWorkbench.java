/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.ChatComponentText;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.IChatComponent;
/*    */ import net.minecraft.world.IInteractionObject;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockAddedWorkbench
/*    */   extends BlockAdded
/*    */ {
/*    */   public BlockAddedWorkbench(Material material, int opacity, String harvestTool, int harvestLevel, float slip, String display) {
/* 28 */     super(material, opacity, false, harvestTool, harvestLevel, slip, display);
/* 29 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_180639_a(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 37 */     if (world.field_72995_K)
/*    */     {
/* 39 */       return true;
/*    */     }
/*    */ 
/*    */     
/* 43 */     player.func_180468_a(new InterfaceAddedCraftingTable(world, pos, this));
/* 44 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public static class InterfaceAddedCraftingTable
/*    */     implements IInteractionObject
/*    */   {
/*    */     private final World world;
/*    */     private final BlockPos position;
/*    */     private final BlockAddedWorkbench block;
/*    */     private static final String __OBFID = "CL_00002127";
/*    */     
/*    */     public InterfaceAddedCraftingTable(World worldIn, BlockPos pos, BlockAddedWorkbench block) {
/* 57 */       this.world = worldIn;
/* 58 */       this.position = pos;
/* 59 */       this.block = block;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public String func_70005_c_() {
/* 67 */       return null;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public boolean func_145818_k_() {
/* 75 */       return false;
/*    */     }
/*    */ 
/*    */     
/*    */     public IChatComponent func_145748_c_() {
/* 80 */       return (IChatComponent)new ChatComponentText(this.block.getDisplayName(this.block.func_176223_P()));
/*    */     }
/*    */ 
/*    */     
/*    */     public Container func_174876_a(InventoryPlayer playerInventory, EntityPlayer playerIn) {
/* 85 */       return (Container)new ContainerAddedWorkbench(playerInventory, this.world, this.position);
/*    */     }
/*    */ 
/*    */     
/*    */     public String func_174875_k() {
/* 90 */       return "minecraft:crafting_table";
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedWorkbench.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */