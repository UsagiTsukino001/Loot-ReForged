package com.tmtravlr.lootplusplus.additions;

import net.minecraft.block.state.IBlockState;

public interface InterfaceBlockAdded {
  String getDisplayName(IBlockState paramIBlockState);
}


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\InterfaceBlockAdded.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */