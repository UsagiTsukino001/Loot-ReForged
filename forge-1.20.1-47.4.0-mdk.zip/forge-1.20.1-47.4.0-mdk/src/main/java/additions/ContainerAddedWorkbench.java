/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.entity.player.InventoryPlayer;
/*    */ import net.minecraft.inventory.ContainerWorkbench;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class ContainerAddedWorkbench
/*    */   extends ContainerWorkbench
/*    */ {
/*    */   public BlockPos pos;
/*    */   public World field_75161_g;
/*    */   
/*    */   public ContainerAddedWorkbench(InventoryPlayer inventory, World world, BlockPos pos) {
/* 16 */     super(inventory, world, pos);
/* 17 */     this.pos = pos;
/* 18 */     this.field_75161_g = world;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_75145_c(EntityPlayer player) {
/* 24 */     return !(this.field_75161_g.func_180495_p(this.pos).func_177230_c() instanceof BlockAddedWorkbench) ? false : ((player.func_70092_e(this.pos.func_177958_n() + 0.5D, this.pos.func_177956_o() + 0.5D, this.pos.func_177952_p() + 0.5D) <= 64.0D));
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ContainerAddedWorkbench.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */