/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.block.BlockLadder;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.EnumWorldBlockLayer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockAddedLadder
/*    */   extends BlockLadder implements InterfaceBlockAdded {
/* 12 */   public String displayName = "";
/* 13 */   public String harvestTool = "none";
/*    */   
/*    */   public boolean isOpaque = true;
/*    */   
/*    */   public BlockAddedLadder(String harvestTool, int harvestLevel, float slip, String display) {
/* 18 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*    */     
/* 20 */     if (harvestLevel != -1) {
/* 21 */       setHarvestLevel(harvestTool, harvestLevel);
/*    */     }
/*    */     
/* 24 */     func_149713_g(0);
/*    */     
/* 26 */     this.harvestTool = harvestTool;
/* 27 */     this.field_149765_K = slip;
/* 28 */     this.displayName = display;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isToolEffective(String type, IBlockState state) {
/* 42 */     return type.equals(this.harvestTool);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public EnumWorldBlockLayer func_180664_k() {
/* 49 */     return EnumWorldBlockLayer.TRANSLUCENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayName(IBlockState state) {
/* 54 */     return this.displayName;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedLadder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */