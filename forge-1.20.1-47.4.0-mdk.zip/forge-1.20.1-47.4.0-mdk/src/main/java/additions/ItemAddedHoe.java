/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemHoe;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ 
/*    */ public class ItemAddedHoe
/*    */   extends ItemHoe
/*    */ {
/*    */   public String displayName;
/*    */   
/*    */   public ItemAddedHoe(Item.ToolMaterial material, String display) {
/* 16 */     super(material);
/* 17 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/* 18 */     this.displayName = display;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 24 */     return StatCollector.func_74838_a(this.displayName).trim();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_82789_a(ItemStack tool, ItemStack materialStack) {
/* 32 */     return ItemAdded.isToolRepairable(tool, materialStack, this.field_77843_a);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedHoe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */