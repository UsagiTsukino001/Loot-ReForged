/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.List;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBow;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemAddedGun
/*     */   extends ItemBow
/*     */ {
/*     */   public static final float POWER_MULTIPLIER = 1.25F;
/*  35 */   public static final DecimalFormat DECIMALFORMAT = new DecimalFormat("#.###");
/*     */   
/*  37 */   public String displayName = "";
/*  38 */   public float baseDamage = 0.0F;
/*  39 */   public int waitTime = 20;
/*  40 */   public int bulletCount = 1;
/*  41 */   public int enchantability = 1;
/*     */   
/*     */   public ItemStack repairStack;
/*     */   public Item ammoItem;
/*     */   public ItemAddedThrowable shotItem;
/*     */   public String shootingSound;
/*     */   
/*     */   public ItemAddedGun(String display, float damage, int time, int durability, int bullets, int enchant, ItemStack repairItem, Item ammo, ItemAddedThrowable shot, String sound) {
/*  49 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/*  50 */     func_77656_e(durability);
/*  51 */     this.baseDamage = damage;
/*  52 */     this.waitTime = time;
/*  53 */     this.bulletCount = bullets;
/*  54 */     this.enchantability = enchant;
/*  55 */     this.repairStack = repairItem;
/*  56 */     this.displayName = display;
/*  57 */     this.ammoItem = ammo;
/*  58 */     this.shotItem = shot;
/*  59 */     this.shootingSound = sound;
/*     */   }
/*     */   
/*     */   public int getWaitTime(ItemStack stack) {
/*  63 */     int time = this.waitTime;
/*     */     
/*  65 */     if (stack == null || stack.func_77978_p() == null || !stack.func_77978_p().func_74764_b("ench")) {
/*  66 */       return this.waitTime;
/*     */     }
/*     */     
/*  69 */     NBTTagList enchList = stack.func_77978_p().func_150295_c("ench", 10);
/*     */     
/*  71 */     int size = enchList.func_74745_c();
/*  72 */     for (int i = 0; i < size; i++) {
/*  73 */       NBTTagCompound tag = enchList.func_150305_b(i);
/*     */       
/*  75 */       int id = tag.func_74762_e("id");
/*  76 */       Enchantment enchant = Enchantment.func_180306_c(id);
/*  77 */       if (LootPPHelper.isQuickdraw(enchant)) {
/*  78 */         int lvl = tag.func_74762_e("lvl");
/*     */         
/*  80 */         if (lvl > 0) {
/*  81 */           time = time / 2 + time / 2 * (lvl + 1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  86 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumAction func_77661_b(ItemStack stack) {
/*  94 */     return EnumAction.NONE;
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_77653_i(ItemStack stack) {
/*  99 */     return StatCollector.func_74838_a(this.displayName).trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77659_a(ItemStack stack, World world, EntityPlayer player) {
/* 109 */     if (!world.field_72995_K) {
/* 110 */       int tickStamp = getTimeStamp(stack);
/*     */       
/* 112 */       if (tickStamp <= player.field_70173_aa && player.field_70173_aa - tickStamp < getWaitTime(stack)) {
/* 113 */         return stack;
/*     */       }
/*     */       
/* 116 */       boolean flag = (player.field_71075_bZ.field_75098_d || this.bulletCount == 0 || EnchantmentHelper.func_77506_a(Enchantment.field_77342_w.field_77352_x, stack) > 0);
/* 117 */       if (flag || player.field_71071_by.func_146028_b(this.ammoItem)) {
/*     */ 
/*     */         
/* 120 */         int power = EnchantmentHelper.func_77506_a(Enchantment.field_77345_t.field_77352_x, stack);
/* 121 */         int punch = EnchantmentHelper.func_77506_a(Enchantment.field_77344_u.field_77352_x, stack);
/*     */         
/* 123 */         for (int i = 0; i < ((this.bulletCount < 1) ? 1 : this.bulletCount) && (flag || player.field_71071_by.func_146028_b(this.ammoItem)); i++) {
/* 124 */           if (!flag) {
/* 125 */             player.field_71071_by.func_146026_a(this.ammoItem);
/*     */           }
/*     */           
/* 128 */           if (!world.field_72995_K) {
/*     */             
/* 130 */             EntityAddedThrownItem.nextVelocity = this.shotItem.velocity;
/* 131 */             EntityAddedThrownItem thrown = new EntityAddedThrownItem(world, (EntityLivingBase)player, this.shotItem);
/*     */             
/* 133 */             if (thrown.damage > 0.0F) {
/* 134 */               thrown.damage += power * 1.25F + this.baseDamage;
/*     */             }
/*     */             
/* 137 */             if (punch > 0) {
/* 138 */               thrown.punch = punch;
/*     */             }
/*     */             
/* 141 */             world.func_72838_d((Entity)thrown);
/*     */           } 
/*     */         } 
/*     */         
/* 145 */         stack.func_77972_a(1, (EntityLivingBase)player);
/* 146 */         world.func_72956_a((Entity)player, this.shootingSound, 1.0F, 1.0F / (0.8F + field_77697_d.nextFloat() * 0.4F));
/* 147 */         setTimeStamp(stack, player.field_70173_aa);
/*     */       } 
/*     */     } 
/*     */     
/* 151 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_77624_a(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced) {
/* 162 */     tooltip.add("");
/* 163 */     if (this.baseDamage > 0.0F) {
/* 164 */       int power = EnchantmentHelper.func_77506_a(Enchantment.field_77345_t.field_77352_x, stack);
/* 165 */       float damage = this.baseDamage + this.shotItem.damage + power * 1.25F;
/*     */       
/* 167 */       if (damage != 0.0F) {
/* 168 */         tooltip.add(EnumChatFormatting.BLUE + "+" + DECIMALFORMAT.format(damage) + StatCollector.func_74838_a("gun.info.rangeddamage"));
/*     */       }
/*     */     } 
/*     */     
/* 172 */     tooltip.add(EnumChatFormatting.BLUE + "+" + DECIMALFORMAT.format((getWaitTime(stack) / 20.0F)) + StatCollector.func_74838_a("gun.info.reloadtime"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_77619_b() {
/* 181 */     return this.enchantability;
/*     */   }
/*     */   
/*     */   public int getTimeStamp(ItemStack stack) {
/* 185 */     if (!stack.func_77942_o()) {
/* 186 */       stack.func_77982_d(new NBTTagCompound());
/*     */     }
/* 188 */     return stack.func_77978_p().func_74762_e("TickStamp");
/*     */   }
/*     */   
/*     */   public void setTimeStamp(ItemStack stack, int ticks) {
/* 192 */     if (!stack.func_77942_o()) {
/* 193 */       stack.func_77982_d(new NBTTagCompound());
/*     */     }
/* 195 */     stack.func_77978_p().func_74768_a("TickStamp", ticks);
/*     */   }
/*     */   
/*     */   private String getName() {
/* 199 */     return "lootplusplus:" + func_77658_a().substring(func_77658_a().indexOf(".") + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82789_a(ItemStack toRepair, ItemStack repairMaterial) {
/* 207 */     return (this.repairStack != null && repairMaterial != null && this.repairStack.func_77973_b() == repairMaterial.func_77973_b() && (this.repairStack.func_77952_i() == 32767 || this.repairStack.func_77952_i() == repairMaterial.func_77952_i()));
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedGun.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */