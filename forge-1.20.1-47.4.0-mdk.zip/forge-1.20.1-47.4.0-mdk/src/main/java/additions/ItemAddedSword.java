/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.google.common.collect.HashMultimap;
/*    */ import com.google.common.collect.Multimap;
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.entity.SharedMonsterAttributes;
/*    */ import net.minecraft.entity.ai.attributes.AttributeModifier;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.ItemSword;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ public class ItemAddedSword
/*    */   extends ItemSword
/*    */ {
/*    */   public String displayName;
/*    */   public float field_150934_a;
/*    */   public Item.ToolMaterial toolMaterial;
/*    */   
/*    */   public ItemAddedSword(Item.ToolMaterial material, float damageBonus, String display) {
/* 21 */     super(material);
/* 22 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/* 23 */     this.displayName = display;
/* 24 */     this.field_150934_a = damageBonus + material.func_78000_c();
/* 25 */     this.toolMaterial = material;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 31 */     return StatCollector.func_74838_a(this.displayName).trim();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_82789_a(ItemStack tool, ItemStack materialStack) {
/* 39 */     return ItemAdded.isToolRepairable(tool, materialStack, this.toolMaterial);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Multimap func_111205_h() {
/* 47 */     HashMultimap hashMultimap = HashMultimap.create();
/* 48 */     hashMultimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Weapon modifier", this.field_150934_a, 0));
/* 49 */     return (Multimap)hashMultimap;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedSword.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */