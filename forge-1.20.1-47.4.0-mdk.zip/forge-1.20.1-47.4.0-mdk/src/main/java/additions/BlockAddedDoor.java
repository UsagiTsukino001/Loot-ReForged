/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.BlockDoor;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAddedDoor
/*     */   extends BlockDoor
/*     */   implements InterfaceBlockAdded
/*     */ {
/*  24 */   public String displayName = "";
/*  25 */   public String harvestTool = "pickaxe";
/*     */   public boolean isOpaque = true;
/*     */   public boolean onlyRedstone = false;
/*     */   public Item doorItem;
/*     */   
/*     */   public BlockAddedDoor(Material material, boolean redstone, boolean opaque, String harvestTool, int harvestLevel, float slip, String display) {
/*  31 */     super(material);
/*     */     
/*  33 */     if (harvestLevel != -1) {
/*  34 */       setHarvestLevel(harvestTool, harvestLevel);
/*     */     }
/*     */     
/*  37 */     func_149713_g(0);
/*  38 */     this.isOpaque = opaque;
/*  39 */     this.harvestTool = harvestTool;
/*  40 */     this.displayName = display;
/*  41 */     this.onlyRedstone = redstone;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_180646_a(World worldIn, BlockPos pos) {
/*  47 */     return new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 1.0D, 1.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
/*  55 */     if (this.onlyRedstone)
/*     */     {
/*  57 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  61 */     BlockPos blockpos1 = (state.func_177229_b((IProperty)field_176523_O) == BlockDoor.EnumDoorHalf.LOWER) ? pos : pos.func_177977_b();
/*  62 */     IBlockState iblockstate1 = pos.equals(blockpos1) ? state : worldIn.func_180495_p(blockpos1);
/*     */     
/*  64 */     if (iblockstate1.func_177230_c() != this)
/*     */     {
/*  66 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  70 */     state = iblockstate1.func_177231_a((IProperty)field_176519_b);
/*  71 */     worldIn.func_180501_a(blockpos1, state, 2);
/*  72 */     worldIn.func_175704_b(blockpos1, pos);
/*  73 */     worldIn.func_180498_a(playerIn, ((Boolean)state.func_177229_b((IProperty)field_176519_b)).booleanValue() ? 1003 : 1006, pos, 0);
/*  74 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public Item func_180665_b(World worldIn, BlockPos pos) {
/*  82 */     return this.doorItem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Item func_180660_a(IBlockState state, Random rand, int fortune) {
/*  92 */     return (state.func_177229_b((IProperty)field_176523_O) == BlockDoor.EnumDoorHalf.UPPER) ? null : this.doorItem;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_176200_f(World worldIn, BlockPos pos) {
/* 100 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/* 107 */     return EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state) {
/* 120 */     return type.equals(this.harvestTool);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 125 */     return this.displayName;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedDoor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */