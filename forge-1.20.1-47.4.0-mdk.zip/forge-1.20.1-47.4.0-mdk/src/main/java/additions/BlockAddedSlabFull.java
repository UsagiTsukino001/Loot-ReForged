/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import net.minecraft.block.material.Material;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockAddedSlabFull
/*    */   extends BlockAddedSlab
/*    */ {
/*    */   public BlockAddedSlabFull(Material material, int opacity, String harvestTool, int harvestLevel, float slip, String display) {
/* 15 */     super(material, opacity, harvestTool, harvestLevel, slip, display);
/*    */   }
/*    */   
/*    */   public boolean func_176552_j() {
/* 19 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedSlabFull.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */