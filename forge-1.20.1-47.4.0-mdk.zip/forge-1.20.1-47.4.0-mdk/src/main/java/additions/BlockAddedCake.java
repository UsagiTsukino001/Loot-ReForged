/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.effects.GiveEffects;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyInteger;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ public class BlockAddedCake
/*     */   extends BlockAdded
/*     */   implements InterfaceBlockAdded
/*     */ {
/*  30 */   public static final PropertyInteger BITES2 = PropertyInteger.func_177719_a("bites", 0, 1);
/*  31 */   public static final PropertyInteger BITES3 = PropertyInteger.func_177719_a("bites", 0, 2);
/*  32 */   public static final PropertyInteger BITES4 = PropertyInteger.func_177719_a("bites", 0, 3);
/*  33 */   public static final PropertyInteger BITES5 = PropertyInteger.func_177719_a("bites", 0, 4);
/*  34 */   public static final PropertyInteger BITES6 = PropertyInteger.func_177719_a("bites", 0, 5);
/*  35 */   public static final PropertyInteger BITES7 = PropertyInteger.func_177719_a("bites", 0, 6);
/*  36 */   public static final PropertyInteger BITES8 = PropertyInteger.func_177719_a("bites", 0, 7);
/*  37 */   public static final PropertyInteger BITES9 = PropertyInteger.func_177719_a("bites", 0, 8);
/*  38 */   public static final PropertyInteger BITES10 = PropertyInteger.func_177719_a("bites", 0, 9);
/*  39 */   public static final PropertyInteger BITES11 = PropertyInteger.func_177719_a("bites", 0, 10);
/*  40 */   public static final PropertyInteger BITES12 = PropertyInteger.func_177719_a("bites", 0, 11);
/*  41 */   public static final PropertyInteger BITES13 = PropertyInteger.func_177719_a("bites", 0, 12);
/*  42 */   public static final PropertyInteger BITES14 = PropertyInteger.func_177719_a("bites", 0, 13);
/*  43 */   public static final PropertyInteger BITES15 = PropertyInteger.func_177719_a("bites", 0, 14);
/*  44 */   public static final PropertyInteger BITES16 = PropertyInteger.func_177719_a("bites", 0, 15);
/*     */   
/*  46 */   public static int nextNumBites = 7;
/*     */   
/*     */   public PropertyInteger bites;
/*  49 */   public int numBites = 7;
/*  50 */   public int hunger = 2;
/*  51 */   public float saturation = 0.1F;
/*     */   public boolean alwaysEdible = false;
/*  53 */   public ArrayList<GiveEffects.EffectInfo> effects = new ArrayList<GiveEffects.EffectInfo>();
/*     */   
/*  55 */   public double height = 0.5D;
/*  56 */   public double width = 0.0625D;
/*     */   
/*     */   public BlockAddedCake(float slip, int numBites, int hungerRestored, float saturationRestored, boolean alwaysEdible, String display) {
/*  59 */     super(Material.field_151568_F, 0, false, "none", -1, slip, display);
/*     */     
/*  61 */     this.numBites = numBites;
/*  62 */     this.bites = getPropertyFromNumBites(numBites);
/*  63 */     this.alwaysEdible = alwaysEdible;
/*  64 */     this.hunger = hungerRestored;
/*  65 */     this.saturation = saturationRestored;
/*  66 */     if (this.bites != null) {
/*  67 */       func_180632_j(func_176223_P().func_177226_a((IProperty)this.bites, Integer.valueOf(0)));
/*     */     }
/*     */   }
/*     */   
/*     */   private float getBiteDistance(IBlockState state) {
/*  72 */     int currentBites = 0;
/*     */     
/*  74 */     if (this.bites != null) {
/*  75 */       currentBites = ((Integer)state.func_177229_b((IProperty)this.bites)).intValue();
/*     */     }
/*     */     
/*  78 */     return currentBites * (float)(1.0D - 2.0D * this.width) / this.numBites;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180654_a(IBlockAccess worldIn, BlockPos pos) {
/*  83 */     float biteDistance = getBiteDistance(worldIn.func_180495_p(pos));
/*  84 */     func_149676_a((float)this.width + biteDistance, 0.0F, (float)this.width, 1.0F - (float)this.width, (float)this.height, 1.0F - (float)this.width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149683_g() {
/*  92 */     func_149676_a((float)this.width, 0.0F, (float)this.width, 1.0F - (float)this.width, (float)this.height, 1.0F - (float)this.width);
/*     */   }
/*     */ 
/*     */   
/*     */   public AxisAlignedBB func_180640_a(World worldIn, BlockPos pos, IBlockState state) {
/*  97 */     float biteDistance = getBiteDistance(state);
/*  98 */     return new AxisAlignedBB(pos.func_177958_n() + this.width + biteDistance, pos.func_177956_o(), pos.func_177952_p() + this.width, pos.func_177958_n() + 1.0D - this.width, pos.func_177956_o() + this.height, pos.func_177952_p() + 1.0D - this.width);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public AxisAlignedBB func_180646_a(World worldIn, BlockPos pos) {
/* 104 */     return func_180640_a(worldIn, pos, worldIn.func_180495_p(pos));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/* 109 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/* 114 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 119 */     eatCake(worldIn, pos, state, playerIn);
/* 120 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180649_a(World worldIn, BlockPos pos, EntityPlayer playerIn) {
/* 125 */     eatCake(worldIn, pos, worldIn.func_180495_p(pos), playerIn);
/*     */   }
/*     */ 
/*     */   
/*     */   private void eatCake(World worldIn, BlockPos pos, IBlockState state, EntityPlayer player) {
/* 130 */     if (state.func_177230_c() != this) {
/*     */       return;
/*     */     }
/*     */     
/* 134 */     if (player.func_71043_e(this.alwaysEdible)) {
/*     */       
/* 136 */       player.func_71024_bL().func_75122_a(this.hunger, this.saturation);
/* 137 */       int bitesTaken = 0;
/* 138 */       if (this.bites != null) {
/* 139 */         bitesTaken = ((Integer)state.func_177229_b((IProperty)this.bites)).intValue();
/*     */       }
/*     */       
/* 142 */       if (bitesTaken + 1 < this.numBites) {
/*     */         
/* 144 */         worldIn.func_180501_a(pos, state.func_177226_a((IProperty)this.bites, Integer.valueOf(bitesTaken + 1)), 3);
/*     */       }
/*     */       else {
/*     */         
/* 148 */         worldIn.func_175698_g(pos);
/*     */       } 
/*     */       
/* 151 */       if (!worldIn.field_72995_K) {
/*     */         
/* 153 */         Random rand = new Random();
/*     */         
/* 155 */         for (GiveEffects.EffectInfo info : this.effects) {
/* 156 */           if (info != null && info.probability >= rand.nextFloat()) {
/* 157 */             GiveEffects.addEffectToEntity((EntityLivingBase)player, info, true);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addPotionEffect(PotionEffect potion, float probability, String particleType) {
/* 165 */     this.effects.add(new GiveEffects.EffectInfoPotion(Potion.field_76425_a[potion.func_76456_a()], potion.func_76459_b(), potion.func_76458_c(), probability, particleType));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176196_c(World worldIn, BlockPos pos) {
/* 170 */     return super.func_176196_c(worldIn, pos) ? canBlockStay(worldIn, pos) : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_176204_a(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock) {
/* 178 */     if (!canBlockStay(worldIn, pos))
/*     */     {
/* 180 */       worldIn.func_175698_g(pos);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean canBlockStay(World worldIn, BlockPos pos) {
/* 186 */     return worldIn.func_180495_p(pos.func_177977_b()).func_177230_c().func_149688_o().func_76220_a();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149745_a(Random random) {
/* 194 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Item func_180660_a(IBlockState state, Random rand, int fortune) {
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/* 212 */     if (this.bites != null) {
/* 213 */       return func_176223_P().func_177226_a((IProperty)this.bites, Integer.valueOf(meta));
/*     */     }
/*     */     
/* 216 */     return func_176223_P();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/* 225 */     if (this.bites != null) {
/* 226 */       return ((Integer)state.func_177229_b((IProperty)this.bites)).intValue();
/*     */     }
/*     */     
/* 229 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected BlockState func_180661_e() {
/* 235 */     (new IProperty[1])[0] = (IProperty)getPropertyFromNumBites(nextNumBites); return new BlockState(this, (getPropertyFromNumBites(nextNumBites) == null) ? new IProperty[0] : new IProperty[1]);
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_180641_l(World worldIn, BlockPos pos) {
/* 240 */     if (this.bites != null) {
/* 241 */       return this.numBites + 1 - ((Integer)worldIn.func_180495_p(pos).func_177229_b((IProperty)this.bites)).intValue();
/*     */     }
/*     */     
/* 244 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149740_M() {
/* 250 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private PropertyInteger getPropertyFromNumBites(int bitesToSet) {
/* 255 */     switch (bitesToSet) {
/*     */       case 1:
/* 257 */         return null;
/*     */       case 2:
/* 259 */         return BITES2;
/*     */       case 3:
/* 261 */         return BITES3;
/*     */       case 4:
/* 263 */         return BITES4;
/*     */       case 5:
/* 265 */         return BITES5;
/*     */       case 6:
/* 267 */         return BITES6;
/*     */       case 7:
/* 269 */         return BITES7;
/*     */       case 8:
/* 271 */         return BITES8;
/*     */       case 9:
/* 273 */         return BITES9;
/*     */       case 10:
/* 275 */         return BITES10;
/*     */       case 11:
/* 277 */         return BITES11;
/*     */       case 12:
/* 279 */         return BITES12;
/*     */       case 13:
/* 281 */         return BITES13;
/*     */       case 14:
/* 283 */         return BITES14;
/*     */       case 15:
/* 285 */         return BITES15;
/*     */       case 16:
/* 287 */         return BITES16;
/*     */     } 
/* 289 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedCake.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */