/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockFalling;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.EnumWorldBlockLayer;
/*    */ import net.minecraft.world.IBlockAccess;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockAddedFalling
/*    */   extends BlockFalling implements InterfaceBlockAdded {
/* 17 */   public String displayName = "";
/*    */   public boolean isBeaconBase = false;
/* 19 */   public String harvestTool = "pickaxe";
/*    */   public boolean isOpaque = true;
/*    */   
/*    */   public BlockAddedFalling(Material material, int opacity, boolean isBeaconBase, String harvestTool, int harvestLevel, float slip, String display) {
/* 23 */     super(material);
/* 24 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*    */     
/* 26 */     if (harvestLevel != -1) {
/* 27 */       setHarvestLevel(harvestTool, harvestLevel);
/*    */     }
/*    */     
/* 30 */     if (opacity >= 0) {
/* 31 */       func_149713_g(opacity);
/* 32 */       this.isOpaque = false;
/*    */     } else {
/*    */       
/* 35 */       func_149713_g(255);
/*    */     } 
/*    */     
/* 38 */     this.harvestTool = harvestTool;
/* 39 */     this.field_149765_K = slip;
/* 40 */     this.displayName = display;
/* 41 */     this.isBeaconBase = isBeaconBase;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_149662_c() {
/* 46 */     return this.isOpaque;
/*    */   }
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public EnumWorldBlockLayer func_180664_k() {
/* 52 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_149686_d() {
/* 58 */     return this.isOpaque;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean func_176225_a(IBlockAccess iba, BlockPos pos, EnumFacing side) {
/* 68 */     if (!this.isOpaque) {
/* 69 */       Block block = iba.func_180495_p(pos).func_177230_c();
/* 70 */       return (block != this);
/*    */     } 
/*    */     
/* 73 */     return super.func_176225_a(iba, pos, side);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isBeaconBase(IBlockAccess worldObj, BlockPos pos, BlockPos beaconPos) {
/* 81 */     return this.isBeaconBase;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isToolEffective(String type, IBlockState state) {
/* 90 */     return type.equals(this.harvestTool);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayName(IBlockState state) {
/* 95 */     return this.displayName;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedFalling.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */