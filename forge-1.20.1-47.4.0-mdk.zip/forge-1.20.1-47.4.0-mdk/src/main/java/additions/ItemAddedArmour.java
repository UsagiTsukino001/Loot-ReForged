/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.item.ItemArmor;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemAddedArmour
/*    */   extends ItemArmor
/*    */ {
/*    */   public String displayName;
/*    */   public String armourTexture;
/*    */   
/*    */   public ItemAddedArmour(ItemArmor.ArmorMaterial material, int armourType, String display, String modelTextureName) {
/* 18 */     super(material, 0, armourType);
/* 19 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/* 20 */     this.displayName = display;
/* 21 */     this.armourTexture = modelTextureName;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 27 */     return StatCollector.func_74838_a(this.displayName).trim();
/*    */   }
/*    */ 
/*    */   
/*    */   public String getArmorTexture(ItemStack armor, Entity entity, int slot, String type) {
/* 32 */     String texture = this.armourTexture;
/* 33 */     String domain = "minecraft";
/*    */     
/* 35 */     int colonIndex = this.armourTexture.indexOf(":");
/*    */     
/* 37 */     if (colonIndex > 0) {
/* 38 */       texture = this.armourTexture.substring(colonIndex + 1);
/* 39 */       domain = this.armourTexture.substring(0, colonIndex);
/*    */     } 
/*    */     
/* 42 */     return domain + ":textures/models/armor/" + texture + ".png";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_82789_a(ItemStack stack, ItemStack materialStack) {
/* 50 */     ItemStack wildStack = materialStack.func_77946_l();
/* 51 */     wildStack.func_77964_b(32767);
/* 52 */     return (func_82812_d() == LootPPHelper.addedArmourMaterials.get(materialStack) || func_82812_d() == LootPPHelper.addedArmourMaterials.get(wildStack) || stack.func_77973_b() == materialStack.func_77973_b());
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedArmour.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */