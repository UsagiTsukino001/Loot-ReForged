/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import com.tmtravlr.lootplusplus.effects.GiveEffects;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Random;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemFood;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.potion.Potion;
/*    */ import net.minecraft.potion.PotionEffect;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemAddedFood
/*    */   extends ItemFood
/*    */ {
/* 23 */   public static Random rand = new Random();
/* 24 */   public String displayName = "";
/*    */   public boolean shines;
/* 26 */   public int eatDuration = 32;
/* 27 */   public ArrayList<GiveEffects.EffectInfo> effects = new ArrayList<GiveEffects.EffectInfo>();
/*    */   
/*    */   public ItemAddedFood(int hunger, float saturation, boolean wolvesEat, boolean alwaysEdible, int timeToEat, boolean shiny, String display) {
/* 30 */     super(hunger, saturation, wolvesEat);
/* 31 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/* 32 */     this.eatDuration = timeToEat;
/* 33 */     if (alwaysEdible) {
/* 34 */       func_77848_i();
/*    */     }
/*    */     
/* 37 */     this.displayName = display;
/* 38 */     this.shines = shiny;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 44 */     return StatCollector.func_74838_a(this.displayName).trim();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean func_77636_d(ItemStack p_77636_1_) {
/* 51 */     return this.shines;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void func_77849_c(ItemStack stack, World world, EntityPlayer player) {
/* 56 */     if (!world.field_72995_K)
/*    */     {
/* 58 */       for (GiveEffects.EffectInfo info : this.effects) {
/* 59 */         if (info != null && info.probability >= rand.nextFloat()) {
/* 60 */           GiveEffects.addEffectToEntity((EntityLivingBase)player, info, true);
/*    */         }
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public void addPotionEffect(PotionEffect potion, float probability, String particleType) {
/* 67 */     this.effects.add(new GiveEffects.EffectInfoPotion(Potion.field_76425_a[potion.func_76456_a()], potion.func_76459_b(), potion.func_76458_c(), probability, particleType));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_77626_a(ItemStack p_77626_1_) {
/* 75 */     return this.eatDuration;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedFood.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */