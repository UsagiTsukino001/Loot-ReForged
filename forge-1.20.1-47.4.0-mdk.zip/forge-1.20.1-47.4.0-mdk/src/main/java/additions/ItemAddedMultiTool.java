/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockDirt;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.EnumAction;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemTool;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.util.EnumHelper;
/*     */ import net.minecraftforge.event.ForgeEventFactory;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemAddedMultiTool
/*     */   extends ItemTool
/*     */ {
/*  37 */   public static Item.ToolMaterial multiMaterial = EnumHelper.addToolMaterial("lpp_multitool", 0, 1, 1.0F, 0.0F, 1);
/*     */   
/*  39 */   public String displayName = "";
/*  40 */   public float damageModifier = 0.0F;
/*  41 */   public int harvestLevel = 0;
/*  42 */   public float efficiency = 0.0F;
/*  43 */   public int enchantability = 1;
/*  44 */   public Set<String> toolClasses = new HashSet<String>();
/*  45 */   public ItemStack repairStack = null;
/*     */   
/*     */   private boolean isSword;
/*     */   
/*     */   private boolean isPick;
/*     */   private boolean isAxe;
/*     */   private boolean isShovel;
/*     */   private boolean isHoe;
/*     */   
/*     */   public ItemAddedMultiTool(String[] types, int harvestLevel, int durability, float damage, float efficiency, int enchantability, ItemStack repairItem, String display) {
/*  55 */     super(damage, multiMaterial, new HashSet());
/*     */     
/*  57 */     this.field_77777_bU = 1;
/*  58 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/*  59 */     func_77656_e(durability);
/*  60 */     this.damageModifier = damage;
/*  61 */     this.harvestLevel = harvestLevel;
/*  62 */     this.efficiency = efficiency;
/*  63 */     this.enchantability = enchantability;
/*  64 */     this.toolClasses.addAll(Arrays.asList(types));
/*  65 */     this.displayName = display;
/*     */     
/*  67 */     this.isSword = this.toolClasses.contains("sword");
/*  68 */     this.isPick = this.toolClasses.contains("pickaxe");
/*  69 */     this.isAxe = this.toolClasses.contains("axe");
/*  70 */     this.isShovel = this.toolClasses.contains("shovel");
/*  71 */     this.isHoe = this.toolClasses.contains("hoe");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_77653_i(ItemStack stack) {
/*  77 */     return StatCollector.func_74838_a(this.displayName).trim();
/*     */   }
/*     */ 
/*     */   
/*     */   public float func_150893_a(ItemStack stack, Block block) {
/*  82 */     float strength = 1.0F;
/*     */     
/*  84 */     if (this.isSword) {
/*  85 */       strength = Math.max(Items.field_151048_u.func_150893_a(stack, block), strength);
/*     */     }
/*     */     
/*  88 */     if (this.isPick) {
/*  89 */       strength = Math.max((block.func_149688_o() != Material.field_151573_f && block.func_149688_o() != Material.field_151574_g && block.func_149688_o() != Material.field_151576_e) ? super.func_150893_a(stack, block) : this.efficiency, strength);
/*     */     }
/*     */     
/*  92 */     if (this.isAxe) {
/*  93 */       strength = Math.max((block.func_149688_o() != Material.field_151575_d && block.func_149688_o() != Material.field_151585_k && block.func_149688_o() != Material.field_151582_l) ? super.func_150893_a(stack, block) : this.efficiency, strength);
/*     */     }
/*     */     
/*  96 */     return strength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_150897_b(Block blockIn) {
/* 104 */     if (this.isSword && blockIn == Blocks.field_150321_G) {
/* 105 */       return true;
/*     */     }
/*     */     
/* 108 */     if (this.isPick && ((blockIn == Blocks.field_150343_Z) ? (this.harvestLevel >= 3) : ((blockIn != Blocks.field_150484_ah) ? ((blockIn != Blocks.field_150482_ag) ? ((blockIn != Blocks.field_150412_bA) ? ((blockIn != Blocks.field_150475_bE) ? ((blockIn != Blocks.field_150340_R) ? ((blockIn != Blocks.field_150352_o) ? ((blockIn != Blocks.field_150339_S) ? ((blockIn != Blocks.field_150366_p) ? ((blockIn != Blocks.field_150368_y) ? ((blockIn != Blocks.field_150369_x) ? ((blockIn != Blocks.field_150450_ax) ? ((blockIn != Blocks.field_150439_ay) ? (blockIn.func_149688_o() == Material.field_151576_e || blockIn.func_149688_o() == Material.field_151573_f || blockIn.func_149688_o() == Material.field_151574_g) : (this.harvestLevel >= 2)) : (this.harvestLevel >= 2)) : (this.harvestLevel >= 1)) : (this.harvestLevel >= 1)) : (this.harvestLevel >= 1)) : (this.harvestLevel >= 1)) : (this.harvestLevel >= 2)) : (this.harvestLevel >= 2)) : (this.harvestLevel >= 2)) : (this.harvestLevel >= 2)) : (this.harvestLevel >= 2)) : (this.harvestLevel >= 2)))) {
/* 109 */       return true;
/*     */     }
/*     */     
/* 112 */     if (this.isShovel && (blockIn == Blocks.field_150431_aC || blockIn == Blocks.field_150433_aE)) {
/* 113 */       return true;
/*     */     }
/*     */     
/* 116 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_77644_a(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker) {
/* 128 */     stack.func_77972_a(this.isSword ? 1 : 2, attacker);
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_179218_a(ItemStack stack, World worldIn, Block blockIn, BlockPos pos, EntityLivingBase playerIn) {
/* 137 */     if (blockIn.func_176195_g(worldIn, pos) != 0.0D)
/*     */     {
/* 139 */       stack.func_77972_a((this.toolClasses.size() == 1 && this.isSword) ? 2 : 1, playerIn);
/*     */     }
/*     */     
/* 142 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_77662_d() {
/* 151 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_77619_b() {
/* 159 */     return this.enchantability;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumAction func_77661_b(ItemStack stack) {
/* 167 */     return this.isSword ? EnumAction.BLOCK : EnumAction.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_77626_a(ItemStack stack) {
/* 175 */     return this.isSword ? 72000 : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77659_a(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn) {
/* 183 */     if (this.isSword) {
/* 184 */       playerIn.func_71008_a(itemStackIn, func_77626_a(itemStackIn));
/*     */     }
/* 186 */     return itemStackIn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180614_a(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 197 */     if (this.isHoe) {
/* 198 */       if (!playerIn.func_175151_a(pos.func_177972_a(side), side, stack))
/*     */       {
/* 200 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 204 */       int hook = ForgeEventFactory.onHoeUse(stack, playerIn, worldIn, pos);
/* 205 */       if (hook != 0) return (hook > 0);
/*     */       
/* 207 */       IBlockState iblockstate = worldIn.func_180495_p(pos);
/* 208 */       Block block = iblockstate.func_177230_c();
/*     */       
/* 210 */       if (side != EnumFacing.DOWN && worldIn.func_175623_d(pos.func_177984_a())) {
/*     */         
/* 212 */         if (block == Blocks.field_150349_c)
/*     */         {
/* 214 */           return useHoe(stack, playerIn, worldIn, pos, Blocks.field_150458_ak.func_176223_P());
/*     */         }
/*     */         
/* 217 */         if (block == Blocks.field_150346_d)
/*     */         {
/* 219 */           switch (SwitchDirtType.TYPE_LOOKUP[((BlockDirt.DirtType)iblockstate.func_177229_b((IProperty)BlockDirt.field_176386_a)).ordinal()]) {
/*     */             
/*     */             case 1:
/* 222 */               return useHoe(stack, playerIn, worldIn, pos, Blocks.field_150458_ak.func_176223_P());
/*     */             case 2:
/* 224 */               return useHoe(stack, playerIn, worldIn, pos, Blocks.field_150346_d.func_176223_P().func_177226_a((IProperty)BlockDirt.field_176386_a, (Comparable)BlockDirt.DirtType.DIRT));
/*     */           } 
/*     */ 
/*     */         
/*     */         }
/*     */       } 
/*     */     } 
/* 231 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean useHoe(ItemStack stack, EntityPlayer player, World worldIn, BlockPos target, IBlockState newState) {
/* 236 */     worldIn.func_72908_a((target.func_177958_n() + 0.5F), (target.func_177956_o() + 0.5F), (target.func_177952_p() + 0.5F), (newState.func_177230_c()).field_149762_H.func_150498_e(), ((newState.func_177230_c()).field_149762_H.func_150497_c() + 1.0F) / 2.0F, (newState.func_177230_c()).field_149762_H.func_150494_d() * 0.8F);
/*     */     
/* 238 */     if (worldIn.field_72995_K)
/*     */     {
/* 240 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 244 */     worldIn.func_175656_a(target, newState);
/* 245 */     stack.func_77972_a(1, (EntityLivingBase)player);
/* 246 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82789_a(ItemStack tool, ItemStack materialStack) {
/* 255 */     return (materialStack != null && this.repairStack != null && materialStack.func_77973_b() == this.repairStack.func_77973_b() && (this.repairStack.func_77952_i() == 32767 || materialStack.func_77952_i() == this.repairStack.func_77952_i()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHarvestLevel(ItemStack stack, String toolClass) {
/* 271 */     int level = super.getHarvestLevel(stack, toolClass);
/* 272 */     if (level == -1 && toolClass != null && this.toolClasses.contains(toolClass))
/*     */     {
/* 274 */       return this.harvestLevel;
/*     */     }
/*     */ 
/*     */     
/* 278 */     return level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getToolClasses(ItemStack stack) {
/* 285 */     return !this.toolClasses.isEmpty() ? this.toolClasses : super.getToolClasses(stack);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float getDigSpeed(ItemStack stack, IBlockState state) {
/* 291 */     for (String type : getToolClasses(stack)) {
/*     */       
/* 293 */       if (state.func_177230_c().isToolEffective(type, state))
/* 294 */         return this.efficiency; 
/*     */     } 
/* 296 */     return super.getDigSpeed(stack, state);
/*     */   }
/*     */   
/*     */   static final class SwitchDirtType
/*     */   {
/* 301 */     static final int[] TYPE_LOOKUP = new int[(BlockDirt.DirtType.values()).length];
/*     */     
/*     */     private static final String __OBFID = "CL_00002179";
/*     */ 
/*     */     
/*     */     static {
/*     */       try {
/* 308 */         TYPE_LOOKUP[BlockDirt.DirtType.DIRT.ordinal()] = 1;
/*     */       }
/* 310 */       catch (NoSuchFieldError noSuchFieldError) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 317 */         TYPE_LOOKUP[BlockDirt.DirtType.COARSE_DIRT.ordinal()] = 2;
/*     */       }
/* 319 */       catch (NoSuchFieldError noSuchFieldError) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedMultiTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */