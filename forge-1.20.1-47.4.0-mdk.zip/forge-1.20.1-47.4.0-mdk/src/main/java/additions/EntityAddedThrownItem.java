/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.projectile.EntityThrowable;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EntityDamageSourceIndirect;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityAddedThrownItem
/*     */   extends EntityThrowable
/*     */ {
/*  29 */   public static float nextVelocity = -1.0F;
/*     */   
/*  31 */   public float damage = 0.0F;
/*  32 */   public float punch = 0.0F;
/*  33 */   public float gravity = 0.03F;
/*  34 */   public float inaccuracy = 0.0F;
/*     */   
/*  36 */   protected ItemAddedThrowable itemThrown = null;
/*     */   
/*     */   public EntityAddedThrownItem(World worldIn) {
/*  39 */     super(worldIn);
/*     */   }
/*     */   
/*     */   public EntityAddedThrownItem(World worldIn, EntityLivingBase entity) {
/*  43 */     this(worldIn, entity, (ItemAddedThrowable)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public EntityAddedThrownItem(World worldIn, EntityLivingBase entity, ItemAddedThrowable throwable) {
/*  48 */     super(worldIn, entity);
/*  49 */     setItemThrown(throwable);
/*     */   }
/*     */   
/*     */   public EntityAddedThrownItem(World worldIn, double x, double y, double z) {
/*  53 */     super(worldIn, x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void func_70088_a() {
/*  58 */     super.func_70088_a();
/*     */     
/*  60 */     this.field_70180_af.func_75682_a(5, "");
/*     */   }
/*     */ 
/*     */   
/*     */   protected float func_70182_d() {
/*  65 */     float velocity = (nextVelocity < 0.0F) ? 1.5F : nextVelocity;
/*  66 */     nextVelocity = -1.0F;
/*  67 */     return velocity;
/*     */   }
/*     */ 
/*     */   
/*     */   protected float func_70183_g() {
/*  72 */     return this.inaccuracy;
/*     */   }
/*     */ 
/*     */   
/*     */   protected float func_70185_h() {
/*  77 */     return this.gravity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void func_70184_a(MovingObjectPosition position) {
/*  84 */     if (position.field_72308_g != null && this.damage >= 0.0F) {
/*  85 */       position.field_72308_g.func_70097_a((new EntityDamageSourceIndirect("lppthrown", (Entity)this, (Entity)func_85052_h())
/*     */           {
/*     */             public IChatComponent func_151519_b(EntityLivingBase entity)
/*     */             {
/*  89 */               IChatComponent ichatcomponent = (func_76346_g() == null) ? this.field_76386_o.func_145748_c_() : func_76346_g().func_145748_c_();
/*  90 */               Item thrown = ((EntityAddedThrownItem)this.field_76386_o).itemThrown;
/*  91 */               String s = "death.attack." + this.field_76373_n;
/*  92 */               String s1 = s + ".item";
/*  93 */               return (thrown != null && StatCollector.func_94522_b(s1)) ? (IChatComponent)new ChatComponentTranslation(s1, new Object[] { entity.func_145748_c_(), ichatcomponent, (new ItemStack(thrown)).func_82833_r() }) : (IChatComponent)new ChatComponentTranslation(s, new Object[] { entity.func_145748_c_(), ichatcomponent });
/*     */             }
/*  95 */           }).func_76349_b(), this.damage);
/*     */       
/*  97 */       if (this.punch > 0.0F) {
/*     */         
/*  99 */         float force = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
/*     */         
/* 101 */         if (force > 0.0F)
/*     */         {
/* 103 */           position.field_72308_g.func_70024_g(this.field_70159_w * this.punch * 0.6000000238418579D / force, 0.1D, this.field_70179_y * this.punch * 0.6000000238418579D / force);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 108 */     if (this.itemThrown != null && !this.field_70170_p.field_72995_K) {
/* 109 */       LootPPHelper.dropThrownDropAdditions(this.itemThrown, (Entity)this);
/*     */     }
/*     */     
/* 112 */     for (int i = 0; i < 8; i++) {
/* 113 */       int itemId = Item.func_150891_b(Item.func_111206_d(this.field_70180_af.func_75681_e(5)));
/* 114 */       this.field_70170_p.func_175688_a(EnumParticleTypes.ITEM_CRACK, this.field_70165_t, this.field_70163_u, this.field_70161_v, (this.field_70146_Z.nextFloat() - 0.5D) * 0.08D, (this.field_70146_Z.nextFloat() - 0.5D) * 0.08D, (this.field_70146_Z.nextFloat() - 0.5D) * 0.08D, new int[] { (itemId == 0) ? Item.func_150891_b(Items.field_151126_ay) : itemId });
/*     */     } 
/*     */     
/* 117 */     if (!this.field_70170_p.field_72995_K) {
/* 118 */       func_70106_y();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_70014_b(NBTTagCompound tagCompound) {
/* 124 */     super.func_70014_b(tagCompound);
/*     */     
/* 126 */     tagCompound.func_74778_a("ItemThrown", Item.field_150901_e.func_177774_c(this.itemThrown).toString());
/*     */     
/* 128 */     tagCompound.func_74776_a("Damage", this.damage);
/* 129 */     tagCompound.func_74776_a("Punch", this.punch);
/* 130 */     tagCompound.func_74776_a("Gravity", this.gravity);
/* 131 */     tagCompound.func_74776_a("Inaccuracy", this.inaccuracy);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70037_a(NBTTagCompound tagCompound) {
/* 137 */     super.func_70037_a(tagCompound);
/*     */     
/* 139 */     Item item = Item.func_111206_d(tagCompound.func_74779_i("ItemThrown"));
/* 140 */     if (item instanceof ItemAddedThrowable) {
/* 141 */       this.itemThrown = (ItemAddedThrowable)item;
/*     */     } else {
/*     */       
/* 144 */       this.itemThrown = null;
/*     */     } 
/*     */     
/* 147 */     this.damage = tagCompound.func_74760_g("Damage");
/* 148 */     this.punch = tagCompound.func_74760_g("Punch");
/* 149 */     this.gravity = tagCompound.func_74760_g("Gravity");
/* 150 */     this.inaccuracy = tagCompound.func_74760_g("Inaccuracy");
/*     */   }
/*     */   
/*     */   public void func_70071_h_() {
/* 154 */     super.func_70071_h_();
/*     */     
/* 156 */     String itemName = this.field_70180_af.func_75681_e(5);
/* 157 */     if (itemName.equals("") && 
/* 158 */       this.itemThrown != null) {
/* 159 */       setItemThrown(this.itemThrown);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setItemThrown(ItemAddedThrowable item) {
/* 165 */     this.itemThrown = item;
/*     */     
/* 167 */     if (item != null) {
/*     */       
/* 169 */       this.damage = this.itemThrown.damage;
/* 170 */       this.gravity = this.itemThrown.gravity;
/* 171 */       this.inaccuracy = this.itemThrown.inaccuracy;
/*     */       
/* 173 */       this.field_70180_af.func_75692_b(5, Item.field_150901_e.func_177774_c(item).toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   public Item getItemThrown() {
/* 178 */     if (this.itemThrown != null) {
/* 179 */       return this.itemThrown;
/*     */     }
/*     */     
/* 182 */     String itemName = this.field_70180_af.func_75681_e(5);
/* 183 */     Item item = Item.func_111206_d(itemName);
/*     */     
/* 185 */     if (item instanceof ItemAddedThrowable) {
/* 186 */       this.itemThrown = (ItemAddedThrowable)item;
/*     */       
/* 188 */       this.damage = this.itemThrown.damage;
/* 189 */       this.gravity = this.itemThrown.gravity;
/* 190 */       this.inaccuracy = this.itemThrown.inaccuracy;
/*     */       
/* 192 */       return this.itemThrown;
/*     */     } 
/*     */     
/* 195 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\EntityAddedThrownItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */