/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.block.properties.PropertyInteger;
/*    */ import net.minecraft.block.state.BlockState;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.creativetab.CreativeTabs;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockAddedMetadata
/*    */   extends BlockAdded
/*    */ {
/* 23 */   public static final PropertyInteger META = PropertyInteger.func_177719_a("metadata", 0, 15);
/*    */   
/* 25 */   public String[] displayNames = new String[16];
/*    */   
/*    */   public BlockAddedMetadata(Material material, int opacity, boolean isBeaconBase, String harvestTool, int harvestLevel, float slip, String[] display) {
/* 28 */     super(material, opacity, isBeaconBase, harvestTool, harvestLevel, slip, display[0]);
/* 29 */     func_180632_j(func_176223_P().func_177226_a((IProperty)META, Integer.valueOf(0)));
/* 30 */     this.displayNames = display;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayName(IBlockState state) {
/* 35 */     int meta = func_176201_c(state);
/* 36 */     return this.displayNames[meta];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_180651_a(IBlockState state) {
/* 44 */     return func_176201_c(state);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public void func_149666_a(Item itemIn, CreativeTabs tab, List<ItemStack> list) {
/* 53 */     for (int i = 0; i < 16; i++) {
/* 54 */       list.add(new ItemStack(this, 1, i));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public IBlockState func_176203_a(int meta) {
/* 63 */     return func_176223_P().func_177226_a((IProperty)META, Integer.valueOf(meta));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_176201_c(IBlockState state) {
/* 71 */     return ((Integer)state.func_177229_b((IProperty)META)).intValue();
/*    */   }
/*    */ 
/*    */   
/*    */   protected BlockState func_180661_e() {
/* 76 */     return new BlockState(this, new IProperty[] { (IProperty)META });
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedMetadata.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */