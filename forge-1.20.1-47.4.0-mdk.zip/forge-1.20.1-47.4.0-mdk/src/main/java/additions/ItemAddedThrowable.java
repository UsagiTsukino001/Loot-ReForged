/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.stats.StatList;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemAddedThrowable
/*    */   extends ItemAdded
/*    */ {
/*    */   public float damage;
/*    */   public float velocity;
/*    */   public float gravity;
/*    */   public float inaccuracy;
/*    */   public float chance;
/*    */   public ArrayList<ArrayList<LootPPHelper.DropInfo>> dropList;
/*    */   
/*    */   public ItemAddedThrowable(boolean shiny, float damageToSet, float velocityToSet, float gravityToSet, float inaccuracyToSet, float chanceToSet, ArrayList<ArrayList<LootPPHelper.DropInfo>> dropListToSet, String display) {
/* 26 */     super(shiny, display);
/* 27 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/*    */     
/* 29 */     this.damage = damageToSet;
/* 30 */     this.velocity = velocityToSet;
/* 31 */     this.gravity = gravityToSet;
/* 32 */     this.inaccuracy = inaccuracyToSet;
/* 33 */     this.dropList = dropListToSet;
/* 34 */     this.chance = chanceToSet;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ItemStack func_77659_a(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn) {
/* 42 */     if (!playerIn.field_71075_bZ.field_75098_d)
/*    */     {
/* 44 */       itemStackIn.field_77994_a--;
/*    */     }
/*    */     
/* 47 */     worldIn.func_72956_a((Entity)playerIn, "random.bow", 0.5F, 0.4F / (field_77697_d.nextFloat() * 0.4F + 0.8F));
/*    */     
/* 49 */     if (!worldIn.field_72995_K) {
/* 50 */       EntityAddedThrownItem.nextVelocity = this.velocity;
/* 51 */       EntityAddedThrownItem thrown = new EntityAddedThrownItem(worldIn, (EntityLivingBase)playerIn, this);
/* 52 */       worldIn.func_72838_d((Entity)thrown);
/*    */     } 
/*    */ 
/*    */     
/* 56 */     playerIn.func_71029_a(StatList.field_75929_E[Item.func_150891_b(this)]);
/* 57 */     return itemStackIn;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedThrowable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */