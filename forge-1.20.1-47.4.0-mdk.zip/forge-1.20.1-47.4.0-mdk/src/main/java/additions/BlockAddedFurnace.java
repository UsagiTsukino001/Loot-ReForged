/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockFurnace;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyBool;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.InventoryHelper;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumParticleTypes;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockAddedFurnace
/*     */   extends BlockFurnace
/*     */   implements InterfaceBlockAdded
/*     */ {
/*  30 */   public static final PropertyBool ACTIVE = PropertyBool.func_177716_a("active");
/*     */   
/*  32 */   private Random rand = new Random();
/*     */   public static boolean swapping = false;
/*  34 */   public String displayName = "";
/*  35 */   public String harvestTool = "pickaxe";
/*     */   
/*     */   public float speedFactor;
/*     */   public boolean isOpaque = true;
/*     */   public Material furnaceMaterial;
/*     */   
/*     */   public BlockAddedFurnace(Material material, float speed, String harvestTool, int opacity, int harvestLevel, float light, float slip, String display) {
/*  42 */     super(false);
/*     */     
/*  44 */     func_180632_j(func_176223_P().func_177226_a((IProperty)ACTIVE, Boolean.valueOf(false)));
/*     */     
/*  46 */     this.furnaceMaterial = material;
/*     */     
/*  48 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*     */     
/*  50 */     if (harvestLevel != -1) {
/*  51 */       setHarvestLevel(harvestTool, harvestLevel);
/*     */     } else {
/*     */       
/*  54 */       setHarvestLevel(null, -1);
/*     */     } 
/*     */     
/*  57 */     if (opacity >= 0) {
/*  58 */       func_149713_g(opacity);
/*  59 */       this.isOpaque = false;
/*     */     } else {
/*     */       
/*  62 */       func_149713_g(255);
/*     */     } 
/*     */     
/*  65 */     this.harvestTool = harvestTool;
/*  66 */     func_149715_a(light);
/*  67 */     this.field_149765_K = slip;
/*  68 */     this.displayName = display;
/*  69 */     this.speedFactor = speed;
/*     */   }
/*     */   
/*     */   public Material func_149688_o() {
/*  73 */     return this.furnaceMaterial;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLightValue(IBlockAccess world, BlockPos pos) {
/*  86 */     Block block = world.func_180495_p(pos).func_177230_c();
/*  87 */     if (block != this)
/*     */     {
/*  89 */       return block.getLightValue(world, pos);
/*     */     }
/*     */     
/*  92 */     IBlockState state = world.func_180495_p(pos);
/*     */     
/*  94 */     return ((Boolean)state.func_177229_b((IProperty)ACTIVE)).booleanValue() ? 15 : func_149750_m();
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_180655_c(World worldIn, BlockPos pos, IBlockState state, Random rand) {
/* 100 */     if (((Boolean)state.func_177229_b((IProperty)ACTIVE)).booleanValue()) {
/*     */       
/* 102 */       EnumFacing enumfacing = (EnumFacing)state.func_177229_b((IProperty)field_176447_a);
/* 103 */       double d0 = pos.func_177958_n() + 0.5D;
/* 104 */       double d1 = pos.func_177956_o() + rand.nextDouble() * 6.0D / 16.0D;
/* 105 */       double d2 = pos.func_177952_p() + 0.5D;
/* 106 */       double d3 = 0.52D;
/* 107 */       double d4 = rand.nextDouble() * 0.6D - 0.3D;
/*     */       
/* 109 */       switch (SwitchEnumFacing.FACING_LOOKUP[enumfacing.ordinal()]) {
/*     */         
/*     */         case 1:
/* 112 */           worldIn.func_175688_a(EnumParticleTypes.SMOKE_NORMAL, d0 - d3, d1, d2 + d4, 0.0D, 0.0D, 0.0D, new int[0]);
/* 113 */           worldIn.func_175688_a(EnumParticleTypes.FLAME, d0 - d3, d1, d2 + d4, 0.0D, 0.0D, 0.0D, new int[0]);
/*     */           break;
/*     */         case 2:
/* 116 */           worldIn.func_175688_a(EnumParticleTypes.SMOKE_NORMAL, d0 + d3, d1, d2 + d4, 0.0D, 0.0D, 0.0D, new int[0]);
/* 117 */           worldIn.func_175688_a(EnumParticleTypes.FLAME, d0 + d3, d1, d2 + d4, 0.0D, 0.0D, 0.0D, new int[0]);
/*     */           break;
/*     */         case 3:
/* 120 */           worldIn.func_175688_a(EnumParticleTypes.SMOKE_NORMAL, d0 + d4, d1, d2 - d3, 0.0D, 0.0D, 0.0D, new int[0]);
/* 121 */           worldIn.func_175688_a(EnumParticleTypes.FLAME, d0 + d4, d1, d2 - d3, 0.0D, 0.0D, 0.0D, new int[0]);
/*     */           break;
/*     */         case 4:
/* 124 */           worldIn.func_175688_a(EnumParticleTypes.SMOKE_NORMAL, d0 + d4, d1, d2 + d3, 0.0D, 0.0D, 0.0D, new int[0]);
/* 125 */           worldIn.func_175688_a(EnumParticleTypes.FLAME, d0 + d4, d1, d2 + d3, 0.0D, 0.0D, 0.0D, new int[0]);
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/* 135 */     EnumFacing enumfacing = EnumFacing.func_82600_a(meta);
/*     */     
/* 137 */     if (enumfacing.func_176740_k() == EnumFacing.Axis.Y)
/*     */     {
/* 139 */       enumfacing = EnumFacing.NORTH;
/*     */     }
/*     */     
/* 142 */     boolean active = false;
/*     */     
/* 144 */     if ((meta & 0x8) == 8) {
/* 145 */       active = true;
/*     */     }
/*     */     
/* 148 */     return func_176223_P().func_177226_a((IProperty)field_176447_a, (Comparable)enumfacing).func_177226_a((IProperty)ACTIVE, Boolean.valueOf(active));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/* 156 */     return ((EnumFacing)state.func_177229_b((IProperty)field_176447_a)).func_176745_a() | (((Boolean)state.func_177229_b((IProperty)ACTIVE)).booleanValue() ? 8 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockState func_180661_e() {
/* 161 */     return new BlockState((Block)this, new IProperty[] { (IProperty)field_176447_a, (IProperty)ACTIVE });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 169 */     if (worldIn.field_72995_K)
/*     */     {
/* 171 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 175 */     TileEntity tileentity = worldIn.func_175625_s(pos);
/*     */     
/* 177 */     if (tileentity instanceof TileEntityAddedFurnace)
/*     */     {
/* 179 */       playerIn.func_71007_a((IInventory)tileentity);
/*     */     }
/*     */     
/* 182 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setState(boolean active, World worldIn, BlockPos pos) {
/* 191 */     IBlockState iblockstate = worldIn.func_180495_p(pos);
/* 192 */     Block block = iblockstate.func_177230_c();
/* 193 */     TileEntity te = worldIn.func_175625_s(pos);
/*     */     
/* 195 */     if (block instanceof BlockAddedFurnace) {
/*     */ 
/*     */ 
/*     */       
/* 199 */       worldIn.func_180501_a(pos, block.func_176223_P().func_177226_a((IProperty)field_176447_a, iblockstate.func_177229_b((IProperty)field_176447_a)).func_177226_a((IProperty)ACTIVE, Boolean.valueOf(active)), 3);
/*     */ 
/*     */       
/* 202 */       if (te != null) {
/* 203 */         te.func_145829_t();
/* 204 */         worldIn.func_175690_a(pos, te);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TileEntity func_149915_a(World p_149915_1_, int p_149915_2_) {
/* 216 */     return (TileEntity)new TileEntityAddedFurnace(this.displayName, this.speedFactor);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180663_b(World worldIn, BlockPos pos, IBlockState state) {
/* 221 */     if (!swapping) {
/*     */       
/* 223 */       TileEntity tileentity = worldIn.func_175625_s(pos);
/*     */       
/* 225 */       if (tileentity instanceof net.minecraft.tileentity.TileEntityFurnace) {
/*     */         
/* 227 */         InventoryHelper.func_180175_a(worldIn, pos, (IInventory)tileentity);
/* 228 */         worldIn.func_175666_e(pos, (Block)this);
/*     */       } 
/*     */     } 
/*     */     
/* 232 */     super.func_180663_b(worldIn, pos, state);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/* 237 */     return this.isOpaque;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_176225_a(IBlockAccess iba, BlockPos pos, EnumFacing side) {
/* 247 */     if (!this.isOpaque) {
/* 248 */       Block block = iba.func_180495_p(pos).func_177230_c();
/* 249 */       return (block != this);
/*     */     } 
/*     */     
/* 252 */     return super.func_176225_a(iba, pos, side);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public Item func_180665_b(World world, BlockPos pos) {
/* 259 */     IBlockState state = world.func_180495_p(pos);
/* 260 */     return Item.func_150898_a((Block)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Item func_180660_a(IBlockState state, Random rand, int fortune) {
/* 266 */     return Item.func_150898_a((Block)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state) {
/* 275 */     return type.equals(this.harvestTool);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/* 282 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/* 288 */     return this.isOpaque;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 293 */     return this.displayName;
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   static final class SwitchEnumFacing
/*     */   {
/* 300 */     static final int[] FACING_LOOKUP = new int[(EnumFacing.values()).length];
/*     */     
/*     */     private static final String __OBFID = "CL_00002111";
/*     */ 
/*     */     
/*     */     static {
/*     */       try {
/* 307 */         FACING_LOOKUP[EnumFacing.WEST.ordinal()] = 1;
/*     */       }
/* 309 */       catch (NoSuchFieldError noSuchFieldError) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 316 */         FACING_LOOKUP[EnumFacing.EAST.ordinal()] = 2;
/*     */       }
/* 318 */       catch (NoSuchFieldError noSuchFieldError) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 325 */         FACING_LOOKUP[EnumFacing.NORTH.ordinal()] = 3;
/*     */       }
/* 327 */       catch (NoSuchFieldError noSuchFieldError) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 334 */         FACING_LOOKUP[EnumFacing.SOUTH.ordinal()] = 4;
/*     */       }
/* 336 */       catch (NoSuchFieldError noSuchFieldError) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedFurnace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */