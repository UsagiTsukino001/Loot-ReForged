/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockStairs;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.EnumWorldBlockLayer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockAddedStairs
/*    */   extends BlockStairs
/*    */   implements InterfaceBlockAdded
/*    */ {
/* 15 */   public String displayName = "";
/*    */   public boolean isOpaque = false;
/*    */   
/*    */   public BlockAddedStairs(Block block, int meta, String display) {
/* 19 */     super(block.func_176203_a(meta));
/*    */     
/* 21 */     this.displayName = display;
/*    */     
/* 23 */     func_149713_g(block.func_149717_k());
/* 24 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/* 25 */     setHarvestLevel(block.getHarvestTool(block.func_176203_a(meta)), block.getHarvestLevel(block.func_176203_a(meta)));
/* 26 */     this.isOpaque = block.func_149662_c();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public EnumWorldBlockLayer func_180664_k() {
/* 33 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayName(IBlockState state) {
/* 38 */     return this.displayName;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedStairs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */