/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.IPlantable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAddedPlant
/*     */   extends BlockAdded
/*     */ {
/*     */   public BlockAddedPlant(Material material, String harvestTool, int harvestLevel, String display) {
/*  28 */     super(material, 0, false, harvestTool, harvestLevel, 0.6F, display);
/*     */     
/*  30 */     func_149676_a(0.3F, 0.0F, 0.3F, 0.7F, 0.7F, 0.7F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_176196_c(World world, BlockPos pos) {
/*  39 */     return (super.func_176196_c(world, pos) && canBlockStay(world, pos));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNeighborChange(IBlockAccess world, BlockPos pos, BlockPos neighbour) {
/*  48 */     super.onNeighborChange(world, pos, neighbour);
/*  49 */     if (world instanceof World) {
/*  50 */       checkAndDropBlock((World)world, pos);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180650_b(World world, BlockPos pos, IBlockState state, Random rand) {
/*  59 */     checkAndDropBlock(world, pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkAndDropBlock(World world, BlockPos pos) {
/*  67 */     if (!canBlockStay(world, pos)) {
/*     */       
/*  69 */       func_176226_b(world, pos, world.func_180495_p(pos), 0);
/*  70 */       world.func_175698_g(pos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBlockStay(World world, BlockPos pos) {
/*  79 */     if (func_149688_o() == Material.field_151585_k) {
/*  80 */       return world.func_180495_p(pos.func_177977_b()).func_177230_c().canSustainPlant((IBlockAccess)world, pos.func_177977_b(), EnumFacing.UP, (IPlantable)Blocks.field_150327_N);
/*     */     }
/*     */     
/*  83 */     return World.func_175683_a((IBlockAccess)world, pos.func_177977_b());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AxisAlignedBB func_180640_a(World world, BlockPos pos, IBlockState state) {
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/* 101 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/* 107 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedPlant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */