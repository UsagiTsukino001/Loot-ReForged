/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.entity.Render;
/*    */ import net.minecraft.client.renderer.entity.RenderItem;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.client.renderer.texture.TextureMap;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ 
/*    */ public class RenderAddedThrownItem
/*    */   extends Render {
/*    */   private final RenderItem renderItem;
/*    */   
/*    */   public RenderAddedThrownItem(RenderManager renderManager, RenderItem renderItem) {
/* 19 */     super(renderManager);
/* 20 */     this.renderItem = renderItem;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void func_76986_a(Entity entity, double x, double y, double z, float p_76986_8_, float partialTicks) {
/* 31 */     GlStateManager.func_179094_E();
/* 32 */     GlStateManager.func_179109_b((float)x, (float)y, (float)z);
/* 33 */     GlStateManager.func_179091_B();
/* 34 */     GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
/* 35 */     GlStateManager.func_179114_b(-this.field_76990_c.field_78735_i, 0.0F, 1.0F, 0.0F);
/* 36 */     GlStateManager.func_179114_b(this.field_76990_c.field_78732_j, 1.0F, 0.0F, 0.0F);
/* 37 */     func_110776_a(TextureMap.field_110575_b);
/* 38 */     this.renderItem.func_175043_b(getItemStackToRender(entity));
/* 39 */     GlStateManager.func_179101_C();
/* 40 */     GlStateManager.func_179121_F();
/* 41 */     super.func_76986_a(entity, x, y, z, p_76986_8_, partialTicks);
/*    */   }
/*    */ 
/*    */   
/*    */   public ItemStack getItemStackToRender(Entity entity) {
/* 46 */     if (entity instanceof EntityAddedThrownItem) {
/* 47 */       Item item = ((EntityAddedThrownItem)entity).getItemThrown();
/*    */       
/* 49 */       if (item != null) {
/* 50 */         return new ItemStack(item, 1, 0);
/*    */       }
/*    */     } 
/*    */     
/* 54 */     return new ItemStack(Items.field_151126_ay, 1, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ResourceLocation func_110775_a(Entity entity) {
/* 62 */     return TextureMap.field_110575_b;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\RenderAddedThrownItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */