/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyBool;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAddedWall
/*     */   extends BlockAdded
/*     */   implements InterfaceBlockAdded
/*     */ {
/*  33 */   public static final PropertyBool UP = PropertyBool.func_177716_a("up");
/*  34 */   public static final PropertyBool NORTH = PropertyBool.func_177716_a("north");
/*  35 */   public static final PropertyBool EAST = PropertyBool.func_177716_a("east");
/*  36 */   public static final PropertyBool SOUTH = PropertyBool.func_177716_a("south");
/*  37 */   public static final PropertyBool WEST = PropertyBool.func_177716_a("west");
/*     */   
/*     */   public BlockAddedWall(Block base, boolean opaque, String harvestTool, int harvestLevel, String display) {
/*  40 */     super(base.func_149688_o(), 0, false, harvestTool, harvestLevel, base.field_149765_K, display);
/*     */     
/*  42 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*  43 */     func_180632_j(this.field_176227_L.func_177621_b().func_177226_a((IProperty)UP, Boolean.valueOf(false)).func_177226_a((IProperty)NORTH, Boolean.valueOf(false)).func_177226_a((IProperty)EAST, Boolean.valueOf(false)).func_177226_a((IProperty)SOUTH, Boolean.valueOf(false)).func_177226_a((IProperty)WEST, Boolean.valueOf(false)));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/*  48 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176205_b(IBlockAccess worldIn, BlockPos pos) {
/*  53 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/*  58 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180654_a(IBlockAccess worldIn, BlockPos pos) {
/*  63 */     boolean flag = canConnectTo(worldIn, pos.func_177978_c());
/*  64 */     boolean flag1 = canConnectTo(worldIn, pos.func_177968_d());
/*  65 */     boolean flag2 = canConnectTo(worldIn, pos.func_177976_e());
/*  66 */     boolean flag3 = canConnectTo(worldIn, pos.func_177974_f());
/*  67 */     float f = 0.25F;
/*  68 */     float f1 = 0.75F;
/*  69 */     float f2 = 0.25F;
/*  70 */     float f3 = 0.75F;
/*  71 */     float f4 = 1.0F;
/*     */     
/*  73 */     if (flag)
/*     */     {
/*  75 */       f2 = 0.0F;
/*     */     }
/*     */     
/*  78 */     if (flag1)
/*     */     {
/*  80 */       f3 = 1.0F;
/*     */     }
/*     */     
/*  83 */     if (flag2)
/*     */     {
/*  85 */       f = 0.0F;
/*     */     }
/*     */     
/*  88 */     if (flag3)
/*     */     {
/*  90 */       f1 = 1.0F;
/*     */     }
/*     */     
/*  93 */     if (flag && flag1 && !flag2 && !flag3) {
/*     */       
/*  95 */       f4 = 0.8125F;
/*  96 */       f = 0.3125F;
/*  97 */       f1 = 0.6875F;
/*     */     }
/*  99 */     else if (!flag && !flag1 && flag2 && flag3) {
/*     */       
/* 101 */       f4 = 0.8125F;
/* 102 */       f2 = 0.3125F;
/* 103 */       f3 = 0.6875F;
/*     */     } 
/*     */     
/* 106 */     func_149676_a(f, 0.0F, f2, f1, f4, f3);
/*     */   }
/*     */ 
/*     */   
/*     */   public AxisAlignedBB func_180640_a(World worldIn, BlockPos pos, IBlockState state) {
/* 111 */     func_180654_a((IBlockAccess)worldIn, pos);
/* 112 */     this.field_149756_F = 1.5D;
/* 113 */     return super.func_180640_a(worldIn, pos, state);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canConnectTo(IBlockAccess worldIn, BlockPos pos) {
/* 118 */     Block block = worldIn.func_180495_p(pos).func_177230_c();
/* 119 */     return (block == Blocks.field_180401_cv) ? false : ((!(block instanceof BlockAddedWall) && !(block instanceof net.minecraft.block.BlockFenceGate)) ? ((block.func_149688_o().func_76218_k() && block.func_149686_d()) ? ((block.func_149688_o() != Material.field_151572_C)) : false) : true);
/*     */   }
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_176225_a(IBlockAccess worldIn, BlockPos pos, EnumFacing side) {
/* 125 */     return (side == EnumFacing.DOWN) ? super.func_176225_a(worldIn, pos, side) : true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176221_a(IBlockState state, IBlockAccess worldIn, BlockPos pos) {
/* 134 */     return state.func_177226_a((IProperty)UP, Boolean.valueOf(!worldIn.func_175623_d(pos.func_177984_a()))).func_177226_a((IProperty)NORTH, Boolean.valueOf(canConnectTo(worldIn, pos.func_177978_c()))).func_177226_a((IProperty)EAST, Boolean.valueOf(canConnectTo(worldIn, pos.func_177974_f()))).func_177226_a((IProperty)SOUTH, Boolean.valueOf(canConnectTo(worldIn, pos.func_177968_d()))).func_177226_a((IProperty)WEST, Boolean.valueOf(canConnectTo(worldIn, pos.func_177976_e())));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSideSolid(IBlockAccess world, BlockPos pos, EnumFacing side) {
/* 149 */     return (side == EnumFacing.UP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_180651_a(IBlockState state) {
/* 157 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/* 165 */     return func_176223_P();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/* 173 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockState func_180661_e() {
/* 178 */     return new BlockState(this, new IProperty[] { (IProperty)UP, (IProperty)NORTH, (IProperty)EAST, (IProperty)WEST, (IProperty)SOUTH });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state) {
/* 191 */     return type.equals(this.harvestTool);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/* 198 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 203 */     return this.displayName;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedWall.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */