/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.item.ItemDoor;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemBlockAddedDoor
/*    */   extends ItemDoor
/*    */ {
/*    */   public Block door;
/*    */   
/*    */   public ItemBlockAddedDoor(Block block) {
/* 24 */     super(block);
/* 25 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/* 26 */     this.door = block;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_180614_a(ItemStack stack, EntityPlayer playerIn, World worldIn, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 37 */     if (side != EnumFacing.UP)
/*    */     {
/* 39 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 43 */     IBlockState iblockstate = worldIn.func_180495_p(pos);
/* 44 */     Block block = iblockstate.func_177230_c();
/*    */     
/* 46 */     if (!block.func_176200_f(worldIn, pos))
/*    */     {
/* 48 */       pos = pos.func_177972_a(side);
/*    */     }
/*    */     
/* 51 */     if (!playerIn.func_175151_a(pos, side, stack))
/*    */     {
/* 53 */       return false;
/*    */     }
/* 55 */     if (!this.door.func_176196_c(worldIn, pos))
/*    */     {
/* 57 */       return false;
/*    */     }
/*    */ 
/*    */     
/* 61 */     func_179235_a(worldIn, pos, EnumFacing.func_176733_a(playerIn.field_70177_z), this.door);
/* 62 */     stack.field_77994_a--;
/* 63 */     return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 71 */     if (this.door instanceof BlockAddedDoor) {
/* 72 */       return StatCollector.func_74838_a(((BlockAddedDoor)this.door).displayName).trim();
/*    */     }
/*    */     
/* 75 */     return super.func_77653_i(stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemBlockAddedDoor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */