/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemSlab;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ 
/*    */ public class ItemBlockAddedSlab
/*    */   extends ItemSlab
/*    */ {
/*    */   public ItemBlockAddedSlab(Block block) {
/* 13 */     super(block, ((BlockAddedSlab)block).func_176552_j() ? (BlockAddedSlab)((BlockAddedSlab)block).slab : (BlockAddedSlab)block, ((BlockAddedSlab)block).func_176552_j() ? (BlockAddedSlab)block : (BlockAddedSlab)((BlockAddedSlab)block).full);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 19 */     if (func_179223_d() instanceof BlockAddedSlab) {
/* 20 */       return StatCollector.func_74838_a(((BlockAddedSlab)func_179223_d()).displayName).trim();
/*    */     }
/*    */     
/* 23 */     return super.func_77653_i(stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemBlockAddedSlab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */