/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.ItemRecord;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class ItemAddedRecord
/*    */   extends ItemRecord
/*    */ {
/*    */   public String description;
/*    */   
/*    */   public ItemAddedRecord(String name, String d) {
/* 17 */     super(name);
/* 18 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/* 19 */     this.description = d;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public String func_150927_i() {
/* 26 */     return this.description;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ResourceLocation getRecordResource(String name) {
/* 39 */     return new ResourceLocation("lootplusplus", name);
/*    */   }
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 44 */     return Items.field_151096_cd.func_77653_i(new ItemStack(Items.field_151096_cd));
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */