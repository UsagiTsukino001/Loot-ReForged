/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemBlock;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ public class ItemBlockAdded
/*    */   extends ItemBlock {
/*    */   public ItemBlockAdded(Block block) {
/* 11 */     super(block);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 17 */     if (func_179223_d() instanceof InterfaceBlockAdded) {
/* 18 */       return StatCollector.func_74838_a(((InterfaceBlockAdded)func_179223_d()).getDisplayName(func_179223_d().func_176203_a(stack.func_77960_j()))).trim();
/*    */     }
/*    */     
/* 21 */     return super.func_77653_i(stack);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemBlockAdded.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */