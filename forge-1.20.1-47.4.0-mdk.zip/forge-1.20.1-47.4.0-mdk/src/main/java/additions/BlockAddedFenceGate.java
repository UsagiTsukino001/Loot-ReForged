/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import net.minecraft.block.BlockFenceGate;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockAddedFenceGate extends BlockFenceGate implements InterfaceBlockAdded {
/*     */   public Material field_149764_J;
/*  18 */   public String displayName = "";
/*  19 */   public String harvestTool = "pickaxe";
/*     */   
/*     */   public boolean isOpaque = true;
/*     */   public boolean onlyRedstone = false;
/*     */   
/*     */   public BlockAddedFenceGate(Material material, boolean redstone, boolean opaque, String harvestTool, int harvestLevel, float slip, String display) {
/*  25 */     this.field_149764_J = material;
/*     */     
/*  27 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*     */     
/*  29 */     if (harvestLevel != -1) {
/*  30 */       setHarvestLevel(harvestTool, harvestLevel);
/*     */     }
/*     */     
/*  33 */     func_149713_g(0);
/*  34 */     this.isOpaque = opaque;
/*  35 */     this.harvestTool = harvestTool;
/*  36 */     this.displayName = display;
/*  37 */     this.onlyRedstone = redstone;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176196_c(World worldIn, BlockPos pos) {
/*  42 */     return worldIn.func_180495_p(pos).func_177230_c().func_176200_f(worldIn, pos);
/*     */   }
/*     */ 
/*     */   
/*     */   public Material func_149688_o() {
/*  47 */     return this.field_149764_J;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumFacing side, float hitX, float hitY, float hitZ) {
/*  56 */     if (this.onlyRedstone)
/*     */     {
/*  58 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  62 */     if (((Boolean)state.func_177229_b((IProperty)field_176466_a)).booleanValue()) {
/*     */       
/*  64 */       state = state.func_177226_a((IProperty)field_176466_a, Boolean.valueOf(false));
/*  65 */       worldIn.func_180501_a(pos, state, 2);
/*     */     }
/*     */     else {
/*     */       
/*  69 */       EnumFacing enumfacing1 = EnumFacing.func_176733_a(playerIn.field_70177_z);
/*     */       
/*  71 */       if (state.func_177229_b((IProperty)field_176387_N) == enumfacing1.func_176734_d())
/*     */       {
/*  73 */         state = state.func_177226_a((IProperty)field_176387_N, (Comparable)enumfacing1);
/*     */       }
/*     */       
/*  76 */       state = state.func_177226_a((IProperty)field_176466_a, Boolean.valueOf(true));
/*  77 */       worldIn.func_180501_a(pos, state, 2);
/*     */     } 
/*     */     
/*  80 */     worldIn.func_180498_a(playerIn, ((Boolean)state.func_177229_b((IProperty)field_176466_a)).booleanValue() ? 1003 : 1006, pos, 0);
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/*  89 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state) {
/* 102 */     return type.equals(this.harvestTool);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 107 */     return this.displayName;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedFenceGate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */