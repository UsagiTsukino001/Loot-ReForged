/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.crafting.FurnaceRecipes;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.tileentity.TileEntityFurnace;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileEntityAddedFurnace
/*     */   extends TileEntityFurnace
/*     */ {
/*  24 */   private static final int[] topSlots = new int[] { 0 };
/*  25 */   private static final int[] bottomSlots = new int[] { 2, 1 };
/*  26 */   private static final int[] sideSlots = new int[] { 1 };
/*     */   
/*  28 */   private ItemStack[] storedItems = new ItemStack[3];
/*     */   private String customInventoryName;
/*  30 */   public int trueFurnaceCookTime = 0;
/*  31 */   public int totalFurnaceCookTime = 200;
/*     */   public int field_145956_a;
/*     */   public int furnaceCookTime;
/*     */   public int field_145963_i;
/*     */   
/*     */   public TileEntityAddedFurnace() {
/*  37 */     this("Furnace", 200.0F);
/*     */   }
/*     */   
/*     */   public TileEntityAddedFurnace(String name, float speed) {
/*  41 */     this.customInventoryName = name;
/*  42 */     super.func_145951_a(name);
/*  43 */     this.totalFurnaceCookTime = MathHelper.func_76141_d(200.0F / speed);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_70302_i_() {
/*  51 */     return this.storedItems.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70301_a(int slot) {
/*  59 */     return this.storedItems[slot];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70298_a(int slot, int amount) {
/*  68 */     if (this.storedItems[slot] != null) {
/*     */ 
/*     */ 
/*     */       
/*  72 */       if ((this.storedItems[slot]).field_77994_a <= amount) {
/*     */         
/*  74 */         ItemStack itemStack = this.storedItems[slot];
/*  75 */         this.storedItems[slot] = null;
/*  76 */         return itemStack;
/*     */       } 
/*     */ 
/*     */       
/*  80 */       ItemStack itemstack = this.storedItems[slot].func_77979_a(amount);
/*     */       
/*  82 */       if ((this.storedItems[slot]).field_77994_a == 0)
/*     */       {
/*  84 */         this.storedItems[slot] = null;
/*     */       }
/*     */       
/*  87 */       return itemstack;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70304_b(int slot) {
/* 102 */     if (this.storedItems[slot] != null) {
/*     */       
/* 104 */       ItemStack itemstack = this.storedItems[slot];
/* 105 */       this.storedItems[slot] = null;
/* 106 */       return itemstack;
/*     */     } 
/*     */ 
/*     */     
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70299_a(int slot, ItemStack stack) {
/* 119 */     this.storedItems[slot] = stack;
/*     */     
/* 121 */     if (stack != null && stack.field_77994_a > func_70297_j_())
/*     */     {
/* 123 */       stack.field_77994_a = func_70297_j_();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInventoryName() {
/* 132 */     return hasCustomInventoryName() ? this.customInventoryName : "container.furnace";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCustomInventoryName() {
/* 140 */     return (this.customInventoryName != null && this.customInventoryName.length() > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_145951_a(String name) {
/* 145 */     this.customInventoryName = name;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_145839_a(NBTTagCompound tag) {
/* 150 */     super.func_145839_a(tag);
/* 151 */     NBTTagList nbttaglist = tag.func_150295_c("Items", 10);
/* 152 */     this.storedItems = new ItemStack[func_70302_i_()];
/*     */     
/* 154 */     for (int i = 0; i < nbttaglist.func_74745_c(); i++) {
/*     */       
/* 156 */       NBTTagCompound nbttagcompound1 = nbttaglist.func_150305_b(i);
/* 157 */       byte b0 = nbttagcompound1.func_74771_c("Slot");
/*     */       
/* 159 */       if (b0 >= 0 && b0 < this.storedItems.length)
/*     */       {
/* 161 */         this.storedItems[b0] = ItemStack.func_77949_a(nbttagcompound1);
/*     */       }
/*     */     } 
/*     */     
/* 165 */     this.field_145956_a = tag.func_74765_d("BurnTime");
/* 166 */     this.furnaceCookTime = tag.func_74765_d("CookTime");
/* 167 */     this.trueFurnaceCookTime = tag.func_74762_e("TrueCookTime");
/* 168 */     this.field_145963_i = func_145952_a(this.storedItems[1]);
/* 169 */     this.totalFurnaceCookTime = tag.func_74762_e("SmeltingTime");
/* 170 */     if (tag.func_150297_b("CustomName", 8))
/*     */     {
/* 172 */       this.customInventoryName = tag.func_74779_i("CustomName");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_145841_b(NBTTagCompound tag) {
/* 178 */     super.func_145841_b(tag);
/* 179 */     tag.func_74777_a("BurnTime", (short)this.field_145956_a);
/* 180 */     tag.func_74777_a("CookTime", (short)this.furnaceCookTime);
/* 181 */     tag.func_74768_a("TrueCookTime", this.trueFurnaceCookTime);
/* 182 */     tag.func_74768_a("SmeltingTime", this.totalFurnaceCookTime);
/* 183 */     NBTTagList nbttaglist = new NBTTagList();
/*     */     
/* 185 */     for (int i = 0; i < this.storedItems.length; i++) {
/*     */       
/* 187 */       if (this.storedItems[i] != null) {
/*     */         
/* 189 */         NBTTagCompound nbttagcompound1 = new NBTTagCompound();
/* 190 */         nbttagcompound1.func_74774_a("Slot", (byte)i);
/* 191 */         this.storedItems[i].func_77955_b(nbttagcompound1);
/* 192 */         nbttaglist.func_74742_a((NBTBase)nbttagcompound1);
/*     */       } 
/*     */     } 
/*     */     
/* 196 */     tag.func_74782_a("Items", (NBTBase)nbttaglist);
/*     */     
/* 198 */     if (hasCustomInventoryName())
/*     */     {
/* 200 */       tag.func_74778_a("CustomName", this.customInventoryName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_145950_i() {
/* 234 */     return (this.field_145956_a > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_73660_a() {
/* 239 */     boolean isBurning = func_145950_i();
/* 240 */     boolean flag1 = false;
/*     */     
/* 242 */     if (isBurning)
/*     */     {
/* 244 */       this.field_145956_a--;
/*     */     }
/*     */     
/* 247 */     if (!this.field_145850_b.field_72995_K) {
/*     */       
/* 249 */       if (!isBurning && (this.storedItems[1] == null || this.storedItems[0] == null)) {
/* 250 */         MathHelper.func_76125_a(this.trueFurnaceCookTime, 0, this.totalFurnaceCookTime);
/*     */       }
/*     */       else {
/*     */         
/* 254 */         if (this.field_145956_a == 0 && canSmelt()) {
/*     */           
/* 256 */           this.field_145963_i = this.field_145956_a = func_145952_a(this.storedItems[1]);
/*     */           
/* 258 */           if (this.field_145956_a > 0) {
/*     */             
/* 260 */             flag1 = true;
/*     */             
/* 262 */             if (this.storedItems[1] != null) {
/*     */               
/* 264 */               (this.storedItems[1]).field_77994_a--;
/*     */               
/* 266 */               if ((this.storedItems[1]).field_77994_a == 0)
/*     */               {
/* 268 */                 this.storedItems[1] = this.storedItems[1].func_77973_b().getContainerItem(this.storedItems[1]);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 274 */         if (func_145950_i() && canSmelt()) {
/*     */           
/* 276 */           this.trueFurnaceCookTime++;
/*     */           
/* 278 */           if (this.trueFurnaceCookTime == this.totalFurnaceCookTime)
/*     */           {
/* 280 */             this.trueFurnaceCookTime = 0;
/* 281 */             func_145949_j();
/* 282 */             flag1 = true;
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 287 */           this.trueFurnaceCookTime = 0;
/*     */         } 
/*     */         
/* 290 */         this.furnaceCookTime = this.trueFurnaceCookTime * 200 / this.totalFurnaceCookTime;
/*     */       } 
/*     */       
/* 293 */       if (isBurning != ((this.field_145956_a > 0))) {
/*     */         
/* 295 */         flag1 = true;
/* 296 */         BlockAddedFurnace.setState((this.field_145956_a > 0), this.field_145850_b, this.field_174879_c);
/*     */       } 
/*     */     } 
/*     */     
/* 300 */     if (flag1)
/*     */     {
/* 302 */       func_70296_d();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canSmelt() {
/* 311 */     if (this.storedItems[0] == null)
/*     */     {
/* 313 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 317 */     ItemStack itemstack = FurnaceRecipes.func_77602_a().func_151395_a(this.storedItems[0]);
/* 318 */     if (itemstack == null) return false; 
/* 319 */     if (this.storedItems[2] == null) return true; 
/* 320 */     if (!this.storedItems[2].func_77969_a(itemstack)) return false; 
/* 321 */     int result = (this.storedItems[2]).field_77994_a + itemstack.field_77994_a;
/* 322 */     return (result <= func_70297_j_() && result <= this.storedItems[2].func_77976_d());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_145949_j() {
/* 331 */     if (canSmelt()) {
/*     */       
/* 333 */       ItemStack itemstack = FurnaceRecipes.func_77602_a().func_151395_a(this.storedItems[0]);
/*     */       
/* 335 */       if (this.storedItems[2] == null) {
/*     */         
/* 337 */         this.storedItems[2] = itemstack.func_77946_l();
/*     */       }
/* 339 */       else if (this.storedItems[2].func_77973_b() == itemstack.func_77973_b()) {
/*     */         
/* 341 */         (this.storedItems[2]).field_77994_a += itemstack.field_77994_a;
/*     */       } 
/*     */       
/* 344 */       (this.storedItems[0]).field_77994_a--;
/*     */       
/* 346 */       if ((this.storedItems[0]).field_77994_a <= 0)
/*     */       {
/* 348 */         this.storedItems[0] = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getAccessibleSlotsFromSide(int p_94128_1_) {
/* 359 */     return (p_94128_1_ == 0) ? bottomSlots : ((p_94128_1_ == 1) ? topSlots : sideSlots);
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_174887_a_(int id) {
/* 364 */     switch (id) {
/*     */       
/*     */       case 0:
/* 367 */         return this.field_145956_a;
/*     */       case 1:
/* 369 */         return this.field_145963_i;
/*     */       case 2:
/* 371 */         return this.trueFurnaceCookTime;
/*     */       case 3:
/* 373 */         return this.totalFurnaceCookTime;
/*     */     } 
/* 375 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_174885_b(int id, int value) {
/* 381 */     switch (id) {
/*     */       
/*     */       case 0:
/* 384 */         this.field_145956_a = value;
/*     */         break;
/*     */       case 1:
/* 387 */         this.field_145963_i = value;
/*     */         break;
/*     */       case 2:
/* 390 */         this.trueFurnaceCookTime = value;
/*     */         break;
/*     */       case 3:
/* 393 */         this.totalFurnaceCookTime = value;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\TileEntityAddedFurnace.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */