/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAddedCarpet
/*     */   extends BlockAdded
/*     */ {
/*     */   public BlockAddedCarpet(Material material, int opacity, boolean opaque, boolean isBeaconBase, String harvestTool, int harvestLevel, float slip, String display) {
/*  21 */     super(material, opacity, isBeaconBase, harvestTool, harvestLevel, slip, display);
/*     */     
/*  23 */     this.isOpaque = opaque;
/*  24 */     func_149676_a(0.0F, 0.0F, 0.0F, 1.0F, 0.0625F, 1.0F);
/*  25 */     func_149713_g(0);
/*  26 */     setBlockBoundsFromMeta(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/*  35 */     return false;
/*     */   }
/*     */   
/*     */   public boolean func_149686_d() {
/*  39 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_149683_g() {
/*  47 */     setBlockBoundsFromMeta(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_180654_a(IBlockAccess iba, BlockPos pos) {
/*  56 */     setBlockBoundsFromMeta(0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setBlockBoundsFromMeta(int meta) {
/*  61 */     byte b0 = 0;
/*  62 */     float f = (1 * (1 + b0)) / 16.0F;
/*  63 */     func_149676_a(0.0F, 0.0F, 0.0F, 1.0F, f, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_176196_c(World world, BlockPos pos) {
/*  71 */     return (super.func_176196_c(world, pos) && canBlockStay(world, pos));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onNeighborChange(IBlockAccess world, BlockPos pos, BlockPos neighbour) {
/*  81 */     if (world instanceof World) {
/*  82 */       checkIfBlockCanStay((World)world, pos);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkIfBlockCanStay(World world, BlockPos pos) {
/*  88 */     if (!canBlockStay(world, pos)) {
/*     */       
/*  90 */       func_176226_b(world, pos, world.func_180495_p(pos), 0);
/*  91 */       world.func_175698_g(pos);
/*  92 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canBlockStay(World world, BlockPos pos) {
/* 105 */     return !world.func_175623_d(pos.func_177977_b());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/* 112 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_176225_a(IBlockAccess world, BlockPos pos, EnumFacing side) {
/* 122 */     return (side == EnumFacing.UP) ? true : super.func_176225_a(world, pos, side);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedCarpet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */