/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.item.ItemStack;
/*    */ 
/*    */ public class ItemBlockAddedMultipleMeta
/*    */   extends ItemBlockAdded
/*    */ {
/*    */   public ItemBlockAddedMultipleMeta(Block block) {
/* 10 */     super(block);
/* 11 */     func_77656_e(0);
/* 12 */     func_77627_a(true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_77647_b(int damage) {
/* 21 */     return damage;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77667_c(ItemStack stack) {
/* 30 */     return func_77658_a() + "_" + stack.func_77960_j();
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemBlockAddedMultipleMeta.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */