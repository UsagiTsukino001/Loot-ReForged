/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAdded
/*     */   extends Block
/*     */   implements InterfaceBlockAdded
/*     */ {
/*  22 */   public String displayName = "";
/*     */   public boolean isBeaconBase = false;
/*  24 */   public String harvestTool = "pickaxe";
/*     */   public boolean isOpaque = true;
/*     */   
/*     */   public BlockAdded(Material material, int opacity, boolean isBeaconBase, String harvestTool, int harvestLevel, float slip, String display) {
/*  28 */     super(material);
/*  29 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*     */     
/*  31 */     if (harvestLevel != -1) {
/*  32 */       setHarvestLevel(harvestTool, harvestLevel);
/*     */     }
/*     */     
/*  35 */     if (opacity >= 0) {
/*  36 */       func_149713_g(opacity);
/*  37 */       this.isOpaque = false;
/*     */     } else {
/*     */       
/*  40 */       func_149713_g(255);
/*     */     } 
/*     */     
/*  43 */     this.harvestTool = harvestTool;
/*  44 */     this.field_149765_K = slip;
/*  45 */     this.displayName = display;
/*  46 */     this.isBeaconBase = isBeaconBase;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/*  52 */     return this.isOpaque;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/*  59 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/*  65 */     return this.isOpaque;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_176225_a(IBlockAccess iba, BlockPos pos, EnumFacing side) {
/*  76 */     if (!this.isOpaque) {
/*  77 */       Block block = iba.func_180495_p(pos).func_177230_c();
/*  78 */       return (block != this);
/*     */     } 
/*     */     
/*  81 */     return super.func_176225_a(iba, pos, side);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBeaconBase(IBlockAccess worldObj, BlockPos pos, BlockPos beaconPos) {
/*  89 */     return this.isBeaconBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state) {
/*  99 */     return type.equals(this.harvestTool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHarvestTool(IBlockState state) {
/* 108 */     return this.harvestTool;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 113 */     return this.displayName;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAdded.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */