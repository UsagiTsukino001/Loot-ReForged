/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.block.BlockPane;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.EnumWorldBlockLayer;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ public class BlockAddedPane
/*    */   extends BlockPane
/*    */   implements InterfaceBlockAdded
/*    */ {
/*    */   public String displayName;
/* 17 */   public String harvestTool = "pickaxe";
/*    */   public boolean isOpaque = true;
/*    */   
/*    */   public BlockAddedPane(Material material, boolean opaque, String harvestTool, int harvestLevel, float slip, String display) {
/* 21 */     super(material, true);
/*    */     
/* 23 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*    */     
/* 25 */     if (harvestLevel != -1) {
/* 26 */       setHarvestLevel(harvestTool, harvestLevel);
/*    */     }
/*    */     
/* 29 */     this.isOpaque = opaque;
/*    */     
/* 31 */     func_149713_g(0);
/*    */     
/* 33 */     this.harvestTool = harvestTool;
/* 34 */     this.field_149765_K = slip;
/* 35 */     this.displayName = display;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isToolEffective(String type, int metadata) {
/* 48 */     return type.equals(this.harvestTool);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public EnumWorldBlockLayer func_180664_k() {
/* 55 */     return EnumWorldBlockLayer.TRANSLUCENT;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayName(IBlockState state) {
/* 60 */     return this.displayName;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedPane.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */