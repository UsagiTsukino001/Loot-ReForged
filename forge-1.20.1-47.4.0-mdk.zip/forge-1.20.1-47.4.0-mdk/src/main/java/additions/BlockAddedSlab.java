/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockSlab;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.properties.PropertyEnum;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.util.IStringSerializable;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAddedSlab
/*     */   extends BlockSlab
/*     */   implements InterfaceBlockAdded
/*     */ {
/*  33 */   public static final PropertyEnum VARIANT = PropertyEnum.func_177709_a("variant", EnumType.class);
/*     */   
/*  35 */   public String displayName = "";
/*  36 */   public String harvestTool = "pickaxe";
/*     */   public boolean isOpaque = true;
/*  38 */   public Block slab = (Block)this;
/*  39 */   public Block full = (Block)this;
/*     */   
/*     */   public BlockAddedSlab(Material material, int opacity, String harvestTool, int harvestLevel, float slip, String display) {
/*  42 */     super(material);
/*  43 */     if (!func_176552_j()) {
/*  44 */       func_149647_a(LootPPHelper.tabLootPPAdditions);
/*     */     } else {
/*     */       
/*  47 */       func_149647_a(null);
/*     */     } 
/*     */     
/*  50 */     if (harvestLevel != -1) {
/*  51 */       setHarvestLevel(harvestTool, harvestLevel);
/*     */     }
/*     */     
/*  54 */     if (opacity >= 0) {
/*  55 */       func_149713_g(opacity);
/*  56 */       this.isOpaque = false;
/*     */     } else {
/*     */       
/*  59 */       func_149713_g(255);
/*     */     } 
/*     */     
/*  62 */     IBlockState iblockstate = this.field_176227_L.func_177621_b();
/*  63 */     if (!func_176552_j()) {
/*  64 */       iblockstate = iblockstate.func_177226_a((IProperty)field_176554_a, (Comparable)BlockSlab.EnumBlockHalf.BOTTOM);
/*     */     }
/*  66 */     func_180632_j(iblockstate.func_177226_a((IProperty)VARIANT, EnumType.ALL));
/*     */     
/*  68 */     this.harvestTool = harvestTool;
/*  69 */     this.field_149765_K = slip;
/*  70 */     this.displayName = display;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/*  75 */     return (this.isOpaque && func_176552_j());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/*  82 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/*  87 */     return (this.isOpaque && func_176552_j());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_176225_a(IBlockAccess iba, BlockPos pos, EnumFacing side) {
/*  97 */     if (func_176552_j() && !this.isOpaque) {
/*  98 */       Block block = iba.func_180495_p(pos).func_177230_c();
/*  99 */       return (block != this);
/*     */     } 
/*     */     
/* 102 */     return super.func_176225_a(iba, pos, side);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state) {
/* 115 */     return type.equals(this.harvestTool);
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_150002_b(int p_150002_1_) {
/* 120 */     return this.displayName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public Item func_180665_b(World world, BlockPos pos) {
/* 129 */     return Item.func_150898_a(this.slab);
/*     */   }
/*     */ 
/*     */   
/*     */   public Item func_180660_a(IBlockState state, Random rand, int p_149650_3_) {
/* 134 */     return Item.func_150898_a(this.slab);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 139 */     return this.displayName;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_176552_j() {
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public IProperty func_176551_l() {
/* 149 */     return (IProperty)VARIANT;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object func_176553_a(ItemStack stack) {
/* 154 */     return EnumType.ALL;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockState func_180661_e() {
/* 159 */     return func_176552_j() ? new BlockState((Block)this, new IProperty[] { (IProperty)VARIANT }) : new BlockState((Block)this, new IProperty[] { (IProperty)VARIANT, (IProperty)field_176554_a });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/* 167 */     IBlockState iblockstate = func_176223_P();
/*     */     
/* 169 */     if (!func_176552_j())
/*     */     {
/* 171 */       iblockstate = iblockstate.func_177226_a((IProperty)field_176554_a, ((meta & 0x8) == 0) ? (Comparable)BlockSlab.EnumBlockHalf.BOTTOM : (Comparable)BlockSlab.EnumBlockHalf.TOP);
/*     */     }
/*     */     
/* 174 */     return iblockstate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/* 182 */     int i = 0;
/*     */     
/* 184 */     if (!func_176552_j() && state.func_177229_b((IProperty)field_176554_a) == BlockSlab.EnumBlockHalf.TOP)
/*     */     {
/* 186 */       i = 8;
/*     */     }
/*     */     
/* 189 */     return i;
/*     */   }
/*     */   
/*     */   public enum EnumType
/*     */     implements IStringSerializable {
/* 194 */     ALL("all");
/*     */     
/*     */     private final String name;
/*     */     
/*     */     EnumType(String nameToSet) {
/* 199 */       this.name = nameToSet;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 204 */       return this.name;
/*     */     }
/*     */ 
/*     */     
/*     */     public String func_176610_l() {
/* 209 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedSlab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */