/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.resources.model.ModelResourceLocation;
/*     */ import net.minecraft.enchantment.Enchantment;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.entity.projectile.EntityArrow;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemBow;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.nbt.NBTTagList;
/*     */ import net.minecraft.util.AxisAlignedBB;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.entity.player.ArrowLooseEvent;
/*     */ import net.minecraftforge.event.entity.player.ArrowNockEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemAddedBow
/*     */   extends ItemBow
/*     */ {
/*  39 */   public static final DecimalFormat DECIMALFORMAT = new DecimalFormat("#.###");
/*     */   
/*  41 */   public String displayName = "";
/*  42 */   public float baseDamage = 0.0F;
/*  43 */   public int drawTime = 20;
/*  44 */   public int arrowCount = 1;
/*  45 */   public int enchantability = 1;
/*     */   
/*     */   public ItemStack repairStack;
/*     */   public Item ammoItem;
/*     */   public String shootingSound;
/*     */   
/*     */   public ItemAddedBow(String display, float damage, int time, int durability, int arrows, int enchant, ItemStack repairItem, Item ammo, String sound) {
/*  52 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/*  53 */     func_77656_e(durability);
/*  54 */     this.baseDamage = damage;
/*  55 */     this.drawTime = time;
/*  56 */     this.arrowCount = arrows;
/*  57 */     this.enchantability = enchant;
/*  58 */     this.repairStack = repairItem;
/*  59 */     this.displayName = display;
/*  60 */     this.ammoItem = ammo;
/*  61 */     this.shootingSound = sound;
/*     */   }
/*     */   
/*     */   public int getDrawTime(ItemStack stack) {
/*  65 */     int time = this.drawTime;
/*     */     
/*  67 */     if (stack == null || stack.func_77978_p() == null || !stack.func_77978_p().func_74764_b("ench")) {
/*  68 */       return this.drawTime;
/*     */     }
/*     */     
/*  71 */     NBTTagList enchList = stack.func_77978_p().func_150295_c("ench", 10);
/*     */     
/*  73 */     int size = enchList.func_74745_c();
/*  74 */     for (int i = 0; i < size; i++) {
/*  75 */       NBTTagCompound tag = enchList.func_150305_b(i);
/*     */       
/*  77 */       int id = tag.func_74762_e("id");
/*  78 */       Enchantment enchant = Enchantment.func_180306_c(id);
/*  79 */       if (LootPPHelper.isQuickdraw(enchant)) {
/*  80 */         int lvl = tag.func_74762_e("lvl");
/*     */         
/*  82 */         if (lvl > 0) {
/*  83 */           time = time / 2 + time / 2 * (lvl + 1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  88 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_77653_i(ItemStack stack) {
/*  94 */     return StatCollector.func_74838_a(this.displayName).trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_77624_a(ItemStack stack, EntityPlayer playerIn, List<String> tooltip, boolean advanced) {
/* 105 */     tooltip.add("");
/*     */     
/* 107 */     tooltip.add(EnumChatFormatting.BLUE + "+" + DECIMALFORMAT.format((getDrawTime(stack) / 20.0F)) + StatCollector.func_74838_a("bow.info.drawtime"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_77615_a(ItemStack stack, World world, EntityPlayer player, int amountDrawn) {
/* 116 */     if (!world.field_72995_K) {
/* 117 */       int j = func_77626_a(stack) - amountDrawn;
/* 118 */       boolean shouldContinue = true;
/* 119 */       boolean flag = (player.field_71075_bZ.field_75098_d || this.arrowCount == 0 || EnchantmentHelper.func_77506_a(Enchantment.field_77342_w.field_77352_x, stack) > 0);
/*     */       
/* 121 */       if (this.ammoItem == Items.field_151032_g) {
/* 122 */         for (int i = 0; i < this.arrowCount; i++) {
/* 123 */           ArrowLooseEvent event = new ArrowLooseEvent(player, stack, j);
/*     */           
/* 125 */           MinecraftForge.EVENT_BUS.post((Event)event);
/*     */           
/* 127 */           if (event.isCanceled())
/*     */           {
/* 129 */             shouldContinue = false;
/*     */           }
/*     */           
/* 132 */           j = event.charge;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 137 */       if (shouldContinue && (flag || player.field_71071_by.func_146028_b(this.ammoItem))) {
/*     */         
/* 139 */         float drawAmount = j / getDrawTime(stack);
/* 140 */         drawAmount = (drawAmount * drawAmount + drawAmount * 2.0F) / 3.0F;
/*     */         
/* 142 */         if (drawAmount < 0.1D) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 147 */         if (drawAmount > 1.0F)
/*     */         {
/* 149 */           drawAmount = 1.0F;
/*     */         }
/*     */ 
/*     */         
/* 153 */         int power = EnchantmentHelper.func_77506_a(Enchantment.field_77345_t.field_77352_x, stack);
/* 154 */         int punch = EnchantmentHelper.func_77506_a(Enchantment.field_77344_u.field_77352_x, stack);
/*     */         
/* 156 */         for (int i = 0; i < ((this.arrowCount < 1) ? 1 : this.arrowCount) && (flag || player.field_71071_by.func_146028_b(this.ammoItem)); i++) {
/* 157 */           if (this.ammoItem == Items.field_151032_g) {
/* 158 */             EntityArrow entityarrow = new EntityArrow(world, (EntityLivingBase)player, drawAmount * 2.0F);
/*     */             
/* 160 */             int disp = i % 4;
/* 161 */             entityarrow.field_70163_u += 0.25D * disp;
/*     */             
/* 163 */             if (drawAmount == 1.0F)
/*     */             {
/* 165 */               entityarrow.func_70243_d(true);
/*     */             }
/*     */             
/* 168 */             if (power > 0)
/*     */             {
/* 170 */               entityarrow.func_70239_b(entityarrow.func_70242_d() + power * 0.5D + 0.5D);
/*     */             }
/*     */             
/* 173 */             if (punch > 0)
/*     */             {
/* 175 */               entityarrow.func_70240_a(punch);
/*     */             }
/*     */             
/* 178 */             if (EnchantmentHelper.func_77506_a(Enchantment.field_77343_v.field_77352_x, stack) > 0)
/*     */             {
/* 180 */               entityarrow.func_70015_d(100);
/*     */             }
/*     */             
/* 183 */             if (flag) {
/*     */               
/* 185 */               entityarrow.field_70251_a = 2;
/*     */             }
/*     */             else {
/*     */               
/* 189 */               player.field_71071_by.func_146026_a(Items.field_151032_g);
/*     */             } 
/*     */             
/* 192 */             if (!world.field_72995_K)
/*     */             {
/* 194 */               world.func_72838_d((Entity)entityarrow);
/*     */             }
/*     */           }
/* 197 */           else if (this.ammoItem instanceof ItemAddedThrowable) {
/* 198 */             if (!flag) {
/* 199 */               player.field_71071_by.func_146026_a(this.ammoItem);
/*     */             }
/*     */             
/* 202 */             if (!world.field_72995_K) {
/*     */               
/* 204 */               EntityAddedThrownItem.nextVelocity = ((ItemAddedThrowable)this.ammoItem).velocity * drawAmount * 2.0F;
/* 205 */               EntityAddedThrownItem thrown = new EntityAddedThrownItem(world, (EntityLivingBase)player, (ItemAddedThrowable)this.ammoItem);
/*     */               
/* 207 */               if (drawAmount == 1.0F)
/*     */               {
/*     */                 
/* 210 */                 thrown.damage = (float)(thrown.damage * 1.5D);
/*     */               }
/*     */               
/* 213 */               if (power > 0 && thrown.damage > 0.0F) {
/* 214 */                 thrown.damage += power * 0.5F + 0.5F;
/*     */               }
/*     */               
/* 217 */               if (punch > 0) {
/* 218 */                 thrown.punch = punch;
/*     */               }
/*     */               
/* 221 */               world.func_72838_d((Entity)thrown);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 226 */         stack.func_77972_a(1, (EntityLivingBase)player);
/* 227 */         world.func_72956_a((Entity)player, this.shootingSound, 1.0F, 1.0F / (field_77697_d.nextFloat() * 0.4F + 1.2F) + drawAmount * 0.5F);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 233 */     double xPos = player.field_70165_t - (MathHelper.func_76134_b(player.field_70177_z / 180.0F * 3.1415927F) * 0.16F);
/* 234 */     double yPos = player.field_70163_u + player.func_70047_e() - 0.10000000149011612D;
/* 235 */     double zPos = player.field_70161_v - (MathHelper.func_76126_a(player.field_70177_z / 180.0F * 3.1415927F) * 0.16F);
/*     */     
/* 237 */     if (this.ammoItem == Items.field_151032_g) {
/* 238 */       List<EntityArrow> arrowList = world.func_72872_a(EntityArrow.class, new AxisAlignedBB(xPos - 1.0D, yPos - 1.0D, zPos - 1.0D, xPos + 1.0D, yPos + 1.5D, zPos + 1.0D));
/*     */       
/* 240 */       for (EntityArrow arrow : arrowList) {
/* 241 */         arrow.func_70239_b(arrow.func_70242_d() + this.baseDamage);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77659_a(ItemStack stack, World world, EntityPlayer player) {
/* 251 */     if (this.ammoItem == Items.field_151032_g) {
/* 252 */       ArrowNockEvent event = new ArrowNockEvent(player, stack);
/* 253 */       if (MinecraftForge.EVENT_BUS.post((Event)event)) return event.result;
/*     */     
/*     */     } 
/* 256 */     if (player.field_71075_bZ.field_75098_d || player.field_71071_by.func_146028_b(this.ammoItem) || this.arrowCount == 0 || EnchantmentHelper.func_77506_a(Enchantment.field_77342_w.field_77352_x, stack) > 0)
/*     */     {
/* 258 */       player.func_71008_a(stack, func_77626_a(stack));
/*     */     }
/*     */     
/* 261 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_77619_b() {
/* 270 */     return this.enchantability;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public ModelResourceLocation getModel(ItemStack stack, EntityPlayer player, int useRemaining) {
/* 284 */     if (player.func_71011_bu() != null && stack != null && stack.func_77973_b() == this) {
/*     */       
/* 286 */       int i = stack.func_77988_m() - player.func_71052_bv();
/*     */       
/* 288 */       if (i >= getDrawTime(stack))
/*     */       {
/* 290 */         return new ModelResourceLocation(getName() + "_pulling_2", "inventory");
/*     */       }
/* 292 */       if (i > getDrawTime(stack) * 2 / 3)
/*     */       {
/* 294 */         return new ModelResourceLocation(getName() + "_pulling_1", "inventory");
/*     */       }
/* 296 */       if (i > 0)
/*     */       {
/* 298 */         return new ModelResourceLocation(getName() + "_pulling_0", "inventory");
/*     */       }
/*     */     } 
/*     */     
/* 302 */     return null;
/*     */   }
/*     */   
/*     */   private String getName() {
/* 306 */     return "lootplusplus:" + func_77658_a().substring(func_77658_a().indexOf(".") + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_82789_a(ItemStack toRepair, ItemStack repairMaterial) {
/* 314 */     return (this.repairStack != null && repairMaterial != null && this.repairStack.func_77973_b() == repairMaterial.func_77973_b() && (this.repairStack.func_77952_i() == 32767 || this.repairStack.func_77952_i() == repairMaterial.func_77952_i()));
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedBow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */