/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.block.BlockButton;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.util.EnumWorldBlockLayer;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ public class BlockAddedButton
/*    */   extends BlockButton
/*    */   implements InterfaceBlockAdded {
/* 14 */   public String displayName = "";
/* 15 */   public String harvestTool = "pickaxe";
/*    */   public boolean isOpaque = true;
/* 17 */   public int tickRate = 20;
/*    */   
/*    */   public BlockAddedButton(boolean arrowsTrigger, boolean opaque, int tickRate, String harvestTool, int harvestLevel, String display) {
/* 20 */     super(arrowsTrigger);
/*    */     
/* 22 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*    */     
/* 24 */     if (harvestLevel != -1) {
/* 25 */       setHarvestLevel(harvestTool, harvestLevel);
/*    */     }
/*    */     
/* 28 */     func_149713_g(0);
/* 29 */     this.isOpaque = opaque;
/* 30 */     this.harvestTool = harvestTool;
/* 31 */     this.displayName = display;
/* 32 */     this.tickRate = tickRate;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_149738_a(World p_149738_1_) {
/* 40 */     return this.tickRate;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public EnumWorldBlockLayer func_180664_k() {
/* 47 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isToolEffective(String type, IBlockState state) {
/* 61 */     return type.equals(this.harvestTool);
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayName(IBlockState state) {
/* 66 */     return this.displayName;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */