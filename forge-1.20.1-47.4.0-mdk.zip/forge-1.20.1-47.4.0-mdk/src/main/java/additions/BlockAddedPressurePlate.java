/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.BlockPressurePlate;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.item.EntityItem;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockAddedPressurePlate
/*     */   extends BlockPressurePlate
/*     */   implements InterfaceBlockAdded
/*     */ {
/*  26 */   public String displayName = "";
/*  27 */   public int entitiesForFull = 1;
/*  28 */   public int tickRate = 10;
/*  29 */   public String field_150069_a = "everything";
/*  30 */   public String harvestTool = "pickaxe";
/*     */   public boolean isOpaque = true;
/*     */   
/*     */   public BlockAddedPressurePlate(Material material, String sensitivity, int tick, int weight, boolean opaque, String harvestTool, int harvestLevel, String display) {
/*  34 */     super(material, BlockPressurePlate.Sensitivity.EVERYTHING);
/*     */     
/*  36 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*     */     
/*  38 */     if (harvestLevel != -1) {
/*  39 */       setHarvestLevel(harvestTool, harvestLevel);
/*     */     }
/*     */     
/*  42 */     func_149713_g(0);
/*  43 */     this.isOpaque = opaque;
/*  44 */     this.harvestTool = harvestTool;
/*  45 */     this.displayName = display;
/*  46 */     this.tickRate = tick;
/*  47 */     this.entitiesForFull = weight;
/*  48 */     this.field_150069_a = sensitivity;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int func_180669_e(World world, BlockPos pos) {
/*  53 */     List list = null;
/*     */     
/*  55 */     if (this.field_150069_a.equals("everything"))
/*     */     {
/*  57 */       list = world.func_72839_b((Entity)null, func_180667_a(pos));
/*     */     }
/*     */     
/*  60 */     if (this.field_150069_a.equals("mobs"))
/*     */     {
/*  62 */       list = world.func_72872_a(EntityLivingBase.class, func_180667_a(pos));
/*     */     }
/*     */     
/*  65 */     if (this.field_150069_a.equals("players"))
/*     */     {
/*  67 */       list = world.func_72872_a(EntityPlayer.class, func_180667_a(pos));
/*     */     }
/*     */     
/*  70 */     if (this.field_150069_a.equals("items"))
/*     */     {
/*  72 */       list = world.func_72872_a(EntityItem.class, func_180667_a(pos));
/*     */     }
/*     */     
/*  75 */     int entitiesFound = 0;
/*     */     
/*  77 */     if (list != null && !list.isEmpty()) {
/*     */       
/*  79 */       Iterator<Entity> iterator = list.iterator();
/*     */       
/*  81 */       while (iterator.hasNext()) {
/*     */         
/*  83 */         Entity entity = iterator.next();
/*     */         
/*  85 */         if (!entity.func_145773_az())
/*     */         {
/*  87 */           entitiesFound++;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  92 */     if (entitiesFound <= 0)
/*     */     {
/*  94 */       return 0;
/*     */     }
/*     */ 
/*     */     
/*  98 */     float f = Math.min(this.entitiesForFull, entitiesFound) / this.entitiesForFull;
/*  99 */     return MathHelper.func_76123_f(f * 15.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_149738_a(World p_149738_1_) {
/* 108 */     return this.tickRate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToolEffective(String type, int metadata) {
/* 121 */     return type.equals(this.harvestTool);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/* 128 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 133 */     return this.displayName;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedPressurePlate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */