/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockRotatedPillar;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.BlockState;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockAddedPillar
/*     */   extends BlockRotatedPillar
/*     */   implements InterfaceBlockAdded {
/*  24 */   public String displayName = "";
/*     */   public boolean isBeaconBase = false;
/*  26 */   public String harvestTool = "pickaxe";
/*     */   public boolean isOpaque = true;
/*     */   
/*     */   public BlockAddedPillar(Material material, int opacity, boolean isBeaconBase, String harvestTool, int harvestLevel, float slip, String display) {
/*  30 */     super(material);
/*  31 */     func_149647_a(LootPPHelper.tabLootPPAdditions);
/*     */     
/*  33 */     if (harvestLevel != -1) {
/*  34 */       setHarvestLevel(harvestTool, harvestLevel);
/*     */     }
/*     */     
/*  37 */     if (opacity >= 0) {
/*  38 */       func_149713_g(opacity);
/*  39 */       this.isOpaque = false;
/*     */     } else {
/*     */       
/*  42 */       func_149713_g(255);
/*     */     } 
/*     */     
/*  45 */     this.harvestTool = harvestTool;
/*  46 */     this.field_149765_K = slip;
/*  47 */     this.displayName = display;
/*  48 */     this.isBeaconBase = isBeaconBase;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_149662_c() {
/*  53 */     return this.isOpaque;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/*  60 */     return this.isOpaque ? EnumWorldBlockLayer.SOLID : EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_149686_d() {
/*  66 */     return this.isOpaque;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public boolean func_176225_a(IBlockAccess iba, BlockPos pos, EnumFacing side) {
/*  76 */     if (!this.isOpaque) {
/*  77 */       Block block = iba.func_180495_p(pos).func_177230_c();
/*  78 */       return (block != this);
/*     */     } 
/*     */     
/*  81 */     return super.func_176225_a(iba, pos, side);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBeaconBase(IBlockAccess worldObj, BlockPos pos, BlockPos beaconPos) {
/*  88 */     return this.isBeaconBase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isToolEffective(String type, IBlockState state) {
/* 101 */     return type.equals(this.harvestTool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IBlockState func_176203_a(int meta) {
/* 109 */     EnumFacing.Axis axis = EnumFacing.Axis.Y;
/* 110 */     int j = meta & 0xC;
/*     */     
/* 112 */     if (j == 4) {
/*     */       
/* 114 */       axis = EnumFacing.Axis.X;
/*     */     }
/* 116 */     else if (j == 8) {
/*     */       
/* 118 */       axis = EnumFacing.Axis.Z;
/*     */     } 
/*     */     
/* 121 */     return func_176223_P().func_177226_a((IProperty)field_176298_M, (Comparable)axis);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_176201_c(IBlockState state) {
/* 129 */     int i = 0;
/* 130 */     EnumFacing.Axis axis = (EnumFacing.Axis)state.func_177229_b((IProperty)field_176298_M);
/*     */     
/* 132 */     if (axis == EnumFacing.Axis.X) {
/*     */       
/* 134 */       i |= 0x4;
/*     */     }
/* 136 */     else if (axis == EnumFacing.Axis.Z) {
/*     */       
/* 138 */       i |= 0x8;
/*     */     } 
/*     */     
/* 141 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   protected BlockState func_180661_e() {
/* 146 */     return new BlockState((Block)this, new IProperty[] { (IProperty)field_176298_M });
/*     */   }
/*     */ 
/*     */   
/*     */   protected ItemStack func_180643_i(IBlockState state) {
/* 151 */     return new ItemStack(Item.func_150898_a((Block)this), 1, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public IBlockState func_180642_a(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
/* 156 */     return super.func_180642_a(worldIn, pos, facing, hitX, hitY, hitZ, meta, placer).func_177226_a((IProperty)field_176298_M, (Comparable)facing.func_176740_k());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canSustainLeaves(IBlockAccess world, BlockPos pos) {
/* 162 */     return (func_149688_o() == Material.field_151575_d);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWood(IBlockAccess world, BlockPos pos) {
/* 168 */     return (func_149688_o() == Material.field_151575_d);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 173 */     return this.displayName;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedPillar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */