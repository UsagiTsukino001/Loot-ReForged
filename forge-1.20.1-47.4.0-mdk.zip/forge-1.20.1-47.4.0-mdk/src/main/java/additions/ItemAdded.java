/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.StatCollector;
/*    */ import net.minecraftforge.fml.relauncher.Side;
/*    */ import net.minecraftforge.fml.relauncher.SideOnly;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemAdded
/*    */   extends Item
/*    */ {
/*    */   public String displayName;
/*    */   public boolean shines;
/*    */   
/*    */   public ItemAdded(boolean shiny, String display) {
/* 19 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/* 20 */     this.displayName = display;
/* 21 */     this.shines = shiny;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @SideOnly(Side.CLIENT)
/*    */   public boolean func_77636_d(ItemStack stack) {
/* 28 */     return this.shines ? true : super.func_77636_d(stack);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 34 */     return StatCollector.func_74838_a(this.displayName).trim();
/*    */   }
/*    */   
/*    */   public static boolean isToolRepairable(ItemStack stack, ItemStack repairingWith, Item.ToolMaterial material) {
/* 38 */     ItemStack repairingWild = repairingWith.func_77946_l();
/* 39 */     repairingWild.func_77964_b(32767);
/* 40 */     return (material == LootPPHelper.addedToolMaterials.get(repairingWith) || material == LootPPHelper.addedToolMaterials.get(repairingWild) || stack.func_77973_b() == repairingWith.func_77973_b());
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAdded.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */