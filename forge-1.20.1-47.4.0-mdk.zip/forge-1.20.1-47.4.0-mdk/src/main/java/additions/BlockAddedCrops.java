/*     */ package com.tmtravlr.lootplusplus.additions;
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.TreeMap;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.BlockCrops;
/*     */ import net.minecraft.block.properties.IProperty;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumWorldBlockLayer;
/*     */ import net.minecraft.world.IBlockAccess;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.EnumPlantType;
/*     */ import net.minecraftforge.common.IPlantable;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ public class BlockAddedCrops extends BlockCrops implements InterfaceBlockAdded {
/*  27 */   public static TreeMap<ItemStack, BlockAddedCrops> itemToCrop = new TreeMap<ItemStack, BlockAddedCrops>(LootPPHelper.stackComparatorWild);
/*     */   
/*     */   public static boolean rightClickHarvesting = false;
/*     */   
/*  31 */   public String displayName = "";
/*  32 */   public ItemStack seedItem = new ItemStack(Items.field_151014_N);
/*     */   
/*     */   public boolean canBonemeal = true;
/*     */   public boolean nether = false;
/*     */   public boolean rightClickHarvest = false;
/*     */   
/*     */   public BlockAddedCrops(ItemStack seed, boolean bonemeal, boolean netherPlant, boolean rightClick, String display) {
/*  39 */     this.displayName = display;
/*  40 */     this.seedItem = seed;
/*  41 */     this.canBonemeal = bonemeal;
/*  42 */     this.nether = netherPlant;
/*  43 */     this.rightClickHarvest = rightClick;
/*     */     
/*  45 */     itemToCrop.put(seed, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EnumPlantType getPlantType(IBlockAccess world, BlockPos pos) {
/*  53 */     return this.nether ? EnumPlantType.Nether : EnumPlantType.Crop;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean func_149854_a(Block ground) {
/*  61 */     return this.nether ? ((ground == Blocks.field_150425_aM)) : ((ground == Blocks.field_150458_ak));
/*     */   }
/*     */ 
/*     */   
/*     */   public Item func_149866_i() {
/*  66 */     return this.seedItem.func_77973_b();
/*     */   }
/*     */ 
/*     */   
/*     */   protected Item func_149865_P() {
/*  71 */     return func_149866_i();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_180651_a(IBlockState state) {
/*  79 */     return (this.seedItem.func_77952_i() == 32767) ? 0 : this.seedItem.func_77952_i();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<ItemStack> getDrops(IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
/*  85 */     List<ItemStack> ret = new ArrayList<ItemStack>();
/*     */     
/*  87 */     Random rand = (world instanceof World) ? ((World)world).field_73012_v : RANDOM;
/*  88 */     int age = ((Integer)state.func_177229_b((IProperty)field_176488_a)).intValue();
/*  89 */     int count = func_149745_a(rand);
/*     */     
/*  91 */     for (int i = 0; i < count; i++)
/*     */     {
/*  93 */       ret.add(new ItemStack(func_149866_i(), 1, func_180651_a(state)));
/*     */     }
/*     */ 
/*     */     
/*  97 */     if (age >= 7) {
/*     */       
/*  99 */       int k = 3 + fortune;
/*     */       
/* 101 */       for (int j = 0; j < 3 + fortune; j++) {
/*     */         
/* 103 */         if (rand.nextBoolean())
/*     */         {
/* 105 */           ret.add(new ItemStack(func_149866_i(), 1, func_180651_a(state)));
/*     */         }
/*     */       } 
/*     */     } 
/* 109 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_180670_a(World worldIn, Random rand, BlockPos pos, IBlockState state) {
/* 114 */     return this.canBonemeal;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_180650_b(World worldIn, BlockPos pos, IBlockState state, Random rand) {
/* 119 */     super.func_180650_b(worldIn, pos, state, rand);
/*     */     
/* 121 */     if (worldIn.func_175671_l(pos.func_177984_a()) >= (this.nether ? 0 : 9)) {
/*     */       
/* 123 */       int i = ((Integer)state.func_177229_b((IProperty)field_176488_a)).intValue();
/*     */       
/* 125 */       if (i < 7) {
/*     */         
/* 127 */         float f = func_180672_a((Block)this, worldIn, pos);
/*     */         
/* 129 */         if (rand.nextInt((int)(25.0F / f) + 1) == 0)
/*     */         {
/* 131 */           worldIn.func_180501_a(pos, state.func_177226_a((IProperty)field_176488_a, Integer.valueOf(i + 1)), 2);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_180671_f(World worldIn, BlockPos pos, IBlockState state) {
/* 139 */     return ((worldIn.func_175699_k(pos) >= (this.nether ? 0 : 8) || worldIn.func_175678_i(pos)) && worldIn.func_180495_p(pos.func_177977_b()).func_177230_c().canSustainPlant((IBlockAccess)worldIn, pos.func_177977_b(), EnumFacing.UP, (IPlantable)this));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_180639_a(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 144 */     if (!this.rightClickHarvest || ((Integer)state.func_177229_b((IProperty)field_176488_a)).intValue() < 7) {
/* 145 */       return false;
/*     */     }
/*     */     
/* 148 */     if (world.field_72995_K)
/*     */     {
/* 150 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 154 */     rightClickHarvesting = true;
/* 155 */     func_180657_a(world, player, pos, state, null);
/* 156 */     rightClickHarvesting = false;
/* 157 */     world.func_175656_a(pos, func_176223_P());
/* 158 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public EnumWorldBlockLayer func_180664_k() {
/* 166 */     return EnumWorldBlockLayer.TRANSLUCENT;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDisplayName(IBlockState state) {
/* 172 */     return this.displayName;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\BlockAddedCrops.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */