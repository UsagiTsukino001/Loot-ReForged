/*    */ package com.tmtravlr.lootplusplus.additions;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemSpade;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.StatCollector;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemAddedShovel
/*    */   extends ItemSpade
/*    */ {
/*    */   public String displayName;
/*    */   
/*    */   public ItemAddedShovel(Item.ToolMaterial material, String display) {
/* 17 */     super(material);
/* 18 */     func_77637_a(LootPPHelper.tabLootPPAdditions);
/* 19 */     this.displayName = display;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String func_77653_i(ItemStack stack) {
/* 25 */     return StatCollector.func_74838_a(this.displayName).trim();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_82789_a(ItemStack tool, ItemStack materialStack) {
/* 33 */     return ItemAdded.isToolRepairable(tool, materialStack, this.field_77862_b);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\additions\ItemAddedShovel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */