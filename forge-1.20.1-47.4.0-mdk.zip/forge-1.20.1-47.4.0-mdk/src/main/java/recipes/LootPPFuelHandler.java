/*    */ package com.tmtravlr.lootplusplus.recipes;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*    */ import java.util.TreeMap;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraftforge.fml.common.IFuelHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LootPPFuelHandler
/*    */   implements IFuelHandler
/*    */ {
/* 19 */   public TreeMap<ItemStack, Integer> fuelMap = new TreeMap<ItemStack, Integer>(LootPPHelper.stackComparatorWild);
/*    */ 
/*    */   
/*    */   public int getBurnTime(ItemStack fuel) {
/* 23 */     if (this.fuelMap.containsKey(fuel)) {
/* 24 */       return ((Integer)this.fuelMap.get(fuel)).intValue();
/*    */     }
/* 26 */     return 0;
/*    */   }
/*    */   
/*    */   public void addFuel(ItemStack fuel, int duration) {
/* 30 */     this.fuelMap.put(fuel, Integer.valueOf(duration));
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\recipes\LootPPFuelHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */