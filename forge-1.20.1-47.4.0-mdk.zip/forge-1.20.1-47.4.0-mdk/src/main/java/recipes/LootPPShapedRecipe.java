/*     */ package com.tmtravlr.lootplusplus.recipes;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.inventory.InventoryCrafting;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.ForgeHooks;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ import net.minecraftforge.oredict.ShapedOreRecipe;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LootPPShapedRecipe
/*     */   extends ShapedOreRecipe
/*     */ {
/*     */   private static final int MAX_CRAFT_GRID_WIDTH = 3;
/*     */   private static final int MAX_CRAFT_GRID_HEIGHT = 3;
/*  32 */   private ItemStack output = null;
/*  33 */   private Object[] input = null;
/*  34 */   private int width = 0;
/*  35 */   private int height = 0;
/*     */   private boolean mirrored = true;
/*     */   
/*  38 */   public LootPPShapedRecipe(Block result, Object... recipe) { this(new ItemStack(result), recipe); } public LootPPShapedRecipe(Item result, Object... recipe) {
/*  39 */     this(new ItemStack(result), recipe);
/*     */   }
/*     */   public LootPPShapedRecipe(ItemStack result, Object... recipe) {
/*  42 */     super(result, recipe);
/*  43 */     this.output = result.func_77946_l();
/*     */     
/*  45 */     String shape = "";
/*  46 */     int idx = 0;
/*     */     
/*  48 */     if (recipe[idx] instanceof Boolean) {
/*     */       
/*  50 */       this.mirrored = ((Boolean)recipe[idx]).booleanValue();
/*  51 */       if (recipe[idx + 1] instanceof Object[]) {
/*     */         
/*  53 */         recipe = (Object[])recipe[idx + 1];
/*     */       }
/*     */       else {
/*     */         
/*  57 */         idx = 1;
/*     */       } 
/*     */     } 
/*     */     
/*  61 */     if (recipe[idx] instanceof String[]) {
/*     */       
/*  63 */       String[] parts = (String[])recipe[idx++];
/*     */       
/*  65 */       for (String s : parts) {
/*     */         
/*  67 */         this.width = s.length();
/*  68 */         shape = shape + s;
/*     */       } 
/*     */       
/*  71 */       this.height = parts.length;
/*     */     }
/*     */     else {
/*     */       
/*  75 */       while (recipe[idx] instanceof String) {
/*     */         
/*  77 */         String s = (String)recipe[idx++];
/*  78 */         shape = shape + s;
/*  79 */         this.width = s.length();
/*  80 */         this.height++;
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     if (this.width * this.height != shape.length()) {
/*     */       
/*  86 */       String ret = "Invalid shaped ore recipe: ";
/*  87 */       for (Object tmp : recipe)
/*     */       {
/*  89 */         ret = ret + tmp + ", ";
/*     */       }
/*  91 */       ret = ret + this.output;
/*  92 */       throw new RuntimeException(ret);
/*     */     } 
/*     */     
/*  95 */     HashMap<Character, Object> itemMap = new HashMap<Character, Object>();
/*     */     
/*  97 */     for (; idx < recipe.length; idx += 2) {
/*     */       
/*  99 */       Character chr = (Character)recipe[idx];
/* 100 */       Object in = recipe[idx + 1];
/*     */       
/* 102 */       if (in instanceof ItemStack) {
/*     */         
/* 104 */         itemMap.put(chr, ((ItemStack)in).func_77946_l());
/*     */       }
/* 106 */       else if (in instanceof Item) {
/*     */         
/* 108 */         itemMap.put(chr, new ItemStack((Item)in));
/*     */       }
/* 110 */       else if (in instanceof Block) {
/*     */         
/* 112 */         itemMap.put(chr, new ItemStack((Block)in, 1, 32767));
/*     */       }
/* 114 */       else if (in instanceof String) {
/*     */         
/* 116 */         itemMap.put(chr, OreDictionary.getOres((String)in));
/*     */       }
/*     */       else {
/*     */         
/* 120 */         String ret = "Invalid shaped ore recipe: ";
/* 121 */         for (Object tmp : recipe)
/*     */         {
/* 123 */           ret = ret + tmp + ", ";
/*     */         }
/* 125 */         ret = ret + this.output;
/* 126 */         throw new RuntimeException(ret);
/*     */       } 
/*     */     } 
/*     */     
/* 130 */     this.input = new Object[this.width * this.height];
/* 131 */     int x = 0;
/* 132 */     for (char chr : shape.toCharArray())
/*     */     {
/* 134 */       this.input[x++] = itemMap.get(Character.valueOf(chr));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77572_b(InventoryCrafting var1) {
/* 142 */     return this.output.func_77946_l();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_77570_a() {
/* 148 */     return this.input.length;
/*     */   }
/*     */   public ItemStack func_77571_b() {
/* 151 */     return this.output;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_77569_a(InventoryCrafting inv, World world) {
/* 159 */     for (int x = 0; x <= 3 - this.width; x++) {
/*     */       
/* 161 */       for (int y = 0; y <= 3 - this.height; y++) {
/*     */         
/* 163 */         if (checkMatch(inv, x, y, false))
/*     */         {
/* 165 */           return true;
/*     */         }
/*     */         
/* 168 */         if (this.mirrored && checkMatch(inv, x, y, true))
/*     */         {
/* 170 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 175 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkMatch(InventoryCrafting inv, int startX, int startY, boolean mirror) {
/* 181 */     for (int x = 0; x < 3; x++) {
/*     */       
/* 183 */       for (int y = 0; y < 3; y++) {
/*     */         
/* 185 */         int subX = x - startX;
/* 186 */         int subY = y - startY;
/* 187 */         Object target = null;
/*     */         
/* 189 */         if (subX >= 0 && subY >= 0 && subX < this.width && subY < this.height)
/*     */         {
/* 191 */           if (mirror) {
/*     */             
/* 193 */             target = this.input[this.width - subX - 1 + subY * this.width];
/*     */           }
/*     */           else {
/*     */             
/* 197 */             target = this.input[subX + subY * this.width];
/*     */           } 
/*     */         }
/*     */         
/* 201 */         ItemStack slot = inv.func_70463_b(x, y);
/*     */         
/* 203 */         if (target instanceof ItemStack) {
/*     */           
/* 205 */           if (!OreDictionary.itemMatches((ItemStack)target, slot, false))
/*     */           {
/* 207 */             return false;
/*     */           }
/*     */           
/* 210 */           ItemStack targetStack = (ItemStack)target;
/*     */           
/* 212 */           if (targetStack.func_77942_o() && !targetStack.func_77978_p().func_82582_d())
/*     */           {
/* 214 */             if (!LootPPHelper.compareNBT((NBTBase)targetStack.func_77978_p(), (NBTBase)slot.func_77978_p()))
/*     */             {
/* 216 */               return false;
/*     */             }
/*     */           }
/*     */         }
/* 220 */         else if (target instanceof List) {
/*     */           
/* 222 */           boolean matched = false;
/*     */           
/* 224 */           Iterator<ItemStack> itr = ((List<ItemStack>)target).iterator();
/* 225 */           while (itr.hasNext() && !matched)
/*     */           {
/* 227 */             matched = OreDictionary.itemMatches(itr.next(), slot, false);
/*     */           }
/*     */           
/* 230 */           if (!matched)
/*     */           {
/* 232 */             return false;
/*     */           }
/*     */         }
/* 235 */         else if (target == null && slot != null) {
/*     */           
/* 237 */           return false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 242 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ShapedOreRecipe setMirrored(boolean mirror) {
/* 247 */     this.mirrored = mirror;
/* 248 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getInput() {
/* 258 */     return this.input;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack[] func_179532_b(InventoryCrafting inv) {
/* 264 */     return ForgeHooks.defaultRecipeGetRemainingItems(inv);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\recipes\LootPPShapedRecipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */