/*     */ package com.tmtravlr.lootplusplus.recipes;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.inventory.InventoryCrafting;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.ForgeHooks;
/*     */ import net.minecraftforge.oredict.OreDictionary;
/*     */ import net.minecraftforge.oredict.ShapelessOreRecipe;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LootPPShapelessRecipe
/*     */   extends ShapelessOreRecipe
/*     */ {
/*  22 */   private ItemStack output = null;
/*  23 */   private ArrayList<Object> input = new ArrayList();
/*     */   
/*  25 */   public LootPPShapelessRecipe(Block result, Object... recipe) { this(new ItemStack(result), recipe); } public LootPPShapelessRecipe(Item result, Object... recipe) {
/*  26 */     this(new ItemStack(result), recipe);
/*     */   }
/*     */   
/*     */   public LootPPShapelessRecipe(ItemStack result, Object... recipe) {
/*  30 */     super(result, recipe);
/*  31 */     this.output = result.func_77946_l();
/*  32 */     for (Object in : recipe) {
/*     */       
/*  34 */       if (in instanceof ItemStack) {
/*     */         
/*  36 */         this.input.add(((ItemStack)in).func_77946_l());
/*     */       }
/*  38 */       else if (in instanceof Item) {
/*     */         
/*  40 */         this.input.add(new ItemStack((Item)in));
/*     */       }
/*  42 */       else if (in instanceof Block) {
/*     */         
/*  44 */         this.input.add(new ItemStack((Block)in));
/*     */       }
/*  46 */       else if (in instanceof String) {
/*     */         
/*  48 */         this.input.add(OreDictionary.getOres((String)in));
/*     */       }
/*     */       else {
/*     */         
/*  52 */         String ret = "Invalid shapeless ore recipe: ";
/*  53 */         for (Object tmp : recipe)
/*     */         {
/*  55 */           ret = ret + tmp + ", ";
/*     */         }
/*  57 */         ret = ret + this.output;
/*  58 */         throw new RuntimeException(ret);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int func_77570_a() {
/*  67 */     return this.input.size();
/*     */   }
/*     */   public ItemStack func_77571_b() {
/*  70 */     return this.output;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77572_b(InventoryCrafting var1) {
/*  76 */     return this.output.func_77946_l();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_77569_a(InventoryCrafting var1, World world) {
/*  85 */     ArrayList<Object> required = new ArrayList(this.input);
/*     */     
/*  87 */     for (int x = 0; x < var1.func_70302_i_(); x++) {
/*     */       
/*  89 */       ItemStack slot = var1.func_70301_a(x);
/*     */       
/*  91 */       if (slot != null) {
/*     */         
/*  93 */         boolean inRecipe = false;
/*  94 */         Iterator<Object> req = required.iterator();
/*     */         
/*  96 */         while (req.hasNext()) {
/*     */           
/*  98 */           boolean match = false;
/*     */           
/* 100 */           Object next = req.next();
/*     */           
/* 102 */           if (next instanceof ItemStack) {
/*     */             
/* 104 */             match = OreDictionary.itemMatches((ItemStack)next, slot, false);
/*     */             
/* 106 */             ItemStack targetStack = (ItemStack)next;
/*     */             
/* 108 */             if (match && targetStack.func_77942_o() && !targetStack.func_77978_p().func_82582_d())
/*     */             {
/* 110 */               match = LootPPHelper.compareNBT((NBTBase)targetStack.func_77978_p(), (NBTBase)slot.func_77978_p());
/*     */             }
/*     */           }
/* 113 */           else if (next instanceof List) {
/*     */             
/* 115 */             Iterator<ItemStack> itr = ((List<ItemStack>)next).iterator();
/* 116 */             while (itr.hasNext() && !match)
/*     */             {
/* 118 */               match = OreDictionary.itemMatches(itr.next(), slot, false);
/*     */             }
/*     */           } 
/*     */           
/* 122 */           if (match) {
/*     */             
/* 124 */             inRecipe = true;
/* 125 */             required.remove(next);
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 130 */         if (!inRecipe)
/*     */         {
/* 132 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     return required.isEmpty();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ArrayList<Object> getInput() {
/* 147 */     return this.input;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack[] func_179532_b(InventoryCrafting inv) {
/* 153 */     return ForgeHooks.defaultRecipeGetRemainingItems(inv);
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\recipes\LootPPShapelessRecipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */