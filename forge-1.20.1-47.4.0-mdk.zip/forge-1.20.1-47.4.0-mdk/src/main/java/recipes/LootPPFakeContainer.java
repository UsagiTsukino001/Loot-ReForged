/*    */ package com.tmtravlr.lootplusplus.recipes;
/*    */ 
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.inventory.Container;
/*    */ import net.minecraft.inventory.IInventory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LootPPFakeContainer
/*    */   extends Container
/*    */ {
/*    */   public void func_75130_a(IInventory i) {}
/*    */   
/*    */   public boolean func_75145_c(EntityPlayer player) {
/* 21 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\recipes\LootPPFakeContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */