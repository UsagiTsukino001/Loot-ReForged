/*    */ package com.tmtravlr.lootplusplus.recipes;
/*    */ 
/*    */ import net.minecraft.inventory.InventoryCrafting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LootPPFakeInventoryCrafting
/*    */   extends InventoryCrafting
/*    */ {
/*    */   public LootPPFakeInventoryCrafting(int width) {
/* 17 */     super(new LootPPFakeContainer(), width, width);
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\recipes\LootPPFakeInventoryCrafting.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */