/*     */ package com.tmtravlr.lootplusplus.testing;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPItems;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.item.ItemMonsterPlacer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.server.gui.IUpdatePlayerListBox;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.ChatComponentText;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.util.MathHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TileEntityTestingEntitySpawner
/*     */   extends TileEntity
/*     */   implements IUpdatePlayerListBox, IInventory
/*     */ {
/*     */   public ItemStack item;
/*     */   
/*     */   public void func_73660_a() {
/*  28 */     tryToSpawn();
/*     */   }
/*     */   
/*     */   public void tryToSpawn() {
/*  32 */     if (this.item != null) {
/*  33 */       boolean success = false;
/*     */       
/*  35 */       if (this.item.func_77973_b() == Items.field_151063_bx) {
/*  36 */         Entity entity = ItemMonsterPlacer.func_77840_a(this.field_145850_b, this.item.func_77952_i(), MathHelper.func_76128_c(this.field_174879_c.func_177958_n()) + 0.5D, MathHelper.func_76128_c(this.field_174879_c.func_177956_o()) + 1.0D, MathHelper.func_76128_c(this.field_174879_c.func_177952_p()) + 0.5D);
/*     */         
/*  38 */         if (entity != null)
/*     */         {
/*  40 */           if (entity instanceof net.minecraft.entity.EntityLivingBase && this.item.func_82837_s())
/*     */           {
/*  42 */             ((EntityLiving)entity).func_96094_a(this.item.func_82833_r());
/*     */           }
/*     */         }
/*     */         
/*  46 */         success = true;
/*     */       } 
/*     */       
/*  49 */       if (this.item.func_77973_b() == LootPPItems.itemTestingSpawner) {
/*  50 */         ItemTestingEntitySpawner.spawnEntity(this.field_145850_b, this.item, MathHelper.func_76128_c(this.field_174879_c.func_177958_n()) + 0.5D, MathHelper.func_76128_c(this.field_174879_c.func_177956_o()) + 1.0D, MathHelper.func_76128_c(this.field_174879_c.func_177952_p()) + 0.5D);
/*     */         
/*  52 */         success = true;
/*     */       } 
/*     */       
/*  55 */       if (success) {
/*  56 */         this.item.field_77994_a--;
/*     */         
/*  58 */         if (this.item.field_77994_a >= 0) {
/*  59 */           this.item = null;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_70302_i_() {
/*  67 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack func_70301_a(int slot) {
/*  72 */     return this.item;
/*     */   }
/*     */ 
/*     */   
/*     */   public ItemStack func_70298_a(int slot, int amount) {
/*  77 */     if (this.item != null) {
/*     */ 
/*     */ 
/*     */       
/*  81 */       if (this.item.field_77994_a <= amount) {
/*     */         
/*  83 */         ItemStack itemStack = this.item;
/*  84 */         this.item = null;
/*  85 */         func_70296_d();
/*  86 */         return itemStack;
/*     */       } 
/*     */ 
/*     */       
/*  90 */       ItemStack itemstack = this.item.func_77979_a(amount);
/*     */       
/*  92 */       if (this.item.field_77994_a == 0)
/*     */       {
/*  94 */         this.item = null;
/*     */       }
/*     */       
/*  97 */       func_70296_d();
/*  98 */       return itemstack;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_70304_b(int slot) {
/* 109 */     if (this.item != null) {
/*     */       
/* 111 */       ItemStack itemstack = this.item;
/* 112 */       this.item = null;
/* 113 */       return itemstack;
/*     */     } 
/*     */ 
/*     */     
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70299_a(int slot, ItemStack is) {
/* 123 */     this.item = is;
/*     */     
/* 125 */     if (is != null && is.field_77994_a > func_70297_j_()) {
/*     */       
/* 127 */       is.field_77994_a = func_70297_j_();
/* 128 */       tryToSpawn();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String func_70005_c_() {
/* 134 */     return "container.singlespawner";
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean func_145818_k_() {
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_70297_j_() {
/* 144 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_145839_a(NBTTagCompound tag) {
/* 149 */     super.func_145839_a(tag);
/* 150 */     NBTTagCompound itemTag = tag.func_74775_l("Item");
/*     */     
/* 152 */     this.item = ItemStack.func_77949_a(itemTag);
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_145841_b(NBTTagCompound tag) {
/* 157 */     super.func_145841_b(tag);
/* 158 */     NBTTagCompound itemTag = new NBTTagCompound();
/* 159 */     if (this.item != null) {
/* 160 */       this.item.func_77955_b(itemTag);
/*     */     }
/* 162 */     tag.func_74782_a("Item", (NBTBase)itemTag);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_70296_d() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_70300_a(EntityPlayer p_70300_1_) {
/* 172 */     return (this.field_145850_b.func_175625_s(this.field_174879_c) != this) ? false : ((p_70300_1_.func_70092_e(this.field_174879_c.func_177958_n() + 0.5D, this.field_174879_c.func_177956_o() + 0.5D, this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_174889_b(EntityPlayer player) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void func_174886_c(EntityPlayer player) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_94041_b(int slot, ItemStack is) {
/* 188 */     return (is.func_77973_b() == Items.field_151063_bx || is.func_77973_b() == LootPPItems.itemTestingSpawner);
/*     */   }
/*     */ 
/*     */   
/*     */   public IChatComponent func_145748_c_() {
/* 193 */     return (IChatComponent)new ChatComponentText(func_70005_c_());
/*     */   }
/*     */ 
/*     */   
/*     */   public int func_174887_a_(int id) {
/* 198 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_174885_b(int id, int value) {}
/*     */ 
/*     */   
/*     */   public int func_174890_g() {
/* 206 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void func_174888_l() {
/* 211 */     this.item = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\testing\TileEntityTestingEntitySpawner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */