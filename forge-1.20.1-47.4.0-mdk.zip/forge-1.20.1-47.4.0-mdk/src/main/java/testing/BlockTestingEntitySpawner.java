/*    */ package com.tmtravlr.lootplusplus.testing;
/*    */ 
/*    */ import com.tmtravlr.lootplusplus.LootPPItems;
/*    */ import java.util.Random;
/*    */ import net.minecraft.block.BlockContainer;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.BlockPos;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ 
/*    */ public class BlockTestingEntitySpawner
/*    */   extends BlockContainer
/*    */ {
/*    */   public BlockTestingEntitySpawner() {
/* 21 */     super(Material.field_151576_e);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int func_149745_a(Random rand) {
/* 27 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean func_149662_c() {
/* 32 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public TileEntity func_149915_a(World world, int number) {
/* 40 */     return new TileEntityTestingEntitySpawner();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean func_180639_a(World world, BlockPos pos, IBlockState state, EntityPlayer player, EnumFacing side, float hitX, float hitY, float hitZ) {
/* 47 */     if (!world.field_72995_K) {
/* 48 */       TileEntityTestingEntitySpawner tetes = (TileEntityTestingEntitySpawner)world.func_175625_s(pos);
/*    */       
/* 50 */       if (tetes != null) {
/*    */         
/* 52 */         ItemStack is = player.func_71045_bC();
/*    */         
/* 54 */         if (is != null && (is.func_77973_b() == Items.field_151063_bx || is.func_77973_b() == LootPPItems.itemTestingSpawner)) {
/* 55 */           tetes.item = is.func_77946_l();
/* 56 */           tetes.item.field_77994_a = 1;
/* 57 */           is.field_77994_a--;
/*    */           
/* 59 */           return true;
/*    */         } 
/*    */       } 
/*    */     } 
/* 63 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\testing\BlockTestingEntitySpawner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */