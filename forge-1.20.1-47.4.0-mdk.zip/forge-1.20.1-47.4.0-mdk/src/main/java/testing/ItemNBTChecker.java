/*     */ package com.tmtravlr.lootplusplus.testing;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.ChatComponentTranslation;
/*     */ import net.minecraft.util.EnumChatFormatting;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.IChatComponent;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemNBTChecker
/*     */   extends Item
/*     */ {
/*     */   public boolean onItemUseFirst(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ) {
/*  32 */     if (!player.field_70170_p.field_72995_K) {
/*  33 */       TileEntity te = world.func_175625_s(pos);
/*  34 */       if (te != null) {
/*  35 */         NBTTagCompound tag = new NBTTagCompound();
/*  36 */         te.func_145841_b(tag);
/*     */         
/*  38 */         File nbtOutput = new File(LootPPHelper.idFolder, "NBTOutput.txt");
/*     */         
/*     */         try {
/*  41 */           PrintStream writeStream = new PrintStream(nbtOutput);
/*     */           
/*  43 */           writeStream.println(tag.toString());
/*     */           
/*  45 */           writeStream.close();
/*     */           
/*  47 */           player.func_145747_a((IChatComponent)new ChatComponentTranslation("info.lppnbtdump.block", new Object[0]));
/*     */         }
/*  49 */         catch (FileNotFoundException e) {
/*  50 */           e.printStackTrace();
/*  51 */           ChatComponentTranslation chatComponentTranslation = new ChatComponentTranslation("commands.lppnbtdump.failed", new Object[0]);
/*  52 */           chatComponentTranslation.func_150256_b().func_150238_a(EnumChatFormatting.RED);
/*  53 */           player.func_145747_a((IChatComponent)chatComponentTranslation);
/*     */         } 
/*     */         
/*  56 */         return true;
/*     */       } 
/*     */       
/*  59 */       ChatComponentTranslation message = new ChatComponentTranslation("info.lppnbtdump.block.nonbt", new Object[0]);
/*  60 */       message.func_150256_b().func_150238_a(EnumChatFormatting.RED);
/*  61 */       player.func_145747_a((IChatComponent)message);
/*     */     } 
/*     */     
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_111207_a(ItemStack stack, EntityPlayer player, EntityLivingBase entity) {
/*  72 */     return printEntityInfo(player, entity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_77644_a(ItemStack stack, EntityLivingBase entity, EntityLivingBase player) {
/*  80 */     if (player instanceof EntityPlayer) {
/*  81 */       printEntityInfo((EntityPlayer)player, entity);
/*     */     }
/*     */     
/*  84 */     return false;
/*     */   }
/*     */   
/*     */   private boolean printEntityInfo(EntityPlayer player, EntityLivingBase entity) {
/*  88 */     if (!player.field_70170_p.field_72995_K) {
/*  89 */       NBTTagCompound tag = new NBTTagCompound();
/*  90 */       entity.func_70109_d(tag);
/*     */       
/*  92 */       File nbtOutput = new File(LootPPHelper.idFolder, "NBTOutput.txt");
/*     */       
/*     */       try {
/*  95 */         PrintStream writeStream = new PrintStream(nbtOutput);
/*     */ 
/*     */         
/*  98 */         writeStream.println(tag.toString());
/*     */         
/* 100 */         writeStream.close();
/*     */         
/* 102 */         player.func_145747_a((IChatComponent)new ChatComponentTranslation("info.lppnbtdump.entity", new Object[] { entity.func_70005_c_() }));
/*     */       }
/* 104 */       catch (FileNotFoundException e) {
/* 105 */         e.printStackTrace();
/* 106 */         ChatComponentTranslation message = new ChatComponentTranslation("commands.lppnbtdump.failed", new Object[0]);
/* 107 */         message.func_150256_b().func_150238_a(EnumChatFormatting.RED);
/* 108 */         player.func_145747_a((IChatComponent)message);
/*     */       } 
/*     */     } 
/*     */     
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public void func_77624_a(ItemStack stack, EntityPlayer player, List<String> list, boolean debug) {
/* 120 */     list.add(EnumChatFormatting.GRAY + "Right click an entity or block to save it's nbt");
/* 121 */     list.add(EnumChatFormatting.GRAY + "that can be used in a lppsummon or lppsetblock");
/* 122 */     list.add(EnumChatFormatting.GRAY + "command or in the config files.");
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\testing\ItemNBTChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */