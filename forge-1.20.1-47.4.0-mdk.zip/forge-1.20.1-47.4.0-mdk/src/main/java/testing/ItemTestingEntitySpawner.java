/*     */ package com.tmtravlr.lootplusplus.testing;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityList;
/*     */ import net.minecraft.entity.EntityLiving;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemMonsterPlacer;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.stats.StatList;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.MathHelper;
/*     */ import net.minecraft.util.MovingObjectPosition;
/*     */ import net.minecraft.util.ReportedException;
/*     */ import net.minecraft.util.StatCollector;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.relauncher.Side;
/*     */ import net.minecraftforge.fml.relauncher.SideOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemTestingEntitySpawner
/*     */   extends ItemMonsterPlacer
/*     */ {
/*     */   public ItemTestingEntitySpawner() {
/*  52 */     func_77627_a(false);
/*  53 */     func_77637_a(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean func_180614_a(ItemStack stack, EntityPlayer player, World world, BlockPos pos, EnumFacing side, float hitX, float hitY, float hitZ) {
/*  63 */     if (world.field_72995_K)
/*     */     {
/*  65 */       return true;
/*     */     }
/*  67 */     if (!player.func_175151_a(pos.func_177972_a(side), side, stack))
/*     */     {
/*  69 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  73 */     IBlockState iblockstate = world.func_180495_p(pos);
/*  74 */     pos = pos.func_177972_a(side);
/*     */     
/*  76 */     double d0 = 0.0D;
/*     */     
/*  78 */     if (side == EnumFacing.UP && iblockstate instanceof net.minecraft.block.BlockFence)
/*     */     {
/*  80 */       d0 = 0.5D;
/*     */     }
/*     */     
/*  83 */     Entity entity = spawnEntity(world, stack, pos.func_177958_n() + 0.5D, pos.func_177956_o() + d0, pos.func_177952_p() + 0.5D);
/*     */     
/*  85 */     if (entity != null) {
/*     */       
/*  87 */       if (!player.field_71075_bZ.field_75098_d)
/*     */       {
/*  89 */         stack.field_77994_a--;
/*     */       }
/*     */       
/*  92 */       player.func_71029_a(StatList.field_75929_E[Item.func_150891_b((Item)this)]);
/*     */     } 
/*     */     
/*  95 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ItemStack func_77659_a(ItemStack stack, World world, EntityPlayer player) {
/* 105 */     if (world.field_72995_K)
/*     */     {
/* 107 */       return stack;
/*     */     }
/*     */ 
/*     */     
/* 111 */     MovingObjectPosition movingobjectposition = func_77621_a(world, player, true);
/*     */     
/* 113 */     if (movingobjectposition == null)
/*     */     {
/* 115 */       return stack;
/*     */     }
/*     */ 
/*     */     
/* 119 */     if (movingobjectposition.field_72313_a == MovingObjectPosition.MovingObjectType.BLOCK) {
/*     */       
/* 121 */       BlockPos blockpos = movingobjectposition.func_178782_a();
/*     */       
/* 123 */       if (!world.func_175660_a(player, blockpos))
/*     */       {
/* 125 */         return stack;
/*     */       }
/*     */       
/* 128 */       if (!player.func_175151_a(blockpos, movingobjectposition.field_178784_b, stack))
/*     */       {
/* 130 */         return stack;
/*     */       }
/*     */       
/* 133 */       if (world.func_180495_p(blockpos).func_177230_c() instanceof net.minecraft.block.BlockLiquid) {
/*     */         
/* 135 */         Entity entity = spawnEntity(world, stack, blockpos.func_177958_n() + 0.5D, blockpos.func_177956_o() + 0.5D, blockpos.func_177952_p() + 0.5D);
/*     */         
/* 137 */         if (entity != null) {
/*     */           
/* 139 */           if (!player.field_71075_bZ.field_75098_d)
/*     */           {
/* 141 */             stack.field_77994_a--;
/*     */           }
/*     */           
/* 144 */           player.func_71029_a(StatList.field_75929_E[Item.func_150891_b((Item)this)]);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 149 */     return stack;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Entity spawnEntity(World world, ItemStack is, double xpos, double ypos, double zpos) {
/* 160 */     if (is.func_77978_p() == null || !is.func_77978_p().func_74764_b("EntityName")) {
/*     */       
/* 162 */       EntityList.EntityEggInfo entityegginfo = (EntityList.EntityEggInfo)EntityList.field_75627_a.get(Integer.valueOf(is.func_77952_i()));
/* 163 */       if (entityegginfo != null) {
/*     */         
/* 165 */         boolean bool = (is.func_77978_p() != null && !is.func_77978_p().func_74764_b("EntityData"));
/* 166 */         Entity entity1 = null;
/*     */         
/* 168 */         if (bool) {
/* 169 */           entity1 = EntityList.func_75616_a(is.func_77952_i(), world);
/*     */         } else {
/*     */           
/* 172 */           NBTTagCompound nbttagcompound = new NBTTagCompound();
/*     */           try {
/* 174 */             nbttagcompound = (NBTTagCompound)is.func_77978_p().func_74775_l("EntityData").func_74737_b();
/*     */           }
/* 176 */           catch (Exception e) {
/* 177 */             System.out.println("[Loot++] Caught Exception while trying to read in NBT data.");
/* 178 */             e.printStackTrace();
/*     */           } 
/* 180 */           nbttagcompound.func_74778_a("id", EntityList.func_75617_a(is.func_77952_i()));
/*     */           
/* 182 */           entity1 = EntityList.func_75615_a(nbttagcompound, world);
/*     */         } 
/*     */         
/* 185 */         if (entity1 != null) {
/*     */ 
/*     */           
/* 188 */           entity1.func_70012_b(xpos, ypos, zpos, MathHelper.func_76142_g(world.field_73012_v.nextFloat() * 360.0F), 0.0F);
/* 189 */           if (entity1 instanceof EntityLiving) {
/* 190 */             ((EntityLiving)entity1).field_70759_as = entity1.field_70177_z;
/* 191 */             ((EntityLiving)entity1).field_70761_aq = entity1.field_70177_z;
/* 192 */             if (bool) {
/* 193 */               ((EntityLiving)entity1).func_180482_a(world.func_175649_E(entity1.func_180425_c()), null);
/*     */             }
/*     */           } 
/* 196 */           world.func_72838_d(entity1);
/*     */         } 
/*     */         
/* 199 */         return entity1;
/*     */       } 
/*     */       
/* 202 */       return null;
/*     */     } 
/*     */     
/* 205 */     String entityName = is.func_77978_p().func_74779_i("EntityName");
/*     */     
/* 207 */     if (entityName == null || entityName.equals(""))
/*     */     {
/* 209 */       return null;
/*     */     }
/*     */     
/* 212 */     boolean hasNoNBT = !is.func_77978_p().func_74764_b("EntityData");
/* 213 */     Entity entity = null;
/*     */     
/* 215 */     if (hasNoNBT) {
/* 216 */       entity = EntityList.func_75620_a(entityName, world);
/*     */     } else {
/*     */       
/* 219 */       NBTTagCompound nbttagcompound = new NBTTagCompound();
/*     */       try {
/* 221 */         nbttagcompound = (NBTTagCompound)is.func_77978_p().func_74775_l("EntityData").func_74737_b();
/*     */       }
/* 223 */       catch (ReportedException e) {
/* 224 */         System.out.println("[Loot++] Caught Exception while trying to read in NBT data.");
/* 225 */         e.printStackTrace();
/*     */       } 
/* 227 */       nbttagcompound.func_74778_a("id", entityName);
/*     */       
/* 229 */       entity = EntityList.func_75615_a(nbttagcompound, world);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     if (entity != null) {
/*     */ 
/*     */       
/* 238 */       entity.func_70012_b(xpos, ypos, zpos, MathHelper.func_76142_g(world.field_73012_v.nextFloat() * 360.0F), 0.0F);
/* 239 */       if (entity instanceof EntityLiving) {
/* 240 */         ((EntityLiving)entity).field_70759_as = entity.field_70177_z;
/* 241 */         ((EntityLiving)entity).field_70761_aq = entity.field_70177_z;
/* 242 */         if (hasNoNBT) {
/* 243 */           ((EntityLiving)entity).func_180482_a(world.func_175649_E(entity.func_180425_c()), null);
/*     */         }
/*     */       } 
/* 246 */       world.func_72838_d(entity);
/*     */     } 
/* 248 */     return entity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SideOnly(Side.CLIENT)
/*     */   public int func_82790_a(ItemStack stack, int layer) {
/* 278 */     NBTTagCompound tag = stack.func_77978_p();
/*     */     
/* 280 */     if (tag != null) {
/*     */ 
/*     */       
/* 283 */       if (tag.func_74764_b("Icon")) {
/* 284 */         return 16777215;
/*     */       }
/*     */       
/* 287 */       if ((layer == 0 && tag.func_74764_b("PrimaryColor")) || (layer != 0 && tag.func_74764_b("SecondaryColor"))) {
/* 288 */         return (layer == 0) ? tag.func_74762_e("PrimaryColor") : tag.func_74762_e("SecondaryColor");
/*     */       }
/*     */       
/* 291 */       int color = 16777215;
/*     */       
/*     */       try {
/* 294 */         Entity entity = EntityList.func_75620_a(tag.func_74779_i("EntityName"), (World)(Minecraft.func_71410_x()).field_71441_e);
/* 295 */         if (entity == null) {
/* 296 */           EntityList.EntityEggInfo entityEggInfo = (EntityList.EntityEggInfo)EntityList.field_75627_a.get(Integer.valueOf(stack.func_77952_i()));
/* 297 */           return (entityEggInfo != null) ? ((layer == 0) ? entityEggInfo.field_75611_b : entityEggInfo.field_75612_c) : 16777215;
/*     */         } 
/* 299 */         int entityId = EntityList.func_75619_a(entity);
/* 300 */         EntityList.EntityEggInfo eggInfo = (EntityList.EntityEggInfo)EntityList.field_75627_a.get(Integer.valueOf(entityId));
/*     */         
/* 302 */         if (eggInfo != null) {
/* 303 */           if (layer == 0) {
/* 304 */             tag.func_74768_a("PrimaryColor", eggInfo.field_75611_b);
/*     */           } else {
/* 306 */             tag.func_74768_a("SecondaryColor", eggInfo.field_75612_c);
/* 307 */           }  return (layer == 0) ? eggInfo.field_75611_b : eggInfo.field_75612_c;
/*     */         } 
/*     */         
/* 310 */         Random rand = new Random(tag.func_74779_i("EntityName").hashCode());
/* 311 */         int primary = rand.nextInt(color);
/* 312 */         int secondary = rand.nextInt(color);
/* 313 */         if (layer == 0) {
/* 314 */           tag.func_74768_a("PrimaryColor", primary);
/*     */         } else {
/* 316 */           tag.func_74768_a("SecondaryColor", secondary);
/* 317 */         }  return (layer == 0) ? primary : secondary;
/*     */       
/*     */       }
/* 320 */       catch (Exception e) {
/* 321 */         e.printStackTrace();
/*     */         
/* 323 */         return color;
/*     */       } 
/*     */     } 
/* 326 */     EntityList.EntityEggInfo entityegginfo = (EntityList.EntityEggInfo)EntityList.field_75627_a.get(Integer.valueOf(stack.func_77952_i()));
/* 327 */     return (entityegginfo != null) ? ((layer == 0) ? entityegginfo.field_75611_b : entityegginfo.field_75612_c) : 16777215;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String func_77653_i(ItemStack is) {
/* 335 */     String s = ("" + StatCollector.func_74838_a(func_77658_a() + ".name")).trim();
/* 336 */     String s1 = null;
/* 337 */     if (is.func_77978_p() != null && is.func_77978_p().func_74764_b("EntityName")) {
/* 338 */       s1 = is.func_77978_p().func_74779_i("EntityName");
/*     */     } else {
/*     */       
/* 341 */       EntityList.EntityEggInfo entityegginfo = (EntityList.EntityEggInfo)EntityList.field_75627_a.get(Integer.valueOf(is.func_77952_i()));
/* 342 */       if (entityegginfo != null) {
/* 343 */         s1 = EntityList.func_75617_a(is.func_77952_i());
/*     */       }
/*     */     } 
/*     */     
/* 347 */     if (s1 != null)
/*     */     {
/* 349 */       s = s + " " + StatCollector.func_74838_a("entity." + s1 + ".name");
/*     */     }
/*     */     
/* 352 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\testing\ItemTestingEntitySpawner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */