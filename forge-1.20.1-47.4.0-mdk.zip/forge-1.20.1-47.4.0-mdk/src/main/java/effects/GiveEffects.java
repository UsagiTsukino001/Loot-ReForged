/*     */ package com.tmtravlr.lootplusplus.effects;
/*     */ 
/*     */ import com.tmtravlr.lootplusplus.LootPPBlocks;
/*     */ import com.tmtravlr.lootplusplus.LootPPHelper;
/*     */ import com.tmtravlr.lootplusplus.LootPPItems;
/*     */ import com.tmtravlr.lootplusplus.commands.CommandSenderGeneric;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Random;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.command.ICommandSender;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTBase;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.Vec3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GiveEffects
/*     */ {
/*  32 */   private static Random rand = new Random();
/*     */   
/*  34 */   public static TreeMap<ItemStack, ArrayList<EffectInfo>> entityOnHitEntityMap = new TreeMap<ItemStack, ArrayList<EffectInfo>>(LootPPHelper.stackComparatorNBT);
/*  35 */   public static TreeMap<ItemStack, ArrayList<EffectInfo>> youOnHitEntityMap = new TreeMap<ItemStack, ArrayList<EffectInfo>>(LootPPHelper.stackComparatorNBT);
/*  36 */   public static TreeMap<ItemStack, ArrayList<EffectInfo>> onItemBlockDigMap = new TreeMap<ItemStack, ArrayList<EffectInfo>>(LootPPHelper.stackComparatorNBT);
/*  37 */   public static TreeMap<ItemStack, ArrayList<EffectInfo>> onItemBlockBrokeMap = new TreeMap<ItemStack, ArrayList<EffectInfo>>(LootPPHelper.stackComparatorNBT);
/*  38 */   public static TreeMap<ItemStack, ArrayList<EffectInfo>> onRightClickMap = new TreeMap<ItemStack, ArrayList<EffectInfo>>(LootPPHelper.stackComparatorNBT);
/*  39 */   public static TreeMap<ItemStack, ArrayList<EffectInfo>> onWornMap = new TreeMap<ItemStack, ArrayList<EffectInfo>>(LootPPHelper.stackComparatorNBT);
/*  40 */   public static TreeMap<ItemStack, ArrayList<EffectInfo>> onHeldMap = new TreeMap<ItemStack, ArrayList<EffectInfo>>(LootPPHelper.stackComparatorNBT);
/*  41 */   public static TreeMap<ItemStack, ArrayList<EffectInfo>> onPassiveMap = new TreeMap<ItemStack, ArrayList<EffectInfo>>(LootPPHelper.stackComparatorNBT);
/*  42 */   public static TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>> standingOnMap = new TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>>(LootPPHelper.blockComparator);
/*  43 */   public static TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>> insideMap = new TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>>(LootPPHelper.blockComparator);
/*  44 */   public static TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>> onBlockBlockDigMap = new TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>>(LootPPHelper.blockComparator);
/*  45 */   public static TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>> onBlockBlockBrokeMap = new TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>>(LootPPHelper.blockComparator);
/*     */ 
/*     */   
/*     */   public static void giveEntityHitEffects(EntityLivingBase entityHitting, EntityLivingBase entityHit) {
/*  49 */     ItemStack held = entityHitting.func_70694_bm();
/*  50 */     ItemStack heldWild = held.func_77946_l();
/*  51 */     heldWild.func_77964_b(32767);
/*     */     
/*  53 */     ItemStack dummy = held.func_77946_l();
/*  54 */     dummy.func_150996_a(LootPPItems.generalDummyIcon);
/*  55 */     ItemStack dummyWild = dummy.func_77946_l();
/*  56 */     dummyWild.func_77964_b(32767);
/*     */     
/*  58 */     if (!entityOnHitEntityMap.isEmpty()) {
/*  59 */       HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/*  60 */       addAllRelevant(dummy, dummyWild, held, heldWild, infoSet, entityOnHitEntityMap);
/*     */       
/*  62 */       for (EffectInfo info : infoSet) {
/*  63 */         if (info.probability >= rand.nextFloat()) {
/*  64 */           addEffectToEntity(entityHit, info);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*  69 */     if (!youOnHitEntityMap.isEmpty()) {
/*  70 */       HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/*  71 */       addAllRelevant(dummy, dummyWild, held, heldWild, infoSet, youOnHitEntityMap);
/*     */       
/*  73 */       for (EffectInfo info : infoSet) {
/*  74 */         if (info.probability >= rand.nextFloat()) {
/*  75 */           addEffectToEntity(entityHitting, info);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void giveDigEffects(EntityLivingBase entity, IBlockState state) {
/*  83 */     ItemStack held = entity.func_70694_bm();
/*  84 */     if (held != null) {
/*  85 */       ItemStack heldWild = held.func_77946_l();
/*  86 */       heldWild.func_77964_b(32767);
/*     */       
/*  88 */       ItemStack dummy = held.func_77946_l();
/*  89 */       dummy.func_150996_a(LootPPItems.generalDummyIcon);
/*  90 */       ItemStack dummyWild = dummy.func_77946_l();
/*  91 */       dummyWild.func_77964_b(32767);
/*     */       
/*  93 */       if (!onItemBlockDigMap.isEmpty()) {
/*  94 */         HashSet<EffectInfo> hashSet = new HashSet<EffectInfo>();
/*  95 */         addAllRelevant(dummy, dummyWild, held, heldWild, hashSet, onItemBlockDigMap);
/*     */         
/*  97 */         for (EffectInfo effectInfo : hashSet) {
/*  98 */           if (effectInfo.probability >= rand.nextFloat()) {
/*  99 */             addEffectToEntity(entity, effectInfo);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 105 */     LootPPHelper.BlockMeta info = new LootPPHelper.BlockMeta(state);
/* 106 */     LootPPHelper.BlockMeta infoWild = new LootPPHelper.BlockMeta(info.block, 32767);
/* 107 */     LootPPHelper.BlockMeta infoDummy = new LootPPHelper.BlockMeta(LootPPBlocks.blockCommandBlockTrigger, info.meta);
/* 108 */     LootPPHelper.BlockMeta infoDummyWild = new LootPPHelper.BlockMeta(infoDummy.block, 32767);
/*     */     
/* 110 */     HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/* 111 */     addAllRelevantBlocks(infoDummy, infoDummyWild, info, infoWild, infoSet, onBlockBlockDigMap);
/*     */     
/* 113 */     for (EffectInfo effectInfo : infoSet) {
/* 114 */       if (effectInfo.probability >= rand.nextFloat()) {
/* 115 */         addEffectToEntity(entity, effectInfo);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void giveBreakEffects(EntityLivingBase entity, IBlockState state) {
/* 122 */     ItemStack held = entity.func_70694_bm();
/* 123 */     if (held != null) {
/* 124 */       ItemStack heldWild = held.func_77946_l();
/* 125 */       heldWild.func_77964_b(32767);
/*     */       
/* 127 */       ItemStack dummy = held.func_77946_l();
/* 128 */       dummy.func_150996_a(LootPPItems.generalDummyIcon);
/* 129 */       ItemStack dummyWild = dummy.func_77946_l();
/* 130 */       dummyWild.func_77964_b(32767);
/*     */       
/* 132 */       if (!onItemBlockBrokeMap.isEmpty()) {
/* 133 */         HashSet<EffectInfo> hashSet = new HashSet<EffectInfo>();
/* 134 */         addAllRelevant(dummy, dummyWild, held, heldWild, hashSet, onItemBlockBrokeMap);
/*     */         
/* 136 */         for (EffectInfo effectInfo : hashSet) {
/* 137 */           if (effectInfo.probability >= rand.nextFloat()) {
/* 138 */             addEffectToEntity(entity, effectInfo);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     LootPPHelper.BlockMeta info = new LootPPHelper.BlockMeta(state);
/* 145 */     LootPPHelper.BlockMeta infoWild = new LootPPHelper.BlockMeta(info.block, 32767);
/* 146 */     LootPPHelper.BlockMeta infoDummy = new LootPPHelper.BlockMeta(LootPPBlocks.blockCommandBlockTrigger, info.meta);
/* 147 */     LootPPHelper.BlockMeta infoDummyWild = new LootPPHelper.BlockMeta(infoDummy.block, 32767);
/*     */     
/* 149 */     HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/* 150 */     addAllRelevantBlocks(infoDummy, infoDummyWild, info, infoWild, infoSet, onBlockBlockBrokeMap);
/*     */     
/* 152 */     for (EffectInfo effectInfo : infoSet) {
/* 153 */       if (effectInfo.probability >= rand.nextFloat()) {
/* 154 */         addEffectToEntity(entity, effectInfo);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void giveRightClickEffects(EntityLivingBase entity) {
/* 161 */     ItemStack held = entity.func_70694_bm();
/* 162 */     ItemStack heldWild = held.func_77946_l();
/* 163 */     heldWild.func_77964_b(32767);
/*     */     
/* 165 */     ItemStack dummy = held.func_77946_l();
/* 166 */     dummy.func_150996_a(LootPPItems.generalDummyIcon);
/* 167 */     ItemStack dummyWild = dummy.func_77946_l();
/* 168 */     dummyWild.func_77964_b(32767);
/*     */     
/* 170 */     if (!onRightClickMap.isEmpty()) {
/* 171 */       HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/* 172 */       addAllRelevant(dummy, dummyWild, held, heldWild, infoSet, onRightClickMap);
/*     */       
/* 174 */       for (EffectInfo info : infoSet) {
/* 175 */         if (info.probability >= rand.nextFloat()) {
/* 176 */           addEffectToEntity(entity, info);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void givePassiveEffects(EntityLivingBase entity) {
/* 186 */     if (!onHeldMap.isEmpty() && entity.func_70694_bm() != null) {
/* 187 */       ItemStack held = entity.func_70694_bm();
/* 188 */       ItemStack heldWild = held.func_77946_l();
/* 189 */       heldWild.func_77964_b(32767);
/*     */       
/* 191 */       ItemStack dummy = held.func_77946_l();
/* 192 */       dummy.func_150996_a(LootPPItems.generalDummyIcon);
/* 193 */       ItemStack dummyWild = dummy.func_77946_l();
/* 194 */       dummyWild.func_77964_b(32767);
/*     */       
/* 196 */       HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/* 197 */       addAllRelevant(dummy, dummyWild, held, heldWild, infoSet, onHeldMap);
/*     */       
/* 199 */       for (EffectInfo info : infoSet) {
/* 200 */         if (info.probability >= rand.nextFloat()) {
/* 201 */           addEffectToEntity(entity, info);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 208 */     if (!onPassiveMap.isEmpty()) {
/* 209 */       ArrayList<ItemStack> inventory = new ArrayList<ItemStack>();
/* 210 */       if (entity instanceof EntityPlayer) {
/* 211 */         inventory.addAll(Arrays.asList(((EntityPlayer)entity).field_71071_by.field_70462_a));
/*     */       }
/* 213 */       if (entity.func_70035_c() != null) {
/* 214 */         inventory.addAll(Arrays.asList(entity.func_70035_c()));
/*     */       }
/*     */       
/* 217 */       for (ItemStack stack : inventory) {
/*     */         
/* 219 */         if (stack != null) {
/* 220 */           ItemStack passiveWild = stack.func_77946_l();
/* 221 */           passiveWild.func_77964_b(32767);
/*     */           
/* 223 */           ItemStack dummy = stack.func_77946_l();
/* 224 */           dummy.func_150996_a(LootPPItems.generalDummyIcon);
/* 225 */           ItemStack dummyWild = dummy.func_77946_l();
/* 226 */           dummyWild.func_77964_b(32767);
/*     */           
/* 228 */           HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/* 229 */           addAllRelevant(dummy, dummyWild, stack, passiveWild, infoSet, onPassiveMap);
/*     */           
/* 231 */           for (EffectInfo info : infoSet) {
/* 232 */             if (info.probability >= rand.nextFloat()) {
/* 233 */               addEffectToEntity(entity, info);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 242 */     if (!onWornMap.isEmpty()) {
/* 243 */       TreeSet<ItemStack> armor = new TreeSet<ItemStack>(LootPPHelper.stackComparatorWild);
/* 244 */       if (entity instanceof EntityPlayer) {
/* 245 */         armor.addAll(Arrays.asList(entity.func_70035_c()));
/*     */       } else {
/*     */         
/* 248 */         for (int i = 1; i < 5; i++) {
/* 249 */           armor.add(entity.func_71124_b(i));
/*     */         }
/*     */       } 
/*     */       
/* 253 */       for (ItemStack stack : armor) {
/* 254 */         if (stack != null) {
/* 255 */           ItemStack pieceWild = stack.func_77946_l();
/* 256 */           pieceWild.func_77964_b(32767);
/*     */           
/* 258 */           ItemStack dummy = stack.func_77946_l();
/* 259 */           dummy.func_150996_a(LootPPItems.generalDummyIcon);
/* 260 */           ItemStack dummyWild = dummy.func_77946_l();
/* 261 */           dummyWild.func_77964_b(32767);
/*     */           
/* 263 */           HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/* 264 */           addAllRelevant(dummy, dummyWild, stack, pieceWild, infoSet, onWornMap);
/*     */           
/* 266 */           for (EffectInfo info : infoSet) {
/* 267 */             if (info.probability >= rand.nextFloat()) {
/*     */               
/* 269 */               if (!info.alsoEquipped.isEmpty() && 
/* 270 */                 !armor.containsAll(info.alsoEquipped)) {
/*     */                 continue;
/*     */               }
/*     */ 
/*     */               
/* 275 */               addEffectToEntity(entity, info);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 283 */     if (!standingOnMap.isEmpty()) {
/* 284 */       IBlockState state = entity.field_70170_p.func_180495_p(entity.func_180425_c().func_177977_b());
/*     */       
/* 286 */       LootPPHelper.BlockMeta info = new LootPPHelper.BlockMeta(state);
/* 287 */       LootPPHelper.BlockMeta infoWild = new LootPPHelper.BlockMeta(info.block, 32767);
/* 288 */       LootPPHelper.BlockMeta infoDummy = new LootPPHelper.BlockMeta(LootPPBlocks.blockCommandBlockTrigger, info.meta);
/* 289 */       LootPPHelper.BlockMeta infoDummyWild = new LootPPHelper.BlockMeta(infoDummy.block, 32767);
/*     */       
/* 291 */       HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/* 292 */       addAllRelevantBlocks(infoDummy, infoDummyWild, info, infoWild, infoSet, standingOnMap);
/*     */       
/* 294 */       for (EffectInfo effectInfo : infoSet) {
/* 295 */         if (effectInfo.probability >= rand.nextFloat()) {
/* 296 */           addEffectToEntity(entity, effectInfo);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 301 */     if (!insideMap.isEmpty()) {
/* 302 */       BlockPos minPos = new BlockPos((entity.func_174813_aQ()).field_72340_a, (entity.func_174813_aQ()).field_72338_b, (entity.func_174813_aQ()).field_72339_c);
/* 303 */       BlockPos maxPos = new BlockPos((entity.func_174813_aQ()).field_72336_d, (entity.func_174813_aQ()).field_72337_e, (entity.func_174813_aQ()).field_72334_f);
/*     */       
/* 305 */       if (entity.field_70170_p.func_175707_a(minPos, maxPos))
/*     */       {
/* 307 */         for (int i = minPos.func_177958_n(); i <= maxPos.func_177958_n(); i++) {
/*     */           
/* 309 */           for (int j = minPos.func_177956_o(); j <= maxPos.func_177956_o(); j++) {
/*     */             
/* 311 */             for (int k = minPos.func_177952_p(); k <= maxPos.func_177952_p(); k++) {
/*     */               
/* 313 */               BlockPos currentPos = new BlockPos(i, j, k);
/* 314 */               IBlockState state = entity.field_70170_p.func_180495_p(currentPos);
/*     */               
/* 316 */               LootPPHelper.BlockMeta info = new LootPPHelper.BlockMeta(state);
/* 317 */               LootPPHelper.BlockMeta infoWild = new LootPPHelper.BlockMeta(info.block, 32767);
/* 318 */               LootPPHelper.BlockMeta infoDummy = new LootPPHelper.BlockMeta(LootPPBlocks.blockCommandBlockTrigger, info.meta);
/* 319 */               LootPPHelper.BlockMeta infoDummyWild = new LootPPHelper.BlockMeta(infoDummy.block, 32767);
/*     */               
/* 321 */               HashSet<EffectInfo> infoSet = new HashSet<EffectInfo>();
/* 322 */               addAllRelevantBlocks(infoDummy, infoDummyWild, info, infoWild, infoSet, insideMap);
/*     */               
/* 324 */               for (EffectInfo effectInfo : infoSet) {
/* 325 */                 if (effectInfo.probability >= rand.nextFloat()) {
/* 326 */                   addEffectToEntity(entity, effectInfo);
/*     */                 }
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void addAllRelevant(ItemStack dummy, ItemStack dummyWild, ItemStack current, ItemStack currentWild, HashSet<EffectInfo> infoSet, TreeMap<ItemStack, ArrayList<EffectInfo>> effectMap) {
/* 337 */     addRelevant(dummy, infoSet, effectMap);
/* 338 */     addRelevant(dummyWild, infoSet, effectMap);
/* 339 */     addRelevant(current, infoSet, effectMap);
/* 340 */     addRelevant(currentWild, infoSet, effectMap);
/*     */   }
/*     */   
/*     */   public static void addAllRelevantBlocks(LootPPHelper.BlockMeta dummy, LootPPHelper.BlockMeta dummyWild, LootPPHelper.BlockMeta current, LootPPHelper.BlockMeta currentWild, HashSet<EffectInfo> infoSet, TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>> effectMap) {
/* 344 */     addRelevantBlocks(dummy, infoSet, effectMap);
/* 345 */     addRelevantBlocks(dummyWild, infoSet, effectMap);
/* 346 */     addRelevantBlocks(current, infoSet, effectMap);
/* 347 */     addRelevantBlocks(currentWild, infoSet, effectMap);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addRelevant(ItemStack stack, HashSet<EffectInfo> infoSet, TreeMap<ItemStack, ArrayList<EffectInfo>> effectMap) {
/* 352 */     for (ItemStack effectStack : effectMap.keySet()) {
/* 353 */       if (stack != null && effectStack != null && stack.func_77973_b() == effectStack.func_77973_b() && 
/* 354 */         LootPPHelper.compareNBT((NBTBase)effectStack.func_77978_p(), (NBTBase)stack.func_77978_p()) && 
/* 355 */         effectMap.get(effectStack) != null) {
/* 356 */         infoSet.addAll(effectMap.get(effectStack));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addRelevantBlocks(LootPPHelper.BlockMeta blockInfo, HashSet<EffectInfo> infoSet, TreeMap<LootPPHelper.BlockMeta, ArrayList<EffectInfo>> effectMap) {
/* 365 */     for (LootPPHelper.BlockMeta effectBlock : effectMap.keySet()) {
/* 366 */       if (blockInfo != null && effectBlock != null && blockInfo.block == effectBlock.block && (effectBlock.meta == 32767 || blockInfo.meta == effectBlock.meta) && 
/* 367 */         effectMap.get(effectBlock) != null) {
/* 368 */         infoSet.addAll(effectMap.get(effectBlock));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void addEffectToEntity(EntityLivingBase entity, EffectInfo info) {
/* 375 */     addEffectToEntity(entity, info, false);
/*     */   }
/*     */   
/*     */   public static void addEffectToEntity(EntityLivingBase entity, EffectInfo info, boolean force) {
/* 379 */     if (info.effectType == EffectType.POTION && info.getEffectInfoPotion() != null) {
/* 380 */       addPotionEffect(entity, info.getEffectInfoPotion(), force);
/*     */     }
/*     */     
/* 383 */     if (info.effectType == EffectType.COMMAND && info.getEffectInfoCommand() != null) {
/* 384 */       addCommandEffect(entity, info.getEffectInfoCommand(), force);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addPotionEffect(EntityLivingBase entity, EffectInfoPotion info, boolean force) {
/* 389 */     PotionEffect existingEffect = entity.func_70660_b(info.effect);
/* 390 */     PotionEffect effect = new PotionEffect(info.effect.func_76396_c(), info.effectDuration, info.effectStrength, info.particleType.equalsIgnoreCase("faded"), !info.particleType.equalsIgnoreCase("none"));
/*     */ 
/*     */     
/* 393 */     if (existingEffect != null && existingEffect.func_76458_c() >= effect.func_76458_c() && info.effect != Potion.field_76439_r && (!force || info.effect == Potion.field_180152_w)) {
/* 394 */       if (existingEffect.func_76459_b() <= 1) {
/* 395 */         existingEffect.func_76452_a(effect);
/*     */       }
/*     */     } else {
/* 398 */       entity.func_70690_d(effect);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void addCommandEffect(EntityLivingBase entity, EffectInfoCommand info, boolean force) {
/* 403 */     MinecraftServer.func_71276_C().func_71187_D().func_71556_a((ICommandSender)new CommandSenderGeneric(entity.func_70005_c_(), entity.field_70170_p, new Vec3(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v)), info.command);
/*     */   }
/*     */ 
/*     */   
/*     */   public enum EffectType
/*     */   {
/* 409 */     POTION,
/* 410 */     COMMAND;
/*     */   }
/*     */   
/*     */   public static abstract class EffectInfo
/*     */   {
/*     */     public float probability;
/*     */     public GiveEffects.EffectType effectType;
/* 417 */     public ArrayList<ItemStack> alsoEquipped = new ArrayList<ItemStack>();
/*     */     
/*     */     public GiveEffects.EffectInfoPotion getEffectInfoPotion() {
/* 420 */       return (this instanceof GiveEffects.EffectInfoPotion) ? (GiveEffects.EffectInfoPotion)this : null;
/*     */     }
/*     */     
/*     */     public GiveEffects.EffectInfoCommand getEffectInfoCommand() {
/* 424 */       return (this instanceof GiveEffects.EffectInfoCommand) ? (GiveEffects.EffectInfoCommand)this : null;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class EffectInfoPotion extends EffectInfo {
/*     */     public Potion effect;
/*     */     public int effectDuration;
/*     */     public int effectStrength;
/*     */     public String particleType;
/*     */     
/*     */     public EffectInfoPotion() {
/* 435 */       this(Potion.field_76424_c, 0, 0, 0.0F, "normal");
/*     */     }
/*     */     
/*     */     public EffectInfoPotion(Potion potion, int duration, int strength, float chance, String particles) {
/* 439 */       this.effect = potion;
/* 440 */       this.effectDuration = duration;
/* 441 */       this.effectStrength = strength;
/* 442 */       this.probability = chance;
/* 443 */       this.particleType = particles;
/* 444 */       this.effectType = GiveEffects.EffectType.POTION;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 449 */       String toReturn = "{id: " + this.effect + ", duration: " + this.effectDuration + ", strength: " + this.effectStrength + ", probability: " + this.probability + ", particles: " + this.particleType;
/*     */       
/* 451 */       if (!this.alsoEquipped.isEmpty()) {
/* 452 */         toReturn = toReturn + ", also:{ ";
/*     */         
/* 454 */         for (ItemStack stack : this.alsoEquipped) {
/* 455 */           toReturn = toReturn + Item.field_150901_e.func_177774_c(stack.func_77973_b()) + "-" + stack.func_77952_i() + " ";
/*     */         }
/*     */         
/* 458 */         toReturn = toReturn + "} ";
/*     */       } 
/* 460 */       return toReturn + "}";
/*     */     }
/*     */   }
/*     */   
/*     */   public static class EffectInfoCommand extends EffectInfo {
/*     */     public String command;
/*     */     
/*     */     public EffectInfoCommand(float probabilityToSet, String commandToSet) {
/* 468 */       this.probability = probabilityToSet;
/* 469 */       this.command = commandToSet;
/* 470 */       this.effectType = GiveEffects.EffectType.COMMAND;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 475 */       String toReturn = "{command: " + this.command + ", probability: " + this.probability;
/*     */       
/* 477 */       if (!this.alsoEquipped.isEmpty()) {
/* 478 */         toReturn = toReturn + ", also:{ ";
/*     */         
/* 480 */         for (ItemStack stack : this.alsoEquipped) {
/* 481 */           toReturn = toReturn + Item.field_150901_e.func_177774_c(stack.func_77973_b()) + "-" + stack.func_77952_i() + " ";
/*     */         }
/*     */         
/* 484 */         toReturn = toReturn + "} ";
/*     */       } 
/* 486 */       return toReturn + "}";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\ccpublic\Downloads\Loot++-1.7.1_for_1.8.jar!\com\tmtravlr\lootplusplus\effects\GiveEffects.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */